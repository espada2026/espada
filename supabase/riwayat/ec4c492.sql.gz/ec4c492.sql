-- ============================================================================
-- SIGARDA: skema database Supabase
--
-- Jalankan SELURUH berkas ini sekali di Supabase > SQL Editor (New query > tempel > Run).
--
-- PERINGATAN: berkas ini MENGHAPUS tabel SIGARDA yang sudah ada lalu membuatnya ulang.
-- Aman dipakai pada proyek yang masih kosong. Jangan dijalankan pada proyek yang sudah berisi
-- data sungguhan kecuali Anda memang ingin mengosongkannya.
--
-- Prinsip keamanan:
--   * Semua tabel memakai Row Level Security. Pengguna hanya BOLEH MEMBACA data sesuai perannya.
--   * TIDAK ADA pengguna yang boleh menulis langsung ke tabel. Semua perubahan lewat fungsi
--     sg_* (security definer) yang memeriksa peran dan menerapkan aturan SKU di server.
--   * Fungsi *_internal hanya bisa dipanggil oleh Edge Function (service_role).
-- ============================================================================

set check_function_bodies = off;

-- ---------------------------------------------------------------------------
-- 0. Bersihkan versi lama
-- ---------------------------------------------------------------------------
drop table if exists public.siaga_garuda, public.tkk_siaga, public.tabungan_cek, public.sfh_catatan, public.portofolio_snapshot, public.dokumen_templat, public.penegak_isian, public.sku_pra_uji,public.pengukuhan_dewan, public.pinsa_tugas, public.bina_damping, public.kepengurusan_log, public.penugasan_peserta, public.penugasan_log, public.penugasan_rombel, public.guru_agama,
  public.naik_kelas_log, public.naik_kelas_batch, public.notifikasi, public.push_langganan, public.push_konfigurasi, public.keepalive_konfigurasi, public.terbit_ulang_konfigurasi,
  public.dokumen_terbit, public.dokumen_urut, public.iuran_kas, public.iuran_log, public.iuran, public.asisten_iuran,
  public.sesi_ujian_peserta, public.sesi_ujian_butir, public.sesi_ujian, public.sertifikat_tingkat, public.sku_penilaian, public.instrumen_panduan, public.instrumen_penguji, public.instrumen_kriteria, public.instrumen,
  public.raport, public.sidang_dk, public.sidang_urut, public.pengaturan,
  public.materi, public.portofolio_jurnal, public.portofolio,
  public.absensi_hadir, public.absensi_sesi, public.sku_riwayat, public.sku_progress,
  public.login_gagal, public.sku_unit, public.sku_butir, public.pf_item, public.profiles cascade;

do $$
declare r record;
begin
  for r in
    select p.oid::regprocedure as f from pg_proc p
    where p.pronamespace = 'public'::regnamespace and (p.proname like 'sg\_%' or p.proname = 'peran')
  loop
    execute 'drop function if exists ' || r.f || ' cascade';
  end loop;
end $$;

drop schema if exists sigarda cascade;
create schema sigarda;
grant usage on schema sigarda to authenticated, service_role;

-- Tanggal hari ini menurut WIB (server Supabase memakai UTC; tanpa ini "hari ini" salah sebelum pukul 07.00 WIB)
create function sigarda.hari_ini() returns date language sql stable as
$$ select (now() at time zone 'Asia/Jakarta')::date $$;

-- ---------------------------------------------------------------------------
-- 1. Tabel
-- ---------------------------------------------------------------------------
create table public.profiles (
  id uuid primary key default gen_random_uuid(),                 -- sama dengan auth.users.id untuk akun yang dapat masuk; anggota tanpa akun (anak Siaga) memakai id acak. Tanpa FK ke auth.users: hapus akun menghapus profil lewat pemicu profil_hapus_bersama_akun
  username text not null unique check (username ~ '^[a-z0-9][a-z0-9._-]{2,31}$'),  -- NIS untuk Penegak
  role text not null check (role in ('peserta','penguji','admin')),
  nama text not null check (char_length(btrim(nama)) between 1 and 120),
  nis text unique, kelas text, sangga text,
  agama text check (agama in ('Islam','Katolik','Protestan','Hindu','Buddha','Khonghucu')),
  jabatan text check (jabatan in ('Dewan Ambalan','Pembina','Admin Gudep')),
  calon_garuda date,
  nta text,                                                        -- Nomor Tanda Anggota Pramuka (opsional; diisi saat sidang)
  jabatan_dewan text check (jabatan_dewan is null or (char_length(jabatan_dewan) between 2 and 60 and jabatan_dewan !~ '[[:cntrl:]<>]')),  -- jabatan Dewan Ambalan (isian bebas; Pradana dan Pradani berfungsi khusus) pada akun PENEGAK; akun Dewan lama (role penguji) hanya sampai diarsipkan
  jenis_kelamin text check (jenis_kelamin in ('L','P')),          -- L = laki-laki, P = perempuan; semua peran; kosong pada anggota lama sampai dilengkapi Admin
  whatsapp text check (whatsapp is null or whatsapp ~ '^[0-9 +()./-]{8,20}$'),   -- diisi sendiri oleh pemilik akun (tahap L5); hanya format yang diperiksa, bukan keaktifan nomor
  status text not null default 'aktif' check (status in ('aktif','nonaktif','alumni')),   -- Penegak: nonaktif = tidak melanjutkan Pramuka (masih siswa), alumni = sudah lulus; keduanya hanya dapat dilihat
  status_pada date,                                                -- sejak kapan status ini berlaku
  lulus_ta text check (lulus_ta is null or lulus_ta ~ '^[0-9]{4}/[0-9]{4}$'),   -- tahun ajaran kelulusan (angkatan), hanya alumni
  pinsa boolean not null default false,                           -- Pimpinan Sangga (Penegak Calon Laksana ke atas, dipilih Bina Damping rombelnya); satu Pinsa per sangga per rombel; hilang sendiri bila pindah rombel/sangga atau tidak aktif
  tanpa_akun boolean not null default false,                      -- anggota Siaga yang datanya dikelola Pembina (tanpa auth.users, PIN, WhatsApp, atau isian mandiri)
  perindukan text check (perindukan is null or (char_length(perindukan) between 1 and 40 and perindukan !~ '[[:cntrl:]<>]')),   -- Siaga: kelompok besar (3-4 barung)
  barung text check (barung is null or (char_length(barung) between 1 and 40 and barung !~ '[[:cntrl:]<>]')),                   -- Siaga: kelompok 6-8 anak di dalam perindukan
  wajib_ganti_pin boolean not null default true,
  pin_direset_oleh uuid references public.profiles(id) on delete set null,
  pin_direset_pada timestamptz,
  pin_diubah timestamptz,
  dibuat date not null default sigarda.hari_ini(),
  -- Penegak: hanya NIS dan rombel yang wajib sejak akun dibuat; sangga (dibagi Pembina/Bina Damping) dan agama (diisi Penegak sendiri, dijaga pemicu tolak_peserta_tak_aktif: tanpa agama tidak ada progres SKU) boleh kosong.
  constraint profil_peserta check (role <> 'peserta' or (kelas is not null and jabatan is null and (nis is not null or tanpa_akun))),
  constraint profil_tanpa_akun check (not tanpa_akun or (role = 'peserta' and jabatan_dewan is null and not pinsa)),
  constraint profil_barung check (barung is null or perindukan is not null),
  constraint profil_penguji check (role <> 'penguji' or jabatan in ('Dewan Ambalan','Pembina')),
  constraint profil_admin check (role <> 'admin' or jabatan = 'Admin Gudep'),
  constraint profil_nta check (nta is null or nta ~ '^[0-9A-Za-z./ -]{1,40}$'),
  constraint profil_jabatan_dewan check (jabatan_dewan is null or role = 'peserta' or (role = 'penguji' and jabatan = 'Dewan Ambalan')),
  constraint profil_pinsa check (not pinsa or role = 'peserta')
);
-- ===== Jabatan tunggal Dewan Ambalan (Fase A): indeks =====
-- Pradana, Pradani, dan Pemangku Adat masing-masing hanya satu pemegang (Pemangku Adat = ketua sidang Dewan Kehormatan; Pradana dan Pradani
-- menandatangani Surat Tanda Lulus). Daftar jabatan tunggal sama dengan sigarda.jabatan_tunggal.
create unique index profil_pradana_pradani_unik on public.profiles (jabatan_dewan) where jabatan_dewan in ('Pradana','Pradani','Pemangku Adat');
-- ===== akhir indeks jabatan tunggal =====
-- Satu Pinsa untuk tiap sangga di dalam satu rombel (nama sangga tanpa membedakan huruf besar/kecil)
create unique index profil_pinsa_unik on public.profiles (kelas, lower(sangga)) where pinsa;

-- Katalog (diisi otomatis di bagian akhir berkas ini dari data aplikasi)
create table public.sku_butir (
  id text primary key,                     -- BAN-05
  tingkat text not null check (tingkat in ('Bantara','Laksana','Mula','Bantu','Tata')),   -- Bantara/Laksana = Penegak; Mula/Bantu/Tata = Siaga (SK Kwarnas 119/2011)
  no int not null,
  teks text not null
);
create table public.sku_unit (
  id text primary key,                     -- BAN-05 atau BAN-01-ISL-1
  butir_id text not null references public.sku_butir(id),
  tingkat text not null,
  butir_no int not null,
  agama text,                              -- null = berlaku untuk semua agama
  sub int
);
create table public.pf_item (
  id text primary key                      -- PF-01 sampai PF-26
);

create table public.sku_progress (
  peserta_id uuid not null references public.profiles(id) on delete cascade,
  sku_id text not null references public.sku_unit(id),
  status text not null default 'belum' check (status in ('belum','diajukan','proses','ulang','lulus')),
  jadwal date,
  penguji_id uuid references public.profiles(id) on delete set null,
  tanggal_uji date,
  nilai text check (nilai in ('Sangat baik','Baik','Cukup')),
  catatan text, catatan_peserta text,
  verifikasi text, diverifikasi_pada timestamptz,
  verifikasi_token text check (verifikasi_token ~ '^[0-9a-f]{32}$'),   -- token acak 128 bit untuk QR; dibuat saat lulus, dihapus bila tidak lagi lulus
  diubah timestamptz not null default now(),
  primary key (peserta_id, sku_id)
);
create unique index on public.sku_progress (verifikasi_token) where verifikasi_token is not null;
-- Pencarian kode pendek VRF- pada halaman verifikasi publik (sg_verifikasi_kode). Tidak unik: kode 28 bit berasal dari hash dan dapat kembar.
create index sku_progress_verifikasi_idx on public.sku_progress (verifikasi) where verifikasi is not null;
create table public.sku_riwayat (
  id bigint generated always as identity primary key,
  peserta_id uuid not null references public.profiles(id) on delete cascade,
  sku_id text not null,
  waktu timestamptz not null default now(),
  teks text not null,
  oleh uuid references public.profiles(id) on delete set null
);
create index on public.sku_riwayat (peserta_id);

create table public.absensi_sesi (
  tanggal date primary key,   -- hari latihan apa pun (Siaga tidak hanya berlatih pada hari Jumat)
  dibuat_oleh uuid references public.profiles(id) on delete set null,
  dibuat_pada timestamptz not null default now()
);
create table public.absensi_hadir (
  tanggal date not null references public.absensi_sesi(tanggal) on delete cascade,
  peserta_id uuid not null references public.profiles(id) on delete cascade,
  status text not null check (status in ('H','I','S','A')),
  oleh uuid references public.profiles(id) on delete set null,
  waktu timestamptz not null default now(),
  primary key (tanggal, peserta_id)
);
create index on public.absensi_hadir (peserta_id);

-- ===== Iuran bumbung kepramukaan: tabel =====
-- Dicatat Dewan Ambalan atau asisten bendahara (Penegak Calon Laksana yang ditunjuk) pada sesi latihan Jumat. Satu baris per Penegak per Jumat
-- yang berisi iuran (jumlah > 0); tidak ada baris berarti tidak iuran. Terpisah dari status absensi (yang izin atau sakit boleh menitip).
-- jenis: 'rutin' = dibayar pada Jumat itu; 'susulan' = ditebus belakangan untuk Jumat itu (mis. sekaligus saat ujian SKU).
create table public.iuran (
  tanggal date not null references public.absensi_sesi(tanggal) on delete cascade,
  peserta_id uuid not null references public.profiles(id) on delete cascade,
  jumlah int not null check (jumlah between 1 and 1000000),
  jenis text not null default 'rutin' check (jenis in ('rutin','susulan')),
  oleh uuid references public.profiles(id) on delete set null,
  waktu timestamptz not null default now(),
  primary key (tanggal, peserta_id)
);
create index on public.iuran (peserta_id);
-- Riwayat setiap perubahan iuran (hanya bertambah). Terbaca pengurus; tidak dapat diubah atau dihapus lewat API.
create table public.iuran_log (
  id bigint generated always as identity primary key,
  tanggal date not null,
  peserta_id uuid not null references public.profiles(id) on delete cascade,
  jumlah_lama int,
  jumlah_baru int,
  jenis text not null,
  oleh uuid references public.profiles(id) on delete set null,
  waktu timestamptz not null default now()
);
create index on public.iuran_log (tanggal);
-- Tutup kas per pertemuan: total uang fisik yang dihitung, untuk dicocokkan dengan jumlah catatan iuran.
create table public.iuran_kas (
  tanggal date primary key references public.absensi_sesi(tanggal) on delete cascade,
  total_fisik int not null check (total_fisik between 0 and 100000000),
  catatan text not null default '' check (char_length(catatan) <= 300),
  oleh uuid references public.profiles(id) on delete set null,
  waktu timestamptz not null default now()
);
-- Asisten bendahara: Penegak yang ditunjuk untuk membantu mencatat iuran (tidak dapat mencatat iurannya sendiri).
create table public.asisten_iuran (
  peserta_id uuid primary key references public.profiles(id) on delete cascade,
  ditunjuk_oleh uuid references public.profiles(id) on delete set null,
  ditunjuk_pada timestamptz not null default now()
);
-- ===== Tabungan Siaga (Fase 3): tabel =====
-- Tabungan Siaga (Pramuka Siaga, Fase 3; SK Kwarnas 119/2011 butir 4 tiap tingkat: punya buku tabungan dan menabung teratur beberapa minggu; kebiasaan menabung SK 186/1979).
-- Uang tabungan milik anak dan disimpan di bukunya sendiri, BUKAN di aplikasi: satu baris = pada tanggal itu Pembina memeriksa buku tabungan dan melihat setoran minggu itu.
-- Tidak ada baris = tidak diperiksa. Minggu menabung dihitung aplikasi dari baris-baris ini (src/lib/tabunganLogic.js).
create table public.tabungan_cek (
  peserta_id uuid not null references public.profiles(id) on delete cascade,
  tanggal date not null check (tanggal >= date '2015-01-01'),
  jumlah int not null check (jumlah between 1 and 100000000),
  catatan text not null default '' check (char_length(catatan) <= 200),
  oleh uuid references public.profiles(id) on delete set null,
  waktu timestamptz not null default now(),
  primary key (peserta_id, tanggal)
);
-- ===== akhir tabel tabungan =====

-- ===== akhir tabel iuran =====
-- ===== Penugasan penguji per rombel: tabel =====
-- Admin Gudep menetapkan Pembina dan Dewan Ambalan yang bertugas menguji tiap rombel, per tahun ajaran (dikelola lewat sg_penugasan_*).
-- Fase 1a hanya menyimpan dan menampilkan penugasan; penegakannya (siapa yang boleh dipilih Penegak) menyusul di fase 1b.
-- Rombel tanpa penugasan tetap memakai aturan lama (semua penguji) sampai Admin mengatur atau menyalin dari tahun lalu.
create table public.penugasan_rombel (
  tahun_ajaran text not null check (tahun_ajaran ~ '^[0-9]{4}/[0-9]{4}$'),
  rombel text not null check (rombel ~ '^(X|XI|XII)-(0[1-9]|10)$'),
  penguji_id uuid not null references public.profiles(id) on delete cascade,
  ditetapkan_oleh uuid references public.profiles(id) on delete set null,
  ditetapkan_pada timestamptz not null default now(),
  primary key (tahun_ajaran, rombel, penguji_id)
);
create index penugasan_rombel_penguji_idx on public.penugasan_rombel (penguji_id);
-- Riwayat setiap perubahan penugasan (hanya bertambah). Nama disalin agar riwayat tetap terbaca setelah akun dihapus.
create table public.penugasan_log (
  id bigint generated always as identity primary key,
  waktu timestamptz not null default now(),
  tahun_ajaran text not null,
  rombel text not null,
  penguji_id uuid references public.profiles(id) on delete set null,
  penguji_nama text not null,
  tindakan text not null check (tindakan in ('tambah','hapus')),
  catatan text not null default '' check (char_length(catatan) <= 200),
  oleh uuid references public.profiles(id) on delete set null,
  oleh_nama text not null default '',
  peserta_id uuid references public.profiles(id) on delete set null,     -- terisi bila penugasan khusus satu Penegak (rombel = kelas Penegak saat itu)
  peserta_nama text
);
create index penugasan_log_ta_idx on public.penugasan_log (tahun_ajaran, id);
-- ===== Dewan Ambalan sebagai atribut Penegak: tabel =====
-- Penugasan KHUSUS satu Penegak (pengecualian): bila sebuah Penegak punya baris di sini pada tahun ajaran berjalan, hanya penguji itu yang sah untuk
-- Penegak tersebut (menggantikan penugasan rombelnya). Contoh: pindah rombel di tengah tahun, Pembina cuti panjang, konflik kepentingan, Penegak berjabatan Dewan.
-- Diatur Pembina dan Admin Gudep lewat sg_penugasan_peserta_atur; riwayat di penugasan_log.
create table public.penugasan_peserta (
  tahun_ajaran text not null check (tahun_ajaran ~ '^[0-9]{4}/[0-9]{4}$'),
  peserta_id uuid not null references public.profiles(id) on delete cascade,
  penguji_id uuid not null references public.profiles(id) on delete cascade,
  ditetapkan_oleh uuid references public.profiles(id) on delete set null,
  ditetapkan_pada timestamptz not null default now(),
  primary key (tahun_ajaran, peserta_id, penguji_id)
);
create index penugasan_peserta_penguji_idx on public.penugasan_peserta (penguji_id);
-- Riwayat kepengurusan Dewan Ambalan (hanya bertambah): siapa memegang jabatan apa, kapan diberikan, kapan dicabut dan mengapa. Nama disalin agar tetap terbaca.
create table public.kepengurusan_log (
  id bigint generated always as identity primary key,
  waktu timestamptz not null default now(),
  peserta_id uuid references public.profiles(id) on delete set null,
  peserta_nama text not null,
  nis text,
  tindakan text not null check (tindakan in ('beri','ganti','cabut')),
  jabatan_lama text,
  jabatan_baru text,
  alasan text not null default '' check (char_length(alasan) <= 200),
  oleh uuid references public.profiles(id) on delete set null,
  oleh_nama text not null default ''
);
create index kepengurusan_log_waktu_idx on public.kepengurusan_log (id);
-- ===== akhir tabel dewan penegak =====
-- ===== Pengukuhan Dewan Ambalan (Fase A): tabel =====
-- Pengukuhan kepengurusan Dewan Ambalan (ketua dan wakil ketua) oleh Ketua Kwartir Ranting: satu catatan per tahun ajaran. Dasar: AD/ART Munas 2023, Anggaran Rumah Tangga
-- Pasal 51 ayat (2) huruf a (ditetapkan berdasarkan rekomendasi Ketua Majelis Pembimbing Gugusdepan dan dikukuhkan dengan surat keputusan Ketua Kwartir Ranting).
-- Nomor dan tanggal rekomendasi Ketua Mabigus opsional, tetapi harus diisi berpasangan.
create table public.pengukuhan_dewan (
  tahun_ajaran text primary key check (tahun_ajaran ~ '^[0-9]{4}/[0-9]{4}$'),
  nomor_sk text not null check (char_length(nomor_sk) between 1 and 80 and nomor_sk !~ '[[:cntrl:]<>]'),
  tanggal_sk date not null,
  rekomendasi_nomor text not null default '' check (char_length(rekomendasi_nomor) <= 80 and rekomendasi_nomor !~ '[[:cntrl:]<>]'),
  rekomendasi_tanggal date,
  catatan text not null default '' check (char_length(catatan) <= 200),
  diubah_oleh uuid references public.profiles(id) on delete set null,
  diubah_pada timestamptz not null default now(),
  constraint pengukuhan_rekomendasi_pasangan check ((rekomendasi_nomor = '') = (rekomendasi_tanggal is null))
);
-- ===== akhir tabel pengukuhan dewan =====
-- ===== Pinsa dan Bina Damping (fase B): tabel =====
-- Bina Damping: 2 orang per rombel per tahun ajaran, Penegak berjabatan Dewan Ambalan yang minimal Calon Laksana (utamakan yang sudah Laksana), ditunjuk lewat
-- sg_bina_damping_atur. Satu orang hanya satu rombel per tahun ajaran (persediaan pendamping terbatas). Tanpa kebijakan baca: dibaca lewat fungsi sg_* saja.
-- Baris hilang sendiri (pemicu profiles_bina_damping_bersih) bila Penegaknya nonaktif/alumni atau tidak lagi berjabatan Dewan.
create table public.bina_damping (
  tahun_ajaran text not null check (tahun_ajaran ~ '^[0-9]{4}/[0-9]{4}$'),
  rombel text not null check (rombel ~ '^(X|XI|XII)-(0[1-9]|10)$'),
  penegak_id uuid not null references public.profiles(id) on delete cascade,
  ditetapkan_oleh uuid references public.profiles(id) on delete set null,
  ditetapkan_pada timestamptz not null default now(),
  primary key (tahun_ajaran, rombel, penegak_id)
);
create unique index bina_damping_satu_rombel_idx on public.bina_damping (tahun_ajaran, penegak_id);
create index bina_damping_penegak_idx on public.bina_damping (penegak_id);
-- ===== akhir tabel pinsa bina damping =====
-- ===== Pinsa tertugas lintas rombel (persiapan uji coba 2 Okt 2026): tabel =====
-- Pinsa sebuah sangga dapat berasal dari anggota sangga itu sendiri (profiles.pinsa) ATAU dari Penegak Calon Laksana (Bantara selesai) yang DITUGASKAN menjadi anggota
-- sangga di rombel lain, mis. kakak kelas untuk sangga rombel Calon Bantara (keputusan pemilik gudep 26 Sep 2026). Satu orang satu sangga per tahun ajaran; paling banyak 2
-- penugasan per sangga (dijaga sg_pinsa_tugaskan). Tanpa kebijakan baca: dibaca lewat fungsi sg_sangga_rombel dan sg_pinsa_calon. Baris hilang sendiri bila Penegaknya
-- nonaktif/alumni (pemicu profiles_pinsa_tugas_bersih).
create table public.pinsa_tugas (
  tahun_ajaran text not null check (tahun_ajaran ~ '^[0-9]{4}/[0-9]{4}$'),
  rombel text not null check (rombel ~ '^(X|XI|XII)-(0[1-9]|10)$'),
  sangga text not null check (char_length(sangga) between 1 and 40 and sangga = btrim(sangga)),
  penegak_id uuid not null references public.profiles(id) on delete cascade,
  ditetapkan_oleh uuid references public.profiles(id) on delete set null,
  ditetapkan_pada timestamptz not null default now(),
  primary key (tahun_ajaran, penegak_id)
);
create index pinsa_tugas_sangga_idx on public.pinsa_tugas (tahun_ajaran, rombel, lower(sangga));
create index pinsa_tugas_ditetapkan_oleh_idx on public.pinsa_tugas (ditetapkan_oleh);
-- ===== akhir tabel pinsa tertugas =====
-- Guru agama di sekolah (per agama), rujukan surat pengantar bila tidak ada Pembina yang seagama dengan Penegak (dikelola Admin).
create table public.guru_agama (
  id bigint generated always as identity primary key,
  agama text not null check (agama in ('Islam','Katolik','Protestan','Hindu','Buddha','Khonghucu')),
  nama text not null check (char_length(btrim(nama)) between 1 and 120),
  keterangan text not null default '' check (char_length(keterangan) <= 200),
  diubah_oleh uuid references public.profiles(id) on delete set null,
  diubah_pada timestamptz not null default now()
);
create unique index guru_agama_unik on public.guru_agama (agama, lower(nama));
-- ===== akhir tabel penugasan =====

-- ===== Dokumen terbit: tabel =====
-- Dokumen resmi yang diterbitkan aplikasi dan keasliannya dapat diperiksa lewat QR (sg_verifikasi_token) atau kode VRF- (sg_verifikasi_kode).
-- Saat ini satu jenis: surat pengantar ke guru agama (butir agama Penegak yang tidak punya Pembina seagama). Surat dicetak untuk tanda tangan
-- dan stempel BASAH; QR hanya membuktikan surat itu benar diterbitkan aplikasi. Nama dan jabatan disalin (snapshot) agar tetap terbaca kelak.
-- Nomor berasal dari penghitung per jenis dan tahun (dokumen_urut, tidak pernah dipakai ulang) atau diisi manual.
create table public.dokumen_terbit (
  id bigint generated always as identity primary key,
  token text not null unique check (token ~ '^[0-9a-f]{32}$'),        -- token acak 128 bit untuk QR
  kode text not null check (kode ~ '^VRF-[0-9A-F]{7}$'),              -- kode pendek tercetak (hanya menjawab sah atau tidak)
  jenis text not null check (jenis in ('surat_pengantar_agama')),
  nomor text not null unique check (char_length(nomor) between 1 and 80),
  nomor_urut int,
  tanggal date not null,
  peserta_id uuid references public.profiles(id) on delete set null,
  peserta_nama text not null,
  penerbit text not null check (char_length(penerbit) between 1 and 120),
  dibuat_oleh uuid references public.profiles(id) on delete set null,
  dibuat_oleh_nama text not null,
  dibuat_oleh_jabatan text not null default '',
  penanda_tangan_nama text not null check (char_length(penanda_tangan_nama) between 1 and 120),
  penanda_tangan_jabatan text not null check (char_length(penanda_tangan_jabatan) between 1 and 80),
  payload jsonb not null default '{}'::jsonb,                         -- surat agama: { agama, nis, kelas, sangga, guru: { id, nama, keterangan }, butir: [id unit], catatan }
  dibuat_pada timestamptz not null default now(),
  dicabut_pada timestamptz,
  dicabut_oleh uuid references public.profiles(id) on delete set null,
  dicabut_alasan text not null default '' check (char_length(dicabut_alasan) <= 200)
);
create index dokumen_terbit_peserta_idx on public.dokumen_terbit (peserta_id, jenis);
create index dokumen_terbit_kode_idx on public.dokumen_terbit (kode);
create table public.dokumen_urut (          -- penghitung nomor dokumen per jenis dan tahun (tidak pernah dipakai ulang)
  jenis text not null,
  tahun int not null,
  terakhir int not null default 0,
  primary key (jenis, tahun)
);
-- ===== akhir tabel dokumen =====

-- ===== Notifikasi: tabel =====
-- Kotak Notifikasi di aplikasi (semua peran) dan bahan Web Push. Baris dibuat HANYA oleh pemicu dan fungsi server (sigarda.notif_buat);
-- pemilik hanya membaca dan menandai dibaca (sg_notifikasi_tandai). Isi singkat dan tanpa hasil lulus/ulang. `kunci` mencegah notifikasi ganda
-- untuk peristiwa yang sama (pengingat, jadwal sesi). push_status diisi Edge Function notif-push.
create table public.notifikasi (
  id bigint generated always as identity primary key,
  penerima_id uuid not null references public.profiles(id) on delete cascade,
  jenis text not null check (jenis in ('ajukan','alih','mulai','hasil','pengingat','lama','sesi','surat','tes','eskalasi','agenda','musyawarah','kegiatan','pra_uji','tkk','beranda')),   -- 'tes' = notifikasi uji dari tombol di halaman Notifikasi; 'eskalasi' = tangga pengingat tahap L5; 'agenda' = pengingat H-30/H-7/H-1 tahap L6; 'musyawarah' = usulan/pengingat Musyawarah Ambalan tahap L6b; 'kegiatan' = usulan/pengingat 10 jenis kegiatan lain tahap L6b; 'beranda' = pengajuan/tinjauan Berita, Prestasi, Galeri di Kelola Beranda (Fase 2 landing page, Fase 3)
  judul text not null check (char_length(judul) between 1 and 120),
  isi text not null default '' check (char_length(isi) <= 300),
  tautan jsonb not null default '{}'::jsonb,                        -- { tab: 'antrian' | 'sku' | 'beranda' | 'cetak' }
  kunci text check (kunci is null or char_length(kunci) <= 160),
  dibuat timestamptz not null default now(),
  dibaca_pada timestamptz,
  push_status text check (push_status in ('dikirim','gagal'))
);
create index notifikasi_penerima_idx on public.notifikasi (penerima_id, id desc);
create unique index notifikasi_kunci_unik on public.notifikasi (penerima_id, kunci) where kunci is not null;
-- Perangkat yang berlangganan Web Push. endpoint unik: perangkat yang sama dialihkan ke akun yang MASUK terakhir; menekan Keluar menghapusnya.
-- Tanpa kebijakan baca: hanya fungsi server (kunci langganan tidak boleh bocor ke klien lain).
create table public.push_langganan (
  id bigint generated always as identity primary key,
  penerima_id uuid not null references public.profiles(id) on delete cascade,
  endpoint text not null unique check (char_length(endpoint) between 20 and 1000),
  p256dh text not null check (char_length(p256dh) between 20 and 200),
  auth text not null check (char_length(auth) between 8 and 100),
  agen text not null default '' check (char_length(agen) <= 200),
  dibuat timestamptz not null default now(),
  diperbarui timestamptz not null default now()
);
create index push_langganan_penerima_idx on public.push_langganan (penerima_id);
-- Satu baris: alamat fungsi notif-push, rahasia bersama, dan kunci publik VAPID. Diisi pemilik proyek lewat sigarda.push_atur di SQL Editor; tanpa kebijakan.
create table public.push_konfigurasi (
  id boolean primary key default true check (id),
  url text not null check (url ~ '^https://'),
  rahasia text not null check (char_length(rahasia) >= 16),
  kunci_publik text not null check (kunci_publik ~ '^[A-Za-z0-9_-]{60,120}$'),
  diubah timestamptz not null default now()
);
-- ===== akhir tabel notifikasi =====

-- ===== Naik kelas dan status anggota: tabel =====
-- Kolom status, status_pada, dan lulus_ta ada di profiles. Satu kenaikan kelas massal = satu baris naik_kelas_batch + satu baris naik_kelas_log per Penegak
-- (hanya bertambah; menyimpan keadaan sebelum dan sesudah agar dapat dibatalkan). Perubahan status satu orang tercatat di naik_kelas_log tanpa batch.
create table public.naik_kelas_batch (
  id bigint generated always as identity primary key,
  waktu timestamptz not null default now(),
  tahun_ajaran text not null check (tahun_ajaran ~ '^[0-9]{4}/[0-9]{4}$'),           -- tahun ajaran yang baru dimulai
  ringkasan jsonb not null default '{}'::jsonb,
  oleh uuid references public.profiles(id) on delete set null,
  oleh_nama text not null default '',
  dibatalkan_pada timestamptz,
  dibatalkan_oleh uuid references public.profiles(id) on delete set null
);
create table public.naik_kelas_log (
  id bigint generated always as identity primary key,
  batch_id bigint references public.naik_kelas_batch(id) on delete cascade,
  waktu timestamptz not null default now(),
  peserta_id uuid references public.profiles(id) on delete set null,
  peserta_nama text not null,
  nis text not null default '',
  aksi text not null check (aksi in ('lanjut','tidak_lanjut','lulus','aktifkan','nonaktifkan')),
  dari_kelas text, ke_kelas text,
  dari_status text not null check (dari_status in ('aktif','nonaktif','alumni')),
  ke_status text not null check (ke_status in ('aktif','nonaktif','alumni')),
  dari_status_pada date,
  dari_lulus_ta text,
  catatan text not null default '' check (char_length(catatan) <= 200),
  oleh uuid references public.profiles(id) on delete set null,
  oleh_nama text not null default ''
);
create index naik_kelas_log_batch_idx on public.naik_kelas_log (batch_id);
create index naik_kelas_log_peserta_idx on public.naik_kelas_log (peserta_id, id);
-- ===== akhir tabel naik kelas =====

-- ===== Agenda tahunan (tahap L6): tabel =====
-- Kegiatan tahunan Ambalan: 6 jenis baku (musyawarah, naik_kelas, sidang, tiga pelantikan) atau 'lainnya' (judul bebas).
-- peserta_terkait (opsional): Penegak yang ikut diberi tahu pengingat H-30/H-7/H-1 selain semua pengurus (mis. calon sidang/pelantikan).
-- lewati_batas: HANYA berlaku untuk jenis 'musyawarah' dan HANYA dapat diset true oleh Pembina (bukan Admin) -- baik lewat sg_agenda_simpan
-- langsung, atau (jalur resmi) lewat sg_kegiatan_tinjau saat menyetujui usulan Musyawarah Ambalan (lihat blok kegiatan_usulan di bawah)
-- -- melewati batas "harus sebelum 1 Juli tahun kedua" (pergantian kepengurusan sebelum tahun ajaran baru). Jenis lain yang didukung alur
-- usulan (pelantikan_bantara, pelantikan_laksana, dan 8 jenis di kegiatan_usulan) TIDAK punya batas keras, hanya pengingat.
create table public.agenda (
  id bigint generated always as identity primary key,
  tahun_ajaran text not null check (tahun_ajaran ~ '^[0-9]{4}/[0-9]{4}$'),
  jenis text not null check (jenis in (
    'musyawarah','naik_kelas','sidang','pelantikan_bantara','pelantikan_laksana','pelantikan_garuda','lainnya',
    'pengembaraan','perkemahan','gelora_saka_expo','gladi_tangguh_1','gladi_tangguh_2','penempuhan_sku_laksana','ptgd','pembekalan_dewan',
    'pesta_siaga','persari','pertemuan_siaga','pelantikan_siaga'
  )),
  judul text not null check (char_length(btrim(judul)) between 1 and 120),
  tanggal date not null,
  keterangan text not null default '' check (char_length(keterangan) <= 500),
  peserta_terkait uuid[] not null default '{}',
  lewati_batas boolean not null default false,
  dibuat_oleh uuid references public.profiles(id) on delete set null,
  dibuat_pada timestamptz not null default now(),
  diubah_pada timestamptz not null default now()
);
create index if not exists agenda_tahun_ajaran_idx on public.agenda (tahun_ajaran);
create index if not exists agenda_tanggal_idx on public.agenda (tanggal);
-- ===== akhir tabel agenda =====

-- ===== Usulan kegiatan (tahap L6b): tabel =====
-- Alur resmi di dalam aplikasi untuk kegiatan tahunan yang perlu diusulkan Dewan Ambalan dan disetujui Pembina (Musyawarah Ambalan dan
-- 10 kegiatan lain, lihat JENIS_USULAN di src/lib/kegiatanLogic.js): hanya Pradana atau Pradani (Penegak aktif berjabatan itu, atau akun
-- Dewan lama yang masih menjabat) dapat mengajukan, disertai jenis, tanggal usulan, dan tautan dokumen proposal (Google Drive,
-- dicetak/ditandatangani basah di luar aplikasi seperti dokumen lain). Hanya Pembina yang dapat meninjau: setuju (catatan opsional) atau
-- tolak (catatan WAJIB). Maksimal satu usulan berstatus 'menunggu' per (tahun ajaran, jenis) -- ditegakkan indeks unik parsial, harus
-- ditinjau dulu sebelum diajukan lagi untuk jenis yang sama. Persetujuan otomatis membuat entri di public.agenda (lihat sg_kegiatan_tinjau).
create table public.kegiatan_usulan (
  id bigint generated always as identity primary key,
  tahun_ajaran text not null check (tahun_ajaran ~ '^[0-9]{4}/[0-9]{4}$'),
  jenis text not null check (jenis in (
    'musyawarah','pelantikan_bantara','pelantikan_laksana','pengembaraan','perkemahan','gelora_saka_expo',
    'gladi_tangguh_1','gladi_tangguh_2','penempuhan_sku_laksana','ptgd','pembekalan_dewan'
  )),
  tanggal_usul date not null,
  dokumen_url text not null check (dokumen_url ~ '^https?://' and char_length(dokumen_url) <= 500),
  catatan text not null default '' check (char_length(catatan) <= 500),
  status text not null default 'menunggu' check (status in ('menunggu','disetujui','ditolak')),
  diajukan_oleh uuid references public.profiles(id) on delete set null,
  diajukan_oleh_nama text not null default '',
  diajukan_pada timestamptz not null default now(),
  ditinjau_oleh uuid references public.profiles(id) on delete set null,
  ditinjau_oleh_nama text not null default '',
  ditinjau_pada timestamptz,
  catatan_tinjauan text not null default '' check (char_length(catatan_tinjauan) <= 500),
  diping_pada timestamptz,
  agenda_id bigint references public.agenda(id) on delete set null,
  constraint kegiatan_usulan_tolak_wajib_catatan check (status <> 'ditolak' or char_length(btrim(catatan_tinjauan)) > 0)
);
create index if not exists kegiatan_usulan_tahun_ajaran_idx on public.kegiatan_usulan (tahun_ajaran);
create unique index if not exists kegiatan_usulan_menunggu_unik on public.kegiatan_usulan (tahun_ajaran, jenis) where status = 'menunggu';
-- ===== akhir tabel usulan kegiatan =====

create table public.portofolio (
  peserta_id uuid not null references public.profiles(id) on delete cascade,
  item_id text not null references public.pf_item(id),
  status text not null default 'belum' check (status in ('belum','proses','siap')),
  catatan text not null default '', tautan text not null default '',
  catatan_penguji text not null default '',
  catatan_penguji_oleh uuid references public.profiles(id) on delete set null,
  diperbarui timestamptz not null default now(),
  primary key (peserta_id, item_id)
);
create table public.portofolio_jurnal (
  id bigint generated always as identity primary key,
  peserta_id uuid not null references public.profiles(id) on delete cascade,
  item_id text not null,
  waktu timestamptz not null default now(),
  teks text not null,
  oleh uuid references public.profiles(id) on delete set null
);
create index on public.portofolio_jurnal (peserta_id);

-- Materi SKU: hanya tautan ke file PDF di Google Drive (file tidak disimpan di sini)
create table public.materi (
  id uuid primary key default gen_random_uuid(),
  urutan int not null,
  judul text not null check (char_length(judul) between 1 and 120),
  deskripsi text not null default '' check (char_length(deskripsi) <= 400),
  tautan text not null check (tautan ~ '^https?://' and char_length(tautan) <= 600),
  file_id text not null unique check (file_id ~ '^[A-Za-z0-9_-]{15,120}$'),
  resource_key text not null default '' check (resource_key ~ '^[A-Za-z0-9_-]{0,80}$'),
  butir text[] not null default '{}',
  bagian jsonb not null default '[]' check (jsonb_typeof(bagian) = 'array' and jsonb_array_length(bagian) <= 60),
  dibuat date not null default sigarda.hari_ini(),
  dibuat_oleh uuid references public.profiles(id) on delete set null
);

-- Pengaturan aplikasi (pasangan kunci-nilai). Dibaca semua pengguna aktif; diubah hanya lewat sg_pengaturan_simpan.
create table public.pengaturan (
  kunci text primary key check (kunci ~ '^[a-z_]+\.[a-z_0-9]+$'),
  nilai jsonb not null,
  diubah_oleh uuid references public.profiles(id) on delete set null,
  diubah_pada timestamptz not null default now()
);

-- Sidang Dewan Kehormatan Ambalan: keputusan Lulus/Tidak Lulus SKU (Layak dilantik atau Ditunda/Remedi) per peserta dan tingkat.
-- Nama ketua dan sebutan jabatan dicatat pada saat sidang agar Berita Acara lama tidak berubah bila pengaturan diubah kelak.
create table public.sidang_urut (          -- penghitung nomor berita acara per tahun (tidak pernah dipakai ulang)
  tahun int primary key,
  terakhir int not null
);
create table public.sidang_dk (
  id int generated always as identity primary key,
  peserta_id uuid not null references public.profiles(id) on delete cascade,
  tingkat text not null check (tingkat in ('Bantara','Laksana')),
  tanggal date not null,
  keputusan text not null check (keputusan in ('layak','tunda')),
  magang text not null check (magang in ('memenuhi','tidak')),          -- masa magang / masa tamu ambalan
  tugas_adat text not null check (tugas_adat in ('lulus','tidak')),     -- tugas tambahan adat ambalan
  tugas_adat_ket text not null default '' check (char_length(tugas_adat_ket) <= 60),
  catatan text not null default '' check (char_length(catatan) <= 500),
  nomor_ba text not null check (char_length(nomor_ba) between 1 and 80),
  nomor_urut int,                                                        -- kosong bila nomor diisi manual
  capaian_lulus int not null,
  capaian_total int not null,
  butir_belum text[] not null default '{}',                              -- id unit SKU yang belum lulus saat sidang
  nta text not null default '' check (nta = '' or nta ~ '^[0-9A-Za-z./ -]{1,40}$'),
  ketua_nama text not null default '',
  ketua_sebutan text not null default '',
  dibuat_oleh uuid references public.profiles(id) on delete set null,
  dibuat_pada timestamptz not null default now(),
  token text unique check (token ~ '^[0-9a-f]{32}$'),                    -- QR verifikasi berita acara; dibuat saat dicetak (sg_sidang_token)
  kode text check (kode ~ '^VRF-[0-9A-F]{7}$')
);
create index sidang_dk_kode_idx on public.sidang_dk (kode);
create unique index sidang_dk_nomor on public.sidang_dk (nomor_ba);
create unique index sidang_dk_layak on public.sidang_dk (peserta_id, tingkat) where keputusan = 'layak';
create index on public.sidang_dk (peserta_id);
create index on public.sidang_dk (tanggal);

-- Nilai raport ekstrakurikuler Pramuka per Penegak per semester (dikelola Pembina dan Admin).
-- Skor dan predikat hitung SELALU dihitung server dari kehadiran, capaian SKU, dan sikap memakai pengaturan 'raport.pengaturan'.
-- Predikat akhir boleh diubah Pembina (dengan catatan); deskripsi dibuat otomatis sebagai saran lalu disunting dan ditandai final.
create table public.raport (
  peserta_id uuid not null references public.profiles(id) on delete cascade,
  tahun_ajaran text not null check (tahun_ajaran ~ '^\d{4}/\d{4}$'),
  semester text not null check (semester in ('ganjil','genap')),
  tingkat text not null check (tingkat in ('Bantara','Laksana')),      -- tingkat SKU yang dinilai pada semester itu
  sikap smallint check (sikap between 1 and 5),                        -- penilaian Pembina, skala 1-5
  karakter text[] not null default '{}' check (cardinality(karakter) <= 6),
  skk smallint check (skk between 0 and 99),                           -- jumlah SKK (keterangan, bukan syarat)
  kehadiran_persen smallint check (kehadiran_persen between 0 and 100),   -- kosong = belum ada absensi tercatat semester itu
  hadir smallint check (hadir between 0 and 100),
  pertemuan smallint check (pertemuan between 0 and 100),              -- pertemuan yang tercatat untuk peserta ini (H+I+S+A)
  capaian_lulus smallint not null check (capaian_lulus between 0 and 60),
  capaian_target smallint not null check (capaian_target between 1 and 60),
  skor smallint not null check (skor between 0 and 100),
  predikat_hitung text not null check (predikat_hitung in ('A','B','C','D')),
  predikat_akhir text check (predikat_akhir in ('A','B','C','D')),     -- kosong = mengikuti hasil hitung
  catatan_predikat text not null default '' check (char_length(catatan_predikat) <= 300),
  deskripsi text not null default '' check (char_length(deskripsi) <= 1200),
  status text not null default 'draf' check (status in ('draf','final')),
  diubah_oleh uuid references public.profiles(id) on delete set null,
  diubah_pada timestamptz not null default now(),
  primary key (peserta_id, tahun_ajaran, semester),
  constraint raport_final check (status <> 'final' or (sikap is not null and char_length(btrim(deskripsi)) > 0))
);
create index on public.raport (tahun_ajaran, semester);

-- Instrumen penilaian per unit SKU (butir; butir agama per sub-butir), disusun Pembina dan Admin.
-- Hanya instrumen berstatus 'ditetapkan' yang dipakai menilai dan terlihat Penegak (daftar kriteria saja). Instruksi dan panduan
-- penguji ada di tabel terpisah yang hanya terbaca pengurus. Butir tanpa instrumen ditetapkan tetap memakai alur penilaian lama.
create table public.instrumen (
  sku_id text primary key references public.sku_unit(id) on delete cascade,
  cara_uji text not null default '' check (char_length(cara_uji) <= 300),
  status text not null default 'draf' check (status in ('draf','ditetapkan')),
  diubah_oleh uuid references public.profiles(id) on delete set null,
  diubah_pada timestamptz not null default now()
);
create table public.instrumen_kriteria (
  id bigint generated always as identity primary key,
  sku_id text not null references public.instrumen(sku_id) on delete cascade,
  urutan smallint not null check (urutan between 1 and 20),
  jenis text not null check (jenis in ('Lisan','Praktik','Bukti kegiatan','Pengamatan')),
  teks text not null check (char_length(btrim(teks)) between 1 and 400),
  bobot smallint not null default 1 check (bobot between 1 and 5),
  wajib boolean not null default false,
  -- 'iuran' = nilai disarankan otomatis dari catatan iuran bumbung (hanya butir iuran: BAN-06 dan LAK-06); penguji boleh mengubah dengan alasan
  sumber text not null default 'manual' check (sumber in ('manual','iuran')),
  unique (sku_id, urutan) deferrable initially deferred
);
create index on public.instrumen_kriteria (sku_id);
create table public.instrumen_penguji (
  sku_id text primary key references public.instrumen(sku_id) on delete cascade,
  instruksi text not null default '' check (char_length(instruksi) <= 1500)
);
create table public.instrumen_panduan (
  kriteria_id bigint primary key references public.instrumen_kriteria(id) on delete cascade,
  panduan text not null default '' check (char_length(panduan) <= 1500)
);
-- Catatan tiap penilaian dengan instrumen (hanya bertambah). Rincian menyimpan salinan kriteria saat itu, jadi tetap terbaca
-- walaupun instrumen diubah kemudian.
create table public.sku_penilaian (
  id bigint generated always as identity primary key,
  peserta_id uuid not null references public.profiles(id) on delete cascade,
  sku_id text not null references public.sku_unit(id),
  waktu timestamptz not null default now(),
  penguji_id uuid references public.profiles(id) on delete set null,
  tanggal_uji date not null,
  rincian jsonb not null,
  skor smallint not null check (skor between 0 and 100),
  wajib_ok boolean not null,
  saran text not null check (saran in ('lulus','ulang')),
  hasil text not null check (hasil in ('lulus','ulang')),
  diganti boolean not null default false,
  catatan text not null default ''
);
create index on public.sku_penilaian (peserta_id, sku_id);

-- Token QR untuk Surat Tanda Lulus per tingkat (satu token per Penegak per tingkat). Sah selama seluruh butir tingkat itu masih lulus.
create table public.sertifikat_tingkat (
  token text primary key check (token ~ '^[0-9a-f]{32}$'),
  peserta_id uuid not null references public.profiles(id) on delete cascade,
  tingkat text not null constraint sertifikat_tingkat_tingkat_check check (tingkat in ('Bantara','Laksana','Mula','Bantu','Tata')),
  diterbitkan_oleh uuid references public.profiles(id) on delete set null,
  diterbitkan_pada timestamptz not null default now(),
  unique (peserta_id, tingkat)
);

-- ===== Berkas Calon Garuda (tahap L7): tabel =====
-- Tautan berbagi BACA-SAJA (tanpa login) untuk penilai kwarran/kwarcab meninjau berkas lengkap satu Calon Garuda (kartu SKU
-- Bantara+Laksana, 26 dokumen portofolio, jurnal) -- lihat sg_garuda_token_baca. Satu token AKTIF per peserta (indeks unik
-- parsial di bawah): membuat token baru (sg_garuda_token_buat) otomatis mencabut yang lama, jadi berbagi ulang = ganti
-- tautan, bukan menambah tautan lain. Tanpa kedaluwarsa: berlaku sampai dicabut manual oleh Pembina atau Admin.
-- BEDA TUJUAN dari sertifikat_tingkat/dokumen_terbit/sidang_dk (yang hanya menjawab RINGKASAN untuk membuktikan keaslian):
-- token ini adalah kredensial pemegang tautan yang memberi akses BACA ISI LENGKAP berkas, jadi SENGAJA TIDAK disertakan pada
-- sg_cadangan_admin() (mirip push_langganan/notifikasi -- lihat catatan di sana), berbeda dari sertifikat_tingkat yang aman
-- dicadangkan karena tokennya hanya untuk verifikasi.
create table public.garuda_berkas_token (
  id bigint generated always as identity primary key,
  peserta_id uuid not null references public.profiles(id) on delete cascade,
  token text not null unique check (token ~ '^[0-9a-f]{32}$'),
  dibuat_oleh uuid references public.profiles(id) on delete set null,
  dibuat_oleh_nama text not null default '',
  dibuat_pada timestamptz not null default now(),
  dicabut_pada timestamptz,
  dicabut_oleh uuid references public.profiles(id) on delete set null
);
create index if not exists garuda_berkas_token_peserta_idx on public.garuda_berkas_token (peserta_id);
create unique index if not exists garuda_berkas_token_aktif_unik on public.garuda_berkas_token (peserta_id) where dicabut_pada is null;
-- ===== akhir tabel berkas garuda =====

-- ===== Indeks kunci asing pada tabel besar (tahap indeks-fk) =====
-- Semua kolom ini berkunci asing ke profiles dengan on delete set null: tiap akun yang dihapus memindai seluruh tabel bila kolomnya tanpa indeks
-- (ketahuan dari saran Supabase Advisor: menghapus 850 akun butuh 7 detik). Hanya tabel yang besar atau akan besar; tabel log kecil sengaja tidak diberi indeks.
-- Kolom kunci asing ke katalog (sku_id, butir_id, item_id) tidak perlu: baris katalog tidak pernah dihapus. Dipakai migrasi indeks-fk.
create index if not exists sku_progress_penguji_idx on public.sku_progress (penguji_id);
create index if not exists sku_riwayat_oleh_idx on public.sku_riwayat (oleh);
create index if not exists sku_penilaian_penguji_idx on public.sku_penilaian (penguji_id);
create index if not exists absensi_hadir_oleh_idx on public.absensi_hadir (oleh);
create index if not exists iuran_oleh_idx on public.iuran (oleh);
create index if not exists iuran_log_oleh_idx on public.iuran_log (oleh);
create index if not exists iuran_log_peserta_idx on public.iuran_log (peserta_id);
create index if not exists naik_kelas_log_oleh_idx on public.naik_kelas_log (oleh);
create index if not exists portofolio_catatan_oleh_idx on public.portofolio (catatan_penguji_oleh);
create index if not exists portofolio_jurnal_oleh_idx on public.portofolio_jurnal (oleh);
-- ===== akhir indeks kunci asing =====

-- ===== Keep-alive Supabase (dari dalam database): tabel =====
-- Proyek Free tier dijeda setelah 7 hari tanpa aktivitas. pg_cron memanggil sigarda.keepalive_ping() tiap hari; fungsi itu meminta pg_net mengirim SATU
-- permintaan HTTP ke API proyek sendiri (fungsi publik sg_gudep_publik), sehingga tercatat sebagai lalu lintas API sungguhan. Satu baris; diisi pemilik
-- proyek SEKALI lewat sigarda.keepalive_atur di SQL Editor (kunci anon/publishable memang publik; JANGAN isi service_role). Tanpa kebijakan RLS.
create table public.keepalive_konfigurasi (
  id boolean primary key default true check (id),
  url text not null check (url ~ '^https://[a-z0-9.-]+\.[a-z]{2,}$'),
  kunci text not null check (char_length(kunci) between 20 and 500),
  diubah timestamptz not null default now(),
  ping_terakhir timestamptz,
  ping_id bigint,
  status_terakhir int,
  pesan_terakhir text
);
-- ===== akhir tabel keepalive =====

-- ===== Keep-alive Supabase (dari dalam database): fungsi =====
-- Pemilik proyek menjalankan SEKALI di SQL Editor: select sigarda.keepalive_atur('https://<ref>.supabase.co', '<kunci anon atau publishable>');
-- Menyimpan alamat dan kunci, menjadwalkan dua pekerjaan pg_cron (ping 01.30 UTC = 08.30 WIB, pencatatan hasil 01.35 UTC), lalu langsung mengirim ping pertama.
create function sigarda.keepalive_atur(p_url text, p_kunci text) returns text language plpgsql security definer set search_path = public as
$$
declare v_url text := regexp_replace(btrim(coalesce(p_url, '')), '/+$', ''); v_kunci text := btrim(coalesce(p_kunci, '')); v_catatan text := '';
begin
  if auth.uid() is not null then raise exception 'Pengaturan keep-alive hanya dari SQL Editor Supabase.'; end if;
  if v_url !~ '^https://[a-z0-9.-]+\.[a-z]{2,}$' then raise exception 'Alamat proyek harus berbentuk https://<ref>.supabase.co (tanpa garis miring dan tanpa /rest/v1).'; end if;
  if char_length(v_kunci) not between 20 and 500 then raise exception 'Kunci anon/publishable tampak tidak sah (Project Settings > API Keys). Jangan isi kunci service_role.'; end if;
  insert into public.keepalive_konfigurasi (id, url, kunci) values (true, v_url, v_kunci)
  on conflict (id) do update set url = excluded.url, kunci = excluded.kunci, diubah = now(), ping_id = null, status_terakhir = null, pesan_terakhir = null;
  if to_regnamespace('cron') is null then
    v_catatan := v_catatan || ' pg_cron belum aktif: aktifkan di Dashboard > Integrations lalu jalankan perintah ini lagi (jadwal harian belum dibuat).';
  else
    perform cron.schedule('sigarda-keepalive', '30 1 * * *', 'select sigarda.keepalive_ping()');
    perform cron.schedule('sigarda-keepalive-catat', '35 1 * * *', 'select sigarda.keepalive_catat()');
  end if;
  if to_regnamespace('net') is null then
    v_catatan := v_catatan || ' pg_net belum aktif: aktifkan di Dashboard > Integrations lalu jalankan perintah ini lagi (permintaan belum dapat dikirim).';
  else
    perform sigarda.keepalive_ping();
  end if;
  return 'Keep-alive tersimpan.' || case when v_catatan = '' then ' Ping pertama dikirim; beberapa detik lagi jalankan: select sigarda.keepalive_periksa();' else v_catatan end;
end $$;

-- Satu ping: permintaan HTTP ke API proyek sendiri lewat pg_net (asinkron). Tanpa konfigurasi atau tanpa pg_net tidak melakukan apa pun. Galat tidak dilempar.
create function sigarda.keepalive_ping() returns bigint language plpgsql security definer set search_path = public as
$$
declare v_k public.keepalive_konfigurasi; v_id bigint;
begin
  select * into v_k from public.keepalive_konfigurasi;
  if not found or to_regnamespace('net') is null then return null; end if;
  begin
    execute 'select net.http_post(url := $1, body := $2, headers := $3, timeout_milliseconds := $4)'
      into v_id
      using v_k.url || '/rest/v1/rpc/sg_gudep_publik', '{}'::jsonb,
            jsonb_build_object('Content-Type', 'application/json', 'apikey', v_k.kunci, 'Authorization', 'Bearer ' || v_k.kunci), 10000;
  exception when others then
    update public.keepalive_konfigurasi set ping_terakhir = now(), ping_id = null, status_terakhir = 0, pesan_terakhir = 'Gagal mengantre permintaan: ' || sqlerrm;
    return null;
  end;
  update public.keepalive_konfigurasi set ping_terakhir = now(), ping_id = v_id, status_terakhir = null, pesan_terakhir = 'Menunggu jawaban';
  return v_id;
end $$;

-- Mencatat jawaban ping terakhir dari net._http_response (pg_net hanya menyimpannya beberapa jam, maka dicatat 5 menit sesudah ping).
create function sigarda.keepalive_catat() returns void language plpgsql security definer set search_path = public as
$$
declare v_k public.keepalive_konfigurasi; v_n int; v_status int; v_galat text;
begin
  select * into v_k from public.keepalive_konfigurasi;
  if not found or v_k.ping_id is null or to_regnamespace('net') is null then return; end if;
  begin
    execute 'select count(*)::int, max(status_code), max(error_msg) from net._http_response where id = $1' into v_n, v_status, v_galat using v_k.ping_id;
  exception when others then
    return;
  end;
  if v_n = 0 then
    update public.keepalive_konfigurasi set pesan_terakhir = 'Jawaban belum atau tidak lagi tercatat di pg_net.';
  elsif v_status between 200 and 299 then
    update public.keepalive_konfigurasi set status_terakhir = v_status, pesan_terakhir = 'Database menjawab (HTTP ' || v_status || ').';
  else
    update public.keepalive_konfigurasi set status_terakhir = coalesce(v_status, 0),
      pesan_terakhir = coalesce(v_galat, 'HTTP ' || v_status || (case when v_status in (401, 403) then ': kunci anon salah atau dicabut' when v_status = 404 then ': alamat proyek salah atau fungsi sg_gudep_publik tidak ada' else '' end));
  end if;
end $$;

-- Untuk pemilik di SQL Editor: mencatat jawaban terbaru lalu menampilkan keadaan (terkonfigurasi, ping terakhir, hasilnya, dan jadwal pg_cron aktif).
create function sigarda.keepalive_periksa() returns jsonb language plpgsql security definer set search_path = public as
$$
declare v_k public.keepalive_konfigurasi; v_jadwal int := 0; v_ada boolean;
begin
  perform sigarda.keepalive_catat();
  select * into v_k from public.keepalive_konfigurasi;
  v_ada := found;
  if to_regnamespace('cron') is not null then
    begin
      execute 'select count(*)::int from cron.job where jobname in ($1, $2) and active' into v_jadwal using 'sigarda-keepalive', 'sigarda-keepalive-catat';
    exception when others then v_jadwal := 0; end;
  end if;
  return jsonb_build_object(
    'terkonfigurasi', v_ada, 'alamat', v_k.url, 'ping_terakhir', v_k.ping_terakhir, 'status', v_k.status_terakhir, 'pesan', v_k.pesan_terakhir,
    'pekerjaan_cron_aktif', v_jadwal, 'sehat', coalesce(v_k.status_terakhir between 200 and 299, false) and v_jadwal = 2
  );
end $$;

-- Mematikan keep-alive: menghapus dua pekerjaan pg_cron dan konfigurasinya (mis. saat pindah ke paket berbayar).
create function sigarda.keepalive_matikan() returns void language plpgsql security definer set search_path = public as
$$
begin
  if auth.uid() is not null then raise exception 'Pengaturan keep-alive hanya dari SQL Editor Supabase.'; end if;
  if to_regnamespace('cron') is not null then
    begin
      perform cron.unschedule('sigarda-keepalive');
    exception when others then null; end;
    begin
      perform cron.unschedule('sigarda-keepalive-catat');
    exception when others then null; end;
  end if;
  delete from public.keepalive_konfigurasi;
end $$;
-- ===== akhir fungsi keepalive =====

-- Sesi ujian: jadwal ujian bersama (tanggal, tempat), butir yang diuji, dan daftar peserta. Hasil penilaian tetap dicatat pada
-- sku_progress seperti biasa; papan sesi menurunkan status dari progres pada atau sesudah tanggal sesi.
create table public.sesi_ujian (
  id int generated always as identity primary key,
  nama text not null check (char_length(btrim(nama)) between 1 and 120),
  tanggal date not null check (tanggal between date '2000-01-01' and date '2100-12-31'),
  tempat text not null default '' check (char_length(tempat) <= 120),
  catatan text not null default '' check (char_length(catatan) <= 500),
  status text not null default 'terjadwal' check (status in ('terjadwal','berlangsung','selesai')),
  dibuat_oleh uuid references public.profiles(id) on delete set null,
  dibuat_pada timestamptz not null default now()
);
create index on public.sesi_ujian (tanggal);
create table public.sesi_ujian_butir (
  sesi_id int not null references public.sesi_ujian(id) on delete cascade,
  butir_id text not null references public.sku_butir(id),
  primary key (sesi_id, butir_id)
);
create table public.sesi_ujian_peserta (
  sesi_id int not null references public.sesi_ujian(id) on delete cascade,
  peserta_id uuid not null references public.profiles(id) on delete cascade,
  primary key (sesi_id, peserta_id)
);
create index on public.sesi_ujian_peserta (peserta_id);

-- Pembatasan percobaan masuk per nama pengguna (hanya dipakai Edge Function)
create table public.login_gagal (
  username text primary key,
  jumlah int not null default 0,
  terkunci_sampai timestamptz,
  diperbarui timestamptz not null default now()
);

-- ===== Pra-uji berjenjang (fase C): tabel =====
-- Pra-uji SKU sebelum uji resmi Pembina. Jalur butir Bantara: Penegak > Pinsa > Bina Damping > Pembina; butir Laksana: Penegak > Bina Damping (yang sudah
-- Laksana) > Pembina. Satu baris = satu tahap untuk satu pengajuan; lulus meneruskan pengajuan (baris tahap berikut, atau pengajuan uji resmi di sku_progress),
-- belum = kembali ke Penegak dengan catatan. Baris lama disimpan sebagai riwayat. Pra-uji hanya REKOMENDASI: tidak pernah mengubah status lulus butir.
-- Tanpa hak baca langsung selain kebijakan baca (pemilik, pengurus, penilai); tulis hanya lewat fungsi sg_*.
create table public.sku_pra_uji (
  id bigint generated always as identity primary key,
  peserta_id uuid not null references public.profiles(id) on delete cascade,
  sku_id text not null references public.sku_unit(id),
  tahap text not null check (tahap in ('pinsa','bina_damping')),
  status text not null default 'menunggu' check (status in ('menunggu','lulus','belum','dibatalkan','dilewati')),
  jadwal date not null,                                          -- tanggal uji resmi yang diinginkan Penegak (dibawa sampai tahap Pembina)
  catatan_peserta text not null default '' check (char_length(catatan_peserta) <= 500),
  penilai_id uuid references public.profiles(id) on delete set null,   -- yang memutuskan (Pinsa/Bina Damping), atau Pembina/Admin yang melewati tahap
  penilai_nama text,                                             -- nama saat memutuskan (Penegak tidak dapat membaca profil Pinsa/Bina Damping)
  catatan text not null default '' check (char_length(catatan) <= 1000),
  dibuat timestamptz not null default now(),
  diputuskan_pada timestamptz,
  constraint sku_pra_uji_belum_catatan check (status <> 'belum' or btrim(catatan) <> '')
);
-- Satu tahap menunggu per Penegak per butir
create unique index sku_pra_uji_menunggu_unik on public.sku_pra_uji (peserta_id, sku_id) where status = 'menunggu';
create index sku_pra_uji_peserta_idx on public.sku_pra_uji (peserta_id, sku_id);
create index sku_pra_uji_penilai_idx on public.sku_pra_uji (penilai_id);
create index sku_pra_uji_sku_idx on public.sku_pra_uji (sku_id);
-- ===== akhir tabel pra-uji =====
-- ===== Pelantikan dan Saka (Tahap 2, G1): tabel =====
-- Pelantikan Penegak Bantara dan Laksana (penyematan TKU) dan keanggotaan Saka (Satuan Karya). Data inti untuk syarat Garuda dan formulir daftar isian Kwarcab
-- (tempat dan tanggal pelantikan, surat keterangan aktif Saka). Dicatat Pembina atau Admin Gudep; dibaca pemilik dan pengurus (RLS baca); tulis hanya lewat fungsi sg_*.
create table public.pelantikan (
  id bigint generated always as identity primary key,
  peserta_id uuid not null references public.profiles(id) on delete cascade,
  tingkat text not null check (tingkat in ('bantara','laksana','mula','bantu','tata')),   -- bantara/laksana = Penegak; mula/bantu/tata = anggota Siaga (Fase 4)
  tanggal date not null check (tanggal >= date '2000-01-01'),
  tempat text not null check (char_length(btrim(tempat)) between 1 and 120),
  agenda_id bigint references public.agenda(id) on delete set null,          -- kegiatan pelantikan di Agenda (opsional)
  catatan text not null default '' check (char_length(catatan) <= 200),
  dicatat_oleh uuid references public.profiles(id) on delete set null,
  dicatat_pada timestamptz not null default now(),
  constraint pelantikan_satu_per_tingkat unique (peserta_id, tingkat)
);
create index pelantikan_tanggal_idx on public.pelantikan (tanggal);
create index pelantikan_agenda_idx on public.pelantikan (agenda_id);

create table public.saka_anggota (
  id bigint generated always as identity primary key,
  peserta_id uuid not null references public.profiles(id) on delete cascade,
  saka text not null check (char_length(btrim(saka)) between 1 and 60),                -- nama Saka, isian bebas (saran di layar)
  tanggal_masuk date not null check (tanggal_masuk >= date '2000-01-01'),
  status text not null default 'aktif' check (status in ('aktif','selesai')),
  tanggal_selesai date,
  surat_url text not null default '' check (surat_url = '' or (surat_url ~* '^https?://' and char_length(surat_url) <= 500)),   -- tautan surat keterangan aktif Saka
  catatan text not null default '' check (char_length(catatan) <= 200),
  dicatat_oleh uuid references public.profiles(id) on delete set null,
  dicatat_pada timestamptz not null default now(),
  constraint saka_selesai_konsisten check ((status = 'aktif' and tanggal_selesai is null) or (status = 'selesai' and tanggal_selesai is not null and tanggal_selesai >= tanggal_masuk))
);
create unique index saka_peserta_unik on public.saka_anggota (peserta_id, lower(btrim(saka)));
-- ===== akhir tabel pelantikan dan saka =====
-- ===== TKK (Tahap 2, G2): tabel =====
-- Tanda Kecakapan Khusus (TKK) Penegak: katalog (nama, bidang, sumber; isinya dibangkitkan dari src/data/tkkData.js oleh scripts/buat-skema.mjs dan migrasi),
-- capaian bertingkat Purwa > Madya > Utama per Penegak, dan TKK Krida (Saka). Dicatat Pembina atau Admin Gudep (Pembina yang langsung membina yang memberi TKK);
-- dibaca pemilik dan pengurus (RLS baca); tulis hanya lewat fungsi sg_tkk_*. Syarat tiap SKK TIDAK disimpan (lihat berkas peraturan).
create table public.tkk_katalog (
  id text primary key check (id ~ '^[a-z0-9]+(-[a-z0-9]+)*$' and char_length(id) <= 40),
  nama text not null check (char_length(btrim(nama)) between 1 and 80),
  bidang smallint not null check (bidang between 1 and 5),
  golongan text not null default 'penegak' check (golongan in ('penegak','siaga')),      -- 'siaga' = khusus Siaga, tidak dapat dikenakan pada Penegak
  agama text check (agama is null or agama in ('Islam','Katolik','Protestan','Hindu','Buddha','Khonghucu')),   -- khusus satu agama (mis. Sholat)
  sumber text not null check (sumber in ('skk-132-1979','tambahan','penabung-01-2024')),
  urut smallint not null
);

create table public.tkk_capaian (
  id bigint generated always as identity primary key,
  peserta_id uuid not null references public.profiles(id) on delete cascade,
  tkk_id text not null references public.tkk_katalog(id),
  tingkat text not null check (tingkat in ('purwa','madya','utama')),
  tanggal date not null check (tanggal >= date '2000-01-01'),
  penguji1 text not null check (char_length(btrim(penguji1)) between 1 and 80),       -- tim penguji 2 orang (Pembina yang membina, pembantu Pembina, atau ahli): nama saja
  penguji2 text not null check (char_length(btrim(penguji2)) between 1 and 80),
  melatih text not null check (char_length(btrim(melatih)) between 1 and 200),         -- syarat Penegak: telah melatih sedikitnya seorang Pramuka sampai TKK tingkat di bawahnya
  bukti_url text not null default '' check (bukti_url = '' or (bukti_url ~* '^https?://' and char_length(bukti_url) <= 500)),   -- tautan surat keterangan lulus/piagam
  catatan text not null default '' check (char_length(catatan) <= 200),
  dicatat_oleh uuid references public.profiles(id) on delete set null,
  dicatat_pada timestamptz not null default now(),
  constraint tkk_capaian_satu_per_tingkat unique (peserta_id, tkk_id, tingkat)
);
create index tkk_capaian_tkk_idx on public.tkk_capaian (tkk_id);

create table public.tkk_krida (
  id bigint generated always as identity primary key,
  peserta_id uuid not null references public.profiles(id) on delete cascade,
  nama text not null check (char_length(btrim(nama)) between 1 and 80),               -- nama TKK Krida (mis. dari Saka), isian bebas
  saka text not null default '' check (char_length(saka) <= 60),
  tanggal date not null check (tanggal >= date '2000-01-01'),
  bukti_url text not null default '' check (bukti_url = '' or (bukti_url ~* '^https?://' and char_length(bukti_url) <= 500)),
  catatan text not null default '' check (char_length(catatan) <= 200),
  dicatat_oleh uuid references public.profiles(id) on delete set null,
  dicatat_pada timestamptz not null default now()
);
create unique index tkk_krida_unik on public.tkk_krida (peserta_id, lower(btrim(nama)));

-- Ambang kesiapan Garuda (MINIMAL, dapat dilampaui; standar Kwarcab Purbalingga 2026). Bawaan sama dengan AMBANG_TKK_BAWAAN di src/data/tkkData.js (dijaga uji/tkk-klien.mjs).
insert into public.pengaturan (kunci, nilai) values ('tkk.ambang',
  '{"total": 45, "madya": 3, "utamaWajib": ["berkemah","gerak-jalan","pppk","pengatur-rumah","pengamat","juru-masak","penabung","menjahit","juru-kebun","pengamanan-kampung"]}'::jsonb)
on conflict (kunci) do nothing;
-- ===== akhir tabel tkk =====

-- ===== TKK pengajuan (Tahap 2, G2b): tabel =====
-- Penegak mengajukan capaian TKK sendiri (data sama dengan tkk_capaian); Pembina atau Admin meninjau: disetujui = menjadi capaian resmi, ditolak = catatan wajib.
-- Satu pengajuan yang menunggu per (Penegak, TKK, tingkat). Baris lama disimpan sebagai riwayat. Tulis hanya lewat fungsi sg_tkk_ajukan/_batal/sg_tkk_tinjau.
create table public.tkk_pengajuan (
  id bigint generated always as identity primary key,
  peserta_id uuid not null references public.profiles(id) on delete cascade,
  tkk_id text not null references public.tkk_katalog(id),
  tingkat text not null check (tingkat in ('purwa','madya','utama')),
  tanggal date not null check (tanggal >= date '2000-01-01'),
  penguji1 text not null check (char_length(btrim(penguji1)) between 1 and 80),
  penguji2 text not null check (char_length(btrim(penguji2)) between 1 and 80),
  penguji1_id uuid references public.profiles(id) on delete set null,                   -- Pembina Penguji 1 yang dipilih Penegak dari yang ditugaskan untuk kelasnya (G2c); Pembina ini yang diberi tahu
  penguji_awal text not null default '' check (char_length(penguji_awal) <= 200),        -- nama penguji SEBELUM diganti Pembina saat meninjau (kosong bila tidak diganti)
  melatih text not null check (char_length(btrim(melatih)) between 1 and 200),
  bukti_url text not null default '' check (bukti_url = '' or (bukti_url ~* '^https?://' and char_length(bukti_url) <= 500)),
  catatan text not null default '' check (char_length(catatan) <= 200),
  status text not null default 'menunggu' check (status in ('menunggu','disetujui','ditolak','dibatalkan')),
  diajukan_pada timestamptz not null default now(),
  ditinjau_oleh uuid references public.profiles(id) on delete set null,
  ditinjau_nama text,                                                                   -- nama peninjau saat meninjau (Penegak tidak dapat membaca profil Pembina)
  ditinjau_pada timestamptz,
  catatan_tinjauan text not null default '' check (char_length(catatan_tinjauan) <= 200),
  capaian_id bigint references public.tkk_capaian(id) on delete set null,               -- capaian resmi hasil persetujuan
  constraint tkk_pengajuan_tolak_wajib_catatan check (status <> 'ditolak' or btrim(catatan_tinjauan) <> '')
);
create unique index tkk_pengajuan_menunggu_unik on public.tkk_pengajuan (peserta_id, tkk_id, tingkat) where status = 'menunggu';
create index tkk_pengajuan_tkk_idx on public.tkk_pengajuan (tkk_id);
create index tkk_pengajuan_capaian_idx on public.tkk_pengajuan (capaian_id);
create index tkk_pengajuan_penguji1_idx on public.tkk_pengajuan (penguji1_id);
-- ===== akhir tabel tkk pengajuan =====

-- ===== TKK Siaga (Pramuka Siaga, Fase 5): tabel =====
-- TKK anak Siaga (SK Kwarnas 134/1976 dan 132/1979): SATU tingkat saja (tanpa Purwa/Madya/Utama), tanpa bukti melatih, diuji Pembina (satu nama penguji) dan dicatat
-- Pembina atau Admin; dikenakan sesudah anak menyelesaikan SKU Siaga Bantu. Satu baris per (anak, TKK); mencatat ulang = koreksi. Baca pemilik dan Pembina/Admin (RLS); tulis hanya fungsi.
create table public.tkk_siaga (
  id bigint generated always as identity primary key,
  peserta_id uuid not null references public.profiles(id) on delete cascade,
  tkk_id text not null references public.tkk_katalog(id),
  tanggal date not null check (tanggal >= date '2015-01-01'),
  penguji text not null check (char_length(btrim(penguji)) between 1 and 80),
  bukti_url text not null default '' check (bukti_url = '' or (bukti_url ~* '^https?://' and char_length(bukti_url) <= 500)),
  catatan text not null default '' check (char_length(catatan) <= 200),
  dicatat_oleh uuid references public.profiles(id) on delete set null,
  dicatat_pada timestamptz not null default now(),
  constraint tkk_siaga_satu_per_tkk unique (peserta_id, tkk_id)
);
create index if not exists tkk_siaga_tkk_idx on public.tkk_siaga (tkk_id);
-- ===== akhir tabel tkk siaga =====
-- ===== SPG (Tahap 2, G3): tabel =====
-- Penetapan Syarat Pramuka Garuda (SPG, 13 butir SK Kwarnas 038/2017) oleh Pembina: satu baris per Penegak per butir. Butir yang dapat dihitung dari data aplikasi (SKU Laksana
-- dan 3 bulan sesudah dilantik, TKK, Saka, Penabung) dihitung di klien; baris ini mencatat PENETAPAN Pembina: butir berbasis dokumen (lengkap = 100, belum = 0) dan penimpaan
-- hasil hitung otomatis (timpa = true, alasan di catatan). Tanggal = tanggal pengujian pada lembar SPG. Isi rubrik pengujian TIDAK disimpan di sini.
create table public.spg_penetapan (
  peserta_id uuid not null references public.profiles(id) on delete cascade,
  butir smallint not null check (butir between 1 and 13),
  nilai smallint not null check (nilai in (0, 100)),
  tanggal date not null check (tanggal >= date '2000-01-01'),
  catatan text not null default '' check (char_length(catatan) <= 200),
  timpa boolean not null default false,
  dicatat_oleh uuid references public.profiles(id) on delete set null,
  dicatat_pada timestamptz not null default now(),
  primary key (peserta_id, butir),
  constraint spg_timpa_beralasan check (not timpa or char_length(btrim(catatan)) >= 5)
);
-- ===== akhir tabel spg =====

-- ===== Siaga Garuda (Pramuka Siaga, Fase 6): tabel =====
-- Penetapan Syarat Siaga Garuda (6 butir, Jukran Kwarnas 038/2017) oleh Pembina: satu baris per anak Siaga per butir. Hasil hitung otomatis butir 1 (SKU Tata dan 2 bulan sesudah
-- dilantik) dan butir 2 (TKK) hanya saran di klien; baris ini mencatat PENETAPAN Pembina (100 = terpenuhi, 0 = belum), tanggal pengujian, dan catatan. Isi rubrik TIDAK disimpan.
create table public.siaga_garuda (
  peserta_id uuid not null references public.profiles(id) on delete cascade,
  butir smallint not null check (butir between 1 and 6),
  nilai smallint not null check (nilai in (0, 100)),
  tanggal date not null check (tanggal >= date '2015-01-01'),
  catatan text not null default '' check (char_length(catatan) <= 200),
  dicatat_oleh uuid references public.profiles(id) on delete set null,
  dicatat_pada timestamptz not null default now(),
  primary key (peserta_id, butir)
);
-- ===== akhir tabel siaga garuda =====
-- ===== Gerbang calon Garuda (Tahap 2, G4): tabel =====
-- Tanggal lahir Penegak untuk memeriksa syarat usia Calon Garuda (pedoman Kwarcab Purbalingga 2026: usia 16-20 tahun). Sengaja TABEL TERPISAH, bukan kolom profiles: RLS profil
-- memperlihatkan Penegak berjabatan Dewan kepada semua Penegak, sedangkan tanggal lahir hanya boleh dibaca pemilik dan pengurus. Dicatat Pembina atau Admin (sg_tanggal_lahir_atur).
create table public.tanggal_lahir (
  peserta_id uuid primary key references public.profiles(id) on delete cascade,
  tanggal date not null check (tanggal >= date '1990-01-01'),
  dicatat_oleh uuid references public.profiles(id) on delete set null,
  dicatat_pada timestamptz not null default now()
);

-- Aturan gerbang calon (pengaturan 'garuda.gerbang'; diperbarui tiap tahun oleh Pembina atau Admin): kelas minimal, rentang tanggal lahir yang sah, dan kuota calon
-- sebagai persen dari Penegak aktif. Bawaan sama dengan GERBANG_BAWAAN di src/lib/gerbangLogic.js (dijaga uji/gerbang-klien.mjs).
insert into public.pengaturan (kunci, nilai) values ('garuda.gerbang',
  '{"kelasMin": "XI", "lahirDari": "2007-11-01", "lahirSampai": "2009-05-01", "kuotaPersen": 5}'::jsonb)
on conflict (kunci) do nothing;
-- ===== akhir tabel gerbang =====
-- ===== Tim penilai dan kalender Garuda (Tahap 2, G4b dan G4c): tabel =====
-- Tim penilai Calon Garuda (pedoman Kwarcab Purbalingga 2026): dibentuk dengan SK Kwarcab, TERPISAH untuk putra dan putri (calon putra dinilai tim putra, calon putri tim putri),
-- anggotanya Ketua Gudep (bukan Ka Mabigus sebagai ketua tim), Pembina Gudep, Andalan Ranting urusan Penegak, tokoh masyarakat, dan orang tua (ayah untuk putra, ibu untuk putri).
-- Satu tim per (tahun ajaran, untuk); Calon Garuda dinilai tim yang sesuai jenis kelaminnya. Komposisi yang tidak lengkap hanya diperingatkan di klien. Nomor dan tanggal SK berpasangan.
create table public.tim_penilai (
  id bigint generated always as identity primary key,
  tahun_ajaran text not null check (tahun_ajaran ~ '^[0-9]{4}/[0-9]{4}$'),
  untuk text not null check (untuk in ('putra', 'putri')),
  nomor_sk text not null default '' check (char_length(nomor_sk) <= 80),
  tanggal_sk date check (tanggal_sk is null or tanggal_sk >= date '2000-01-01'),
  sk_url text not null default '' check (sk_url = '' or (sk_url ~* '^https?://' and char_length(sk_url) <= 500)),
  catatan text not null default '' check (char_length(catatan) <= 300),
  dicatat_oleh uuid references public.profiles(id) on delete set null,
  dicatat_pada timestamptz not null default now(),
  constraint tim_penilai_unik unique (tahun_ajaran, untuk),
  constraint tim_penilai_sk_pasangan check ((nomor_sk = '') = (tanggal_sk is null))
);
create table public.tim_penilai_anggota (
  id bigint generated always as identity primary key,
  tim_id bigint not null references public.tim_penilai(id) on delete cascade,
  urut smallint not null check (urut between 1 and 15),
  nama text not null check (char_length(btrim(nama)) between 1 and 80),
  unsur text not null check (unsur in ('ketua_gudep', 'pembina', 'andalan_ranting', 'tokoh_masyarakat', 'orang_tua', 'lainnya')),
  jabatan text not null default 'anggota' check (jabatan in ('ketua', 'anggota')),
  keterangan text not null default '' check (char_length(keterangan) <= 120),
  constraint tim_penilai_anggota_urut unique (tim_id, urut)
);
create unique index tim_penilai_satu_ketua on public.tim_penilai_anggota (tim_id) where jabatan = 'ketua';

-- Kalender tahap Garuda dari Kwarcab (permohonan SK tim, serah portofolio ke Kwarran, verifikasi, pelantikan, dan seterusnya): satu baris per (tahun ajaran, tahap) berisi tanggal
-- mulai dan (opsional) akhir. Daftar tahap = TAHAP_GARUDA di src/lib/kalenderGarudaLogic.js (dijaga uji/tim-kalender-klien.mjs).
create table public.garuda_tahap (
  id bigint generated always as identity primary key,
  tahun_ajaran text not null check (tahun_ajaran ~ '^[0-9]{4}/[0-9]{4}$'),
  tahap text not null check (tahap in ('uji_spg', 'ajukan_tim', 'ambil_sk', 'penilaian_gudep', 'serah_kwarran', 'nilai_kwarran', 'kirim_kwarcab', 'verifikasi_visitasi', 'iuran', 'pelantikan')),
  mulai date not null check (mulai >= date '2000-01-01'),
  akhir date,
  catatan text not null default '' check (char_length(catatan) <= 200),
  dicatat_oleh uuid references public.profiles(id) on delete set null,
  dicatat_pada timestamptz not null default now(),
  constraint garuda_tahap_unik unique (tahun_ajaran, tahap),
  constraint garuda_tahap_rentang check (akhir is null or akhir >= mulai)
);
-- ===== akhir tabel tim kalender =====
-- ===== Isian Penegak dan templat dokumen (Tahap 3, H1): tabel =====
-- Isian data diri Penegak untuk portofolio Garuda (tempat lahir, alamat, keluarga, pendidikan, prestasi, kegiatan, kecakapan, perangkat IT), dipakai sebagai pasangan kunci-nilai.
-- Diisi SENDIRI oleh Penegak (sg_isian_saya_simpan); admin gudep hanya membuat akun dengan nama, NIS, dan rombel. Daftar kunci dan aturan tiap kunci ada di
-- sigarda.isian_periksa (dicerminkan src/lib/isianLogic.js dan dibandingkan langsung pada kisi masukan di uji/isian-klien.mjs). Dibaca pemilik, Pembina, dan Admin (BUKAN Dewan
-- Ambalan: alamat dan riwayat kesehatan bersifat pribadi); ditulis hanya lewat fungsi.
create table public.penegak_isian (
  peserta_id uuid not null references public.profiles(id) on delete cascade,
  kunci text not null check (kunci ~ '^[a-z0-9_]{1,40}$'),
  nilai text not null check (char_length(nilai) between 1 and 200),
  diubah_pada timestamptz not null default now(),
  primary key (peserta_id, kunci)
);

-- Isi templat dokumen per tahun ajaran (rubrik surat keterangan guru untuk portofolio Garuda). Rubrik Kwarcab HANYA di basis data, tidak di repositori: Pembina atau Admin
-- mengisinya dari menu Portofolio. isi = { uji?: teks, baris: [teks], pita?: [tiga teks] }; baris berawalan "# " adalah judul kelompok. Tahun ajaran tanpa templat memakai templat
-- tahun ajaran sebelumnya yang terdekat.
create table public.dokumen_templat (
  id bigint generated always as identity primary key,
  tahun_ajaran text not null check (tahun_ajaran ~ '^\d{4}/\d{4}$'),
  jenis text not null check (jenis in ('surat_uud', 'surat_uu_pramuka', 'surat_tik', 'surat_internet', 'surat_bahasa', 'surat_seni', 'surat_iptek', 'surat_olahraga')),
  isi jsonb not null check (jsonb_typeof(isi) = 'object'),
  diubah_oleh uuid references public.profiles(id) on delete set null,
  diubah_pada timestamptz not null default now(),
  unique (tahun_ajaran, jenis)
);
-- ===== akhir tabel isian penegak =====

-- ===== Salinan beku portofolio (Tahap 3, H3): tabel =====
-- Salinan beku Portofolio format Kwarcab satu Penegak pada saat dicetak atau dikirim ke Kwarcab: seluruh data yang membentuk dokumen (identitas, TKK, SPG, isian data diri,
-- rubrik surat guru, data gudep) disimpan apa adanya, sehingga dokumen yang sama dapat dibuka lagi meski data aplikasi kemudian berubah. Dibuat dan dihapus Pembina atau Admin;
-- dibaca Pembina dan Admin (memuat data pribadi Penegak).
create table public.portofolio_snapshot (
  id bigint generated always as identity primary key,
  peserta_id uuid not null references public.profiles(id) on delete cascade,
  tahun_ajaran text not null check (tahun_ajaran ~ '^\d{4}/\d{4}$'),
  catatan text not null default '' check (char_length(catatan) <= 200 and catatan !~ '[[:cntrl:]<>]'),
  isi jsonb not null check (jsonb_typeof(isi) = 'object'),
  dibuat_oleh uuid references public.profiles(id) on delete set null,
  dibuat_oleh_nama text not null default '',
  dibuat_pada timestamptz not null default now()
);
create index portofolio_snapshot_peserta_idx on public.portofolio_snapshot (peserta_id, dibuat_pada desc);
-- ===== akhir tabel salinan beku portofolio =====

-- ===== Perlindungan anggota / Safe From Harm (Tahap 4): tabel =====
-- Catatan kewajiban Safe From Harm bagi ANGGOTA DEWASA gugus depan menurut Jukran Kwarnas 004/2021: Pembina (Pasal 9 ayat 3 huruf b: lulus Pelatihan Perlindungan; Pasal 7 ayat 4 huruf f:
-- menandatangani pakta integritas; Pasal 7 ayat 4 huruf e: pemeriksaan riwayat hidup dan rekam jejak) dan Admin Gudep (pelatihan). Aplikasi hanya MENCATAT (tanggal dan tautan bukti);
-- laporan kejadian TIDAK disimpan di aplikasi (Pasal 8 ayat 4 huruf g: rahasia, ditangani Komite Perlindungan dan Dewan Kehormatan di luar aplikasi). Satu baris per orang per jenis.
-- Dicatat Pembina atau Admin; dibaca pemilik, Pembina, dan Admin.
create table public.sfh_catatan (
  id bigint generated always as identity primary key,
  anggota_id uuid not null references public.profiles(id) on delete cascade,
  jenis text not null check (jenis in ('pelatihan', 'pakta_integritas', 'rekam_jejak')),
  tanggal date not null check (tanggal >= date '2015-01-01'),
  bukti_url text not null default '' check (char_length(bukti_url) <= 500 and (bukti_url = '' or bukti_url ~* '^https?://[^[:space:]<>]+$')),
  catatan text not null default '' check (char_length(catatan) <= 200 and catatan !~ '[[:cntrl:]<>]'),
  dicatat_oleh uuid references public.profiles(id) on delete set null,
  dicatat_pada timestamptz not null default now(),
  unique (anggota_id, jenis)
);
-- ===== akhir tabel perlindungan anggota =====
-- ===== Kelola Beranda (Fase 2 landing page): tabel =====
-- Isi halaman muka yang dikelola pengurus lewat menu Kelola Beranda. Berita, Prestasi, dan Galeri memakai alur tinjauan yang sama: Dewan
-- Ambalan hanya menulis draf atau mengajukan ('menunggu'); Pembina dan Admin Gudep dapat menerbitkan langsung atau meninjau pengajuan Dewan
-- (menyetujui = 'terbit', menolak = 'ditolak' dengan catatan wajib). Media sosial dan pertanyaan umum tanpa alur tinjauan (lihat catatan
-- masing-masing tabel). Semua ditulis HANYA lewat fungsi sg_* (lihat 586-aksi-beranda-konten.sql); dibaca lewat sg_beranda_publik (hanya yang
-- berstatus 'terbit') dan menu Kelola Beranda (pengurus, semua status).
create table public.beranda_berita (
  id bigint generated always as identity primary key,
  kategori text not null default 'kegiatan' check (kategori in ('kegiatan', 'pengumuman', 'lainnya')),
  judul text not null check (char_length(btrim(judul)) between 1 and 150),
  ringkasan text not null default '' check (char_length(ringkasan) <= 200),
  isi text not null check (char_length(btrim(isi)) between 1 and 4000),
  sampul_url text not null default '' check (sampul_url = '' or sampul_url ~ '^https://[A-Za-z0-9.-]+\.[A-Za-z]{2,}([/?#][^ ]*)?$'),
  status text not null default 'draf' check (status in ('draf', 'menunggu', 'terbit', 'ditolak')),
  terbit_pada timestamptz,  -- kapan tampil publik; boleh masa lalu (berita terlambat ditulis) atau masa depan (terjadwal). Draf/pengajuan menyimpan tanggal pilihan penulis (boleh null = saat diterbitkan).
  catatan_tinjauan text not null default '' check (char_length(catatan_tinjauan) <= 500),
  dibuat_oleh uuid references public.profiles(id) on delete set null,
  dibuat_oleh_nama text not null default '',
  dibuat_pada timestamptz not null default now(),
  ditinjau_oleh uuid references public.profiles(id) on delete set null,
  ditinjau_oleh_nama text not null default '',
  ditinjau_pada timestamptz,
  diubah_pada timestamptz not null default now(),
  constraint beranda_berita_tolak_wajib_catatan check (status <> 'ditolak' or char_length(btrim(catatan_tinjauan)) >= 5)
);
create index if not exists beranda_berita_status_idx on public.beranda_berita (status, terbit_pada desc);

create table public.beranda_prestasi (
  id bigint generated always as identity primary key,
  judul text not null check (char_length(btrim(judul)) between 1 and 150),
  tingkat text not null check (tingkat in ('gudep', 'ranting', 'cabang', 'provinsi', 'nasional')),
  peringkat text not null check (char_length(btrim(peringkat)) between 1 and 60),
  tahun int not null check (tahun between 2000 and 2100),
  diraih_oleh text not null check (char_length(btrim(diraih_oleh)) between 1 and 150),  -- nama regu/tim/gudep; BUKAN nama perorangan tanpa izin
  foto_url text not null default '' check (foto_url = '' or foto_url ~ '^https://[A-Za-z0-9.-]+\.[A-Za-z]{2,}([/?#][^ ]*)?$'),
  status text not null default 'draf' check (status in ('draf', 'menunggu', 'terbit', 'ditolak')),
  catatan_tinjauan text not null default '' check (char_length(catatan_tinjauan) <= 500),
  dibuat_oleh uuid references public.profiles(id) on delete set null,
  dibuat_oleh_nama text not null default '',
  dibuat_pada timestamptz not null default now(),
  ditinjau_oleh uuid references public.profiles(id) on delete set null,
  ditinjau_oleh_nama text not null default '',
  ditinjau_pada timestamptz,
  diubah_pada timestamptz not null default now(),
  constraint beranda_prestasi_tolak_wajib_catatan check (status <> 'ditolak' or char_length(btrim(catatan_tinjauan)) >= 5)
);
create index if not exists beranda_prestasi_status_idx on public.beranda_prestasi (status, tahun desc);

-- Album (tautan Google Drive atau Google Photos; foto sendiri tidak disimpan di aplikasi). Sampul opsional: bila kosong, beranda hanya
-- menampilkan kartu bertajuk tanpa gambar (lihat catatan kejujuran di memori proyek: Google Photos umumnya tidak memberi alamat gambar
-- yang bisa dipasang langsung).
create table public.beranda_galeri (
  id bigint generated always as identity primary key,
  judul text not null check (char_length(btrim(judul)) between 1 and 100),
  tautan text not null check (tautan ~ '^https://[A-Za-z0-9.-]+\.[A-Za-z]{2,}([/?#][^ ]*)?$'),
  sampul_url text not null default '' check (sampul_url = '' or sampul_url ~ '^https://[A-Za-z0-9.-]+\.[A-Za-z]{2,}([/?#][^ ]*)?$'),
  kelompok text not null default 'lainnya' check (kelompok in ('latihan', 'perkemahan', 'pelantikan', 'lainnya')),
  status text not null default 'draf' check (status in ('draf', 'menunggu', 'terbit', 'ditolak')),
  catatan_tinjauan text not null default '' check (char_length(catatan_tinjauan) <= 500),
  dibuat_oleh uuid references public.profiles(id) on delete set null,
  dibuat_oleh_nama text not null default '',
  dibuat_pada timestamptz not null default now(),
  ditinjau_oleh uuid references public.profiles(id) on delete set null,
  ditinjau_oleh_nama text not null default '',
  ditinjau_pada timestamptz,
  diubah_pada timestamptz not null default now(),
  constraint beranda_galeri_tolak_wajib_catatan check (status <> 'ditolak' or char_length(btrim(catatan_tinjauan)) >= 5)
);
create index if not exists beranda_galeri_status_idx on public.beranda_galeri (status, dibuat_pada desc);

-- Kiriman media sosial: kartu tautan dengan pratinjau (BUKAN sematan resmi, lihat keputusan pemilik di memori proyek). SEMUA pengurus dapat
-- menempel dan langsung tampil (tanpa alur tinjauan); `tampil` untuk menyembunyikan tanpa menghapus.
create table public.beranda_sosial (
  id bigint generated always as identity primary key,
  platform text not null check (platform in ('instagram', 'youtube', 'facebook', 'tiktok')),
  tautan text not null check (tautan ~ '^https://[A-Za-z0-9.-]+\.[A-Za-z]{2,}([/?#][^ ]*)?$'),
  keterangan text not null default '' check (char_length(keterangan) <= 200),
  gambar_url text not null default '' check (gambar_url = '' or gambar_url ~ '^https://[A-Za-z0-9.-]+\.[A-Za-z]{2,}([/?#][^ ]*)?$'),
  tampil boolean not null default true,
  dibuat_oleh uuid references public.profiles(id) on delete set null,
  dibuat_oleh_nama text not null default '',
  dibuat_pada timestamptz not null default now(),
  diubah_pada timestamptz not null default now()
);
create index if not exists beranda_sosial_tampil_idx on public.beranda_sosial (tampil, dibuat_pada desc);

-- Pertanyaan umum di beranda: HANYA Pembina dan Admin Gudep (Dewan Ambalan tidak, beda dari Berita/Prestasi/Galeri). Beranda memakai daftar
-- bawaan (src/landing/landingData.js) selama tabel ini kosong.
create table public.beranda_faq (
  id bigint generated always as identity primary key,
  pertanyaan text not null check (char_length(btrim(pertanyaan)) between 1 and 200),
  jawaban text not null check (char_length(btrim(jawaban)) between 1 and 1000),
  urutan int not null default 0,
  diubah_oleh uuid references public.profiles(id) on delete set null,
  diubah_pada timestamptz not null default now()
);
create index if not exists beranda_faq_urutan_idx on public.beranda_faq (urutan);
-- ===== akhir tabel beranda konten =====
-- ===== Terbit ulang situs saat berita terbit: tabel =====
-- Halaman berita statis (berita/<id>-<judul>/ dan sitemap) dibuat saat build di GitHub Actions. Supaya berita yang baru diterbitkan (atau yang jadwal terbitnya tiba)
-- ikut terbit tanpa deploy harian, basis data meminta GitHub menjalankan alur deploy lewat pg_net. Satu baris; diisi pemilik proyek SEKALI lewat
-- sigarda.terbit_ulang_atur di SQL Editor dengan kunci akses GitHub (fine-grained token, HANYA izin Actions: Read and write pada repositori ini). Kunci itu RAHASIA:
-- tanpa kebijakan RLS dan tanpa hak baca (hanya fungsi), tidak ikut sg_cadangan_admin, dan tidak ikut cadangan otomatis (scripts/cadangan/dump.mjs).
create table public.terbit_ulang_konfigurasi (
  id boolean primary key default true check (id),
  repo text not null check (repo ~ '^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$'),
  alur text not null default 'deploy.yml' check (alur ~ '^[A-Za-z0-9_.-]+\.ya?ml$'),
  cabang text not null default 'main' check (cabang ~ '^[A-Za-z0-9_./-]{1,100}$'),
  token text not null check (char_length(token) between 20 and 400),
  diubah timestamptz not null default now(),
  perlu boolean not null default false,      -- ada perubahan berita terbit yang belum diminta terbit ulang
  perlu_sejak timestamptz,
  kirim_terakhir timestamptz,
  kirim_id bigint,                           -- id permintaan pg_net yang jawabannya belum dicatat
  status_terakhir int,
  pesan_terakhir text,
  gagal_beruntun int not null default 0      -- 3 kali gagal beruntun = berhenti mencoba sampai ada perubahan baru atau tindakan pemilik
);
-- ===== akhir tabel terbit ulang =====

-- ===== Terbit ulang situs saat berita terbit: fungsi =====
-- Pemilik proyek menjalankan SEKALI di SQL Editor: select sigarda.terbit_ulang_atur('pemilik/repositori', '<kunci akses GitHub>');
-- Menyimpan repositori dan kunci lalu menjadwalkan satu pekerjaan pg_cron (tiap 5 menit): ia hanya mengirim permintaan bila ada berita terbit yang berubah atau yang
-- jadwalnya baru tiba, jadi tanpa perubahan tidak ada deploy sama sekali.
create function sigarda.terbit_ulang_atur(p_repo text, p_token text, p_alur text default 'deploy.yml', p_cabang text default 'main') returns text
language plpgsql security definer set search_path = public as
$$
declare v_repo text := btrim(coalesce(p_repo, '')); v_token text := btrim(coalesce(p_token, '')); v_alur text := btrim(coalesce(p_alur, '')); v_cabang text := btrim(coalesce(p_cabang, '')); v_catatan text := '';
begin
  if auth.uid() is not null then raise exception 'Pengaturan terbit ulang hanya dari SQL Editor Supabase.'; end if;
  if v_repo !~ '^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$' then raise exception 'Repositori harus berbentuk pemilik/nama, mis. tribudi3267/sigarda.'; end if;
  if char_length(v_token) not between 20 and 400 then raise exception 'Kunci akses GitHub tampak tidak sah (fine-grained token dengan izin Actions: Read and write pada repositori ini).'; end if;
  if v_alur !~ '^[A-Za-z0-9_.-]+\.ya?ml$' then raise exception 'Nama berkas alur harus berakhiran .yml atau .yaml, mis. deploy.yml.'; end if;
  if v_cabang !~ '^[A-Za-z0-9_./-]{1,100}$' then raise exception 'Nama cabang tidak sah.'; end if;
  insert into public.terbit_ulang_konfigurasi (id, repo, alur, cabang, token) values (true, v_repo, v_alur, v_cabang, v_token)
  on conflict (id) do update set repo = excluded.repo, alur = excluded.alur, cabang = excluded.cabang, token = excluded.token, diubah = now(),
    perlu = false, perlu_sejak = null, kirim_id = null, status_terakhir = null, pesan_terakhir = null, gagal_beruntun = 0;
  if to_regnamespace('cron') is null then
    v_catatan := v_catatan || ' pg_cron belum aktif: aktifkan di Dashboard > Integrations lalu jalankan perintah ini lagi (jadwal pemeriksaan belum dibuat).';
  else
    perform cron.schedule('sigarda-terbit-ulang', '*/5 * * * *', 'select sigarda.terbit_ulang_periksa()');
  end if;
  if to_regnamespace('net') is null then
    v_catatan := v_catatan || ' pg_net belum aktif: aktifkan di Dashboard > Integrations lalu jalankan perintah ini lagi (permintaan belum dapat dikirim).';
  end if;
  return 'Terbit ulang tersimpan.' || case when v_catatan = '' then ' Untuk mencoba sekarang jalankan: select sigarda.terbit_ulang_kirim(); lalu beberapa detik kemudian: select sigarda.terbit_ulang_keadaan();' else v_catatan end;
end $$;

-- Meminta GitHub menjalankan alur deploy (POST .../actions/workflows/<alur>/dispatches, jawaban sukses = HTTP 204), asinkron lewat pg_net. Mengembalikan id permintaan,
-- atau null tanpa konfigurasi atau tanpa pg_net. Galat tidak dilempar: dicatat, dan perubahan tetap ditandai "perlu" agar dicoba lagi.
create function sigarda.terbit_ulang_kirim_sekarang() returns bigint language plpgsql security definer set search_path = public as
$$
declare v public.terbit_ulang_konfigurasi; v_id bigint;
begin
  select * into v from public.terbit_ulang_konfigurasi;
  if not found or to_regnamespace('net') is null then return null; end if;
  begin
    execute 'select net.http_post(url := $1, body := $2, headers := $3, timeout_milliseconds := $4)'
      into v_id
      using 'https://api.github.com/repos/' || v.repo || '/actions/workflows/' || v.alur || '/dispatches', jsonb_build_object('ref', v.cabang),
            jsonb_build_object('Accept', 'application/vnd.github+json', 'Authorization', 'Bearer ' || v.token, 'X-GitHub-Api-Version', '2022-11-28',
              'User-Agent', 'sigarda-terbit-ulang', 'Content-Type', 'application/json'), 10000;
  exception when others then
    update public.terbit_ulang_konfigurasi set kirim_terakhir = now(), kirim_id = null, status_terakhir = 0, pesan_terakhir = 'Gagal mengantre permintaan ke GitHub.',
      perlu = true, perlu_sejak = coalesce(perlu_sejak, now()), gagal_beruntun = gagal_beruntun + 1;
    return null;
  end;
  update public.terbit_ulang_konfigurasi set kirim_terakhir = now(), kirim_id = v_id, status_terakhir = null, pesan_terakhir = 'Menunggu jawaban GitHub', perlu = false, perlu_sejak = null;
  return v_id;
end $$;

-- Mencatat jawaban GitHub atas permintaan terakhir dari net._http_response. Sukses (204) menutup permintaan; selain itu perubahan ditandai "perlu" lagi dan pesannya menuntun.
create function sigarda.terbit_ulang_catat() returns void language plpgsql security definer set search_path = public as
$$
declare v public.terbit_ulang_konfigurasi; v_n int; v_status int; v_galat text;
begin
  select * into v from public.terbit_ulang_konfigurasi;
  if not found or v.kirim_id is null or to_regnamespace('net') is null then return; end if;
  begin
    execute 'select count(*)::int, max(status_code), max(error_msg) from net._http_response where id = $1' into v_n, v_status, v_galat using v.kirim_id;
  exception when others then
    return;
  end;
  if v_n = 0 then return; end if;
  if v_status = 204 then
    update public.terbit_ulang_konfigurasi set status_terakhir = 204, kirim_id = null, gagal_beruntun = 0,
      pesan_terakhir = 'Deploy diminta ke GitHub (HTTP 204); halaman berita siap sekitar 2 sampai 3 menit lagi.';
  else
    update public.terbit_ulang_konfigurasi set status_terakhir = coalesce(v_status, 0), kirim_id = null, perlu = true, perlu_sejak = coalesce(perlu_sejak, now()), gagal_beruntun = gagal_beruntun + 1,
      pesan_terakhir = coalesce(v_galat, 'HTTP ' || v_status || (case
        when v_status = 401 then ': kunci akses GitHub salah atau sudah kedaluwarsa (buat kunci baru lalu jalankan sigarda.terbit_ulang_atur lagi)'
        when v_status = 403 then ': kunci tidak punya izin Actions (Read and write) pada repositori ini'
        when v_status = 404 then ': repositori, berkas alur, atau akses kunci tidak cocok'
        when v_status = 422 then ': cabang atau berkas alur tidak ditemukan, atau alur belum mengizinkan dijalankan manual (workflow_dispatch)'
        else '' end));
  end if;
end $$;

-- Dipanggil pg_cron tiap 5 menit: mencatat jawaban terakhir, lalu meminta terbit ulang HANYA bila ada berita terbit yang berubah (penanda "perlu" dari pemicu) atau
-- yang jadwal terbitnya tiba sejak permintaan terakhir. Berhenti mencoba sesudah 3 kegagalan beruntun; jeda minimal 4 menit antar permintaan.
create function sigarda.terbit_ulang_periksa() returns bigint language plpgsql security definer set search_path = public as
$$
declare v public.terbit_ulang_konfigurasi; v_jadwal boolean;
begin
  perform sigarda.terbit_ulang_catat();
  select * into v from public.terbit_ulang_konfigurasi;
  if not found or v.gagal_beruntun >= 3 then return null; end if;
  if v.kirim_terakhir is not null and v.kirim_terakhir > now() - interval '4 minutes' then return null; end if;
  v_jadwal := exists (select 1 from public.beranda_berita where status = 'terbit' and terbit_pada <= now() and terbit_pada > coalesce(v.kirim_terakhir, '-infinity'::timestamptz));
  if not (v.perlu or v_jadwal) then return null; end if;
  return sigarda.terbit_ulang_kirim_sekarang();
end $$;

-- Keadaan terbit ulang TANPA kunci dan repositori (untuk layar Kelola Beranda dan untuk pemilik di SQL Editor): { diatur, perlu, kirimTerakhir, status, pesan, gagalBeruntun, menyerah }.
create function sigarda.terbit_ulang_keadaan() returns jsonb language plpgsql security definer set search_path = public as
$$
declare v public.terbit_ulang_konfigurasi;
begin
  select * into v from public.terbit_ulang_konfigurasi;
  if not found then return jsonb_build_object('diatur', false); end if;
  return jsonb_build_object('diatur', true, 'perlu', v.perlu, 'kirimTerakhir', v.kirim_terakhir, 'status', v.status_terakhir, 'pesan', v.pesan_terakhir,
    'gagalBeruntun', v.gagal_beruntun, 'menyerah', v.gagal_beruntun >= 3);
end $$;

-- Untuk pemilik di SQL Editor: mengirim permintaan terbit ulang sekarang (untuk mencoba pengaturan) dan menghapus hitungan gagal.
create function sigarda.terbit_ulang_kirim() returns text language plpgsql security definer set search_path = public as
$$
begin
  if auth.uid() is not null then raise exception 'Perintah ini hanya dari SQL Editor Supabase.'; end if;
  if not exists (select 1 from public.terbit_ulang_konfigurasi) then raise exception 'Belum diatur: jalankan sigarda.terbit_ulang_atur lebih dulu.'; end if;
  if to_regnamespace('net') is null then raise exception 'pg_net belum aktif (Dashboard > Integrations).'; end if;
  update public.terbit_ulang_konfigurasi set gagal_beruntun = 0;
  perform sigarda.terbit_ulang_kirim_sekarang();
  return 'Permintaan terbit ulang dikirim. Beberapa detik lagi jalankan: select sigarda.terbit_ulang_periksa(); select sigarda.terbit_ulang_keadaan();';
end $$;

-- Mematikan terbit ulang otomatis: menghapus pekerjaan pg_cron dan konfigurasi (termasuk kunci akses).
create function sigarda.terbit_ulang_matikan() returns void language plpgsql security definer set search_path = public as
$$
begin
  if auth.uid() is not null then raise exception 'Perintah ini hanya dari SQL Editor Supabase.'; end if;
  if to_regnamespace('cron') is not null then
    begin
      perform cron.unschedule('sigarda-terbit-ulang');
    exception when others then null; end;
  end if;
  delete from public.terbit_ulang_konfigurasi;
end $$;

-- Pemicu: setiap perubahan yang menyentuh berita TERBIT (diterbitkan, diubah, dibatalkan/ditolak dari terbit, atau dihapus) menandai bahwa halaman berita perlu terbit ulang
-- (pekerjaan pg_cron yang mengirim permintaannya, sehingga banyak perubahan dalam 5 menit menjadi satu deploy). Tanpa konfigurasi tidak melakukan apa pun.
create function sigarda.terbit_ulang_tandai() returns trigger language plpgsql security definer set search_path = public as
$$
begin
  if (TG_OP = 'INSERT' and NEW.status = 'terbit') or (TG_OP = 'DELETE' and OLD.status = 'terbit') or (TG_OP = 'UPDATE' and (OLD.status = 'terbit' or NEW.status = 'terbit')) then
    update public.terbit_ulang_konfigurasi set perlu = true, perlu_sejak = coalesce(perlu_sejak, now()), gagal_beruntun = 0;
  end if;
  return null;
end $$;
create trigger terbit_ulang_berita after insert or update or delete on public.beranda_berita for each row execute function sigarda.terbit_ulang_tandai();

-- Untuk Pembina dan Admin Gudep (layar Kelola Beranda > Berita): keadaan terbit ulang terbaru (jawaban GitHub dicatat dulu).
create function public.sg_terbit_ulang_status() returns jsonb language plpgsql security definer set search_path = public as
$$
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pembina_atau_admin() then raise exception 'Hanya Pembina dan Admin Gudep yang dapat melihat keadaan terbit ulang halaman berita.'; end if;
  perform sigarda.terbit_ulang_catat();
  return sigarda.terbit_ulang_keadaan();
end $$;

-- Tombol "Terbitkan ulang halaman berita sekarang" (Pembina dan Admin Gudep): meminta deploy segera, paling cepat tiap 2 menit; menghapus hitungan gagal (mencoba lagi).
create function public.sg_terbit_ulang_minta() returns jsonb language plpgsql security definer set search_path = public as
$$
declare v_terakhir timestamptz;
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pembina_atau_admin() then raise exception 'Hanya Pembina dan Admin Gudep yang dapat meminta terbit ulang halaman berita.'; end if;
  if not exists (select 1 from public.terbit_ulang_konfigurasi) then raise exception 'Terbit ulang otomatis belum diatur oleh pemilik proyek (lihat README, bagian Halaman berita untuk mesin pencari).'; end if;
  perform sigarda.terbit_ulang_catat();
  select kirim_terakhir into v_terakhir from public.terbit_ulang_konfigurasi;
  if v_terakhir is not null and v_terakhir > now() - interval '2 minutes' then raise exception 'Permintaan baru saja dikirim. Tunggu beberapa menit sebelum meminta lagi.'; end if;
  update public.terbit_ulang_konfigurasi set gagal_beruntun = 0;
  perform sigarda.terbit_ulang_kirim_sekarang();
  return sigarda.terbit_ulang_keadaan();
end $$;
-- ===== akhir fungsi terbit ulang =====
-- ---------------------------------------------------------------------------
-- 2. Fungsi bantu (tidak diekspos lewat API)
-- ---------------------------------------------------------------------------
-- PIN awal (dari admin) dan PIN hasil reset WAJIB diganti dulu. Selama profil bertanda wajib_ganti_pin, server hanya
-- melayani pembacaan profil sendiri dan penggantian PIN; semua pembacaan dan aksi lain ditolak.
create function sigarda.aktif() returns boolean language plpgsql stable security definer set search_path = public as
$$ begin return coalesce((select not wajib_ganti_pin from public.profiles where id = auth.uid()), false); end $$;

create function sigarda.wajib_aktif() returns void language plpgsql stable security definer set search_path = public as
$$
begin
  if exists (select 1 from public.profiles where id = auth.uid() and wajib_ganti_pin) then
    raise exception 'Ganti PIN awal Anda lebih dulu sebelum memakai aplikasi.';
  end if;
end $$;

create function sigarda.peran() returns text language plpgsql stable security definer set search_path = public as
$$ begin return (select role from public.profiles where id = auth.uid()); end $$;

create function sigarda.pengurus() returns boolean language plpgsql stable security definer set search_path = public as
$$
begin
  -- Pengurus: penguji dan Admin yang aktif, serta Penegak aktif yang berjabatan Dewan Ambalan (Dewan = atribut akun Penegak).
  return coalesce((select ((role in ('penguji','admin') or (role = 'peserta' and jabatan_dewan is not null)) and status = 'aktif') and not wajib_ganti_pin
                   from public.profiles where id = auth.uid()), false);
end $$;

create function sigarda.kelola_materi() returns boolean language plpgsql stable security definer set search_path = public as
$$ begin
  return coalesce((select (role = 'admin' or (role = 'penguji' and jabatan = 'Pembina')) and not wajib_ganti_pin from public.profiles where id = auth.uid()), false);
end $$;

create function sigarda.pembina_atau_admin() returns boolean language plpgsql stable security definer set search_path = public as
$$ begin
  return coalesce((select (role = 'admin' or (role = 'penguji' and jabatan = 'Pembina')) and not wajib_ganti_pin from public.profiles where id = auth.uid()), false);
end $$;

-- ===== Usulan kegiatan (tahap L6b): peran ===== (dua fungsi bantu peran, dipakai migrasi L6b)
-- HANYA Pembina (bukan Admin); dipakai untuk keputusan yang sengaja tidak diberikan ke Admin (mis. meninjau usulan kegiatan).
create function sigarda.pembina_saja() returns boolean language plpgsql stable security definer set search_path = public as
$$ begin
  return coalesce((select role = 'penguji' and jabatan = 'Pembina' and status = 'aktif' and not wajib_ganti_pin from public.profiles where id = auth.uid()), false);
end $$;

-- Pradana atau Pradani: Penegak aktif berjabatan itu (akun biasa), ATAU akun Dewan lama (jabatan Dewan Ambalan) yang belum diarsipkan dan
-- masih berjabatan itu (cermin sigarda.dewan(), sama-sama menerima kedua bentuk akun). Satu-satunya yang boleh mengajukan usulan kegiatan
-- (Musyawarah Ambalan dan 10 kegiatan lain, tahap L6b).
create function sigarda.pradana_atau_pradani() returns boolean language plpgsql stable security definer set search_path = public as
$$ begin
  return coalesce((select ((role = 'peserta') or (role = 'penguji' and jabatan = 'Dewan Ambalan')) and status = 'aktif'
                   and jabatan_dewan in ('Pradana', 'Pradani') and not wajib_ganti_pin
                   from public.profiles where id = auth.uid()), false);
end $$;
-- ===== akhir peran usulan kegiatan =====


-- ===== Pra-uji berjenjang (fase C): sakelar =====
-- Sakelar pra-uji (pengaturan 'pra_uji.aktif' = {"aktif": true|false}), bawaan MATI agar peralihan dapat dipilih Pembina lewat sg_pra_uji_sakelar.
-- Bila hidup: uji resmi hanya Pembina (sigarda.bisa_menguji) dan pengajuan Penegak lebih dulu melewati pra-uji Pinsa/Bina Damping.
create function sigarda.pra_uji_aktif() returns boolean language sql stable security definer set search_path = public as
$$ select coalesce((select (nilai ->> 'aktif')::boolean from public.pengaturan where kunci = 'pra_uji.aktif'), false) $$;
-- ===== akhir sakelar pra-uji =====
-- ---- Iuran bumbung: siapa yang boleh mencatat ----
-- Dewan Ambalan (yang sudah mengganti PIN awal)
create function sigarda.dewan() returns boolean language plpgsql stable security definer set search_path = public as
$$
begin
  -- Dewan Ambalan: Penegak aktif berjabatan Dewan (akun biasa) atau akun Dewan lama yang belum diarsipkan.
  return coalesce((select ((role = 'penguji' and jabatan = 'Dewan Ambalan') or (role = 'peserta' and jabatan_dewan is not null)) and status = 'aktif' and not wajib_ganti_pin
                   from public.profiles where id = auth.uid()), false);
end $$;

-- Penegak yang sedang ditunjuk sebagai asisten bendahara
create function sigarda.asisten_iuran() returns boolean language plpgsql stable security definer set search_path = public as
$$
begin
  return coalesce((select p.role = 'peserta' and p.status = 'aktif' and not p.wajib_ganti_pin and exists (select 1 from public.asisten_iuran a where a.peserta_id = p.id)
                   from public.profiles p where p.id = auth.uid()), false);
end $$;

create function sigarda.pencatat_iuran() returns boolean language plpgsql stable security definer set search_path = public as
$$ begin return sigarda.dewan() or sigarda.pembina_saja() or sigarda.asisten_iuran(); end $$;   -- Pembina ikut (Siaga tidak punya Dewan Ambalan; Pembina yang mencatat)
-- ---- akhir bantu iuran ----

-- ---- Iuran bumbung: perhitungan untuk penilaian SKU (harus sama dengan src/lib/iuranLogic.js; dijaga oleh pengujian) ----
-- Pengaturan tersimpan pada kunci 'iuran.pengaturan': {"standar":1000,"ambang":75,"lima":90,"tiga":65,"dua":50}
--   standar = iuran standar per pertemuan (dasar rekomendasi susulan); ambang = persen pertemuan beriuran yang dianggap rutin (nilai 4);
--   lima, tiga, dua = batas persen untuk nilai 5, 3, 2 (di bawah "dua" = nilai 1).
create function sigarda.iuran_angka(p_kunci text, p_bawaan int) returns int language sql stable security definer set search_path = public as
$$ select coalesce((select (nilai ->> p_kunci)::int from public.pengaturan where kunci = 'iuran.pengaturan' and jsonb_typeof(nilai) = 'object'), p_bawaan) $$;

-- Ringkasan iuran seorang Penegak pada SEMESTER yang memuat p_tanggal (Jul-Des = ganjil, Jan-Jun = genap), dihitung sampai p_tanggal:
-- pertemuan terlaksana, pertemuan beriuran (rutin + susulan), persen (dibulatkan setengah ke atas), target menurut ambang, kekurangan, dan saran nilai 1-5.
create function sigarda.iuran_hitung(p_peserta uuid, p_tanggal date)
returns table (o_mulai date, o_akhir date, o_pertemuan int, o_kali int, o_susulan int, o_persen int, o_target int, o_kurang int, o_saran int)
language plpgsql stable security definer set search_path = public as
$$
declare
  v_y int := extract(year from p_tanggal)::int; v_hingga date;
  v_amb int := sigarda.iuran_angka('ambang', 75); v_lima int := sigarda.iuran_angka('lima', 90);
  v_tiga int := sigarda.iuran_angka('tiga', 65); v_dua int := sigarda.iuran_angka('dua', 50);
begin
  if extract(month from p_tanggal) >= 7 then o_mulai := make_date(v_y, 7, 1); o_akhir := make_date(v_y, 12, 31);
  else o_mulai := make_date(v_y, 1, 1); o_akhir := make_date(v_y, 6, 30); end if;
  v_hingga := least(o_akhir, p_tanggal);
  select count(*)::int into o_pertemuan from public.absensi_sesi where tanggal between o_mulai and v_hingga;
  select count(*)::int, count(*) filter (where jenis = 'susulan')::int into o_kali, o_susulan
    from public.iuran where peserta_id = p_peserta and tanggal between o_mulai and v_hingga;
  if o_pertemuan = 0 then
    o_persen := null; o_target := 0; o_kurang := 0; o_saran := null;
  else
    o_persen := floor(o_kali * 100.0 / o_pertemuan + 0.5)::int;
    o_target := ceil(v_amb * o_pertemuan / 100.0)::int;
    o_kurang := greatest(0, o_target - o_kali);
    o_saran := case when o_persen >= v_lima then 5 when o_persen >= v_amb then 4 when o_persen >= v_tiga then 3 when o_persen >= v_dua then 2 else 1 end;
  end if;
  return next;
end $$;
-- ---- akhir hitung iuran ----

-- Nilai pengaturan bertipe teks; bila belum pernah diatur dipakai nilai bawaan.
create function sigarda.pengaturan_teks(p_kunci text, p_bawaan text) returns text
language sql stable security definer set search_path = public as
$$ select coalesce((select nilai #>> '{}' from public.pengaturan where kunci = p_kunci), p_bawaan) $$;

-- Nomor urut diberi nol di depan sampai selebar p_lebar; angka yang lebih panjang tidak dipotong (lpad memotong!).
create function sigarda.pad_nomor(p_no int, p_lebar int) returns text language sql immutable as
$$ select case when char_length(p_no::text) >= p_lebar then p_no::text else lpad(p_no::text, p_lebar, '0') end $$;

-- Nomor berita acara dari format. Kode: {no} {no2} {no3} {no4} {no5} {no6} (nomor urut dengan nol di depan sampai 2-6 angka),
-- {tahun} {bulan} {romawi} {tingkat}. Harus sama dengan formatNomor() di src/lib/sidangLogic.js (dijaga oleh pengujian).
create function sigarda.format_nomor(p_format text, p_no int, p_tanggal date, p_tingkat text) returns text
language sql immutable as
$$
  select replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(p_format,
    '{no6}', sigarda.pad_nomor(p_no, 6)),
    '{no5}', sigarda.pad_nomor(p_no, 5)),
    '{no4}', sigarda.pad_nomor(p_no, 4)),
    '{no3}', sigarda.pad_nomor(p_no, 3)),
    '{no2}', sigarda.pad_nomor(p_no, 2)),
    '{no}', p_no::text),
    '{tahun}', extract(year from p_tanggal)::int::text),
    '{bulan}', lpad(extract(month from p_tanggal)::int::text, 2, '0')),
    '{romawi}', (array['I','II','III','IV','V','VI','VII','VIII','IX','X','XI','XII'])[extract(month from p_tanggal)::int]),
    '{tingkat}', p_tingkat)
$$;

-- ---- Raport ekstrakurikuler: pengaturan dan perhitungan (harus sama dengan src/lib/raportLogic.js; dijaga oleh pengujian) ----
-- Pengaturan tersimpan sebagai satu objek JSON pada kunci 'raport.pengaturan':
--   {"pita":{"sangatBaik":90,"baik":75,"cukup":60},"bobot":{"kehadiran":40,"capaian":40,"sikap":20},"target":{"Bantara":12,"Laksana":11}}
create function sigarda.raport_angka(p_jalur text[], p_bawaan int) returns int language sql stable security definer set search_path = public as
$$
  select coalesce((select (nilai #>> p_jalur)::int from public.pengaturan where kunci = 'raport.pengaturan' and jsonb_typeof(nilai) = 'object'), p_bawaan)
$$;

-- Skor 0-100 = rata-rata tertimbang komponen yang tersedia (kehadiran dan sikap boleh kosong; bobotnya dialihkan ke komponen lain).
-- Capaian = butir lulus semester ini terhadap target, maksimal 100. Sikap 1-5 dikali 20. Pembulatan setengah ke atas.
create function sigarda.raport_skor(p_kehadiran int, p_capaian_lulus int, p_capaian_target int, p_sikap int) returns int
language plpgsql stable security definer set search_path = public as
$$
declare
  wh int := sigarda.raport_angka('{bobot,kehadiran}', 40); wc int := sigarda.raport_angka('{bobot,capaian}', 40); ws int := sigarda.raport_angka('{bobot,sikap}', 20);
  sc int := least(100, round(p_capaian_lulus * 100.0 / p_capaian_target)::int);
  jumlah_w int; jumlah_ws int;
begin
  jumlah_w := wc + case when p_kehadiran is not null then wh else 0 end + case when p_sikap is not null then ws else 0 end;
  if jumlah_w = 0 then return null; end if;
  jumlah_ws := wc * sc + coalesce(wh * p_kehadiran, 0) + coalesce(ws * p_sikap * 20, 0);
  return round(jumlah_ws::numeric / jumlah_w)::int;
end $$;

create function sigarda.raport_predikat(p_skor int) returns text language sql stable security definer set search_path = public as
$$
  select case
    when p_skor is null then null
    when p_skor >= sigarda.raport_angka('{pita,sangatBaik}', 90) then 'A'
    when p_skor >= sigarda.raport_angka('{pita,baik}', 75) then 'B'
    when p_skor >= sigarda.raport_angka('{pita,cukup}', 60) then 'C'
    else 'D' end
$$;

-- Bahan hitung semester: kehadiran (H dan jumlah tercatat H+I+S+A pada Jumat semester itu) dan capaian SKU (butir tingkat itu
-- yang lulus dengan tanggal uji dalam semester itu; butir agama lulus bila seluruh sub-butirnya lulus, tanggalnya yang terakhir).
-- Semester Ganjil: 1 Juli - 31 Desember tahun pertama; Genap: 1 Januari - 30 Juni tahun kedua.
create function sigarda.raport_hitung(p_peserta uuid, p_ta text, p_semester text, p_tingkat text)
returns table (o_hadir int, o_dicatat int, o_lulus int, o_target int)
language plpgsql stable security definer set search_path = public as
$$
declare v_y int := split_part(p_ta, '/', 1)::int; v_mulai date; v_akhir date; v_agama text;
begin
  if p_semester = 'ganjil' then v_mulai := make_date(v_y, 7, 1); v_akhir := make_date(v_y, 12, 31);
  else v_mulai := make_date(v_y + 1, 1, 1); v_akhir := make_date(v_y + 1, 6, 30); end if;
  select agama into v_agama from public.profiles where id = p_peserta;
  select (count(*) filter (where h.status = 'H'))::int, count(*)::int into o_hadir, o_dicatat
  from public.absensi_hadir h where h.peserta_id = p_peserta and h.tanggal between v_mulai and v_akhir;
  select count(*)::int into o_lulus from (
    select u.butir_id
    from public.sku_unit u
    left join public.sku_progress g on g.sku_id = u.id and g.peserta_id = p_peserta
    where u.tingkat = p_tingkat and (u.agama is null or u.agama = v_agama)
    group by u.butir_id
    having bool_and(coalesce(g.status, 'belum') = 'lulus') and max(g.tanggal_uji) between v_mulai and v_akhir
  ) b;
  o_target := sigarda.raport_angka(array['target', p_tingkat], case p_tingkat when 'Bantara' then 12 else 11 end);
  return next;
end $$;

-- ---- Instrumen penilaian: pengaturan dan perhitungan (harus sama dengan src/lib/instrumenLogic.js; dijaga oleh pengujian) ----
-- Pengaturan tersimpan pada kunci 'instrumen.pengaturan':
--   {"ambang":75,"pita":{"sangatBaik":90,"baik":75,"cukup":60},"gerbangWajib":true,"nilaiWajibMin":3}
create function sigarda.instrumen_angka(p_jalur text[], p_bawaan int) returns int language sql stable security definer set search_path = public as
$$
  select coalesce((select (nilai #>> p_jalur)::int from public.pengaturan where kunci = 'instrumen.pengaturan' and jsonb_typeof(nilai) = 'object'), p_bawaan)
$$;

create function sigarda.instrumen_gerbang() returns boolean language sql stable security definer set search_path = public as
$$
  select coalesce((select (nilai ->> 'gerbangWajib')::boolean from public.pengaturan where kunci = 'instrumen.pengaturan' and jsonb_typeof(nilai) = 'object'), true)
$$;

create function sigarda.instrumen_aktif(p_sku text) returns boolean language sql stable security definer set search_path = public as
$$ select exists (select 1 from public.instrumen i where i.sku_id = p_sku and i.status = 'ditetapkan') $$;

-- Skor 0-100 = 20 x jumlah(nilai x bobot) / jumlah(bobot), dibulatkan setengah ke atas. Saran LULUS bila skor mencapai ambang dan
-- (bila gerbang wajib aktif) setiap kriteria wajib bernilai minimal nilaiWajibMin. Nilai (predikat) dari pita.
-- Rincian: array {kriteria_id, nilai 1-5} yang harus mencakup SELURUH kriteria instrumen tepat satu kali.
create function sigarda.instrumen_hitung(p_sku text, p_rincian jsonb)
returns table (o_skor int, o_wajib_ok boolean, o_saran text, o_nilai text)
language plpgsql stable security definer set search_path = public as
$$
declare
  v_jumlah int; v_cocok int; v_beda int; v_s int; v_w int; v_ok boolean; v_skor int;
  v_min int := sigarda.instrumen_angka(array['nilaiWajibMin'], 3);
  v_ambang int := sigarda.instrumen_angka(array['ambang'], 75);
begin
  if p_rincian is null or jsonb_typeof(p_rincian) <> 'array' then raise exception 'Nilai kriteria tidak sah.'; end if;
  select count(*) into v_jumlah from public.instrumen_kriteria where sku_id = p_sku;
  if v_jumlah = 0 then raise exception 'Instrumen belum memiliki kriteria.'; end if;
  if exists (
    select 1 from jsonb_array_elements(p_rincian) e
    where jsonb_typeof(e) <> 'object' or coalesce(e ->> 'kriteria_id', '') !~ '^[0-9]{1,18}$' or coalesce(e ->> 'nilai', '') !~ '^[1-5]$'
  ) then raise exception 'Nilai tiap kriteria harus bilangan bulat 1 sampai 5.'; end if;

  select count(*), count(distinct k.id), coalesce(sum(k.bobot * r.nilai), 0), coalesce(sum(k.bobot), 0), coalesce(bool_and(not k.wajib or r.nilai >= v_min), true)
    into v_cocok, v_beda, v_s, v_w, v_ok
  from (select (e ->> 'kriteria_id')::bigint as kriteria_id, (e ->> 'nilai')::int as nilai from jsonb_array_elements(p_rincian) e) r
  join public.instrumen_kriteria k on k.id = r.kriteria_id and k.sku_id = p_sku;
  if jsonb_array_length(p_rincian) <> v_jumlah or v_cocok <> v_jumlah or v_beda <> v_jumlah then
    raise exception 'Nilai kriteria tidak lengkap atau tidak sesuai instrumen (instrumen mungkin baru diubah). Buka ulang lembar penilaian.';
  end if;

  v_skor := round(20.0 * v_s / v_w)::int;
  o_skor := v_skor;
  o_wajib_ok := v_ok;
  o_saran := case when v_skor >= v_ambang and (v_ok or not sigarda.instrumen_gerbang()) then 'lulus' else 'ulang' end;
  o_nilai := case
    when v_skor >= sigarda.instrumen_angka(array['pita', 'sangatBaik'], 90) then 'Sangat baik'
    when v_skor >= sigarda.instrumen_angka(array['pita', 'baik'], 75) then 'Baik'
    else 'Cukup' end;
  return next;
end $$;

-- ===== SKU Siaga (Pramuka Siaga, Fase 2): prasyarat tingkat =====
-- Tingkat yang harus selesai lebih dulu: Laksana menunggu Bantara; Bantu menunggu Mula; Tata menunggu Bantu (SK Kwarnas 119/2011). Bantara dan Mula tanpa prasyarat.
-- Dicerminkan src/lib/skuLogic.js (PRASYARAT_TINGKAT) dan dibandingkan langsung oleh uji/sku-siaga.mjs.
create function sigarda.prasyarat_tingkat(p_tingkat text) returns text language sql immutable as
$$ select case p_tingkat when 'Laksana' then 'Bantara' when 'Bantu' then 'Mula' when 'Tata' then 'Bantu' end $$;
-- ===== akhir prasyarat tingkat =====

-- Seluruh unit SKU tingkat ini yang berlaku bagi peserta (sesuai agamanya) sudah lulus.
create function sigarda.tingkat_selesai(p_peserta uuid, p_tingkat text) returns boolean
language plpgsql stable security definer set search_path = public as
$$
begin
  return exists (select 1 from public.sku_unit where tingkat = p_tingkat)
    and not exists (
      select 1
      from public.sku_unit u
      join public.profiles p on p.id = p_peserta
      where u.tingkat = p_tingkat and (u.agama is null or u.agama = p.agama)
        and not exists (
          select 1 from public.sku_progress g
          where g.peserta_id = p_peserta and g.sku_id = u.id and g.status = 'lulus'
        )
    );
end $$;

create function sigarda.layak_garuda(p_peserta uuid) returns boolean
language plpgsql stable security definer set search_path = public as
$$ begin return sigarda.tingkat_selesai(p_peserta, 'Bantara') and sigarda.tingkat_selesai(p_peserta, 'Laksana'); end $$;

-- Token acak 32 karakter heksadesimal (128 bit acak penuh): tiga UUID acak, hanya bagian yang bukan penanda versi/varian.
create function sigarda.token_acak() returns text language sql volatile as
$$
  select left(replace(gen_random_uuid()::text, '-', ''), 12) || left(replace(gen_random_uuid()::text, '-', ''), 12) || left(replace(gen_random_uuid()::text, '-', ''), 8)
$$;

create function sigarda.kode_verifikasi(p_bagian text[]) returns text language sql immutable as
$$ select 'VRF-' || upper(lpad(substr(md5(array_to_string(p_bagian, '|')), 1, 7), 7, '0')) $$;

create function sigarda.rapikan(p_teks text) returns text language sql immutable as
$$ select regexp_replace(btrim(coalesce(p_teks, '')), '\s+', ' ', 'g') $$;

-- ---- Penugasan rombel: fungsi bantu (harus sama dengan src/lib/rombelLogic.js; dijaga oleh pengujian) ----
-- Rombel baku: X-01 sampai X-10, XI-01 sampai XI-10, XII-01 sampai XII-10. rombel_baku membuang spasi dan membesarkan huruf.
create function sigarda.rombel_baku(p_teks text) returns text language sql immutable as
$$ select upper(regexp_replace(coalesce(p_teks, ''), '\s+', '', 'g')) $$;

create function sigarda.rombel_sah(p_rombel text) returns boolean language sql immutable as
$$ select coalesce(p_rombel ~ '^((X|XI|XII)-(0[1-9]|10)|[1-6][A-Z]?)$', false) $$;

-- Tahun ajaran berbentuk 2026/2027 (tahun kedua = tahun pertama + 1).
create function sigarda.tahun_ajaran_sah(p_ta text) returns boolean language sql immutable as
$$
  select case when p_ta ~ '^[0-9]{4}/[0-9]{4}$'
    then split_part(p_ta, '/', 2)::int = split_part(p_ta, '/', 1)::int + 1 and split_part(p_ta, '/', 1)::int between 2000 and 2100
    else false end
$$;

-- Tahun ajaran yang sedang berjalan (Juli sampai Desember = tahun ini/tahun depan; Januari sampai Juni = tahun lalu/tahun ini).
create function sigarda.tahun_ajaran_kini() returns text language sql stable as
$$
  select case when extract(month from sigarda.hari_ini()) >= 7
    then extract(year from sigarda.hari_ini())::int || '/' || (extract(year from sigarda.hari_ini())::int + 1)
    else (extract(year from sigarda.hari_ini())::int - 1) || '/' || extract(year from sigarda.hari_ini())::int end
$$;

-- Memastikan pemanggil adalah Admin Gudep yang sudah mengganti PIN awal; selain itu galat dengan pesan p_pesan.
create function sigarda.wajib_admin(p_pesan text) returns void language plpgsql stable security definer set search_path = public as
$$
begin
  perform sigarda.wajib_aktif();
  if coalesce((select role from public.profiles where id = auth.uid()), '') <> 'admin' then raise exception '%', p_pesan; end if;
end $$;
-- ---- akhir bantu penugasan ----

-- ---- Penegakan penugasan penguji: fungsi bantu (dicerminkan src/lib/rombelLogic.js pengujiSah; dijaga oleh pengujian) ----
-- Aturan peran (berlaku saat memilih penguji DAN saat mencatat hasil): penguji = Pembina, Penegak berjabatan Dewan Ambalan (aktif), atau akun Dewan lama
-- yang belum diarsipkan; tidak pernah menguji dirinya sendiri. Butir agama hanya Pembina yang agamanya SAMA dengan Penegak. Butir Laksana: Pembina, atau
-- penguji yang DITUGASKAN untuk Penegak itu (sigarda.ditugaskan: penugasan khusus Penegak, atau penugasan rombelnya); tanpa penugasan, Dewan hanya
-- menguji butir Bantara. Butir Bantara non-agama: semua penguji. Selama belum ada satu pun
-- Pembina yang agamanya terisi (masa peralihan, sebelum Admin mengisinya), semua Pembina dianggap sah seperti aturan lama.
-- Pengecualian: bila ada surat pengantar ke guru agama yang masih berlaku untuk Penegak dan butir itu (sigarda.surat_agama_aktif), Pembina yang
-- tidak seagama boleh mencatat hasil yang dinilai guru agama luar.
create function sigarda.penguji_peran_ok(p_peserta uuid, p_penguji uuid, p_sku text) returns boolean
language plpgsql stable security definer set search_path = public as
$$
declare v_u public.profiles; v_tingkat text; v_agama_butir text; v_agama_peserta text; v_pembina boolean;
begin
  if p_penguji is null or p_penguji = p_peserta or not sigarda.bisa_menguji(p_penguji) then return false; end if;
  select * into v_u from public.profiles where id = p_penguji;
  select tingkat, agama into v_tingkat, v_agama_butir from public.sku_unit where id = p_sku;
  if not found then return false; end if;
  v_pembina := v_u.role = 'penguji' and v_u.jabatan = 'Pembina';
  -- Anak Siaga (kelas SD) hanya diuji Pembina (tanpa Dewan Ambalan maupun pra-uji).
  if not v_pembina and sigarda.kelas_siaga((select kelas from public.profiles where id = p_peserta)) then return false; end if;
  if not v_pembina and v_agama_butir is not null then return false; end if;
  if not v_pembina and v_tingkat = 'Laksana' and not sigarda.ditugaskan(p_peserta, p_penguji) then return false; end if;
  if v_agama_butir is not null
     and exists (select 1 from public.profiles b where b.role = 'penguji' and b.jabatan = 'Pembina' and b.agama is not null) then
    select agama into v_agama_peserta from public.profiles where id = p_peserta;
    if (v_u.agama is null or v_u.agama is distinct from v_agama_peserta) and not sigarda.surat_agama_aktif(p_peserta, p_sku) then return false; end if;
  end if;
  return true;
end $$;

-- Penguji yang sah untuk satu Penegak dan satu butir. Urutan: (1) penugasan KHUSUS Penegak itu pada tahun ajaran berjalan (menggantikan penugasan
-- rombel), (2) penugasan rombelnya, masing-masing bila ada penguji bertugas yang memenuhi aturan peran (o_rombel = true, artinya "hasil penugasan").
-- Bila tidak ada (belum diatur, kelas format lama, atau tak seorang pun yang bertugas boleh menguji butir itu): semua penguji yang memenuhi aturan
-- peran (o_rombel = false).
create function sigarda.penguji_sah(p_peserta uuid, p_sku text) returns table (o_penguji uuid, o_rombel boolean)
language plpgsql stable security definer set search_path = public as
$$
declare v_kelas text;
begin
  select kelas into v_kelas from public.profiles where id = p_peserta and role = 'peserta';
  if not found then return; end if;
  if exists (
    select 1 from public.penugasan_peserta x
    where x.tahun_ajaran = sigarda.tahun_ajaran_kini() and x.peserta_id = p_peserta and sigarda.penguji_peran_ok(p_peserta, x.penguji_id, p_sku)
  ) then
    return query select x.penguji_id, true from public.penugasan_peserta x
      where x.tahun_ajaran = sigarda.tahun_ajaran_kini() and x.peserta_id = p_peserta and sigarda.penguji_peran_ok(p_peserta, x.penguji_id, p_sku);
    return;
  end if;
  if sigarda.rombel_sah(v_kelas) and exists (
    select 1 from public.penugasan_rombel r
    where r.tahun_ajaran = sigarda.tahun_ajaran_kini() and r.rombel = v_kelas and sigarda.penguji_peran_ok(p_peserta, r.penguji_id, p_sku)
  ) then
    return query select r.penguji_id, true from public.penugasan_rombel r
      where r.tahun_ajaran = sigarda.tahun_ajaran_kini() and r.rombel = v_kelas and sigarda.penguji_peran_ok(p_peserta, r.penguji_id, p_sku);
  else
    return query select u.id, false from public.profiles u where sigarda.bisa_menguji(u.id) and sigarda.penguji_peran_ok(p_peserta, u.id, p_sku);
  end if;
end $$;

create function sigarda.penguji_boleh(p_peserta uuid, p_penguji uuid, p_sku text) returns boolean
language sql stable security definer set search_path = public as
$$ select exists (select 1 from sigarda.penguji_sah(p_peserta, p_sku) s where s.o_penguji = p_penguji) $$;

-- ---- Dewan Ambalan sebagai atribut Penegak: fungsi bantu (dicerminkan src/lib/rombelLogic.js dan dewanLogic.js; dijaga oleh pengujian) ----
-- ===== Pra-uji berjenjang (fase C): bisa_menguji =====
-- Boleh menguji: Pembina, Dewan Ambalan lama (belum diarsipkan), atau Penegak aktif berjabatan Dewan Ambalan. Admin Gudep tidak menguji.
-- Sakelar pra-uji HIDUP: uji resmi HANYA Pembina (AD/ART Munas 2023 Pasal 33 ayat (6) dan 35 ayat (3)); Dewan Ambalan tidak menguji.
create function sigarda.bisa_menguji(p_id uuid) returns boolean language sql stable security definer set search_path = public as
$$
  select exists (
    select 1 from public.profiles
    where id = p_id and status = 'aktif'
      and case when sigarda.pra_uji_aktif() then role = 'penguji' and jabatan = 'Pembina'
               else role = 'penguji' or (role = 'peserta' and jabatan_dewan is not null) end
  )
$$;
-- ===== akhir bisa_menguji pra-uji =====

-- Penguji ini DITUGASKAN untuk Penegak ini pada tahun ajaran berjalan? Penugasan khusus Penegak (bila ada) menggantikan penugasan rombelnya.
create function sigarda.ditugaskan(p_peserta uuid, p_penguji uuid) returns boolean language plpgsql stable security definer set search_path = public as
$$
declare v_kelas text;
begin
  if exists (select 1 from public.penugasan_peserta where tahun_ajaran = sigarda.tahun_ajaran_kini() and peserta_id = p_peserta) then
    return exists (select 1 from public.penugasan_peserta where tahun_ajaran = sigarda.tahun_ajaran_kini() and peserta_id = p_peserta and penguji_id = p_penguji);
  end if;
  select kelas into v_kelas from public.profiles where id = p_peserta;
  return sigarda.rombel_sah(v_kelas) and exists (
    select 1 from public.penugasan_rombel where tahun_ajaran = sigarda.tahun_ajaran_kini() and rombel = v_kelas and penguji_id = p_penguji);
end $$;

-- ===== Jabatan tunggal dan ketua sidang (Fase A): bantu =====
-- Jabatan Dewan tanpa selisih huruf: "pradana" -> "Pradana", "PRADANI" -> "Pradani", "pemangku  ADAT" -> "Pemangku Adat"; selain itu spasi dirapikan dan ditulis apa adanya.
create function sigarda.jabatan_baku(p_teks text) returns text language sql immutable as
$$
  select case lower(sigarda.rapikan(p_teks)) when 'pradana' then 'Pradana' when 'pradani' then 'Pradani' when 'pemangku adat' then 'Pemangku Adat' else sigarda.rapikan(p_teks) end
$$;
-- Jabatan yang hanya boleh dipegang satu anggota (cermin JABATAN_TUNGGAL di src/lib/dewanLogic.js; dijaga oleh pengujian).
create function sigarda.jabatan_tunggal(p_jabatan text) returns boolean language sql immutable as
$$ select p_jabatan in ('Pradana', 'Pradani', 'Pemangku Adat') $$;
-- ===== akhir bantu jabatan tunggal =====

-- Mencabut jabatan Dewan dari satu anggota (Penegak, atau akun Dewan lama) dan merapikan akibatnya: penugasan sebagai penguji dihapus (tercatat) dan
-- pengajuan uji yang menunggu dan ditujukan kepadanya kembali ke antrian rombel. Pengujian yang sedang berjalan ("proses") dibiarkan
-- (Pembina dapat mengalihkannya). Tercatat di kepengurusan_log. Tanpa jabatan = tidak melakukan apa pun. Dipanggil juga saat anggota menjadi nonaktif atau alumni.
create function sigarda.jabatan_dewan_lepas(p_id uuid, p_alasan text) returns void language plpgsql security definer set search_path = public as
$$
declare v_t public.profiles; v_oleh text; v_r record;
begin
  select * into v_t from public.profiles where id = p_id;
  if not found or v_t.jabatan_dewan is null then return; end if;
  select nama into v_oleh from public.profiles where id = auth.uid();
  insert into public.kepengurusan_log (peserta_id, peserta_nama, nis, tindakan, jabatan_lama, jabatan_baru, alasan, oleh, oleh_nama)
  values (p_id, v_t.nama, coalesce(v_t.nis, v_t.username), 'cabut', v_t.jabatan_dewan, null, left(coalesce(p_alasan, ''), 200), auth.uid(), coalesce(v_oleh, ''));
  update public.profiles set jabatan_dewan = null where id = p_id;
  for v_r in select tahun_ajaran, rombel from public.penugasan_rombel where penguji_id = p_id loop
    insert into public.penugasan_log (tahun_ajaran, rombel, penguji_id, penguji_nama, tindakan, catatan, oleh, oleh_nama)
    values (v_r.tahun_ajaran, v_r.rombel, p_id, v_t.nama, 'hapus', 'Jabatan Dewan berakhir', auth.uid(), coalesce(v_oleh, ''));
  end loop;
  delete from public.penugasan_rombel where penguji_id = p_id;
  for v_r in select x.tahun_ajaran, x.peserta_id, pr.nama as peserta_nama, pr.kelas from public.penugasan_peserta x join public.profiles pr on pr.id = x.peserta_id where x.penguji_id = p_id loop
    insert into public.penugasan_log (tahun_ajaran, rombel, penguji_id, penguji_nama, tindakan, catatan, oleh, oleh_nama, peserta_id, peserta_nama)
    values (v_r.tahun_ajaran, coalesce(v_r.kelas, ''), p_id, v_t.nama, 'hapus', 'Jabatan Dewan berakhir', auth.uid(), coalesce(v_oleh, ''), v_r.peserta_id, v_r.peserta_nama);
  end loop;
  delete from public.penugasan_peserta where penguji_id = p_id;
  update public.sku_progress set penguji_id = null, diubah = now() where penguji_id = p_id and status = 'diajukan';
end $$;
-- ---- akhir bantu dewan penegak ----
-- ---- akhir bantu penegakan ----

-- ---- Pinsa dan Bina Damping (fase B): fungsi bantu ----
-- Tingkat SKU seorang Penegak untuk penunjukan pendamping: 'calon-bantara' (butir Bantara belum semua lulus), 'calon-laksana' (Bantara selesai),
-- 'laksana' (Bantara dan Laksana selesai).
create function sigarda.tingkat_penegak(p_id uuid) returns text language sql stable security definer set search_path = public as
$$
  select case when not sigarda.tingkat_selesai(p_id, 'Bantara') then 'calon-bantara'
              when not sigarda.tingkat_selesai(p_id, 'Laksana') then 'calon-laksana'
              else 'laksana' end
$$;

-- Pemanggil adalah Bina Damping (aktif) untuk rombel ini pada tahun ajaran berjalan.
create function sigarda.bina_damping_rombel(p_rombel text) returns boolean language plpgsql stable security definer set search_path = public as
$$
begin
  return coalesce((select p.role = 'peserta' and p.status = 'aktif' and not p.wajib_ganti_pin
                     and exists (select 1 from public.bina_damping b where b.penegak_id = p.id and b.rombel = p_rombel and b.tahun_ajaran = sigarda.tahun_ajaran_kini())
                   from public.profiles p where p.id = auth.uid()), false);
end $$;

-- Boleh membagi sangga dan menentukan Pinsa di rombel ini: Pembina, Admin, atau Bina Damping rombel itu.
create function sigarda.sangga_bisa_atur(p_rombel text) returns boolean language sql stable security definer set search_path = public as
$$ select sigarda.pembina_atau_admin() or sigarda.bina_damping_rombel(p_rombel) $$;

-- Peringatan (tidak memblokir) tentang susunan sangga sebuah rombel: [{ "sangga": nama atau null, "teks": ... }]. Batas: 2 Bina Damping, 4-5 sangga
-- per rombel, 4-8 Penegak per sangga, dan tiap sangga punya Pinsa. Rombel tanpa anggota aktif tidak diperingatkan soal sangga.
create function sigarda.sangga_peringatan(p_rombel text) returns jsonb language plpgsql stable security definer set search_path = public as
$$
declare v_p jsonb := '[]'::jsonb; v_r record; v_sangga int := 0; v_bd int; v_tanpa int;
begin
  select count(*) into v_bd from public.bina_damping where tahun_ajaran = sigarda.tahun_ajaran_kini() and rombel = p_rombel;
  if v_bd < 2 then
    v_p := v_p || jsonb_build_array(jsonb_build_object('sangga', null, 'teks', format('Bina Damping rombel ini baru %s dari 2 orang.', v_bd)));
  end if;
  for v_r in
    -- Pinsa sebuah sangga: anggota sangga itu berstatus Pinsa, atau Penegak yang ditugaskan (pinsa_tugas) ke sangga ini.
    select g.nama, g.n, (g.ada_pinsa or exists (select 1 from public.pinsa_tugas t where t.tahun_ajaran = sigarda.tahun_ajaran_kini() and t.rombel = p_rombel and lower(t.sangga) = g.kunci)) as ada_pinsa
    from (select lower(sangga) as kunci, min(sangga) as nama, count(*)::int as n, bool_or(pinsa) as ada_pinsa from public.profiles
          where role = 'peserta' and status = 'aktif' and kelas = p_rombel and btrim(coalesce(sangga, '')) <> '' group by lower(sangga)) g
    order by g.kunci
  loop
    v_sangga := v_sangga + 1;
    if v_r.n < 4 or v_r.n > 8 then
      v_p := v_p || jsonb_build_array(jsonb_build_object('sangga', v_r.nama, 'teks', format('Sangga %s beranggotakan %s Penegak (seharusnya 4 sampai 8).', v_r.nama, v_r.n)));
    end if;
    if not v_r.ada_pinsa then
      v_p := v_p || jsonb_build_array(jsonb_build_object('sangga', v_r.nama, 'teks', format('Sangga %s belum punya Pinsa.', v_r.nama)));
    end if;
  end loop;
  -- Penegak baru dibuat tanpa sangga (Tahap 3, H1): Pembina atau Bina Damping membaginya.
  select count(*)::int into v_tanpa from public.profiles where role = 'peserta' and status = 'aktif' and kelas = p_rombel and btrim(coalesce(sangga, '')) = '';
  if v_tanpa > 0 then
    v_p := v_p || jsonb_build_array(jsonb_build_object('sangga', null, 'teks', format('%s Penegak rombel ini belum punya sangga.', v_tanpa)));
  end if;
  if v_sangga > 0 and (v_sangga < 4 or v_sangga > 5) then
    v_p := v_p || jsonb_build_array(jsonb_build_object('sangga', null, 'teks', format('Rombel ini punya %s sangga (seharusnya 4 sampai 5).', v_sangga)));
  end if;
  return v_p;
end $$;

-- Pinsa hilang sendiri bila Penegak pindah rombel atau sangga, atau tidak lagi aktif (jalur apa pun yang mengubahnya, termasuk naik kelas).
create function sigarda.pinsa_bersihkan() returns trigger language plpgsql set search_path = public as
$$
begin
  if new.pinsa and (new.role <> 'peserta' or new.status <> 'aktif' or new.kelas is distinct from old.kelas
                    or lower(coalesce(new.sangga, '')) is distinct from lower(coalesce(old.sangga, ''))) then
    new.pinsa := false;
  end if;
  return new;
end $$;
create trigger profiles_pinsa_bersih before update on public.profiles for each row execute function sigarda.pinsa_bersihkan();

-- Bina Damping berakhir bila Penegaknya nonaktif/alumni atau tidak lagi berjabatan Dewan (dicabut, atau kepengurusan diganti).
create function sigarda.bina_damping_bersihkan() returns trigger language plpgsql security definer set search_path = public as
$$
begin
  delete from public.bina_damping where penegak_id = new.id;
  return null;
end $$;
create trigger profiles_bina_damping_bersih after update of status, jabatan_dewan, role on public.profiles for each row
  when (new.status <> 'aktif' or new.jabatan_dewan is null or new.role <> 'peserta') execute function sigarda.bina_damping_bersihkan();
-- ---- akhir bantu pinsa bina damping ----

-- ---- Pinsa tertugas lintas rombel: fungsi bantu ----
-- Penugasan Pinsa berakhir bila Penegaknya nonaktif/alumni (jalur apa pun yang mengubah status atau peran).
create function sigarda.pinsa_tugas_bersihkan() returns trigger language plpgsql security definer set search_path = public as
$$
begin
  delete from public.pinsa_tugas where penegak_id = new.id;
  return null;
end $$;
create trigger profiles_pinsa_tugas_bersih after update of status, role on public.profiles for each row
  when (new.status <> 'aktif' or new.role <> 'peserta') execute function sigarda.pinsa_tugas_bersihkan();
-- ---- akhir bantu pinsa tertugas ----

-- ---- Dokumen terbit: fungsi bantu (dicerminkan src/lib/dokumenLogic.js suratAgamaAktif; dijaga oleh pengujian) ----
-- Ada surat pengantar agama yang belum dicabut untuk Penegak ini dan memuat butir (unit) itu?
create function sigarda.surat_agama_aktif(p_peserta uuid, p_sku text) returns boolean
language sql stable security definer set search_path = public as
$$
  select exists (
    select 1 from public.dokumen_terbit d
    where d.jenis = 'surat_pengantar_agama' and d.peserta_id = p_peserta and d.dicabut_pada is null and d.payload -> 'butir' @> jsonb_build_array(p_sku)
  )
$$;
-- ---- akhir bantu dokumen ----

-- ---- Notifikasi: fungsi bantu dan pemicu ----
-- Notifikasi dibuat oleh pemicu pada tabel (bukan di tiap fungsi aksi) agar semua jalur penulisan tercakup, termasuk Edge Function catat-hasil.
-- Isi singkat dan tanpa hasil lulus/ulang (layar kunci HP bisa dilihat orang lain). Penerima tidak pernah sama dengan pelaku yang bersangkutan.
create function sigarda.notif_buat(p_penerima uuid, p_jenis text, p_judul text, p_isi text, p_tautan jsonb, p_kunci text default null) returns void
language plpgsql security definer set search_path = public as
$$
begin
  if p_penerima is null then return; end if;
  insert into public.notifikasi (penerima_id, jenis, judul, isi, tautan, kunci)
  values (p_penerima, p_jenis, left(p_judul, 120), left(coalesce(p_isi, ''), 300), coalesce(p_tautan, '{}'::jsonb), p_kunci)
  on conflict (penerima_id, kunci) where kunci is not null do nothing;
end $$;

-- "Bantara butir 5" untuk satu unit SKU.
create function sigarda.notif_label_butir(p_sku text) returns text language sql stable security definer set search_path = public as
$$ select coalesce((select u.tingkat || ' butir ' || u.butir_no from public.sku_unit u where u.id = p_sku), p_sku) $$;

-- Penguji yang perlu tahu tentang satu pengajuan: penguji tujuan, atau (antrian rombel) semua penguji yang sah untuk Penegak dan butir itu.
create function sigarda.notif_penerima_uji(p_peserta uuid, p_sku text, p_penguji uuid) returns setof uuid
language plpgsql stable security definer set search_path = public as
$$
begin
  if p_penguji is not null then return next p_penguji; return; end if;
  return query select s.o_penguji from sigarda.penguji_sah(p_peserta, p_sku) s;
end $$;

create function sigarda.notif_sku_progress() returns trigger language plpgsql security definer set search_path = public as
$$
declare
  v_lama text; v_lama_penguji uuid; v_nama text; v_label text := sigarda.notif_label_butir(NEW.sku_id); v_x uuid;
begin
  if TG_OP = 'UPDATE' then v_lama := OLD.status; v_lama_penguji := OLD.penguji_id; end if;
  select nama into v_nama from public.profiles where id = NEW.peserta_id;
  if NEW.status = 'diajukan' and v_lama is distinct from 'diajukan' then
    for v_x in select * from sigarda.notif_penerima_uji(NEW.peserta_id, NEW.sku_id, NEW.penguji_id) loop
      perform sigarda.notif_buat(v_x, 'ajukan', 'Pengajuan uji baru',
        v_nama || ' mengajukan ' || v_label || ' untuk ' || to_char(NEW.jadwal, 'DD-MM-YYYY') || case when NEW.penguji_id is null then ' (antrian rombel)' else '' end,
        '{"tab":"antrian"}');
    end loop;
  elsif NEW.status in ('diajukan', 'proses') and NEW.status = v_lama and v_lama_penguji is distinct from NEW.penguji_id then   -- status sama, penguji berganti (mengambil dari antrian bersama = "mulai")
    for v_x in select * from sigarda.notif_penerima_uji(NEW.peserta_id, NEW.sku_id, NEW.penguji_id) loop
      perform sigarda.notif_buat(v_x, 'alih', case when NEW.penguji_id is null then 'Pengajuan masuk antrian rombel' else 'Pengujian dialihkan kepada Anda' end,
        v_nama || ', ' || v_label, '{"tab":"antrian"}');
    end loop;
  elsif NEW.status = 'proses' and v_lama is distinct from 'proses' then
    perform sigarda.notif_buat(NEW.peserta_id, 'mulai', 'Pengujian dimulai', 'Penguji mulai menguji ' || v_label || '.', '{"tab":"sku"}');
  elsif NEW.status in ('lulus', 'ulang') and v_lama is distinct from NEW.status then
    perform sigarda.notif_buat(NEW.peserta_id, 'hasil', 'Hasil penilaian tersedia', 'Hasil ' || v_label || ' sudah dicatat. Buka aplikasi untuk melihatnya.', '{"tab":"sku"}');
  end if;
  return null;
end $$;
create trigger notif_sku_progress after insert or update of status, penguji_id on public.sku_progress
  for each row execute function sigarda.notif_sku_progress();

-- Penegak yang dimasukkan ke sesi ujian bersama. Kunci memuat tanggal: menyimpan ulang sesi tidak menggandakan, mengganti tanggal memberi tahu lagi.
create function sigarda.notif_sesi_peserta() returns trigger language plpgsql security definer set search_path = public as
$$
declare v_s public.sesi_ujian;
begin
  select * into v_s from public.sesi_ujian where id = NEW.sesi_id;
  if not found or v_s.status = 'selesai' then return null; end if;
  perform sigarda.notif_buat(NEW.peserta_id, 'sesi', 'Jadwal ujian bersama',
    v_s.nama || ', ' || to_char(v_s.tanggal, 'DD-MM-YYYY') || case when v_s.tempat <> '' then ' di ' || v_s.tempat else '' end,
    '{"tab":"beranda"}', 'sesi:' || v_s.id || ':' || v_s.tanggal);
  return null;
end $$;
create trigger notif_sesi_peserta after insert on public.sesi_ujian_peserta
  for each row execute function sigarda.notif_sesi_peserta();

create function sigarda.notif_dokumen() returns trigger language plpgsql security definer set search_path = public as
$$
begin
  if NEW.jenis = 'surat_pengantar_agama' and NEW.peserta_id is not null then
    perform sigarda.notif_buat(NEW.peserta_id, 'surat', 'Surat pengantar guru agama terbit', 'Surat nomor ' || NEW.nomor || ' sudah diterbitkan. Cetak dan minta tanda tangan Pembina.', '{"tab":"cetak"}');
  end if;
  return null;
end $$;
create trigger notif_dokumen after insert on public.dokumen_terbit
  for each row execute function sigarda.notif_dokumen();

-- ===== Cadangan (tahap L4): pengingat ===== (penanda ketat di sekitar notif_pengingat saja, tanpa trigger di sekitarnya yang
-- tidak aman diulang, supaya migrasi dapat memperbarui fungsi ini sendirian)
-- ===== Eskalasi (tahap L5): pengingat ===== (penanda kedua yang membungkus fungsi SAMA; dipakai migrasi L5. Tiap tahap baru yang
-- mengubah notif_pengingat cukup menambah penanda serupa di sini, JANGAN mengubah/menghapus penanda tahap sebelumnya -- skrip
-- migrasi lama yang sudah terbit tetap harus bisa dibangun ulang dari inti.sql bila diperlukan)
-- ===== Agenda tahunan (tahap L6): pengingat ===== (penanda ketiga yang membungkus fungsi SAMA; dipakai migrasi L6)
-- ===== Usulan Musyawarah Ambalan (tahap L6b): pengingat ===== (penanda keempat, fungsi SAMA; dipakai migrasi L6b)
-- ===== Usulan kegiatan lain (tahap L6b): pengingat ===== (penanda kelima, fungsi SAMA; dipakai migrasi L6b)
-- ===== Pra-uji berjenjang (fase C): pengingat ===== (penanda keenam, fungsi SAMA; dipakai migrasi pra-uji)
-- ===== Kalender Garuda (Tahap 2, G4d): pengingat ===== (penanda ketujuh, fungsi SAMA; dipakai migrasi pengingat kalender)
-- ===== Pembersihan riwayat penjadwal: pengingat ===== (penanda kedelapan, fungsi SAMA; dipakai migrasi pembersihan riwayat cron)
-- Pengingat harian (dijalankan pg_cron pukul 07.00 WIB): pengujian dan sesi ujian besok, pengajuan yang menunggu lebih dari 3 hari,
-- cadangan data yang sudah sebulan tidak diunduh (tahap L4), tangga eskalasi tidak bergerak (tahap L5), agenda tahunan H-30/H-7/H-1
-- (tahap L6), usulan Musyawarah Ambalan belum terjadwal H-60 lalu tiap 14 hari (tahap L6b), usulan 10 kegiatan lain belum terjadwal
-- H-30/H-60 lalu tiap 14 hari (tahap L6b, juga di luar jam senyap karena selalu berjalan 07.00 WIB), dan pembersihan notifikasi
-- berumur lebih dari 90 hari, dan tahap kalender seleksi Garuda H-7/H-3/H-1/hari-H serta berakhir besok (Tahap 2, G4d). Kunci membuat tiap pengingat terkirim sekali walau dijalankan berulang.
create function sigarda.notif_pengingat() returns void language plpgsql security definer set search_path = public as
$$
declare v_besok date := sigarda.hari_ini() + 1; r record; v_x uuid; v_label text;
begin
  for r in select sp.peserta_id, sp.sku_id, sp.penguji_id, sp.jadwal, p.nama from public.sku_progress sp join public.profiles p on p.id = sp.peserta_id
           where sp.status in ('diajukan', 'proses') and sp.jadwal = v_besok loop
    v_label := sigarda.notif_label_butir(r.sku_id);
    perform sigarda.notif_buat(r.peserta_id, 'pengingat', 'Pengujian besok', v_label || ' dijadwalkan besok.', '{"tab":"sku"}', 'h1:' || r.peserta_id || ':' || r.sku_id || ':' || r.jadwal);
    for v_x in select * from sigarda.notif_penerima_uji(r.peserta_id, r.sku_id, r.penguji_id) loop
      perform sigarda.notif_buat(v_x, 'pengingat', 'Pengujian besok', r.nama || ', ' || v_label, '{"tab":"antrian"}', 'h1:' || r.peserta_id || ':' || r.sku_id || ':' || r.jadwal);
    end loop;
  end loop;
  for r in select sp.peserta_id, sp.sku_id, sp.penguji_id, p.nama, sp.diubah from public.sku_progress sp join public.profiles p on p.id = sp.peserta_id
           where sp.status = 'diajukan' and sp.diubah < now() - interval '3 days' loop
    v_label := sigarda.notif_label_butir(r.sku_id);
    for v_x in select * from sigarda.notif_penerima_uji(r.peserta_id, r.sku_id, r.penguji_id) loop
      perform sigarda.notif_buat(v_x, 'lama', 'Pengajuan menunggu lebih dari 3 hari', r.nama || ', ' || v_label, '{"tab":"antrian"}',
        'lama:' || r.peserta_id || ':' || r.sku_id || ':' || extract(epoch from r.diubah)::bigint);
    end loop;
  end loop;
  for r in select s.id, s.nama, s.tanggal, sp.peserta_id from public.sesi_ujian s join public.sesi_ujian_peserta sp on sp.sesi_id = s.id
           where s.status = 'terjadwal' and s.tanggal = v_besok loop
    perform sigarda.notif_buat(r.peserta_id, 'pengingat', 'Ujian bersama besok', r.nama, '{"tab":"beranda"}', 'sesi-h1:' || r.id || ':' || r.tanggal);
  end loop;
  if not exists (
    select 1 from public.pengaturan where kunci = 'cadangan.terakhir' and (nilai ->> 'pada')::timestamptz > now() - interval '30 days'
  ) then
    for v_x in select id from public.profiles where role = 'admin' and status = 'aktif' loop
      perform sigarda.notif_buat(v_x, 'pengingat', 'Waktunya cadangan data',
        'Sudah lebih dari sebulan sejak cadangan terakhir (atau belum pernah). Unduh dari menu Data Gudep.', '{"tab":"gudep"}',
        'cadangan:' || to_char(now(), 'YYYY-MM'));
    end loop;
  end if;
  perform sigarda.eskalasi_proses();
  perform sigarda.agenda_proses();
  perform sigarda.musyawarah_pengingat();
  perform sigarda.kegiatan_pengingat();
  perform sigarda.pra_uji_pengingat();
  perform sigarda.garuda_kalender_pengingat();
  -- Riwayat pg_cron (cron.job_run_details) hanya 30 hari terakhir: pekerjaan sigarda-terbit-ulang berjalan tiap 5 menit dan tabel itu
  -- tidak dibersihkan siapa pun. Dijaga: tanpa pg_cron atau tanpa izin, pengingat harian tetap berjalan.
  if to_regclass('cron.job_run_details') is not null then
    begin
      execute 'delete from cron.job_run_details where end_time < now() - interval ''30 days''';
    exception when others then null;
    end;
  end if;
  delete from public.notifikasi where dibuat < now() - interval '90 days';
end $$;
-- ===== akhir pengingat cadangan =====
-- ===== akhir pengingat eskalasi =====
-- ===== akhir pengingat agenda =====
-- ===== akhir pengingat usulan musyawarah =====
-- ===== akhir pengingat usulan kegiatan lain =====
-- ===== akhir pengingat pra-uji =====
-- ===== akhir pengingat kalender garuda =====
-- ===== akhir pembersihan riwayat penjadwal =====

-- Mengantre Web Push: satu permintaan HTTP per pernyataan INSERT (pg_net) ke Edge Function notif-push, hanya untuk penerima yang punya perangkat.
-- Tanpa konfigurasi (sigarda.push_atur) atau tanpa pg_net tidak ada yang dikirim; Kotak Notifikasi di aplikasi tetap berjalan. Galat push tidak
-- boleh membatalkan transaksi yang menyebabkannya.
create function sigarda.push_antre() returns trigger language plpgsql security definer set search_path = public as
$$
declare v_k public.push_konfigurasi; v_ids bigint[];
begin
  select * into v_k from public.push_konfigurasi;
  if not found or to_regnamespace('net') is null then return null; end if;
  select array_agg(b.id) into v_ids from baru b where exists (select 1 from public.push_langganan l where l.penerima_id = b.penerima_id);
  if v_ids is null then return null; end if;
  begin
    execute 'select net.http_post(url := $1, headers := $2, body := $3)'
      using v_k.url, jsonb_build_object('Content-Type', 'application/json', 'x-sigarda-rahasia', v_k.rahasia), jsonb_build_object('ids', to_jsonb(v_ids));
  exception when others then
    raise warning 'Antrean push gagal: %', sqlerrm;
  end;
  return null;
end $$;
create trigger notifikasi_push after insert on public.notifikasi
  referencing new table as baru for each statement execute function sigarda.push_antre();

-- Diisi pemilik proyek SEKALI lewat SQL Editor (tanpa login aplikasi): select sigarda.push_atur('https://<ref>.supabase.co/functions/v1/notif-push', '<rahasia>', '<kunci publik VAPID>');
create function sigarda.push_atur(p_url text, p_rahasia text, p_kunci_publik text) returns void language plpgsql security definer set search_path = public as
$$
begin
  if auth.uid() is not null then raise exception 'Pengaturan push hanya dari SQL Editor Supabase.'; end if;
  insert into public.push_konfigurasi (id, url, rahasia, kunci_publik) values (true, btrim(p_url), btrim(p_rahasia), btrim(p_kunci_publik))
  on conflict (id) do update set url = excluded.url, rahasia = excluded.rahasia, kunci_publik = excluded.kunci_publik, diubah = now();
end $$;

-- Ekstensi dan jadwal harian. Bila pg_net atau pg_cron belum dapat diaktifkan (mis. bukan Supabase), langkah ini dilewati dengan catatan;
-- Kotak Notifikasi tetap bekerja, hanya Web Push dan pengingat harian yang menunggu (aktifkan di Dashboard > Integrations, lalu jalankan ulang migrasi).
do $$
begin
  begin create extension if not exists pg_net with schema extensions; exception when others then null; end;
  begin create extension if not exists pg_cron; exception when others then null; end;
  if to_regnamespace('cron') is null then
    raise notice 'pg_cron belum aktif: pengingat harian belum dijadwalkan. Aktifkan pg_cron lalu jalankan ulang migrasi notifikasi.';
  else
    begin
      perform cron.schedule('sigarda-pengingat', '0 0 * * *', 'select sigarda.notif_pengingat()');
    exception when others then
      raise notice 'Penjadwalan pengingat harian gagal: %', sqlerrm;
    end;
  end if;
  if to_regnamespace('net') is null then raise notice 'pg_net belum aktif: Web Push belum dapat dikirim. Aktifkan pg_net lalu jalankan ulang migrasi notifikasi.'; end if;
end $$;
-- ---- akhir bantu notifikasi ----

-- ===== Pra-uji berjenjang (fase C): bantu =====
-- Aturan penilai pra-uji (aturan pengaman: hanya menyaring butir yang sudah ia lulus sendiri; butir agama bersifat per agama sehingga otomatis seagama):
--   * tahap 'pinsa'        : Pinsa (aktif) sangga dan rombel Penegak, yaitu anggota sangga itu berstatus Pinsa ATAU Penegak yang ditugaskan ke sangga itu (pinsa_tugas, lintas rombel);
--                            hanya butir Bantara; Pinsa yang mengajukan sendiri melewati tahap ini.
--   * tahap 'bina_damping' : Bina Damping rombel Penegak pada tahun ajaran berjalan; butir Laksana hanya oleh Bina Damping yang sudah Laksana;
--                            Bina Damping yang mengajukan sendiri disaring Bina Damping lain di rombelnya.
-- Tidak ada penilai yang memenuhi syarat pada suatu tahap = tahap itu dilewati; bila semua tahap terlewati, pengajuan langsung ke Pembina.
create function sigarda.pra_uji_penilai_ok(p_peserta uuid, p_sku text, p_tahap text, p_penilai uuid) returns boolean
language plpgsql stable security definer set search_path = public as
$$
declare v_p public.profiles; v_n public.profiles; v_tingkat text;
begin
  if p_penilai is null or p_penilai = p_peserta then return false; end if;
  select * into v_p from public.profiles where id = p_peserta and role = 'peserta';
  if not found then return false; end if;
  select * into v_n from public.profiles where id = p_penilai and role = 'peserta' and status = 'aktif';
  if not found then return false; end if;
  select tingkat into v_tingkat from public.sku_unit where id = p_sku;
  if not found then return false; end if;
  if not exists (select 1 from public.sku_progress where peserta_id = p_penilai and sku_id = p_sku and status = 'lulus') then return false; end if;
  if p_tahap = 'pinsa' then
    return v_tingkat = 'Bantara' and not v_p.pinsa and v_p.kelas is not null and btrim(coalesce(v_p.sangga, '')) <> ''
       and ((v_n.pinsa and v_n.kelas = v_p.kelas and lower(v_n.sangga) = lower(v_p.sangga))
            or exists (select 1 from public.pinsa_tugas t where t.penegak_id = p_penilai and t.tahun_ajaran = sigarda.tahun_ajaran_kini()
                       and t.rombel = v_p.kelas and lower(t.sangga) = lower(v_p.sangga)));
  elsif p_tahap = 'bina_damping' then
    return exists (select 1 from public.bina_damping b where b.penegak_id = p_penilai and b.rombel = v_p.kelas and b.tahun_ajaran = sigarda.tahun_ajaran_kini())
       and (v_tingkat = 'Bantara' or sigarda.tingkat_penegak(p_penilai) = 'laksana');
  end if;
  return false;
end $$;

-- Semua penilai yang memenuhi syarat pada satu tahap untuk satu Penegak dan satu butir.
create function sigarda.pra_uji_penilai_daftar(p_peserta uuid, p_sku text, p_tahap text) returns setof uuid
language sql stable security definer set search_path = public as
$$
  select u.id from public.profiles u
  where u.role = 'peserta' and u.status = 'aktif'
    and case p_tahap when 'pinsa' then (u.pinsa or exists (select 1 from public.pinsa_tugas t where t.penegak_id = u.id and t.tahun_ajaran = sigarda.tahun_ajaran_kini()))
                     when 'bina_damping' then exists (select 1 from public.bina_damping b where b.penegak_id = u.id) else false end
    and sigarda.pra_uji_penilai_ok(p_peserta, p_sku, p_tahap, u.id)
$$;

-- Tahap sesudah p_setelah (null = mulai dari awal) yang punya penilai: 'pinsa', 'bina_damping', atau 'pembina' (uji resmi).
create function sigarda.pra_uji_tahap_berikut(p_peserta uuid, p_sku text, p_setelah text) returns text
language plpgsql stable security definer set search_path = public as
$$
declare v_urut text[]; v_tahap text;
begin
  v_urut := case when (select tingkat from public.sku_unit where id = p_sku) = 'Bantara' then array['pinsa', 'bina_damping'] else array['bina_damping'] end;
  foreach v_tahap in array v_urut loop
    if p_setelah is not null and array_position(v_urut, v_tahap) <= coalesce(array_position(v_urut, p_setelah), 0) then continue; end if;
    if exists (select 1 from sigarda.pra_uji_penilai_daftar(p_peserta, p_sku, v_tahap)) then return v_tahap; end if;
  end loop;
  return 'pembina';
end $$;

create function sigarda.pra_uji_nama_tahap(p_tahap text) returns text language sql immutable as
$$ select case p_tahap when 'pinsa' then 'Pinsa' when 'bina_damping' then 'Bina Damping' else 'Pembina' end $$;

-- Meneruskan pengajuan ke tahap berikutnya sesudah p_setelah (null = pengajuan baru): baris pra-uji tahap itu, atau bila tidak ada lagi, pengajuan uji resmi
-- (sku_progress 'diajukan', antrian rombel Pembina). Mengembalikan tahap tujuan. Riwayat SKU mencatat perjalanannya.
create function sigarda.pra_uji_teruskan(p_peserta uuid, p_sku text, p_setelah text, p_jadwal date, p_catatan_peserta text, p_oleh uuid) returns text
language plpgsql security definer set search_path = public as
$$
declare v_tahap text := sigarda.pra_uji_tahap_berikut(p_peserta, p_sku, p_setelah);
begin
  if v_tahap = 'pembina' then
    if not exists (select 1 from sigarda.penguji_sah(p_peserta, p_sku)) then
      raise exception 'Belum ada Pembina yang dapat menguji butir ini untuk rombel Penegak tersebut. Hubungi Admin Gudep.';
    end if;
    insert into public.sku_progress (peserta_id, sku_id, status, jadwal, penguji_id, catatan_peserta, diubah)
    values (p_peserta, p_sku, 'diajukan', p_jadwal, null, p_catatan_peserta, now())
    on conflict (peserta_id, sku_id) do update
      set status = 'diajukan', jadwal = excluded.jadwal, penguji_id = null, catatan_peserta = excluded.catatan_peserta, diubah = now();
    insert into public.sku_riwayat (peserta_id, sku_id, teks, oleh)
    values (p_peserta, p_sku, case when p_setelah is null then 'Mengajukan pengujian untuk ' || to_char(p_jadwal, 'YYYY-MM-DD') || ' (antrian rombel, tanpa pra-uji)'
                                   else 'Diteruskan ke pengujian resmi Pembina untuk ' || to_char(p_jadwal, 'YYYY-MM-DD') end, p_oleh);
  else
    insert into public.sku_pra_uji (peserta_id, sku_id, tahap, jadwal, catatan_peserta) values (p_peserta, p_sku, v_tahap, p_jadwal, p_catatan_peserta);
    insert into public.sku_riwayat (peserta_id, sku_id, teks, oleh)
    values (p_peserta, p_sku, case when p_setelah is null then 'Mengajukan pengujian untuk ' || to_char(p_jadwal, 'YYYY-MM-DD') || '; menunggu pra-uji ' || sigarda.pra_uji_nama_tahap(v_tahap)
                                   else 'Diteruskan ke pra-uji ' || sigarda.pra_uji_nama_tahap(v_tahap) end, p_oleh);
  end if;
  return v_tahap;
end $$;

-- Penegak mengajukan butir lewat jalur pra-uji (dipanggil sg_sku_ajukan sesudah pemeriksaan umum). Satu pengajuan menunggu per butir.
create function sigarda.pra_uji_mulai(p_peserta uuid, p_sku text, p_jadwal date, p_catatan text) returns void
language plpgsql security definer set search_path = public as
$$
begin
  if exists (select 1 from public.sku_pra_uji where peserta_id = p_peserta and sku_id = p_sku and status = 'menunggu') then
    raise exception 'Poin ini sedang menunggu pra-uji.';
  end if;
  if not exists (select 1 from sigarda.penguji_sah(p_peserta, p_sku)) then
    raise exception 'Belum ada penguji yang dapat menguji butir ini untuk rombel Anda. Hubungi Admin Gudep.';
  end if;
  perform sigarda.pra_uji_teruskan(p_peserta, p_sku, null, p_jadwal, btrim(coalesce(p_catatan, '')), p_peserta);
end $$;

-- Notifikasi ke Penegak sesudah pra-uji lulus (atau tahap dilewati Pembina): kata kunci "diteruskan ke pra-uji selanjutnya" atau
-- "diteruskan ke pengujian resmi ke Pembina" (keputusan pemilik; berbeda dari hasil uji resmi yang isinya tanpa hasil).
create function sigarda.pra_uji_beritahu_lulus(p_peserta uuid, p_sku text, p_tujuan text, p_dilewati boolean default false) returns void
language plpgsql security definer set search_path = public as
$$
begin
  perform sigarda.notif_buat(p_peserta, 'pra_uji', case when p_dilewati then 'Tahap pra-uji dilewati' else 'Pra-uji lulus' end,
    sigarda.notif_label_butir(p_sku) || case when p_dilewati then ' melewati satu tahap pra-uji dan ' else ' lulus pra-uji dan ' end || case when p_tujuan = 'pembina' then 'diteruskan ke pengujian resmi ke Pembina.' else 'diteruskan ke pra-uji selanjutnya.' end,
    '{"tab":"sku"}');
end $$;

-- Pengajuan pra-uji baru: beri tahu semua penilai yang memenuhi syarat pada tahap itu.
create function sigarda.notif_pra_uji() returns trigger language plpgsql security definer set search_path = public as
$$
declare v_x uuid; v_nama text; v_label text := sigarda.notif_label_butir(NEW.sku_id);
begin
  if NEW.status <> 'menunggu' then return null; end if;
  select nama into v_nama from public.profiles where id = NEW.peserta_id;
  for v_x in select * from sigarda.pra_uji_penilai_daftar(NEW.peserta_id, NEW.sku_id, NEW.tahap) loop
    perform sigarda.notif_buat(v_x, 'pra_uji', 'Pengajuan pra-uji baru', v_nama || ' mengajukan ' || v_label || ' untuk pra-uji ' || sigarda.pra_uji_nama_tahap(NEW.tahap), '{"tab":"pra-uji"}');
  end loop;
  return null;
end $$;
create trigger notif_pra_uji after insert on public.sku_pra_uji for each row execute function sigarda.notif_pra_uji();

-- Pengingat harian (dipanggil sigarda.notif_pengingat): pra-uji menunggu lebih dari 3 hari diingatkan kepada penilainya (sekali per pengajuan). Tanpa penilai
-- (macet) hanya diingatkan kepada Pembina; pengajuan TIDAK pernah lolos otomatis.
create function sigarda.pra_uji_pengingat() returns void language plpgsql security definer set search_path = public as
$$
declare r record; v_x uuid; v_ada boolean;
begin
  for r in select u.id, u.peserta_id, u.sku_id, u.tahap, p.nama from public.sku_pra_uji u join public.profiles p on p.id = u.peserta_id
           where u.status = 'menunggu' and u.dibuat < now() - interval '3 days' loop
    v_ada := false;
    for v_x in select * from sigarda.pra_uji_penilai_daftar(r.peserta_id, r.sku_id, r.tahap) loop
      v_ada := true;
      perform sigarda.notif_buat(v_x, 'pra_uji', 'Pra-uji menunggu lebih dari 3 hari', r.nama || ', ' || sigarda.notif_label_butir(r.sku_id), '{"tab":"pra-uji"}', 'pra-lama:' || r.id);
    end loop;
    if not v_ada then
      for v_x in select id from public.profiles where role = 'penguji' and jabatan = 'Pembina' and status = 'aktif' loop
        perform sigarda.notif_buat(v_x, 'pra_uji', 'Pra-uji tanpa penilai',
          r.nama || ', ' || sigarda.notif_label_butir(r.sku_id) || ': belum ada ' || sigarda.pra_uji_nama_tahap(r.tahap) || ' yang dapat menilai. Lewati tahap ini bila perlu.',
          '{"tab":"pra-uji"}', 'pra-macet:' || r.id);
      end loop;
    end if;
  end loop;
end $$;
-- ===== akhir bantu pra-uji =====
-- ===== Isian Penegak (Tahap 3, H1): fungsi bantu =====
-- Pemeriksa satu isian data diri (kunci dan nilai sudah dirapikan; nilai kosong = menghapus isian). Mengembalikan teks galat atau NULL bila sah. Cermin klien:
-- src/lib/isianLogic.js (periksaIsian), dibandingkan langsung dengan fungsi ini pada kisi masukan di uji/isian-klien.mjs. Daftar kunci:
--   pribadi   : panggilan, tempat_lahir, alamat, gol_darah (A/B/AB/O), no_hp, tinggi (cm), berat (kg), penyakit
--   keluarga  : ayah|ibu|wali_{nama,hp,kerja,alamat}, anak_ke, dari_saudara, sdr1..3_{nama,sebagai}
--   pendidikan: pend_{tk,sd,smp,sma}_{nama,lulus}; prestasi: akd_{tk,sd,smp,sma}, non_{tk,sd,smp,sma}
--   kegiatan  : keg1..7_{nama,tingkat (kwarran/kwarcab/kwarda)}; bidang: bid1..6_{nama,jenis}; perangkat IT: it1..4_{nama,level (bisa/cukup/kurang)}
create function sigarda.isian_periksa(p_kunci text, p_nilai text) returns text language plpgsql immutable as
$$
declare v_maks int; v_n int;
begin
  v_maks := case
    when p_kunci = 'panggilan' then 40
    when p_kunci = 'tempat_lahir' then 60
    when p_kunci = 'alamat' then 200
    when p_kunci = 'penyakit' then 120
    when p_kunci ~ '^(ayah|ibu|wali)_(nama|kerja)$' then 80
    when p_kunci ~ '^(ayah|ibu|wali)_alamat$' then 200
    when p_kunci ~ '^sdr[1-3]_nama$' then 80
    when p_kunci ~ '^sdr[1-3]_sebagai$' then 40
    when p_kunci ~ '^pend_(tk|sd|smp|sma)_nama$' then 100
    when p_kunci ~ '^(akd|non)_(tk|sd|smp|sma)$' then 200
    when p_kunci ~ '^keg[1-7]_nama$' then 120
    when p_kunci ~ '^bid[1-6]_nama$' then 80
    when p_kunci ~ '^bid[1-6]_jenis$' then 60
    when p_kunci ~ '^it[1-4]_nama$' then 80
    -- bentuk khusus (diperiksa di bawah)
    when p_kunci in ('gol_darah', 'no_hp', 'tinggi', 'berat', 'anak_ke', 'dari_saudara') then 30
    when p_kunci ~ '^((ayah|ibu|wali)_hp|pend_(tk|sd|smp|sma)_lulus|keg[1-7]_tingkat|it[1-4]_level)$' then 30
    else null end;
  if v_maks is null then return format('Isian "%s" tidak dikenal.', left(coalesce(p_kunci, ''), 40)); end if;
  if p_nilai is null then return 'Isian harus berupa teks.'; end if;
  if char_length(p_nilai) > v_maks then return format('Isian %s maksimal %s karakter.', p_kunci, v_maks); end if;
  if p_nilai ~ '[[:cntrl:]<>]' then return format('Isian %s memuat karakter yang tidak diizinkan.', p_kunci); end if;
  if p_nilai = '' then return null; end if;

  if p_kunci = 'gol_darah' then
    if p_nilai not in ('A', 'B', 'AB', 'O') then return 'Golongan darah harus A, B, AB, atau O.'; end if;
  elsif p_kunci = 'no_hp' or p_kunci ~ '^(ayah|ibu|wali)_hp$' then
    if p_nilai !~ '^[0-9 +()./-]{8,20}$' then return 'Nomor telepon hanya boleh berisi angka, spasi, dan tanda + ( ) . / - (8-20 karakter).'; end if;
  elsif p_kunci in ('tinggi', 'berat') then
    if p_nilai !~ '^[0-9]{2,3}$' then return format('%s harus berupa angka bulat.', case when p_kunci = 'tinggi' then 'Tinggi badan' else 'Berat badan' end); end if;
    v_n := p_nilai::int;
    if p_kunci = 'tinggi' and v_n not between 50 and 250 then return 'Tinggi badan harus 50 sampai 250 cm.'; end if;
    if p_kunci = 'berat' and v_n not between 20 and 250 then return 'Berat badan harus 20 sampai 250 kg.'; end if;
  elsif p_kunci in ('anak_ke', 'dari_saudara') then
    if p_nilai !~ '^[0-9]{1,2}$' then return 'Isi angka 1 sampai 20.'; end if;
    if p_nilai::int not between 1 and 20 then return 'Isi angka 1 sampai 20.'; end if;
  elsif p_kunci ~ '^pend_(tk|sd|smp|sma)_lulus$' then
    if p_nilai !~ '^[0-9]{4}$' then return 'Tahun lulus harus 1990 sampai 2100.'; end if;
    if p_nilai::int not between 1990 and 2100 then return 'Tahun lulus harus 1990 sampai 2100.'; end if;
  elsif p_kunci ~ '^keg[1-7]_tingkat$' then
    if p_nilai not in ('kwarran', 'kwarcab', 'kwarda') then return 'Tingkat kegiatan harus kwarran, kwarcab, atau kwarda.'; end if;
  elsif p_kunci ~ '^it[1-4]_level$' then
    if p_nilai not in ('bisa', 'cukup', 'kurang') then return 'Tingkat penguasaan harus bisa, cukup, atau kurang.'; end if;
  end if;
  return null;
end $$;

-- Pemeriksa isian tingkat profil (jk, agama, lahir, nta): nilai kosong berarti tidak diubah. Mengembalikan teks galat atau NULL.
create function sigarda.isian_periksa_profil(p_kunci text, p_nilai text) returns text language plpgsql stable as
$$
declare v_t date;
begin
  if p_nilai is null then return 'Isian harus berupa teks.'; end if;
  if p_nilai = '' then return null; end if;
  if p_kunci = 'jk' then
    if p_nilai not in ('L', 'P') then return 'Jenis kelamin harus L (laki-laki) atau P (perempuan).'; end if;
  elsif p_kunci = 'agama' then
    if p_nilai not in ('Islam', 'Katolik', 'Protestan', 'Hindu', 'Buddha', 'Khonghucu') then return 'Agama tidak dikenal.'; end if;
  elsif p_kunci = 'lahir' then
    if p_nilai !~ '^\d{4}-\d{2}-\d{2}$' then return 'Tanggal lahir harus berbentuk TTTT-BB-HH.'; end if;
    begin
      v_t := p_nilai::date;
    exception when others then return 'Tanggal lahir tidak sah.';
    end;
    if v_t < date '1990-01-01' or v_t > sigarda.hari_ini() then return 'Tanggal lahir tidak boleh sebelum tahun 1990 atau di masa depan.'; end if;
  elsif p_kunci = 'nta' then
    if p_nilai !~ '^[0-9A-Za-z./ -]{1,40}$' then return 'NTA tidak valid: maksimal 40 karakter (huruf, angka, titik, garis miring, strip, spasi).'; end if;
  else
    return format('Isian "%s" tidak dikenal.', left(coalesce(p_kunci, ''), 40));
  end if;
  return null;
end $$;
-- ===== akhir bantu isian penegak =====
-- ---------------------------------------------------------------------------
-- 3. Row Level Security: baca sesuai peran, tanpa tulis langsung
-- ---------------------------------------------------------------------------
alter table public.profiles enable row level security;
alter table public.sku_butir enable row level security;
alter table public.sku_unit enable row level security;
alter table public.pf_item enable row level security;
alter table public.sku_progress enable row level security;
alter table public.sku_riwayat enable row level security;
alter table public.absensi_sesi enable row level security;
alter table public.absensi_hadir enable row level security;
alter table public.portofolio enable row level security;
alter table public.portofolio_jurnal enable row level security;
alter table public.materi enable row level security;
alter table public.pengaturan enable row level security;
alter table public.sidang_dk enable row level security;
alter table public.sidang_urut enable row level security;   -- baca: pengurus; tulis: hanya fungsi sg_*
alter table public.raport enable row level security;
alter table public.instrumen enable row level security;
alter table public.instrumen_kriteria enable row level security;
alter table public.instrumen_penguji enable row level security;    -- baca: pengurus saja
alter table public.instrumen_panduan enable row level security;    -- baca: pengurus saja
alter table public.sku_penilaian enable row level security;
alter table public.sertifikat_tingkat enable row level security;   -- tanpa kebijakan: hanya lewat fungsi
alter table public.garuda_berkas_token enable row level security;   -- tanpa kebijakan: hanya lewat fungsi (tahap L7)
alter table public.sesi_ujian enable row level security;
alter table public.sesi_ujian_butir enable row level security;
alter table public.sesi_ujian_peserta enable row level security;
alter table public.iuran enable row level security;
alter table public.tabungan_cek enable row level security;   -- baca: pemilik, Pembina, Admin; tulis: hanya fungsi sg_tabungan_*
alter table public.iuran_log enable row level security;
alter table public.iuran_kas enable row level security;
alter table public.asisten_iuran enable row level security;
alter table public.penugasan_rombel enable row level security;   -- baca: pengurus; tulis: hanya fungsi sg_penugasan_*
alter table public.penugasan_log enable row level security;
alter table public.guru_agama enable row level security;
alter table public.bina_damping enable row level security;   -- tanpa kebijakan: hanya lewat fungsi sg_bina_damping_* dan sg_sangga_*
alter table public.pinsa_tugas enable row level security;   -- tanpa kebijakan: hanya lewat fungsi sg_pinsa_* dan sg_sangga_rombel
alter table public.sku_pra_uji enable row level security;   -- baca: pemilik, penilai, dan pengurus; tulis: hanya fungsi sg_pra_uji_* dan sg_sku_ajukan/batal
alter table public.pelantikan enable row level security;   -- baca: pemilik dan pengurus; tulis: hanya fungsi sg_pelantikan_*
alter table public.tkk_katalog enable row level security;   -- baca: semua pengguna aktif (katalog); tulis: hanya skema/migrasi
alter table public.tkk_capaian enable row level security;   -- baca: pemilik dan pengurus; tulis: hanya fungsi sg_tkk_*
alter table public.tkk_pengajuan enable row level security;   -- baca: pemilik dan pengurus; tulis: hanya fungsi sg_tkk_ajukan/_batal dan sg_tkk_tinjau
alter table public.tim_penilai enable row level security;   -- baca: pengurus; tulis: hanya fungsi sg_tim_penilai_*
alter table public.tim_penilai_anggota enable row level security;   -- baca: pengurus; tulis: hanya fungsi sg_tim_penilai_*
alter table public.garuda_tahap enable row level security;   -- baca: pengurus; tulis: hanya fungsi sg_garuda_tahap_*
alter table public.penegak_isian enable row level security;   -- baca: pemilik, Pembina, dan Admin; tulis: hanya fungsi sg_isian_saya_simpan
alter table public.dokumen_templat enable row level security;   -- baca: Pembina dan Admin; tulis: hanya fungsi sg_dokumen_templat_*
alter table public.portofolio_snapshot enable row level security;   -- baca: Pembina dan Admin; tulis: hanya fungsi sg_portofolio_snapshot_*
alter table public.sfh_catatan enable row level security;   -- baca: pemilik, Pembina, dan Admin; tulis: hanya fungsi sg_sfh_*
alter table public.beranda_berita enable row level security;   -- baca: pengurus (publik lewat sg_beranda_publik); tulis: hanya fungsi sg_berita_*
alter table public.beranda_prestasi enable row level security;   -- baca: pengurus; tulis: hanya fungsi sg_prestasi_*
alter table public.beranda_galeri enable row level security;   -- baca: pengurus; tulis: hanya fungsi sg_galeri_*
alter table public.beranda_sosial enable row level security;   -- baca: pengurus; tulis: hanya fungsi sg_sosial_*
alter table public.beranda_faq enable row level security;   -- baca: pengurus; tulis: hanya fungsi sg_faq_*
alter table public.tanggal_lahir enable row level security;   -- baca: pemilik dan pengurus; tulis: hanya fungsi sg_tanggal_lahir_atur
alter table public.spg_penetapan enable row level security;   -- baca: pemilik dan pengurus; tulis: hanya fungsi sg_spg_*
alter table public.siaga_garuda enable row level security;   -- baca: pemilik, Pembina, Admin; tulis: hanya fungsi sg_siaga_garuda_*
alter table public.tkk_siaga enable row level security;   -- baca: pemilik, Pembina, Admin; tulis: hanya fungsi sg_tkk_siaga_*
alter table public.tkk_krida enable row level security;   -- baca: pemilik dan pengurus; tulis: hanya fungsi sg_tkk_krida_*
alter table public.saka_anggota enable row level security;   -- baca: pemilik dan pengurus; tulis: hanya fungsi sg_saka_*
alter table public.penugasan_peserta enable row level security;   -- baca: pengurus; tulis: hanya fungsi sg_penugasan_peserta_atur
alter table public.kepengurusan_log enable row level security;    -- baca: pengurus; tulis: hanya fungsi kepengurusan
alter table public.pengukuhan_dewan enable row level security;    -- baca: pengurus; tulis: hanya fungsi sg_pengukuhan_dewan_*
alter table public.naik_kelas_batch enable row level security;   -- baca: pengurus; tulis: hanya fungsi sg_naik_kelas*
alter table public.naik_kelas_log enable row level security;
alter table public.agenda enable row level security;   -- baca: semua yang aktif; tulis: hanya fungsi sg_agenda_*
alter table public.kegiatan_usulan enable row level security;   -- baca: pengurus; tulis: hanya fungsi sg_kegiatan_*
alter table public.dokumen_terbit enable row level security;   -- baca: pengurus dan pemilik; tulis: hanya fungsi sg_dokumen_*
alter table public.dokumen_urut enable row level security;
alter table public.notifikasi enable row level security;   -- baca: pemilik; tulis: hanya pemicu dan fungsi sg_*
alter table public.push_langganan enable row level security;   -- tanpa kebijakan: hanya lewat fungsi
alter table public.push_konfigurasi enable row level security; -- tanpa kebijakan: hanya lewat fungsi
alter table public.keepalive_konfigurasi enable row level security; -- tanpa kebijakan: hanya lewat fungsi (SQL Editor)
alter table public.terbit_ulang_konfigurasi enable row level security; -- tanpa kebijakan: memuat kunci akses GitHub; hanya lewat fungsi
alter table public.login_gagal enable row level security;   -- tanpa kebijakan: hanya service_role

-- Penegak melihat dirinya sendiri dan daftar penguji/admin; pengurus melihat semua.
-- Profil sendiri selalu terbaca (aplikasi perlu tahu apakah PIN wajib diganti); selebihnya hanya setelah PIN diganti.
--
-- PERFORMA: fungsi peran dibungkus (select ...) supaya Postgres menghitungnya SEKALI per kueri (InitPlan),
-- bukan sekali per baris. Tanpa pembungkus, pengurus yang membaca puluhan ribu baris memicu puluhan ribu
-- panggilan fungsi plpgsql (masing-masing satu pencarian profil). Hasilnya identik, hanya jauh lebih murah.
-- Perubahan ini ada juga sebagai migrasi mandiri di supabase/migrasi/2026-09-rls-ringan.sql (untuk database yang sudah berisi data).
-- Penegak berjabatan Dewan Ambalan yang aktif juga terbaca semua orang (nama mereka tampil sebagai penguji dan pengurus).
create policy baca_profil on public.profiles for select to authenticated
  using (id = (select auth.uid()) or role in ('penguji','admin') or (jabatan_dewan is not null and status = 'aktif') or (select sigarda.pengurus()));

create policy baca_katalog_butir on public.sku_butir for select to authenticated using ((select sigarda.aktif()));
create policy baca_katalog_unit on public.sku_unit for select to authenticated using ((select sigarda.aktif()));
create policy baca_katalog_pf on public.pf_item for select to authenticated using ((select sigarda.aktif()));
create policy baca_materi on public.materi for select to authenticated using ((select sigarda.aktif()));
create policy baca_agenda on public.agenda for select to authenticated using ((select sigarda.aktif()));
create policy baca_kegiatan_usulan on public.kegiatan_usulan for select to authenticated using ((select sigarda.pengurus()));
create policy baca_sesi on public.absensi_sesi for select to authenticated using ((select sigarda.aktif()));

create policy baca_progres on public.sku_progress for select to authenticated
  using ((select sigarda.aktif()) and (peserta_id = (select auth.uid()) or (select sigarda.pengurus())));
create policy baca_riwayat on public.sku_riwayat for select to authenticated
  using ((select sigarda.aktif()) and (peserta_id = (select auth.uid()) or (select sigarda.pengurus())));
create policy baca_absensi on public.absensi_hadir for select to authenticated
  using ((select sigarda.aktif()) and (peserta_id = (select auth.uid()) or (select sigarda.pengurus())));
-- Iuran: Penegak hanya melihat miliknya; pengurus (Dewan, Pembina, Admin) melihat semua. Asisten bendahara memakai sg_iuran_lembar
-- (tanpa membaca tabel). Rekap agregat untuk semua peran lewat sg_iuran_agregat.
create policy baca_iuran on public.iuran for select to authenticated
  using ((select sigarda.aktif()) and (peserta_id = (select auth.uid()) or (select sigarda.pengurus())));
create policy baca_iuran_log on public.iuran_log for select to authenticated
  using ((select sigarda.aktif()) and (select sigarda.pengurus()));
create policy baca_iuran_kas on public.iuran_kas for select to authenticated
  using ((select sigarda.aktif()) and (select sigarda.pengurus()));
create policy baca_tabungan_cek on public.tabungan_cek for select to authenticated
  using ((select sigarda.aktif()) and (peserta_id = (select auth.uid()) or (select sigarda.pembina_atau_admin())));
create policy baca_asisten_iuran on public.asisten_iuran for select to authenticated
  using ((select sigarda.aktif()) and (peserta_id = (select auth.uid()) or (select sigarda.pengurus())));
-- Penugasan penguji dan guru agama: dibaca pengurus (Pembina dan Dewan hanya melihat); diatur Admin lewat fungsi.
create policy baca_penugasan on public.penugasan_rombel for select to authenticated
  using ((select sigarda.aktif()) and (select sigarda.pengurus()));
create policy baca_penugasan_log on public.penugasan_log for select to authenticated
  using ((select sigarda.aktif()) and (select sigarda.pengurus()));
create policy baca_guru_agama on public.guru_agama for select to authenticated
  using ((select sigarda.aktif()) and (select sigarda.pengurus()));
create policy baca_penugasan_peserta on public.penugasan_peserta for select to authenticated
  using ((select sigarda.aktif()) and (select sigarda.pengurus()));
create policy baca_kepengurusan_log on public.kepengurusan_log for select to authenticated
  using ((select sigarda.aktif()) and (select sigarda.pengurus()));
create policy baca_pengukuhan_dewan on public.pengukuhan_dewan for select to authenticated
  using ((select sigarda.aktif()) and (select sigarda.pengurus()));
-- ===== Kebijakan naik kelas =====
create policy baca_naik_kelas_batch on public.naik_kelas_batch for select to authenticated
  using ((select sigarda.aktif()) and (select sigarda.pengurus()));
create policy baca_naik_kelas_log on public.naik_kelas_log for select to authenticated
  using ((select sigarda.aktif()) and (select sigarda.pengurus()));
-- ===== akhir kebijakan naik kelas =====
create policy baca_portofolio on public.portofolio for select to authenticated
  using ((select sigarda.aktif()) and (peserta_id = (select auth.uid()) or (select sigarda.pengurus())));
create policy baca_jurnal on public.portofolio_jurnal for select to authenticated
  using ((select sigarda.aktif()) and (peserta_id = (select auth.uid()) or (select sigarda.pengurus())));

-- Dokumen terbit: pengurus melihat semua; Penegak hanya dokumen tentang dirinya.
create policy baca_dokumen on public.dokumen_terbit for select to authenticated
  using ((select sigarda.aktif()) and (peserta_id = (select auth.uid()) or (select sigarda.pengurus())));
create policy baca_dokumen_urut on public.dokumen_urut for select to authenticated
  using ((select sigarda.aktif()) and (select sigarda.pengurus()));

-- Notifikasi: hanya milik sendiri.
create policy baca_notifikasi on public.notifikasi for select to authenticated
  using ((select sigarda.aktif()) and penerima_id = (select auth.uid()));

create policy baca_pengaturan on public.pengaturan for select to authenticated using ((select sigarda.aktif()));
create policy baca_sidang on public.sidang_dk for select to authenticated using ((select sigarda.pengurus()));
create policy baca_sidang_urut on public.sidang_urut for select to authenticated using ((select sigarda.pengurus()));
create policy baca_raport on public.raport for select to authenticated using ((select sigarda.pembina_atau_admin()));

-- Instrumen: Penegak hanya melihat instrumen yang ditetapkan dan daftar kriterianya. Instruksi dan panduan penguji hanya pengurus.
create policy baca_instrumen on public.instrumen for select to authenticated
  using ((select sigarda.aktif()) and (status = 'ditetapkan' or (select sigarda.pengurus())));
create policy baca_instrumen_kriteria on public.instrumen_kriteria for select to authenticated
  using ((select sigarda.aktif()) and ((select sigarda.pengurus()) or sku_id in (select i.sku_id from public.instrumen i where i.status = 'ditetapkan')));
create policy baca_instrumen_penguji on public.instrumen_penguji for select to authenticated using ((select sigarda.pengurus()));
create policy baca_instrumen_panduan on public.instrumen_panduan for select to authenticated using ((select sigarda.pengurus()));
create policy baca_penilaian on public.sku_penilaian for select to authenticated
  using ((select sigarda.aktif()) and (peserta_id = (select auth.uid()) or (select sigarda.pengurus())));

-- ===== Pra-uji berjenjang (fase C): kebijakan =====
-- Pra-uji: Penegak melihat pengajuannya sendiri, penilai (Pinsa/Bina Damping) yang sudah memutuskan, pengurus semua. Antrian penilai lewat sg_pra_uji_antrian.
create policy baca_pra_uji on public.sku_pra_uji for select to authenticated
  using ((select sigarda.aktif()) and (peserta_id = (select auth.uid()) or penilai_id = (select auth.uid()) or (select sigarda.pengurus())));
-- ===== akhir kebijakan pra-uji =====

-- ===== Pelantikan dan Saka (Tahap 2, G1): kebijakan =====
-- Pelantikan dan keanggotaan Saka: Penegak melihat miliknya sendiri, pengurus (Pembina, Dewan, Admin) semua.
create policy baca_pelantikan on public.pelantikan for select to authenticated
  using ((select sigarda.aktif()) and (peserta_id = (select auth.uid()) or (select sigarda.pengurus())));
create policy baca_saka_anggota on public.saka_anggota for select to authenticated
  using ((select sigarda.aktif()) and (peserta_id = (select auth.uid()) or (select sigarda.pengurus())));
-- ===== akhir kebijakan pelantikan dan saka =====

-- ===== TKK (Tahap 2, G2): kebijakan =====
-- Katalog TKK dibaca semua pengguna aktif; capaian dan TKK Krida: Penegak melihat miliknya sendiri, pengurus semua.
create policy baca_tkk_katalog on public.tkk_katalog for select to authenticated using ((select sigarda.aktif()));
create policy baca_tkk_capaian on public.tkk_capaian for select to authenticated
  using ((select sigarda.aktif()) and (peserta_id = (select auth.uid()) or (select sigarda.pengurus())));
create policy baca_tkk_krida on public.tkk_krida for select to authenticated
  using ((select sigarda.aktif()) and (peserta_id = (select auth.uid()) or (select sigarda.pengurus())));
create policy baca_siaga_garuda on public.siaga_garuda for select to authenticated
  using ((select sigarda.aktif()) and (peserta_id = (select auth.uid()) or (select sigarda.pembina_atau_admin())));
create policy baca_tkk_siaga on public.tkk_siaga for select to authenticated
  using ((select sigarda.aktif()) and (peserta_id = (select auth.uid()) or (select sigarda.pembina_atau_admin())));
-- ===== akhir kebijakan tkk =====

-- ===== TKK pengajuan (Tahap 2, G2b): kebijakan =====
-- Pengajuan TKK: Penegak melihat pengajuannya sendiri, pengurus semua.
create policy baca_tkk_pengajuan on public.tkk_pengajuan for select to authenticated
  using ((select sigarda.aktif()) and (peserta_id = (select auth.uid()) or (select sigarda.pengurus())));
-- ===== akhir kebijakan tkk pengajuan =====

-- ===== SPG (Tahap 2, G3): kebijakan =====
-- Penetapan SPG: Penegak melihat miliknya sendiri, pengurus semua.
create policy baca_spg_penetapan on public.spg_penetapan for select to authenticated
  using ((select sigarda.aktif()) and (peserta_id = (select auth.uid()) or (select sigarda.pengurus())));
-- ===== akhir kebijakan spg =====

-- ===== Gerbang calon Garuda (Tahap 2, G4): kebijakan =====
-- Tanggal lahir: Penegak melihat miliknya sendiri, pengurus semua (tabel terpisah dari profiles agar tidak terbaca Penegak lain).
create policy baca_tanggal_lahir on public.tanggal_lahir for select to authenticated
  using ((select sigarda.aktif()) and (peserta_id = (select auth.uid()) or (select sigarda.pengurus())));
-- ===== akhir kebijakan gerbang =====

-- ===== Isian Penegak dan templat dokumen (Tahap 3, H1): kebijakan =====
-- Isian data diri: pemilik, Pembina, dan Admin (BUKAN Dewan Ambalan: alamat dan riwayat kesehatan pribadi). Templat dokumen: Pembina dan Admin.
create policy baca_penegak_isian on public.penegak_isian for select to authenticated
  using ((select sigarda.aktif()) and (peserta_id = (select auth.uid()) or (select sigarda.pembina_atau_admin())));
create policy baca_dokumen_templat on public.dokumen_templat for select to authenticated using ((select sigarda.pembina_atau_admin()));
create policy baca_portofolio_snapshot on public.portofolio_snapshot for select to authenticated using ((select sigarda.pembina_atau_admin()));
create policy baca_sfh_catatan on public.sfh_catatan for select to authenticated
  using ((select sigarda.aktif()) and (anggota_id = (select auth.uid()) or (select sigarda.pembina_atau_admin())));
-- ===== akhir kebijakan isian penegak =====

-- ===== Tim penilai dan kalender Garuda (Tahap 2, G4b dan G4c): kebijakan =====
-- Tim penilai dan kalender tahap Garuda dibaca pengurus (Pembina, Dewan, Admin); ditulis hanya lewat fungsi.
create policy baca_tim_penilai on public.tim_penilai for select to authenticated using ((select sigarda.aktif()) and (select sigarda.pengurus()));
create policy baca_tim_penilai_anggota on public.tim_penilai_anggota for select to authenticated using ((select sigarda.aktif()) and (select sigarda.pengurus()));
create policy baca_garuda_tahap on public.garuda_tahap for select to authenticated using ((select sigarda.aktif()) and (select sigarda.pengurus()));
-- ===== akhir kebijakan tim kalender =====

-- ===== Kelola Beranda (Fase 2 landing page): kebijakan =====
-- Isi lengkap (semua status) hanya dibaca pengurus (menu Kelola Beranda); publik membaca lewat sg_beranda_publik (hanya berstatus terbit).
create policy baca_beranda_berita on public.beranda_berita for select to authenticated using ((select sigarda.pengurus()));
create policy baca_beranda_prestasi on public.beranda_prestasi for select to authenticated using ((select sigarda.pengurus()));
create policy baca_beranda_galeri on public.beranda_galeri for select to authenticated using ((select sigarda.pengurus()));
create policy baca_beranda_sosial on public.beranda_sosial for select to authenticated using ((select sigarda.pengurus()));
create policy baca_beranda_faq on public.beranda_faq for select to authenticated using ((select sigarda.pengurus()));
-- ===== akhir kebijakan beranda konten =====

-- Sesi ujian: pengurus melihat semua; Penegak hanya sesi yang mencantumkan dirinya.
create policy baca_sesi_ujian on public.sesi_ujian for select to authenticated
  using ((select sigarda.aktif()) and ((select sigarda.pengurus()) or id in (select sesi_id from public.sesi_ujian_peserta where peserta_id = (select auth.uid()))));
create policy baca_sesi_ujian_butir on public.sesi_ujian_butir for select to authenticated
  using ((select sigarda.aktif()) and ((select sigarda.pengurus()) or sesi_id in (select sesi_id from public.sesi_ujian_peserta where peserta_id = (select auth.uid()))));
create policy baca_sesi_ujian_peserta on public.sesi_ujian_peserta for select to authenticated
  using ((select sigarda.aktif()) and (peserta_id = (select auth.uid()) or (select sigarda.pengurus())));

-- ---------------------------------------------------------------------------
-- 4. Fungsi aksi (RPC). Semua memeriksa peran di server.
-- ---------------------------------------------------------------------------

-- ===== SKU: peserta mengajukan pengujian =====
create function public.sg_sku_ajukan(p_sku_id text, p_jadwal date, p_penguji_id uuid, p_catatan text default '')
returns void language plpgsql security definer set search_path = public as
$$
declare
  v_uid uuid := auth.uid(); v_p public.profiles; v_u public.sku_unit; v_status text;
begin
  perform sigarda.wajib_aktif();
  select * into v_p from public.profiles where id = v_uid;
  if not found or v_p.role <> 'peserta' then raise exception 'Hanya peserta yang dapat mengajukan pengujian.'; end if;
  select * into v_u from public.sku_unit where id = p_sku_id and (agama is null or agama = v_p.agama);
  if not found then raise exception 'Poin SKU tidak ditemukan.'; end if;

  -- Butir Siaga (Mula, Bantu, Tata) hanya untuk anak berkelas SD; butir Penegak hanya untuk Penegak.
  if sigarda.kelas_siaga(v_p.kelas) <> (v_u.tingkat in ('Mula', 'Bantu', 'Tata')) then raise exception 'Butir ini bukan untuk tingkat kelasmu.'; end if;
  select status into v_status from public.sku_progress where peserta_id = v_uid and sku_id = p_sku_id;
  if v_status = 'lulus' then raise exception 'Poin ini sudah lulus.'; end if;
  if v_status in ('diajukan','proses') then raise exception 'Poin ini sedang menunggu atau dalam pengujian.'; end if;
  if sigarda.prasyarat_tingkat(v_u.tingkat) is not null and not sigarda.tingkat_selesai(v_uid, sigarda.prasyarat_tingkat(v_u.tingkat)) then
    raise exception 'Selesaikan seluruh butir % lebih dulu.', sigarda.prasyarat_tingkat(v_u.tingkat);
  end if;
  if p_jadwal is null then raise exception 'Tanggal pengujian wajib diisi.'; end if;
  if char_length(coalesce(p_catatan, '')) > 500 then raise exception 'Catatan maksimal 500 karakter.'; end if;
  -- Sakelar pra-uji hidup: pengajuan lebih dulu melewati pra-uji Pinsa/Bina Damping (p_penguji_id diabaikan; uji resmi selalu ke antrian Pembina rombel).
  if sigarda.pra_uji_aktif() and not sigarda.kelas_siaga(v_p.kelas) then   -- anak Siaga tidak melewati pra-uji (langsung ke antrian Pembina)
    perform sigarda.pra_uji_mulai(v_uid, p_sku_id, p_jadwal, p_catatan);
    return;
  end if;
  -- Ketat saat memilih penguji: hanya penguji yang sah (penugasan rombel, butir Laksana dan butir agama hanya Pembina, agama seagama).
  -- p_penguji_id kosong = antrian bersama rombel: penguji yang sah mana pun mengambilnya lewat "Mulai uji".
  if p_penguji_id is not null and not sigarda.bisa_menguji(p_penguji_id) then
    raise exception 'Pilih penguji terlebih dulu.';
  end if;
  if p_penguji_id is null then
    if not exists (select 1 from sigarda.penguji_sah(v_uid, p_sku_id)) then
      raise exception 'Belum ada penguji yang dapat menguji butir ini untuk rombel Anda. Hubungi Admin Gudep.';
    end if;
  elsif not sigarda.penguji_boleh(v_uid, p_penguji_id, p_sku_id) then
    if v_u.agama is not null then
      raise exception 'Butir agama hanya dapat diuji oleh Pembina yang seagama. Pilih penguji dari daftar.';
    elsif v_u.tingkat = 'Laksana' and not exists (select 1 from public.profiles where id = p_penguji_id and jabatan = 'Pembina') and not sigarda.ditugaskan(v_uid, p_penguji_id) then
      raise exception 'Butir Laksana hanya dapat diuji oleh Pembina atau penguji yang ditugaskan untuk Anda. Pilih penguji dari daftar.';
    else
      raise exception 'Penguji ini tidak bertugas pada rombel Anda. Pilih penguji dari daftar.';
    end if;
  end if;

  insert into public.sku_progress (peserta_id, sku_id, status, jadwal, penguji_id, catatan_peserta, diubah)
  values (v_uid, p_sku_id, 'diajukan', p_jadwal, p_penguji_id, btrim(coalesce(p_catatan, '')), now())
  on conflict (peserta_id, sku_id) do update
    set status = 'diajukan', jadwal = excluded.jadwal, penguji_id = excluded.penguji_id,
        catatan_peserta = excluded.catatan_peserta, diubah = now();
  insert into public.sku_riwayat (peserta_id, sku_id, teks, oleh)
  values (v_uid, p_sku_id, 'Mengajukan pengujian untuk ' || to_char(p_jadwal, 'YYYY-MM-DD') || case when p_penguji_id is null then ' (antrian rombel)' else '' end, v_uid);
end $$;

create function public.sg_sku_batal(p_sku_id text) returns void
language plpgsql security definer set search_path = public as
$$
declare v_uid uuid := auth.uid(); v_status text;
begin
  perform sigarda.wajib_aktif();
  if not exists (select 1 from public.profiles where id = v_uid and role = 'peserta') then
    raise exception 'Hanya peserta yang dapat membatalkan pengajuan.';
  end if;
  -- Pengajuan yang masih menunggu pra-uji (Pinsa/Bina Damping) juga dapat dibatalkan.
  if exists (select 1 from public.sku_pra_uji where peserta_id = v_uid and sku_id = p_sku_id and status = 'menunggu') then
    update public.sku_pra_uji set status = 'dibatalkan', diputuskan_pada = now() where peserta_id = v_uid and sku_id = p_sku_id and status = 'menunggu';
    insert into public.sku_riwayat (peserta_id, sku_id, teks, oleh) values (v_uid, p_sku_id, 'Pengajuan pra-uji dibatalkan peserta', v_uid);
    return;
  end if;
  select status into v_status from public.sku_progress where peserta_id = v_uid and sku_id = p_sku_id;
  if v_status is distinct from 'diajukan' then
    raise exception 'Hanya pengajuan yang belum mulai diuji yang bisa dibatalkan.';
  end if;
  update public.sku_progress
    set status = 'belum', jadwal = null, penguji_id = null, catatan_peserta = '', diubah = now()
    where peserta_id = v_uid and sku_id = p_sku_id;
  insert into public.sku_riwayat (peserta_id, sku_id, teks, oleh) values (v_uid, p_sku_id, 'Pengajuan dibatalkan peserta', v_uid);
end $$;

-- ===== Penegakan penugasan penguji: fungsi aksi =====
-- Daftar penguji yang sah untuk satu butir, beserta beban antrian masing-masing (pengajuan menunggu dan sedang diuji).
-- Penegak memakai untuk dirinya sendiri; Pembina dan Admin Gudep dapat menyebut p_peserta_id (dipakai saat mengalihkan pengajuan).
-- Hasil: { sumber: 'rombel' | 'semua', rombel, agama_butir, penguji: [{ id, nama, jabatan, agama, beban }] } (beban terendah lebih dulu).
create function public.sg_penguji_pilihan(p_sku_id text, p_peserta_id uuid default null) returns jsonb
language plpgsql stable security definer set search_path = public as
$$
declare v_uid uuid := auth.uid(); v_peserta uuid; v_p public.profiles; v_u public.sku_unit;
begin
  perform sigarda.wajib_aktif();
  if exists (select 1 from public.profiles where id = v_uid and role = 'peserta') then v_peserta := v_uid;
  elsif sigarda.pembina_atau_admin() then v_peserta := p_peserta_id;
  else raise exception 'Daftar penguji hanya untuk Penegak, Pembina, dan Admin Gudep.';
  end if;
  select * into v_p from public.profiles where id = v_peserta and role = 'peserta';
  if not found then raise exception 'Peserta tidak ditemukan.'; end if;
  select * into v_u from public.sku_unit where id = p_sku_id and (agama is null or agama = v_p.agama);
  if not found then raise exception 'Poin SKU tidak ditemukan.'; end if;
  return jsonb_build_object(
    'sumber', case when exists (select 1 from sigarda.penguji_sah(v_peserta, p_sku_id) s where s.o_rombel) then 'rombel' else 'semua' end,
    'rombel', v_p.kelas,
    'agama_butir', v_u.agama is not null,
    'penguji', coalesce((
      select jsonb_agg(jsonb_build_object('id', x.id, 'nama', x.nama, 'jabatan', x.jabatan, 'jabatan_dewan', x.jabatan_dewan, 'agama', x.agama, 'beban', x.beban) order by x.beban, x.nama)
      from (
        select u.id, u.nama, case when u.role = 'peserta' then 'Dewan Ambalan' else u.jabatan end as jabatan, u.jabatan_dewan, u.agama,
          (select count(*) from public.sku_progress sp where sp.penguji_id = u.id and sp.status in ('diajukan', 'proses'))::int as beban
        from public.profiles u where u.id in (select s.o_penguji from sigarda.penguji_sah(v_peserta, p_sku_id) s)
      ) x
    ), '[]'::jsonb));
end $$;

-- Pembina atau Admin Gudep mengalihkan pengajuan (menunggu atau sedang diuji) ke penguji lain, dengan alasan yang tercatat di riwayat.
-- p_penguji_id kosong = kembali ke antrian bersama rombel (hanya untuk yang belum mulai diuji).
create function public.sg_sku_alihkan(p_peserta_id uuid, p_sku_id text, p_penguji_id uuid, p_alasan text) returns void
language plpgsql security definer set search_path = public as
$$
declare v_uid uuid := auth.uid(); v_pr public.sku_progress; v_alasan text := btrim(coalesce(p_alasan, '')); v_dari text; v_ke text;
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pembina_atau_admin() then raise exception 'Hanya Pembina atau Admin Gudep yang dapat mengalihkan pengajuan.'; end if;
  select * into v_pr from public.sku_progress where peserta_id = p_peserta_id and sku_id = p_sku_id;
  if not found or v_pr.status not in ('diajukan', 'proses') then
    raise exception 'Hanya pengajuan yang menunggu atau sedang diuji yang dapat dialihkan.';
  end if;
  if v_alasan = '' then raise exception 'Isi alasan pengalihan.'; end if;
  if char_length(v_alasan) > 200 then raise exception 'Alasan maksimal 200 karakter.'; end if;
  if p_penguji_id is null and v_pr.status = 'proses' then
    raise exception 'Pengujian yang sedang berjalan harus dialihkan ke penguji tertentu.';
  end if;
  if p_penguji_id is not null and not sigarda.penguji_boleh(p_peserta_id, p_penguji_id, p_sku_id) then
    raise exception 'Penguji tujuan tidak dapat menguji butir ini untuk rombel Penegak tersebut.';
  end if;
  if p_penguji_id is null and not exists (select 1 from sigarda.penguji_sah(p_peserta_id, p_sku_id)) then
    raise exception 'Belum ada penguji yang dapat menguji butir ini untuk rombel Penegak tersebut.';
  end if;
  if p_penguji_id is not distinct from v_pr.penguji_id then raise exception 'Penguji tujuan sama dengan penguji saat ini.'; end if;
  select coalesce(nama, 'antrian rombel') into v_dari from public.profiles where id = v_pr.penguji_id;
  select coalesce(nama, 'antrian rombel') into v_ke from public.profiles where id = p_penguji_id;
  update public.sku_progress set penguji_id = p_penguji_id, diubah = now() where peserta_id = p_peserta_id and sku_id = p_sku_id;
  insert into public.sku_riwayat (peserta_id, sku_id, teks, oleh)
  values (p_peserta_id, p_sku_id, 'Dialihkan dari ' || coalesce(v_dari, 'antrian rombel') || ' ke ' || coalesce(v_ke, 'antrian rombel') || '. Alasan: ' || v_alasan, v_uid);
end $$;
-- ===== akhir fungsi penegakan =====

-- ===== SKU: penguji mencatat hasil. HANYA dipanggil Edge Function setelah PIN penguji diverifikasi. =====
create function public.sg_sku_catat_internal(
  p_oleh uuid, p_peserta_id uuid, p_sku_id text, p_hasil text,
  p_tanggal_uji date default null, p_nilai text default null, p_catatan text default ''
) returns void language plpgsql security definer set search_path = public as
$$
declare v_p public.profiles; v_kode text; v_cat text := btrim(coalesce(p_catatan, '')); v_lama public.sku_progress; v_ganti text := ''; v_luar text; v_pra text;
begin
  if not sigarda.bisa_menguji(p_oleh) then
    raise exception '%', case when sigarda.pra_uji_aktif() then 'Hanya Pembina yang dapat mencatat hasil uji resmi.' else 'Hanya Pembina atau Dewan Ambalan yang dapat mencatat hasil.' end;
  end if;
  if p_oleh = p_peserta_id then raise exception 'Anda tidak dapat menilai diri sendiri.'; end if;
  select * into v_p from public.profiles where id = p_peserta_id and role = 'peserta';
  if not found then raise exception 'Peserta tidak ditemukan.'; end if;
  if not exists (select 1 from public.sku_unit where id = p_sku_id and (agama is null or agama = v_p.agama)) then
    raise exception 'Poin SKU tidak ditemukan.';
  end if;
  if sigarda.kelas_siaga(v_p.kelas) <> exists (select 1 from public.sku_unit where id = p_sku_id and tingkat in ('Mula', 'Bantu', 'Tata')) then
    raise exception 'Butir ini bukan untuk tingkat kelas peserta (butir Siaga hanya untuk anak berkelas SD).';
  end if;
  -- Butir agama (sub-butir Butir 1) hanya dinilai Pembina yang seagama, dan butir Laksana hanya oleh Pembina atau penguji yang ditugaskan untuk Penegak
  -- itu, untuk semua hasil (mulai uji, lulus, perlu diulang, dikembalikan). Aturan ini sama dengan pemilihan penguji (sigarda.penguji_peran_ok).
  if not sigarda.penguji_peran_ok(p_peserta_id, p_oleh, p_sku_id) then
    if exists (select 1 from public.sku_unit where id = p_sku_id and agama is not null) then
      raise exception 'Butir agama hanya dapat dinilai oleh Pembina yang seagama dengan Penegak.';
    end if;
    raise exception 'Butir Laksana hanya dapat dinilai oleh Pembina atau penguji yang ditugaskan untuk Penegak ini.';
  end if;
  -- Lunak saat mencatat: penguji lain boleh menggantikan penguji tujuan, tetapi tercatat di riwayat.
  select * into v_lama from public.sku_progress where peserta_id = p_peserta_id and sku_id = p_sku_id;
  if found and v_lama.status in ('diajukan', 'proses') and v_lama.penguji_id is not null and v_lama.penguji_id <> p_oleh and p_hasil in ('proses', 'lulus', 'ulang') then
    v_ganti := ' (menggantikan ' || coalesce((select nama from public.profiles where id = v_lama.penguji_id), 'penguji lain') || ')';
  end if;
  -- Butir agama yang dinilai guru agama luar (Pembina tidak seagama, sah karena ada surat pengantar): riwayat menyebut guru dan nomor surat.
  if p_hasil in ('proses', 'lulus', 'ulang') and exists (select 1 from public.sku_unit where id = p_sku_id and agama is not null)
     and exists (select 1 from public.profiles b where b.role = 'penguji' and b.jabatan = 'Pembina' and b.agama is not null)
     and (select agama from public.profiles where id = p_oleh) is distinct from v_p.agama then
    select ' (dinilai guru agama ' || coalesce(d.payload -> 'guru' ->> 'nama', '-') || ', surat nomor ' || d.nomor || ')' into v_luar
    from public.dokumen_terbit d
    where d.jenis = 'surat_pengantar_agama' and d.peserta_id = p_peserta_id and d.dicabut_pada is null and d.payload -> 'butir' @> jsonb_build_array(p_sku_id)
    order by d.id desc limit 1;
    v_ganti := v_ganti || coalesce(v_luar, '');
  end if;
  if p_hasil not in ('proses','lulus','ulang','reset') then raise exception 'Hasil pengujian tidak dikenal.'; end if;
  -- Butir dengan instrumen ditetapkan hanya boleh dinilai lewat sg_sku_catat_rubrik_internal (yang menyalakan penanda ini)
  if p_hasil in ('lulus','ulang') and sigarda.instrumen_aktif(p_sku_id)
     and coalesce(current_setting('sigarda.via_rubrik', true), '') <> 'ya' then
    raise exception 'Butir ini dinilai dengan instrumen penilaian. Catat hasilnya lewat lembar penilaian.';
  end if;
  if p_hasil <> 'reset' and p_tanggal_uji is null then raise exception 'Tanggal uji wajib diisi.'; end if;
  select sigarda.prasyarat_tingkat(tingkat) into v_pra from public.sku_unit where id = p_sku_id;
  if p_hasil <> 'reset' and v_pra is not null and not sigarda.tingkat_selesai(p_peserta_id, v_pra) then
    raise exception 'Peserta belum menyelesaikan seluruh butir %.', v_pra;
  end if;
  if char_length(v_cat) > 1000 then raise exception 'Catatan maksimal 1000 karakter.'; end if;

  -- Pembina memulai atau menuntaskan butir yang masih menunggu pra-uji: pra-uji itu tidak diperlukan lagi.
  if p_hasil in ('proses', 'lulus', 'ulang') then
    update public.sku_pra_uji set status = 'dibatalkan', catatan = 'Dilanjutkan langsung oleh penguji resmi', diputuskan_pada = now()
      where peserta_id = p_peserta_id and sku_id = p_sku_id and status = 'menunggu';
  end if;

  if p_hasil = 'proses' then
    insert into public.sku_progress (peserta_id, sku_id, status, penguji_id, tanggal_uji)
    values (p_peserta_id, p_sku_id, 'proses', p_oleh, p_tanggal_uji)
    on conflict (peserta_id, sku_id) do update
      set status = 'proses', penguji_id = p_oleh, tanggal_uji = p_tanggal_uji, verifikasi = null, diverifikasi_pada = null, verifikasi_token = null, diubah = now();
    insert into public.sku_riwayat (peserta_id, sku_id, teks, oleh) values (p_peserta_id, p_sku_id, 'Pengujian dimulai' || v_ganti, p_oleh);

  elsif p_hasil = 'lulus' then
    if p_nilai is null then raise exception 'Pilih predikat penilaian.'; end if;
    if p_nilai not in ('Sangat baik','Baik','Cukup') then raise exception 'Predikat tidak dikenal.'; end if;
    v_kode := sigarda.kode_verifikasi(array[p_peserta_id::text, p_sku_id, p_oleh::text, p_tanggal_uji::text]);
    insert into public.sku_progress (peserta_id, sku_id, status, penguji_id, tanggal_uji, nilai, catatan, verifikasi, diverifikasi_pada, verifikasi_token)
    values (p_peserta_id, p_sku_id, 'lulus', p_oleh, p_tanggal_uji, p_nilai, v_cat, v_kode, now(), sigarda.token_acak())
    on conflict (peserta_id, sku_id) do update
      set status = 'lulus', penguji_id = p_oleh, tanggal_uji = p_tanggal_uji, nilai = p_nilai, catatan = v_cat,
          verifikasi = v_kode, diverifikasi_pada = now(), verifikasi_token = sigarda.token_acak(), diubah = now();
    insert into public.sku_riwayat (peserta_id, sku_id, teks, oleh)
    values (p_peserta_id, p_sku_id, 'Dinyatakan lulus (' || p_nilai || '), kode ' || v_kode || v_ganti, p_oleh);

  elsif p_hasil = 'ulang' then
    if v_cat = '' then raise exception 'Isi catatan agar peserta tahu bagian yang perlu diperbaiki.'; end if;
    insert into public.sku_progress (peserta_id, sku_id, status, penguji_id, tanggal_uji, nilai, catatan)
    values (p_peserta_id, p_sku_id, 'ulang', p_oleh, p_tanggal_uji, null, v_cat)
    on conflict (peserta_id, sku_id) do update
      set status = 'ulang', penguji_id = p_oleh, tanggal_uji = p_tanggal_uji, nilai = null, catatan = v_cat,
          verifikasi = null, diverifikasi_pada = null, verifikasi_token = null, diubah = now();
    insert into public.sku_riwayat (peserta_id, sku_id, teks, oleh) values (p_peserta_id, p_sku_id, 'Perlu diulang' || v_ganti, p_oleh);

  else -- reset
    if v_cat = '' then raise exception 'Isi alasan pembatalan status.'; end if;
    insert into public.sku_progress (peserta_id, sku_id, status)
    values (p_peserta_id, p_sku_id, 'belum')
    on conflict (peserta_id, sku_id) do update
      set status = 'belum', penguji_id = null, tanggal_uji = null, jadwal = null, nilai = null, catatan = '',
          catatan_peserta = '', verifikasi = null, diverifikasi_pada = null, verifikasi_token = null, diubah = now();
    insert into public.sku_riwayat (peserta_id, sku_id, teks, oleh)
    values (p_peserta_id, p_sku_id, 'Status dikembalikan ke belum diuji. Alasan: ' || v_cat, p_oleh);
  end if;
end $$;

-- ===== SKU: penilaian dengan instrumen. HANYA dipanggil Edge Function setelah PIN penguji diverifikasi. =====
-- Skor dan saran dihitung ulang di server dari nilai tiap kriteria. Penguji boleh memilih hasil yang berbeda dari saran,
-- dengan catatan alasan wajib (tercatat). Hasil diterapkan lewat sg_sku_catat_internal (status, kode verifikasi, riwayat).
create function public.sg_sku_catat_rubrik_internal(
  p_oleh uuid, p_peserta_id uuid, p_sku_id text, p_tanggal_uji date, p_rincian jsonb, p_hasil text, p_catatan text default ''
) returns jsonb language plpgsql security definer set search_path = public as
$$
declare
  v_p public.profiles; v_cat text := btrim(coalesce(p_catatan, '')); v_h record; v_diganti boolean; v_rinci jsonb; v_saran_iuran int; v_beda_iuran boolean := false;
begin
  if not sigarda.bisa_menguji(p_oleh) then
    raise exception '%', case when sigarda.pra_uji_aktif() then 'Hanya Pembina yang dapat mencatat hasil uji resmi.' else 'Hanya Pembina atau Dewan Ambalan yang dapat mencatat hasil.' end;
  end if;
  if p_oleh = p_peserta_id then raise exception 'Anda tidak dapat menilai diri sendiri.'; end if;
  select * into v_p from public.profiles where id = p_peserta_id and role = 'peserta';
  if not found then raise exception 'Peserta tidak ditemukan.'; end if;
  if not exists (select 1 from public.sku_unit where id = p_sku_id and (agama is null or agama = v_p.agama)) then
    raise exception 'Poin SKU tidak ditemukan.';
  end if;
  if p_hasil is null or p_hasil not in ('lulus', 'ulang') then raise exception 'Hasil penilaian dengan instrumen harus lulus atau perlu diulang.'; end if;
  if p_tanggal_uji is null then raise exception 'Tanggal uji wajib diisi.'; end if;
  if not sigarda.instrumen_aktif(p_sku_id) then raise exception 'Butir ini belum memakai instrumen penilaian.'; end if;
  if char_length(v_cat) > 1000 then raise exception 'Catatan maksimal 1000 karakter.'; end if;

  select * into v_h from sigarda.instrumen_hitung(p_sku_id, p_rincian);
  v_diganti := p_hasil <> v_h.o_saran;
  if v_diganti and v_cat = '' then
    raise exception 'Hasil yang dipilih berbeda dari saran (skor %, saran: %). Isi catatan alasannya.', v_h.o_skor, case v_h.o_saran when 'lulus' then 'lulus' else 'perlu diulang' end;
  end if;
  -- Kriteria bersumber iuran: nilai yang berbeda dari saran hitungan iuran (semester dari tanggal uji) wajib disertai catatan alasan
  select o_saran into v_saran_iuran from sigarda.iuran_hitung(p_peserta_id, p_tanggal_uji);
  if v_saran_iuran is not null then
    select exists (
      select 1 from jsonb_array_elements(p_rincian) e join public.instrumen_kriteria k on k.id = (e ->> 'kriteria_id')::bigint and k.sku_id = p_sku_id
      where k.sumber = 'iuran' and (e ->> 'nilai')::int <> v_saran_iuran
    ) into v_beda_iuran;
    if v_beda_iuran and v_cat = '' then
      raise exception 'Nilai kriteria iuran berbeda dari saran hitungan iuran (saran: %). Isi catatan alasannya.', v_saran_iuran;
    end if;
  end if;

  perform set_config('sigarda.via_rubrik', 'ya', true);
  perform public.sg_sku_catat_internal(p_oleh, p_peserta_id, p_sku_id, p_hasil, p_tanggal_uji, case when p_hasil = 'lulus' then v_h.o_nilai end, v_cat);
  perform set_config('sigarda.via_rubrik', '', true);

  select jsonb_agg(jsonb_build_object('kriteria_id', k.id, 'urutan', k.urutan, 'jenis', k.jenis, 'teks', k.teks, 'bobot', k.bobot, 'wajib', k.wajib, 'nilai', r.nilai,
    'sumber', k.sumber, 'saran', case when k.sumber = 'iuran' then v_saran_iuran end) order by k.urutan)
    into v_rinci
  from (select (e ->> 'kriteria_id')::bigint as kriteria_id, (e ->> 'nilai')::int as nilai from jsonb_array_elements(p_rincian) e) r
  join public.instrumen_kriteria k on k.id = r.kriteria_id;

  insert into public.sku_penilaian (peserta_id, sku_id, penguji_id, tanggal_uji, rincian, skor, wajib_ok, saran, hasil, diganti, catatan)
  values (p_peserta_id, p_sku_id, p_oleh, p_tanggal_uji, v_rinci, v_h.o_skor, v_h.o_wajib_ok, v_h.o_saran, p_hasil, v_diganti, v_cat);
  insert into public.sku_riwayat (peserta_id, sku_id, teks, oleh)
  values (p_peserta_id, p_sku_id,
    'Skor instrumen ' || v_h.o_skor || ' dari 100 (saran: ' || case v_h.o_saran when 'lulus' then 'lulus' else 'perlu diulang' end
    || case when v_h.o_wajib_ok then '' else '; ada syarat wajib belum terpenuhi' end || ')'
    || case when v_diganti then '. Hasil dipilih penguji berbeda dari saran. Alasan: ' || v_cat else '' end
    || case when v_beda_iuran and not v_diganti then '. Nilai kriteria iuran berbeda dari saran iuran (' || v_saran_iuran || '). Alasan: ' || v_cat else '' end, p_oleh);

  return jsonb_build_object('skor', v_h.o_skor, 'saran', v_h.o_saran, 'nilai', v_h.o_nilai, 'wajib_ok', v_h.o_wajib_ok, 'diganti', v_diganti);
end $$;

-- ===== Pencalonan Penegak Garuda =====
create function public.sg_calon_garuda_daftar() returns void
language plpgsql security definer set search_path = public as
$$
declare v_uid uuid := auth.uid(); v_p public.profiles;
begin
  perform sigarda.wajib_aktif();
  select * into v_p from public.profiles where id = v_uid;
  if not found or v_p.role <> 'peserta' then raise exception 'Hanya peserta yang dapat mencalonkan diri.'; end if;
  if not sigarda.layak_garuda(v_uid) then raise exception 'Seluruh butir SKU Bantara dan Laksana harus lulus lebih dulu.'; end if;
  if v_p.calon_garuda is null then
    update public.profiles set calon_garuda = sigarda.hari_ini() where id = v_uid;
  end if;
end $$;

-- ===== Jurnal portofolio Garuda =====
create function public.sg_pf_ubah(p_item_id text, p_status text default null, p_catatan text default null, p_tautan text default null)
returns void language plpgsql security definer set search_path = public as
$$
declare
  v_uid uuid := auth.uid(); v_p public.profiles;
  v_status text := 'belum'; v_catatan text := ''; v_tautan text := '';
  n_status text; n_catatan text; n_tautan text; v_ubah text[] := '{}';
  v_label jsonb := '{"belum":"Belum siap","proses":"Sedang disiapkan","siap":"Siap (Ada)"}';
begin
  perform sigarda.wajib_aktif();
  select * into v_p from public.profiles where id = v_uid;
  if not found or v_p.role <> 'peserta' or v_p.calon_garuda is null or not sigarda.layak_garuda(v_uid) then
    raise exception 'Jurnal portofolio khusus Penegak Calon Garuda.';
  end if;
  if not exists (select 1 from public.pf_item where id = p_item_id) then raise exception 'Dokumen portofolio tidak dikenal.'; end if;
  if p_status is not null and p_status not in ('belum','proses','siap') then raise exception 'Status tidak dikenal.'; end if;
  if char_length(coalesce(p_catatan, '')) > 2000 then raise exception 'Catatan maksimal 2000 karakter.'; end if;
  if char_length(coalesce(p_tautan, '')) > 500 then raise exception 'Tautan maksimal 500 karakter.'; end if;
  if btrim(coalesce(p_tautan, '')) <> '' and btrim(p_tautan) !~* '^https?://' then
    raise exception 'Tautan harus diawali http:// atau https://';
  end if;

  select status, catatan, tautan into v_status, v_catatan, v_tautan
    from public.portofolio where peserta_id = v_uid and item_id = p_item_id;
  if not found then   -- SELECT INTO mengisi NULL bila tidak ada baris; kembalikan ke nilai awal
    v_status := 'belum'; v_catatan := ''; v_tautan := '';
  end if;
  n_status := coalesce(p_status, v_status);
  n_catatan := case when p_catatan is null then v_catatan else btrim(p_catatan) end;
  n_tautan := case when p_tautan is null then v_tautan else btrim(p_tautan) end;

  if n_status <> v_status then v_ubah := v_ubah || ('Status: ' || (v_label->>v_status) || ' menjadi ' || (v_label->>n_status)); end if;
  if n_catatan <> btrim(v_catatan) then v_ubah := v_ubah || 'Catatan diperbarui'::text; end if;
  if n_tautan <> btrim(v_tautan) then v_ubah := v_ubah || 'Tautan berkas diperbarui'::text; end if;
  if cardinality(v_ubah) = 0 then return; end if;

  insert into public.portofolio (peserta_id, item_id, status, catatan, tautan, diperbarui)
  values (v_uid, p_item_id, n_status, n_catatan, n_tautan, now())
  on conflict (peserta_id, item_id) do update
    set status = n_status, catatan = n_catatan, tautan = n_tautan, diperbarui = now();
  insert into public.portofolio_jurnal (peserta_id, item_id, teks, oleh)
  values (v_uid, p_item_id, array_to_string(v_ubah, '. '), v_uid);
end $$;

create function public.sg_pf_catat_penguji(p_peserta_id uuid, p_item_id text, p_catatan text) returns void
language plpgsql security definer set search_path = public as
$$
declare v_uid uuid := auth.uid(); v_lama text := ''; v_baru text := btrim(coalesce(p_catatan, ''));
begin
  perform sigarda.wajib_aktif();
  if not sigarda.bisa_menguji(v_uid) then
    raise exception 'Hanya Pembina atau Dewan Ambalan yang dapat memberi catatan.';
  end if;
  if p_peserta_id = v_uid then raise exception 'Anda tidak dapat memberi catatan penguji pada portofolio sendiri.'; end if;
  if not exists (select 1 from public.profiles where id = p_peserta_id and role = 'peserta') then raise exception 'Peserta tidak ditemukan.'; end if;
  if not exists (select 1 from public.pf_item where id = p_item_id) then raise exception 'Dokumen portofolio tidak dikenal.'; end if;
  if char_length(v_baru) > 2000 then raise exception 'Catatan maksimal 2000 karakter.'; end if;

  select catatan_penguji into v_lama from public.portofolio where peserta_id = p_peserta_id and item_id = p_item_id;
  if v_baru = btrim(coalesce(v_lama, '')) then return; end if;

  insert into public.portofolio (peserta_id, item_id, catatan_penguji, catatan_penguji_oleh, diperbarui)
  values (p_peserta_id, p_item_id, v_baru, v_uid, now())
  on conflict (peserta_id, item_id) do update set catatan_penguji = v_baru, catatan_penguji_oleh = v_uid;
  insert into public.portofolio_jurnal (peserta_id, item_id, teks, oleh)
  values (p_peserta_id, p_item_id, case when v_baru = '' then 'Catatan penguji dihapus' else 'Catatan penguji ditambahkan' end, v_uid);
end $$;

-- ===== Absensi latihan Jumat (dicatat pengurus) =====
create function public.sg_absen_buat_sesi(p_tanggal date) returns void
language plpgsql security definer set search_path = public as
$$
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pengurus() then raise exception 'Hanya Dewan Ambalan, Pembina, atau admin yang dapat mencatat absensi.'; end if;
  if p_tanggal is null or p_tanggal < date '2000-01-01' or p_tanggal > date '2100-12-31' then raise exception 'Tanggal tidak valid.'; end if;
  if p_tanggal > sigarda.hari_ini() then raise exception 'Sesi belum bisa dibuat untuk tanggal yang belum tiba.'; end if;
  insert into public.absensi_sesi (tanggal, dibuat_oleh) values (p_tanggal, auth.uid()) on conflict (tanggal) do nothing;
end $$;

create function public.sg_absen_set(p_tanggal date, p_peserta_id uuid, p_status text) returns void
language plpgsql security definer set search_path = public as
$$
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pengurus() then raise exception 'Tidak diizinkan.'; end if;
  if p_status is not null and p_status not in ('H','I','S','A') then raise exception 'Status absensi tidak dikenal.'; end if;
  if not exists (select 1 from public.absensi_sesi where tanggal = p_tanggal) then raise exception 'Sesi absensi belum dibuat.'; end if;
  if not exists (select 1 from public.profiles where id = p_peserta_id and role = 'peserta') then raise exception 'Peserta tidak ditemukan.'; end if;
  if p_status is null then
    delete from public.absensi_hadir where tanggal = p_tanggal and peserta_id = p_peserta_id;
  else
    insert into public.absensi_hadir (tanggal, peserta_id, status, oleh) values (p_tanggal, p_peserta_id, p_status, auth.uid())
    on conflict (tanggal, peserta_id) do update set status = excluded.status, oleh = excluded.oleh, waktu = now();
  end if;
end $$;

create function public.sg_absen_set_banyak(p_tanggal date, p_peserta_ids uuid[], p_status text, p_hanya_kosong boolean default true)
returns void language plpgsql security definer set search_path = public as
$$
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pengurus() then raise exception 'Tidak diizinkan.'; end if;
  if p_status is null or p_status not in ('H','I','S','A') then raise exception 'Status absensi tidak dikenal.'; end if;
  if not exists (select 1 from public.absensi_sesi where tanggal = p_tanggal) then raise exception 'Sesi absensi belum dibuat.'; end if;
  insert into public.absensi_hadir (tanggal, peserta_id, status, oleh)
  select p_tanggal, u.id, p_status, auth.uid()
  from public.profiles u where u.role = 'peserta' and u.status = 'aktif' and u.id = any (p_peserta_ids)
  on conflict (tanggal, peserta_id) do update
    set status = excluded.status, oleh = excluded.oleh, waktu = now()
    where not p_hanya_kosong;
end $$;

create function public.sg_absen_hapus_sesi(p_tanggal date) returns void
language plpgsql security definer set search_path = public as
$$
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pengurus() then raise exception 'Tidak diizinkan.'; end if;
  -- Catatan uang tidak boleh hilang diam-diam bersama sesi: iuran dan tutup kas harus dikosongkan lebih dulu oleh Dewan Ambalan
  if exists (select 1 from public.iuran where tanggal = p_tanggal) or exists (select 1 from public.iuran_kas where tanggal = p_tanggal) then
    raise exception 'Sesi ini memiliki catatan iuran atau tutup kas. Dewan Ambalan perlu mengosongkannya lebih dulu sebelum sesi dihapus.';
  end if;
  delete from public.absensi_sesi where tanggal = p_tanggal;   -- catatan kehadiran ikut terhapus (cascade)
end $$;

-- ===== Iuran bumbung kepramukaan: fungsi aksi =====
-- Mencatat iuran satu Penegak pada satu Jumat. p_jumlah kosong atau 0 = tidak iuran (baris dihapus). Hanya Dewan Ambalan atau asisten bendahara;
-- asisten tidak dapat mencatat iurannya sendiri. Jenis baris baru selalu 'rutin'; baris yang sudah 'susulan' tetap 'susulan' saat jumlahnya diubah.
create function public.sg_iuran_set(p_tanggal date, p_peserta_id uuid, p_jumlah int) returns void
language plpgsql security definer set search_path = public as
$$
declare v_baru int := nullif(p_jumlah, 0); v_lama int; v_jenis text;
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pencatat_iuran() then raise exception 'Hanya Dewan Ambalan atau asisten bendahara yang dapat mencatat iuran.'; end if;
  if v_baru is not null and (v_baru < 1 or v_baru > 1000000) then raise exception 'Jumlah iuran harus antara Rp 1 dan Rp 1.000.000.'; end if;
  if not exists (select 1 from public.absensi_sesi where tanggal = p_tanggal) then raise exception 'Sesi absensi belum dibuat.'; end if;
  if not exists (select 1 from public.profiles where id = p_peserta_id and role = 'peserta') then raise exception 'Peserta tidak ditemukan.'; end if;
  if p_peserta_id = auth.uid() then raise exception 'Iuran Anda sendiri dicatat oleh Dewan Ambalan.'; end if;
  select jumlah, jenis into v_lama, v_jenis from public.iuran where tanggal = p_tanggal and peserta_id = p_peserta_id;
  if v_lama is not distinct from v_baru then return; end if;
  if v_baru is null then
    delete from public.iuran where tanggal = p_tanggal and peserta_id = p_peserta_id;
  else
    insert into public.iuran (tanggal, peserta_id, jumlah, jenis, oleh) values (p_tanggal, p_peserta_id, v_baru, 'rutin', auth.uid())
    on conflict (tanggal, peserta_id) do update set jumlah = excluded.jumlah, oleh = excluded.oleh, waktu = now();
  end if;
  insert into public.iuran_log (tanggal, peserta_id, jumlah_lama, jumlah_baru, jenis, oleh)
  values (p_tanggal, p_peserta_id, v_lama, v_baru, coalesce(v_jenis, 'rutin'), auth.uid());
end $$;

-- Mengisi iuran yang sama untuk banyak Penegak sekaligus (mis. semua yang hadir). p_hanya_kosong = true: yang sudah berisi iuran tidak diubah.
create function public.sg_iuran_set_banyak(p_tanggal date, p_peserta_ids uuid[], p_jumlah int, p_hanya_kosong boolean default true) returns int
language plpgsql security definer set search_path = public as
$$
declare v_id uuid; v_lama int; v_jenis text; v_n int := 0;
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pencatat_iuran() then raise exception 'Hanya Dewan Ambalan atau asisten bendahara yang dapat mencatat iuran.'; end if;
  if p_jumlah is null or p_jumlah < 1 or p_jumlah > 1000000 then raise exception 'Jumlah iuran harus antara Rp 1 dan Rp 1.000.000.'; end if;
  if not exists (select 1 from public.absensi_sesi where tanggal = p_tanggal) then raise exception 'Sesi absensi belum dibuat.'; end if;
  if cardinality(coalesce(p_peserta_ids, '{}')) > 500 then raise exception 'Maksimal 500 peserta per permintaan.'; end if;
  for v_id in select id from public.profiles where role = 'peserta' and status = 'aktif' and id = any (coalesce(p_peserta_ids, '{}')) and id <> auth.uid() loop
    select jumlah, jenis into v_lama, v_jenis from public.iuran where tanggal = p_tanggal and peserta_id = v_id;
    if v_lama is not null and p_hanya_kosong then continue; end if;
    if v_lama is not distinct from p_jumlah then continue; end if;
    insert into public.iuran (tanggal, peserta_id, jumlah, jenis, oleh) values (p_tanggal, v_id, p_jumlah, 'rutin', auth.uid())
    on conflict (tanggal, peserta_id) do update set jumlah = excluded.jumlah, oleh = excluded.oleh, waktu = now();
    insert into public.iuran_log (tanggal, peserta_id, jumlah_lama, jumlah_baru, jenis, oleh)
    values (p_tanggal, v_id, v_lama, p_jumlah, coalesce(v_jenis, 'rutin'), auth.uid());
    v_n := v_n + 1;
  end loop;
  return v_n;
end $$;

-- Lembar catat iuran satu Jumat untuk Dewan Ambalan dan asisten bendahara: daftar Penegak (tanpa dirinya sendiri) beserta kehadiran dan iurannya.
-- Asisten (seorang Penegak) tidak boleh membaca profil Penegak lain lewat tabel, jadi daftar ini disediakan fungsi.
create function public.sg_iuran_lembar(p_tanggal date) returns jsonb
language plpgsql stable security definer set search_path = public as
$$
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pencatat_iuran() then raise exception 'Hanya Dewan Ambalan atau asisten bendahara yang dapat membuka lembar iuran.'; end if;
  return coalesce((
    select jsonb_agg(jsonb_build_object('id', p.id, 'nama', p.nama, 'kelas', p.kelas, 'sangga', p.sangga, 'status', h.status, 'jumlah', i.jumlah, 'jenis', i.jenis)
                     order by p.nama)
    from public.profiles p
    left join public.iuran i on i.peserta_id = p.id and i.tanggal = p_tanggal
    left join public.absensi_hadir h on h.peserta_id = p.id and h.tanggal = p_tanggal
    where p.role = 'peserta' and p.status = 'aktif' and p.id <> auth.uid()
  ), '[]'::jsonb);
end $$;

-- Rekap iuran untuk SEMUA peran (tanpa rincian per orang): total per Jumat untuk gudep, per sangga, dan per kelas, pada rentang tanggal.
-- 'susulan' = bagian total yang berasal dari iuran susulan; 'orang' = jumlah Penegak yang beriuran.
create function public.sg_iuran_agregat(p_mulai date, p_akhir date) returns jsonb
language plpgsql stable security definer set search_path = public as
$$
begin
  perform sigarda.wajib_aktif();
  if p_mulai is null or p_akhir is null or p_mulai > p_akhir or p_akhir - p_mulai > 800 then
    raise exception 'Rentang tanggal tidak valid (maksimal sekitar 2 tahun).';
  end if;
  return coalesce((
    select jsonb_agg(jsonb_build_object('tanggal', x.tanggal, 'tipe', x.tipe, 'kunci', x.kunci, 'jumlah', x.jumlah, 'susulan', x.susulan, 'orang', x.orang)
                     order by x.tanggal, x.tipe, x.kunci)
    from (
      select i.tanggal, 'gudep'::text as tipe, ''::text as kunci, sum(i.jumlah)::int as jumlah,
             coalesce(sum(i.jumlah) filter (where i.jenis = 'susulan'), 0)::int as susulan, count(*)::int as orang
        from public.iuran i where i.tanggal between p_mulai and p_akhir group by i.tanggal
      union all
      select i.tanggal, 'sangga', coalesce(p.sangga, ''), sum(i.jumlah)::int,
             coalesce(sum(i.jumlah) filter (where i.jenis = 'susulan'), 0)::int, count(*)::int
        from public.iuran i join public.profiles p on p.id = i.peserta_id where i.tanggal between p_mulai and p_akhir group by i.tanggal, p.sangga
      union all
      select i.tanggal, 'kelas', coalesce(p.kelas, ''), sum(i.jumlah)::int,
             coalesce(sum(i.jumlah) filter (where i.jenis = 'susulan'), 0)::int, count(*)::int
        from public.iuran i join public.profiles p on p.id = i.peserta_id where i.tanggal between p_mulai and p_akhir group by i.tanggal, p.kelas
    ) x
  ), '[]'::jsonb);
end $$;

-- Tutup kas satu Jumat (Dewan Ambalan): total uang fisik yang dihitung. p_total kosong menghapus catatan tutup kas.
create function public.sg_iuran_kas_simpan(p_tanggal date, p_total int, p_catatan text default '') returns void
language plpgsql security definer set search_path = public as
$$
declare v_cat text := btrim(coalesce(p_catatan, ''));
begin
  perform sigarda.wajib_aktif();
  if not (sigarda.dewan() or sigarda.pembina_saja()) then raise exception 'Hanya Dewan Ambalan atau Pembina yang dapat menutup kas.'; end if;
  if not exists (select 1 from public.absensi_sesi where tanggal = p_tanggal) then raise exception 'Sesi absensi belum dibuat.'; end if;
  if p_total is null then
    delete from public.iuran_kas where tanggal = p_tanggal;
    return;
  end if;
  if p_total < 0 or p_total > 100000000 then raise exception 'Total kas tidak valid.'; end if;
  if char_length(v_cat) > 300 then raise exception 'Catatan maksimal 300 karakter.'; end if;
  insert into public.iuran_kas (tanggal, total_fisik, catatan, oleh) values (p_tanggal, p_total, v_cat, auth.uid())
  on conflict (tanggal) do update set total_fisik = excluded.total_fisik, catatan = excluded.catatan, oleh = excluded.oleh, waktu = now();
end $$;

-- Menunjuk atau mencabut asisten bendahara. Oleh Dewan Ambalan atau Pembina. Dipilih dari Penegak Calon Laksana (SKU Bantara selesai,
-- SKU Laksana belum), maksimal 5 orang sekaligus. Pencabutan tidak mensyaratkan apa pun.
create function public.sg_asisten_iuran_atur(p_peserta_id uuid, p_aktif boolean) returns void
language plpgsql security definer set search_path = public as
$$
begin
  perform sigarda.wajib_aktif();
  if not (sigarda.dewan() or coalesce((select role = 'penguji' and jabatan = 'Pembina' from public.profiles where id = auth.uid()), false)) then
    raise exception 'Hanya Dewan Ambalan atau Pembina yang dapat menunjuk asisten bendahara.';
  end if;
  if not exists (select 1 from public.profiles where id = p_peserta_id and role = 'peserta') then raise exception 'Peserta tidak ditemukan.'; end if;
  if p_aktif is true then
    if not sigarda.tingkat_selesai(p_peserta_id, 'Bantara') or sigarda.tingkat_selesai(p_peserta_id, 'Laksana') then
      raise exception 'Asisten bendahara dipilih dari Penegak Calon Laksana (SKU Bantara selesai, SKU Laksana belum).';
    end if;
    if not exists (select 1 from public.asisten_iuran where peserta_id = p_peserta_id) and (select count(*) from public.asisten_iuran) >= 5 then
      raise exception 'Asisten bendahara maksimal 5 orang. Cabut penunjukan yang lain lebih dulu.';
    end if;
    insert into public.asisten_iuran (peserta_id, ditunjuk_oleh) values (p_peserta_id, auth.uid()) on conflict (peserta_id) do nothing;
  else
    delete from public.asisten_iuran where peserta_id = p_peserta_id;
  end if;
end $$;
-- ---- Iuran bumbung dan penilaian SKU (butir Bantara 6 dan Laksana 6) ----
-- Pengaturan iuran untuk semua pengguna aktif (nilai bawaan bila belum pernah diatur).
create function public.sg_iuran_pengaturan() returns jsonb
language plpgsql stable security definer set search_path = public as
$$
begin
  perform sigarda.wajib_aktif();
  return jsonb_build_object('standar', sigarda.iuran_angka('standar', 1000), 'ambang', sigarda.iuran_angka('ambang', 75),
    'lima', sigarda.iuran_angka('lima', 90), 'tiga', sigarda.iuran_angka('tiga', 65), 'dua', sigarda.iuran_angka('dua', 50));
end $$;

-- Mengubah pengaturan iuran (Pembina dan Admin): iuran standar Rp 500-50.000 (kelipatan Rp 500), ambang rutin, dan batas nilai 5/3/2.
create function public.sg_iuran_pengaturan_simpan(p_nilai jsonb) returns void
language plpgsql security definer set search_path = public as
$$
declare v_k text; v_st int; v_amb int; v_lima int; v_tiga int; v_dua int;
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pembina_atau_admin() then raise exception 'Hanya Pembina dan Admin Gudep yang dapat mengubah pengaturan iuran.'; end if;
  if p_nilai is null or jsonb_typeof(p_nilai) <> 'object' then raise exception 'Pengaturan iuran tidak sah.'; end if;
  foreach v_k in array array['standar', 'ambang', 'lima', 'tiga', 'dua'] loop
    if coalesce(p_nilai ->> v_k, '') !~ '^[0-9]{1,6}$' then raise exception 'Pengaturan iuran: % harus bilangan bulat.', v_k; end if;
  end loop;
  v_st := (p_nilai ->> 'standar')::int; v_amb := (p_nilai ->> 'ambang')::int; v_lima := (p_nilai ->> 'lima')::int;
  v_tiga := (p_nilai ->> 'tiga')::int; v_dua := (p_nilai ->> 'dua')::int;
  if v_st < 500 or v_st > 50000 or v_st % 500 <> 0 then raise exception 'Iuran standar harus kelipatan Rp 500 antara Rp 500 dan Rp 50.000.'; end if;
  if not (v_lima <= 100 and v_lima > v_amb and v_amb > v_tiga and v_tiga > v_dua and v_dua >= 1) then
    raise exception 'Batas persen harus berurutan: nilai 5 (maks. 100) lebih besar dari ambang rutin, ambang lebih besar dari nilai 3, nilai 3 lebih besar dari nilai 2, nilai 2 minimal 1.';
  end if;
  insert into public.pengaturan (kunci, nilai, diubah_oleh, diubah_pada)
  values ('iuran.pengaturan', jsonb_build_object('standar', v_st, 'ambang', v_amb, 'lima', v_lima, 'tiga', v_tiga, 'dua', v_dua), auth.uid(), now())
  on conflict (kunci) do update set nilai = excluded.nilai, diubah_oleh = excluded.diubah_oleh, diubah_pada = excluded.diubah_pada;
end $$;

-- Ringkasan iuran seorang Penegak untuk lembar penilaian butir iuran (pengurus): kepatuhan semester dari tanggal uji, kekurangan, saran nilai,
-- Jumat yang masih kosong (untuk iuran susulan, terlama dulu), dan berapa Jumat ia membantu mencatat sebagai asisten bendahara.
create function public.sg_iuran_ringkas(p_peserta_id uuid, p_tanggal date) returns jsonb
language plpgsql stable security definer set search_path = public as
$$
declare h record; v_kosong jsonb; v_membantu int;
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pengurus() then raise exception 'Hanya pengurus yang dapat melihat ringkasan iuran Penegak.'; end if;
  if p_tanggal is null then raise exception 'Tanggal uji wajib diisi.'; end if;
  if not exists (select 1 from public.profiles where id = p_peserta_id and role = 'peserta') then raise exception 'Peserta tidak ditemukan.'; end if;
  select * into h from sigarda.iuran_hitung(p_peserta_id, p_tanggal);
  select coalesce(jsonb_agg(s.tanggal order by s.tanggal), '[]'::jsonb) into v_kosong
    from public.absensi_sesi s
    where s.tanggal between h.o_mulai and least(h.o_akhir, p_tanggal)
      and not exists (select 1 from public.iuran i where i.tanggal = s.tanggal and i.peserta_id = p_peserta_id);
  select count(distinct l.tanggal)::int into v_membantu from public.iuran_log l where l.oleh = p_peserta_id;
  return jsonb_build_object('mulai', h.o_mulai, 'akhir', h.o_akhir, 'pertemuan', h.o_pertemuan, 'kali', h.o_kali, 'susulan', h.o_susulan,
    'rutin', h.o_kali - h.o_susulan, 'persen', h.o_persen, 'target', h.o_target, 'kurang', h.o_kurang, 'saran', h.o_saran,
    'membantu', v_membantu, 'kosong', v_kosong,
    'pengaturan', jsonb_build_object('standar', sigarda.iuran_angka('standar', 1000), 'ambang', sigarda.iuran_angka('ambang', 75),
      'lima', sigarda.iuran_angka('lima', 90), 'tiga', sigarda.iuran_angka('tiga', 65), 'dua', sigarda.iuran_angka('dua', 50)));
end $$;

-- Iuran susulan (Dewan Ambalan): menebus Jumat yang kosong pada semester dari tanggal uji, TERLAMA DULU, masing-masing p_jumlah, paling banyak
-- p_pertemuan Jumat. Baris ditandai 'susulan' dan dihitung setara dengan iuran rutin. Mengembalikan jumlah Jumat yang terisi.
create function public.sg_iuran_susulan(p_peserta_id uuid, p_tanggal date, p_jumlah int, p_pertemuan int) returns int
language plpgsql security definer set search_path = public as
$$
declare h record; v_t date; v_n int := 0;
begin
  perform sigarda.wajib_aktif();
  if not (sigarda.dewan() or sigarda.pembina_saja()) then raise exception 'Hanya Dewan Ambalan atau Pembina yang dapat mencatat iuran susulan.'; end if;
  if p_tanggal is null then raise exception 'Tanggal uji wajib diisi.'; end if;
  if p_jumlah is null or p_jumlah < 1 or p_jumlah > 1000000 then raise exception 'Jumlah iuran harus antara Rp 1 dan Rp 1.000.000.'; end if;
  if p_pertemuan is null or p_pertemuan < 1 or p_pertemuan > 60 then raise exception 'Jumlah pertemuan susulan harus antara 1 dan 60.'; end if;
  if not exists (select 1 from public.profiles where id = p_peserta_id and role = 'peserta') then raise exception 'Peserta tidak ditemukan.'; end if;
  select * into h from sigarda.iuran_hitung(p_peserta_id, p_tanggal);
  for v_t in
    select s.tanggal from public.absensi_sesi s
    where s.tanggal between h.o_mulai and least(h.o_akhir, p_tanggal, sigarda.hari_ini())
      and not exists (select 1 from public.iuran i where i.tanggal = s.tanggal and i.peserta_id = p_peserta_id)
    order by s.tanggal limit p_pertemuan
  loop
    insert into public.iuran (tanggal, peserta_id, jumlah, jenis, oleh) values (v_t, p_peserta_id, p_jumlah, 'susulan', auth.uid());
    insert into public.iuran_log (tanggal, peserta_id, jumlah_lama, jumlah_baru, jenis, oleh) values (v_t, p_peserta_id, null, p_jumlah, 'susulan', auth.uid());
    v_n := v_n + 1;
  end loop;
  if v_n = 0 then raise exception 'Tidak ada pertemuan tanpa iuran yang dapat ditebus pada semester ini.'; end if;
  return v_n;
end $$;
-- ===== Tabungan Siaga (Fase 3): aksi =====
-- Pembina (atau Admin) mencatat bahwa pada p_tanggal buku tabungan seorang anak Siaga diperiksa dan ada setoran sebesar p_jumlah (rupiah) pada minggu itu.
-- Mencatat ulang tanggal yang sama = koreksi. Hanya anggota Siaga (kelas SD, dengan atau tanpa akun) yang aktif; uang tetap di buku anak, aplikasi hanya mencatat pemeriksaannya.
-- Aturan isian dicerminkan src/lib/tabunganLogic.js (periksaTabungan) dan dibandingkan langsung dengan fungsi ini oleh uji/tabungan-klien.mjs.
create function public.sg_tabungan_catat(p_peserta_id uuid, p_tanggal date, p_jumlah int, p_catatan text default null) returns void
language plpgsql security definer set search_path = public as
$$
declare v_p record; v_cat text := btrim(coalesce(p_catatan, ''));
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pembina_atau_admin() then raise exception 'Hanya Pembina atau Admin Gudep yang dapat mencatat tabungan.'; end if;
  select id, nama, kelas, status, tanpa_akun into v_p from public.profiles where id = p_peserta_id and role = 'peserta';
  if v_p.id is null then raise exception 'Anggota tidak ditemukan.'; end if;
  if not (v_p.tanpa_akun or sigarda.kelas_siaga(v_p.kelas)) then raise exception 'Tabungan hanya dicatat untuk anggota Siaga.'; end if;
  if p_tanggal is null then raise exception 'Tanggal pemeriksaan wajib diisi.'; end if;
  if p_tanggal < date '2015-01-01' or p_tanggal > sigarda.hari_ini() then raise exception 'Tanggal pemeriksaan harus antara 1 Januari 2015 dan hari ini.'; end if;
  if p_jumlah is null or p_jumlah < 1 or p_jumlah > 100000000 then raise exception 'Setoran harus antara Rp 1 dan Rp 100.000.000.'; end if;
  if char_length(v_cat) > 200 then raise exception 'Catatan maksimal 200 karakter.'; end if;
  insert into public.tabungan_cek (peserta_id, tanggal, jumlah, catatan, oleh) values (p_peserta_id, p_tanggal, p_jumlah, v_cat, auth.uid())
  on conflict (peserta_id, tanggal) do update set jumlah = excluded.jumlah, catatan = excluded.catatan, oleh = excluded.oleh, waktu = now();
end $$;

create function public.sg_tabungan_hapus(p_peserta_id uuid, p_tanggal date) returns void
language plpgsql security definer set search_path = public as
$$
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pembina_atau_admin() then raise exception 'Hanya Pembina atau Admin Gudep yang dapat menghapus catatan tabungan.'; end if;
  if exists (select 1 from public.profiles where id = p_peserta_id and status <> 'aktif') then raise exception 'Anggota nonaktif atau alumni tidak dapat diubah.'; end if;
  delete from public.tabungan_cek where peserta_id = p_peserta_id and tanggal = p_tanggal;
end $$;
-- ===== akhir aksi tabungan =====
-- ===== akhir fungsi iuran =====

-- ===== Penugasan penguji per rombel: fungsi aksi (Pembina dan Admin Gudep) =====
-- Menambah (p_ada = true) atau mencabut (false) penugasan satu penguji (Pembina atau Dewan Ambalan) pada beberapa rombel sekaligus.
-- Setiap perubahan nyata dicatat di penugasan_log; yang sudah sesuai dilewati. Mengembalikan jumlah perubahan nyata.
create function public.sg_penugasan_atur(p_tahun_ajaran text, p_penguji_id uuid, p_rombel text[], p_ada boolean) returns int
language plpgsql security definer set search_path = public as
$$
declare v_b text; v_r text; v_n int := 0; v_k int; v_nama text; v_oleh text;
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pembina_atau_admin() then raise exception 'Hanya Pembina dan Admin Gudep yang dapat mengatur penugasan penguji.'; end if;
  if not sigarda.tahun_ajaran_sah(p_tahun_ajaran) then raise exception 'Tahun ajaran tidak sah. Contoh: 2026/2027.'; end if;
  if p_ada is null then raise exception 'Pilihan tambah atau cabut wajib diisi.'; end if;
  select nama into v_nama from public.profiles where id = p_penguji_id;
  if not found or not (sigarda.bisa_menguji(p_penguji_id) or (not p_ada and exists (select 1 from public.penugasan_rombel where penguji_id = p_penguji_id))) then
    raise exception 'Penguji tidak ditemukan. Penugasan hanya untuk Pembina dan Penegak berjabatan Dewan Ambalan yang aktif.';
  end if;
  if coalesce(array_length(p_rombel, 1), 0) = 0 then return 0; end if;
  if array_length(p_rombel, 1) > 30 then raise exception 'Maksimal 30 rombel per permintaan.'; end if;
  select nama into v_oleh from public.profiles where id = auth.uid();

  foreach v_b in array p_rombel loop
    v_r := sigarda.rombel_baku(v_b);
    if not sigarda.rombel_sah(v_r) then
      raise exception 'Rombel "%" tidak sah. Gunakan X-01 sampai X-10, XI-01 sampai XI-10, atau XII-01 sampai XII-10.', v_b;
    end if;
    if p_ada then
      insert into public.penugasan_rombel (tahun_ajaran, rombel, penguji_id, ditetapkan_oleh)
      values (p_tahun_ajaran, v_r, p_penguji_id, auth.uid()) on conflict do nothing;
    else
      delete from public.penugasan_rombel where tahun_ajaran = p_tahun_ajaran and rombel = v_r and penguji_id = p_penguji_id;
    end if;
    get diagnostics v_k = row_count;
    if v_k > 0 then
      insert into public.penugasan_log (tahun_ajaran, rombel, penguji_id, penguji_nama, tindakan, oleh, oleh_nama)
      values (p_tahun_ajaran, v_r, p_penguji_id, v_nama, case when p_ada then 'tambah' else 'hapus' end, auth.uid(), coalesce(v_oleh, ''));
      v_n := v_n + 1;
    end if;
  end loop;
  return v_n;
end $$;

-- Penugasan KHUSUS satu Penegak (pengecualian dari penugasan rombelnya), oleh Pembina atau Admin Gudep. p_penguji_ids = daftar LENGKAP penguji Penegak itu pada
-- tahun ajaran p_tahun_ajaran (kosong = hapus pengecualian, kembali ke penugasan rombel). Tiap penguji harus dapat menguji (Pembina atau Penegak berjabatan Dewan
-- yang aktif) dan bukan Penegak itu sendiri. p_alasan (maks 200) wajib bila ada yang berubah. Perubahan tercatat di penugasan_log. Mengembalikan jumlah perubahan.
create function public.sg_penugasan_peserta_atur(p_tahun_ajaran text, p_peserta_id uuid, p_penguji_ids uuid[], p_alasan text default '') returns int
language plpgsql security definer set search_path = public as
$$
declare v_p public.profiles; v_ids uuid[]; v_id uuid; v_n int := 0; v_nama text; v_oleh text; v_alasan text := sigarda.rapikan(p_alasan); v_k int;
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pembina_atau_admin() then raise exception 'Hanya Pembina dan Admin Gudep yang dapat mengatur penugasan penguji.'; end if;
  if not sigarda.tahun_ajaran_sah(p_tahun_ajaran) then raise exception 'Tahun ajaran tidak sah. Contoh: 2026/2027.'; end if;
  select * into v_p from public.profiles where id = p_peserta_id and role = 'peserta';
  if not found then raise exception 'Penegak tidak ditemukan.'; end if;
  if v_p.status <> 'aktif' then raise exception '% berstatus % dan tidak dapat diatur penugasannya.', v_p.nama, v_p.status; end if;
  v_ids := coalesce((select array_agg(distinct x) from unnest(p_penguji_ids) x), '{}');
  if cardinality(v_ids) > 10 then raise exception 'Maksimal 10 penguji untuk satu Penegak.'; end if;
  if char_length(v_alasan) > 200 then raise exception 'Alasan maksimal 200 karakter.'; end if;
  foreach v_id in array v_ids loop
    if v_id = p_peserta_id then raise exception 'Penegak tidak dapat menjadi pengujinya sendiri.'; end if;
    if not sigarda.bisa_menguji(v_id) then raise exception 'Penguji tidak ditemukan atau tidak aktif. Penugasan hanya untuk Pembina dan Penegak berjabatan Dewan Ambalan.'; end if;
  end loop;
  select nama into v_oleh from public.profiles where id = auth.uid();

  -- yang dicabut
  for v_id in select penguji_id from public.penugasan_peserta where tahun_ajaran = p_tahun_ajaran and peserta_id = p_peserta_id and not (penguji_id = any (v_ids)) loop
    select nama into v_nama from public.profiles where id = v_id;
    delete from public.penugasan_peserta where tahun_ajaran = p_tahun_ajaran and peserta_id = p_peserta_id and penguji_id = v_id;
    insert into public.penugasan_log (tahun_ajaran, rombel, penguji_id, penguji_nama, tindakan, catatan, oleh, oleh_nama, peserta_id, peserta_nama)
    values (p_tahun_ajaran, coalesce(v_p.kelas, ''), v_id, coalesce(v_nama, ''), 'hapus', v_alasan, auth.uid(), coalesce(v_oleh, ''), p_peserta_id, v_p.nama);
    v_n := v_n + 1;
  end loop;
  -- yang ditambah
  foreach v_id in array v_ids loop
    insert into public.penugasan_peserta (tahun_ajaran, peserta_id, penguji_id, ditetapkan_oleh) values (p_tahun_ajaran, p_peserta_id, v_id, auth.uid()) on conflict do nothing;
    get diagnostics v_k = row_count;
    if v_k > 0 then
      select nama into v_nama from public.profiles where id = v_id;
      insert into public.penugasan_log (tahun_ajaran, rombel, penguji_id, penguji_nama, tindakan, catatan, oleh, oleh_nama, peserta_id, peserta_nama)
      values (p_tahun_ajaran, coalesce(v_p.kelas, ''), v_id, coalesce(v_nama, ''), 'tambah', v_alasan, auth.uid(), coalesce(v_oleh, ''), p_peserta_id, v_p.nama);
      v_n := v_n + 1;
    end if;
  end loop;
  if v_n > 0 and v_alasan = '' then raise exception 'Isi alasan penugasan khusus (mis. konflik kepentingan, pindah rombel, penguji cuti).'; end if;
  return v_n;
end $$;

-- Menyalin penugasan tahun ajaran p_dari ke p_ke (yang sudah ada dilewati; tidak ada yang dicabut). Mengembalikan jumlah penugasan baru.
create function public.sg_penugasan_salin(p_dari text, p_ke text) returns int
language plpgsql security definer set search_path = public as
$$
declare v_n int; v_oleh text;
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pembina_atau_admin() then raise exception 'Hanya Pembina dan Admin Gudep yang dapat mengatur penugasan penguji.'; end if;
  if not sigarda.tahun_ajaran_sah(p_dari) or not sigarda.tahun_ajaran_sah(p_ke) then raise exception 'Tahun ajaran tidak sah. Contoh: 2026/2027.'; end if;
  if p_dari = p_ke then raise exception 'Tahun ajaran asal dan tujuan tidak boleh sama.'; end if;
  if not exists (select 1 from public.penugasan_rombel where tahun_ajaran = p_dari) then
    raise exception 'Tahun ajaran % belum memiliki penugasan untuk disalin.', p_dari;
  end if;
  select nama into v_oleh from public.profiles where id = auth.uid();

  with baru as (
    insert into public.penugasan_rombel (tahun_ajaran, rombel, penguji_id, ditetapkan_oleh)
    select p_ke, rombel, penguji_id, auth.uid() from public.penugasan_rombel where tahun_ajaran = p_dari and sigarda.bisa_menguji(penguji_id)
    on conflict do nothing returning rombel, penguji_id
  )
  insert into public.penugasan_log (tahun_ajaran, rombel, penguji_id, penguji_nama, tindakan, catatan, oleh, oleh_nama)
  select p_ke, b.rombel, b.penguji_id, pr.nama, 'tambah', 'Disalin dari ' || p_dari, auth.uid(), coalesce(v_oleh, '')
  from baru b join public.profiles pr on pr.id = b.penguji_id;
  get diagnostics v_n = row_count;
  return v_n;
end $$;

-- Memperbarui rombel banyak Penegak sekaligus (mis. dari "X" menjadi "X-03"). p_data = [{"username": "10231", "rombel": "X-03"}, ...] (username = NIS).
-- Semua atau tidak sama sekali: satu baris yang keliru membatalkan seluruh permintaan, dengan pesan yang menyebut nomor barisnya.
create function public.sg_rombel_perbarui(p_data jsonb) returns int
language plpgsql security definer set search_path = public as
$$
declare v_e jsonb; v_user text; v_r text; v_n int := 0; v_k int;
begin
  perform sigarda.wajib_admin('Hanya Admin Gudep yang dapat memperbarui rombel Penegak.');
  if p_data is null or jsonb_typeof(p_data) <> 'array' then raise exception 'Data rombel tidak valid.'; end if;
  if jsonb_array_length(p_data) > 500 then raise exception 'Maksimal 500 baris per permintaan.'; end if;
  for v_e in select * from jsonb_array_elements(p_data) loop
    v_n := v_n + 1;
    v_user := lower(btrim(coalesce(v_e ->> 'username', '')));
    v_r := sigarda.rombel_baku(v_e ->> 'rombel');
    if v_user = '' then raise exception 'Baris %: NIS wajib diisi.', v_n; end if;
    if not sigarda.rombel_sah(v_r) then
      raise exception 'Baris %: rombel "%" tidak sah. Gunakan X-01 sampai X-10, XI-01 sampai XI-10, atau XII-01 sampai XII-10.', v_n, coalesce(v_e ->> 'rombel', '');
    end if;
    update public.profiles set kelas = v_r where username = v_user and role = 'peserta';
    get diagnostics v_k = row_count;
    if v_k = 0 then raise exception 'Baris %: Penegak dengan NIS "%" tidak ditemukan.', v_n, v_user; end if;
  end loop;
  return v_n;
end $$;

-- Guru agama (rujukan surat pengantar). p_id kosong = tambah; berisi = ubah. Mengembalikan id.
create function public.sg_guru_agama_simpan(p_id bigint, p_agama text, p_nama text, p_keterangan text default '') returns bigint
language plpgsql security definer set search_path = public as
$$
declare v_nama text := sigarda.rapikan(p_nama); v_ket text := sigarda.rapikan(p_keterangan); v_id bigint;
begin
  perform sigarda.wajib_admin('Hanya Admin Gudep yang dapat mengelola guru agama.');
  if coalesce(p_agama, '') not in ('Islam','Katolik','Protestan','Hindu','Buddha','Khonghucu') then raise exception 'Agama tidak dikenal.'; end if;
  if v_nama = '' then raise exception 'Nama guru agama wajib diisi.'; end if;
  if char_length(v_nama) > 120 then raise exception 'Nama maksimal 120 karakter.'; end if;
  if char_length(v_ket) > 200 then raise exception 'Keterangan maksimal 200 karakter.'; end if;
  begin
    if p_id is null then
      insert into public.guru_agama (agama, nama, keterangan, diubah_oleh) values (p_agama, v_nama, v_ket, auth.uid()) returning id into v_id;
    else
      update public.guru_agama set agama = p_agama, nama = v_nama, keterangan = v_ket, diubah_oleh = auth.uid(), diubah_pada = now()
        where id = p_id returning id into v_id;
      if v_id is null then raise exception 'Guru agama tidak ditemukan.'; end if;
    end if;
  exception when unique_violation then
    raise exception 'Guru agama % untuk agama % sudah terdaftar.', v_nama, p_agama;
  end;
  return v_id;
end $$;

create function public.sg_guru_agama_hapus(p_id bigint) returns void
language plpgsql security definer set search_path = public as
$$
begin
  perform sigarda.wajib_admin('Hanya Admin Gudep yang dapat mengelola guru agama.');
  delete from public.guru_agama where id = p_id;
end $$;
-- ===== akhir fungsi penugasan =====

-- ===== Pinsa dan Bina Damping (fase B): aksi =====
-- Menunjuk Bina Damping satu rombel (menggantikan daftar lama; kosong = mengosongkan). Dewan Ambalan, Pembina, dan Admin Gudep.
-- Bina Damping = Penegak aktif berjabatan Dewan Ambalan yang minimal Calon Laksana (Bantara selesai), maksimal 2 per rombel, satu rombel per orang per tahun
-- ajaran. PRIORITAS: Penegak Dewan yang sudah Laksana lebih dulu; yang masih Calon Laksana hanya bila tidak ada lagi Penegak Dewan yang sudah Laksana
-- dan belum bertugas. Mengembalikan jumlah perubahan (yang dicabut + yang ditambah).
create function public.sg_bina_damping_atur(p_tahun_ajaran text, p_rombel text, p_penegak_ids uuid[]) returns int
language plpgsql security definer set search_path = public as
$$
declare v_ids uuid[]; v_id uuid; v_p public.profiles; v_n int := 0; v_k int; v_bebas int;
begin
  perform sigarda.wajib_aktif();
  if not (sigarda.dewan() or sigarda.pembina_atau_admin()) then
    raise exception 'Hanya Dewan Ambalan, Pembina, dan Admin Gudep yang dapat menunjuk Bina Damping.';
  end if;
  if not sigarda.tahun_ajaran_sah(p_tahun_ajaran) then raise exception 'Tahun ajaran tidak sah. Contoh: 2026/2027.'; end if;
  if not sigarda.rombel_sah(p_rombel) then raise exception 'Rombel tidak sah. Contoh: X-01, XI-05, XII-10.'; end if;
  v_ids := coalesce((select array_agg(distinct x) from unnest(p_penegak_ids) x), '{}');
  if cardinality(v_ids) > 2 then raise exception 'Bina Damping maksimal 2 orang per rombel.'; end if;
  foreach v_id in array v_ids loop
    select * into v_p from public.profiles where id = v_id and role = 'peserta';
    if not found or v_p.status <> 'aktif' then raise exception 'Penegak tidak ditemukan atau tidak aktif.'; end if;
    if v_p.jabatan_dewan is null then
      raise exception '% bukan pengurus Dewan Ambalan. Bina Damping dipilih dari Penegak berjabatan Dewan Ambalan.', v_p.nama;
    end if;
    if not sigarda.tingkat_selesai(v_id, 'Bantara') then
      raise exception '% belum menyelesaikan SKU Bantara. Bina Damping minimal Penegak Calon Laksana.', v_p.nama;
    end if;
    if exists (select 1 from public.bina_damping where tahun_ajaran = p_tahun_ajaran and penegak_id = v_id and rombel <> p_rombel) then
      raise exception '% sudah menjadi Bina Damping rombel lain pada tahun ajaran ini.', v_p.nama;
    end if;
    if not sigarda.tingkat_selesai(v_id, 'Laksana') then
      select count(*) into v_bebas from public.profiles q
      where q.role = 'peserta' and q.status = 'aktif' and q.jabatan_dewan is not null and q.id <> all (v_ids)
        and sigarda.tingkat_selesai(q.id, 'Bantara') and sigarda.tingkat_selesai(q.id, 'Laksana')
        and not exists (select 1 from public.bina_damping b where b.tahun_ajaran = p_tahun_ajaran and b.penegak_id = q.id and b.rombel <> p_rombel);
      if v_bebas > 0 then
        raise exception '% masih Calon Laksana. Dahulukan Penegak berjabatan Dewan yang sudah Laksana (masih ada % yang belum bertugas).', v_p.nama, v_bebas;
      end if;
    end if;
  end loop;

  delete from public.bina_damping where tahun_ajaran = p_tahun_ajaran and rombel = p_rombel and not (penegak_id = any (v_ids));
  get diagnostics v_k = row_count;
  v_n := v_k;
  foreach v_id in array v_ids loop
    insert into public.bina_damping (tahun_ajaran, rombel, penegak_id, ditetapkan_oleh) values (p_tahun_ajaran, p_rombel, v_id, auth.uid()) on conflict do nothing;
    get diagnostics v_k = row_count;
    v_n := v_n + v_k;
  end loop;
  return v_n;
end $$;

-- Penunjukan Bina Damping satu tahun ajaran (bawaan: tahun ajaran berjalan) beserta calon yang dapat dipilih. Pengurus (Dewan, Pembina, Admin).
-- { tahun_ajaran, bisa_atur (boleh menunjuk: Dewan, Pembina, Admin), penugasan: [{ rombel, penegak_id, nama, kelas, jabatan_dewan, tingkat }],
--   calon: [{ id, nama, kelas, jabatan_dewan, tingkat, rombel }] } dengan calon = Penegak berjabatan Dewan yang minimal Calon Laksana (Laksana lebih dulu);
-- rombel = tempat ia sudah bertugas pada tahun ajaran itu (null = belum).
create function public.sg_bina_damping_daftar(p_tahun_ajaran text default null) returns jsonb
language plpgsql stable security definer set search_path = public as
$$
declare v_ta text := coalesce(p_tahun_ajaran, sigarda.tahun_ajaran_kini());
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pengurus() then raise exception 'Hanya pengurus yang dapat melihat penunjukan Bina Damping.'; end if;
  if not sigarda.tahun_ajaran_sah(v_ta) then raise exception 'Tahun ajaran tidak sah. Contoh: 2026/2027.'; end if;
  return jsonb_build_object(
    'tahun_ajaran', v_ta,
    'bisa_atur', sigarda.dewan() or sigarda.pembina_atau_admin(),
    'penugasan', coalesce((
      select jsonb_agg(jsonb_build_object('rombel', b.rombel, 'penegak_id', p.id, 'nama', p.nama, 'kelas', p.kelas, 'jabatan_dewan', p.jabatan_dewan,
                                          'tingkat', sigarda.tingkat_penegak(p.id)) order by b.rombel, p.nama)
      from public.bina_damping b join public.profiles p on p.id = b.penegak_id where b.tahun_ajaran = v_ta), '[]'::jsonb),
    'calon', coalesce((
      select jsonb_agg(x.j order by x.urut, x.nama) from (
        select p.nama, case when sigarda.tingkat_selesai(p.id, 'Laksana') then 0 else 1 end as urut,
               jsonb_build_object('id', p.id, 'nama', p.nama, 'kelas', p.kelas, 'jabatan_dewan', p.jabatan_dewan, 'tingkat', sigarda.tingkat_penegak(p.id),
                                  'rombel', (select b.rombel from public.bina_damping b where b.penegak_id = p.id and b.tahun_ajaran = v_ta)) as j
        from public.profiles p
        where p.role = 'peserta' and p.status = 'aktif' and p.jabatan_dewan is not null and sigarda.tingkat_selesai(p.id, 'Bantara')
      ) x), '[]'::jsonb)
  );
end $$;

-- Susunan sangga sebuah rombel beserta Bina Damping dan peringatannya. Boleh dibaca: pengurus, Bina Damping rombel itu, dan Penegak aktif rombel itu.
-- { rombel, tahun_ajaran, bisa_atur, bina_damping: [{ id, nama, tingkat }], anggota: [{ id, nama, sangga, pinsa, tingkat, layak_pinsa }],
--   pinsa_tugas: [{ id, nama, sangga, kelas (asal), tingkat }] (Pinsa yang ditugaskan dari rombel lain), peringatan: [{ sangga, teks }] }
-- `tingkat` (kemajuan SKU sesama Penegak) dan `layak_pinsa` (Bantara selesai) hanya diperlihatkan kepada yang boleh mengatur dan pengurus; Penegak biasa menerima null/false.
create function public.sg_sangga_rombel(p_rombel text) returns jsonb
language plpgsql stable security definer set search_path = public as
$$
declare v_atur boolean; v_lihat boolean;
begin
  perform sigarda.wajib_aktif();
  if not sigarda.rombel_sah(p_rombel) then raise exception 'Rombel tidak sah. Contoh: X-01, XI-05, XII-10.'; end if;
  v_atur := sigarda.sangga_bisa_atur(p_rombel);
  v_lihat := v_atur or sigarda.pengurus();
  if not (v_lihat or exists (select 1 from public.profiles where id = auth.uid() and role = 'peserta' and status = 'aktif' and kelas = p_rombel)) then
    raise exception 'Susunan sangga hanya dapat dilihat pengurus, Bina Damping, dan anggota rombel ini.';
  end if;
  return jsonb_build_object(
    'rombel', p_rombel,
    'tahun_ajaran', sigarda.tahun_ajaran_kini(),
    'bisa_atur', v_atur,
    'bina_damping', coalesce((
      select jsonb_agg(jsonb_build_object('id', p.id, 'nama', p.nama, 'tingkat', case when v_lihat then sigarda.tingkat_penegak(p.id) end) order by p.nama)
      from public.bina_damping b join public.profiles p on p.id = b.penegak_id
      where b.rombel = p_rombel and b.tahun_ajaran = sigarda.tahun_ajaran_kini()), '[]'::jsonb),
    'anggota', coalesce((
      select jsonb_agg(jsonb_build_object('id', x.id, 'nama', x.nama, 'sangga', x.sangga, 'pinsa', x.pinsa, 'tingkat', x.tingkat,
                                          'layak_pinsa', x.tingkat is not null and x.tingkat <> 'calon-bantara') order by lower(x.sangga), x.pinsa desc, x.nama)
      from (select p.id, p.nama, p.sangga, p.pinsa, case when v_lihat then sigarda.tingkat_penegak(p.id) end as tingkat
            from public.profiles p where p.role = 'peserta' and p.status = 'aktif' and p.kelas = p_rombel) x), '[]'::jsonb),
    'pinsa_tugas', coalesce((
      select jsonb_agg(jsonb_build_object('id', p.id, 'nama', p.nama, 'sangga', t.sangga, 'kelas', p.kelas, 'tingkat', case when v_lihat then sigarda.tingkat_penegak(p.id) end)
                       order by lower(t.sangga), p.nama)
      from public.pinsa_tugas t join public.profiles p on p.id = t.penegak_id
      where t.tahun_ajaran = sigarda.tahun_ajaran_kini() and t.rombel = p_rombel), '[]'::jsonb),
    'peringatan', sigarda.sangga_peringatan(p_rombel)
  );
end $$;

-- Membagi sangga dan menentukan Pinsa di satu rombel (Bina Damping rombel itu, Pembina, dan Admin). p_data = [{ id, sangga?, pinsa? }] untuk Penegak aktif
-- rombel itu; kunci yang tidak ada = tidak diubah. Semua atau tidak sama sekali. Pinsa minimal Calon Laksana, satu per sangga; pindah sangga otomatis melepas
-- Pinsa-nya. Mengembalikan { diubah, peringatan } (peringatan tidak memblokir).
create function public.sg_sangga_atur(p_rombel text, p_data jsonb) returns jsonb
language plpgsql security definer set search_path = public as
$$
declare v_e jsonb; v_id uuid; v_t public.profiles; v_s text; v_pinsa boolean; v_lain text; v_n int := 0; v_tahap int;
begin
  perform sigarda.wajib_aktif();
  if not sigarda.rombel_sah(p_rombel) then raise exception 'Rombel tidak sah. Contoh: X-01, XI-05, XII-10.'; end if;
  if not sigarda.sangga_bisa_atur(p_rombel) then
    raise exception 'Hanya Bina Damping rombel ini, Pembina, dan Admin Gudep yang dapat mengatur sangga.';
  end if;
  if p_data is null or jsonb_typeof(p_data) <> 'array' then raise exception 'Data sangga tidak sah.'; end if;
  if jsonb_array_length(p_data) > 60 then raise exception 'Maksimal 60 Penegak per penyimpanan.'; end if;

  -- Tahap 1: nama sangga.
  for v_e in select * from jsonb_array_elements(p_data) loop
    v_id := (v_e ->> 'id')::uuid;
    select * into v_t from public.profiles where id = v_id and role = 'peserta' and kelas = p_rombel and status = 'aktif';
    if not found then raise exception 'Penegak tidak ditemukan di rombel % atau tidak aktif.', p_rombel; end if;
    if v_e ? 'sangga' then
      v_s := sigarda.rapikan(v_e ->> 'sangga');
      if v_s = '' or char_length(v_s) > 40 then raise exception 'Nama sangga wajib diisi (maksimal 40 karakter).'; end if;
      v_s := coalesce((select sangga from public.profiles where role = 'peserta' and lower(sangga) = lower(v_s) limit 1), v_s);
      if v_s is distinct from v_t.sangga then
        update public.profiles set sangga = v_s where id = v_id;
        v_n := v_n + 1;
      end if;
    end if;
  end loop;

  -- Tahap 2: Pinsa. Yang dicabut lebih dulu (agar tukar Pinsa dalam satu simpanan berhasil), lalu yang ditetapkan.
  for v_tahap in 1..2 loop
    for v_e in select * from jsonb_array_elements(p_data) loop
      if not (v_e ? 'pinsa') then continue; end if;
      v_pinsa := (v_e ->> 'pinsa')::boolean;
      if (v_tahap = 1) <> (not v_pinsa) then continue; end if;
      v_id := (v_e ->> 'id')::uuid;
      select * into v_t from public.profiles where id = v_id;
      if v_pinsa is not distinct from v_t.pinsa then continue; end if;
      if v_pinsa then
        if btrim(coalesce(v_t.sangga, '')) = '' then raise exception '% belum punya sangga. Bagi sangga lebih dulu, baru pilih Pinsa.', v_t.nama; end if;
        if not sigarda.tingkat_selesai(v_id, 'Bantara') then
          raise exception '% belum menyelesaikan SKU Bantara. Pinsa dipilih dari Penegak Calon Laksana.', v_t.nama;
        end if;
        select nama into v_lain from public.profiles where role = 'peserta' and status = 'aktif' and kelas = v_t.kelas and lower(sangga) = lower(v_t.sangga) and pinsa and id <> v_id limit 1;
        if v_lain is not null then raise exception 'Sangga % sudah punya Pinsa (%). Cabut dulu Pinsa yang lama.', v_t.sangga, v_lain; end if;
      end if;
      update public.profiles set pinsa = v_pinsa where id = v_id;
      v_n := v_n + 1;
    end loop;
  end loop;
  return jsonb_build_object('diubah', v_n, 'peringatan', sigarda.sangga_peringatan(p_rombel));
end $$;

-- Peran pendampingan diri sendiri (dipakai menu): rombel yang saya dampingi sebagai Bina Damping pada tahun ajaran berjalan, dan apakah saya Pinsa.
create function public.sg_pendampingan_saya() returns jsonb
language plpgsql stable security definer set search_path = public as
$$
begin
  perform sigarda.wajib_aktif();
  return jsonb_build_object(
    'bina_damping', coalesce((select jsonb_agg(b.rombel order by b.rombel) from public.bina_damping b
                              where b.penegak_id = auth.uid() and b.tahun_ajaran = sigarda.tahun_ajaran_kini()), '[]'::jsonb),
    'pinsa', coalesce((select pinsa from public.profiles where id = auth.uid()), false)
             or exists (select 1 from public.pinsa_tugas t where t.penegak_id = auth.uid() and t.tahun_ajaran = sigarda.tahun_ajaran_kini()),
    'pinsa_tugas', coalesce((select jsonb_agg(jsonb_build_object('rombel', t.rombel, 'sangga', t.sangga) order by t.rombel, lower(t.sangga)) from public.pinsa_tugas t
                             where t.penegak_id = auth.uid() and t.tahun_ajaran = sigarda.tahun_ajaran_kini()), '[]'::jsonb));
end $$;
-- ===== akhir aksi pinsa bina damping =====

-- ===== Pinsa tertugas lintas rombel: aksi =====
-- Penegak yang dapat ditugaskan menjadi Pinsa sebuah sangga di rombel p_rombel: aktif, sudah menyelesaikan SKU Bantara, belum bertugas sebagai Pinsa tahun ajaran ini
-- (dan bukan Pinsa sangga sendiri). Dibaca hanya oleh yang boleh mengatur sangga rombel itu (Bina Damping rombel itu, Pembina, Admin); dipanggil saat panel penugasan dibuka.
-- { tahun_ajaran, calon: [{ id, nama, kelas, tingkat }] } urut kelas lalu nama.
create function public.sg_pinsa_calon(p_rombel text) returns jsonb
language plpgsql stable security definer set search_path = public as
$$
begin
  perform sigarda.wajib_aktif();
  if not sigarda.rombel_sah(p_rombel) then raise exception 'Rombel tidak sah. Contoh: X-01, XI-05, XII-10.'; end if;
  if not sigarda.sangga_bisa_atur(p_rombel) then
    raise exception 'Hanya Bina Damping rombel ini, Pembina, dan Admin Gudep yang dapat menugaskan Pinsa.';
  end if;
  return jsonb_build_object(
    'tahun_ajaran', sigarda.tahun_ajaran_kini(),
    'calon', coalesce((
      select jsonb_agg(jsonb_build_object('id', x.id, 'nama', x.nama, 'kelas', x.kelas, 'tingkat', x.tingkat) order by x.kelas, x.nama)
      from (
        select p.id, p.nama, p.kelas, sigarda.tingkat_penegak(p.id) as tingkat
        from public.profiles p
        where p.role = 'peserta' and p.status = 'aktif' and not p.pinsa
          and not exists (select 1 from public.pinsa_tugas t where t.penegak_id = p.id and t.tahun_ajaran = sigarda.tahun_ajaran_kini())
          and exists (select 1 from public.sku_progress s join public.sku_unit u on u.id = s.sku_id where s.peserta_id = p.id and s.status = 'lulus' and u.tingkat = 'Bantara')
          and sigarda.tingkat_selesai(p.id, 'Bantara')
        limit 400
      ) x), '[]'::jsonb));
end $$;

-- Menugaskan satu Penegak Calon Laksana menjadi Pinsa sebuah sangga (p_sangga) di rombel p_rombel (Bina Damping rombel itu, Pembina, Admin). Sangga harus sudah ada di rombel itu.
-- Satu orang satu sangga per tahun ajaran; paling banyak 2 Pinsa tertugas per sangga. Mengembalikan { peringatan } (sama dengan sg_sangga_atur).
create function public.sg_pinsa_tugaskan(p_rombel text, p_sangga text, p_penegak_id uuid) returns jsonb
language plpgsql security definer set search_path = public as
$$
declare v_ta text := sigarda.tahun_ajaran_kini(); v_s text := sigarda.rapikan(p_sangga); v_nama_sangga text; v_p public.profiles; v_t public.pinsa_tugas;
begin
  perform sigarda.wajib_aktif();
  if not sigarda.rombel_sah(p_rombel) then raise exception 'Rombel tidak sah. Contoh: X-01, XI-05, XII-10.'; end if;
  if not sigarda.sangga_bisa_atur(p_rombel) then
    raise exception 'Hanya Bina Damping rombel ini, Pembina, dan Admin Gudep yang dapat menugaskan Pinsa.';
  end if;
  select min(sangga) into v_nama_sangga from public.profiles
    where role = 'peserta' and status = 'aktif' and kelas = p_rombel and lower(btrim(coalesce(sangga, ''))) = lower(v_s) and v_s <> '';
  if v_nama_sangga is null then
    raise exception 'Sangga % belum ada di rombel %. Bagi sangga lebih dulu, baru tugaskan Pinsa.', coalesce(nullif(v_s, ''), '(kosong)'), p_rombel;
  end if;
  select * into v_p from public.profiles where id = p_penegak_id and role = 'peserta' and status = 'aktif';
  if not found then raise exception 'Penegak tidak ditemukan atau tidak aktif.'; end if;
  if not sigarda.tingkat_selesai(p_penegak_id, 'Bantara') then
    raise exception '% belum menyelesaikan SKU Bantara. Pinsa dipilih dari Penegak Calon Laksana.', v_p.nama;
  end if;
  if v_p.pinsa then raise exception '% sudah menjadi Pinsa di sangga sendiri. Cabut dulu Pinsa-nya di rombelnya.', v_p.nama; end if;
  select * into v_t from public.pinsa_tugas where tahun_ajaran = v_ta and penegak_id = p_penegak_id;
  if found then
    raise exception '% sudah bertugas sebagai Pinsa sangga % rombel %. Cabut dulu penugasannya.', v_p.nama, v_t.sangga, v_t.rombel;
  end if;
  if v_p.kelas = p_rombel and lower(btrim(coalesce(v_p.sangga, ''))) = lower(v_nama_sangga) then
    raise exception '% anggota sangga ini sendiri. Jadikan Pinsa lewat kotak centang Pinsa pada susunan sangga.', v_p.nama;
  end if;
  if (select count(*) from public.pinsa_tugas where tahun_ajaran = v_ta and rombel = p_rombel and lower(sangga) = lower(v_nama_sangga)) >= 2 then
    raise exception 'Sangga % sudah punya 2 Pinsa tertugas. Cabut salah satunya lebih dulu.', v_nama_sangga;
  end if;
  insert into public.pinsa_tugas (tahun_ajaran, rombel, sangga, penegak_id, ditetapkan_oleh) values (v_ta, p_rombel, v_nama_sangga, p_penegak_id, auth.uid());
  return jsonb_build_object('peringatan', sigarda.sangga_peringatan(p_rombel));
end $$;

-- Mencabut penugasan Pinsa (p_penegak_id) pada rombel p_rombel (Bina Damping rombel itu, Pembina, Admin). Mencabut yang tidak ada tidak galat.
create function public.sg_pinsa_cabut(p_rombel text, p_penegak_id uuid) returns jsonb
language plpgsql security definer set search_path = public as
$$
begin
  perform sigarda.wajib_aktif();
  if not sigarda.rombel_sah(p_rombel) then raise exception 'Rombel tidak sah. Contoh: X-01, XI-05, XII-10.'; end if;
  if not sigarda.sangga_bisa_atur(p_rombel) then
    raise exception 'Hanya Bina Damping rombel ini, Pembina, dan Admin Gudep yang dapat mencabut penugasan Pinsa.';
  end if;
  delete from public.pinsa_tugas where tahun_ajaran = sigarda.tahun_ajaran_kini() and rombel = p_rombel and penegak_id = p_penegak_id;
  return jsonb_build_object('peringatan', sigarda.sangga_peringatan(p_rombel));
end $$;
-- ===== akhir aksi pinsa tertugas =====

-- ===== Naik kelas dan status anggota: fungsi =====
-- Penegak berstatus nonaktif atau alumni hanya dapat DILIHAT (dan dicetak). Semua penulisan yang menyangkut Penegak itu ditolak pemicu di bawah,
-- sehingga tidak bergantung pada tiap fungsi aksi. Pembaruan yang dipicu tindakan kunci asing (mis. penguji_id menjadi kosong saat akun
-- penguji dihapus) bukan penulisan pengguna dan dilewati (pg_trigger_depth() > 1). Fungsi naik kelas membatalkan pengajuan SEBELUM mengubah status.
create function sigarda.tolak_peserta_tak_aktif() returns trigger language plpgsql security definer set search_path = public as
$$
declare v_status text; v_nama text; v_agama text; v_tanpa_akun boolean;
begin
  if TG_OP = 'UPDATE' and pg_trigger_depth() > 1 then return new; end if;
  select status, nama, agama, tanpa_akun into v_status, v_nama, v_agama, v_tanpa_akun from public.profiles where id = new.peserta_id;
  if v_status is not null and v_status <> 'aktif' then
    if new.peserta_id = auth.uid() then
      raise exception 'Akun Anda berstatus % dan hanya dapat dilihat. Hubungi Pembina atau Admin Gudep bila ingin aktif kembali.', v_status;
    end if;
    raise exception '% berstatus % dan tidak dapat diubah. Aktifkan kembali lebih dulu di menu Anggota.', v_nama, v_status;
  end if;
  -- Agama Penegak baru diisi sendiri sesudah akun dibuat (Tahap 3, H1). Tanpa agama, butir agama tidak tampak baginya sehingga progres SKU-nya tidak lengkap: penulisan progres SKU ditolak sampai agama diisi.
  if v_status = 'aktif' and v_agama is null and TG_TABLE_NAME in ('sku_progress', 'sku_riwayat', 'sku_pra_uji', 'sesi_ujian_peserta') then
    if v_tanpa_akun or (new.peserta_id is distinct from auth.uid() and sigarda.kelas_siaga((select kelas from public.profiles where id = new.peserta_id))) then
      raise exception '% belum dicatat agamanya. Isi agamanya di menu Anggota Siaga (ubah data anak) sebelum mencatat SKU.', v_nama;
    end if;
    if new.peserta_id = auth.uid() then
      raise exception 'Isi agama Anda lebih dulu di menu Akun saya (Data diri) sebelum mengajukan SKU.';
    end if;
    raise exception '% belum mengisi agama. Penegak melengkapinya di menu Akun saya (Data diri), atau Admin Gudep mengisinya di menu Anggota.', v_nama;
  end if;
  return new;
end $$;
create trigger tak_aktif_sku_progress before insert or update on public.sku_progress for each row execute function sigarda.tolak_peserta_tak_aktif();
create trigger tak_aktif_sku_riwayat before insert or update on public.sku_riwayat for each row execute function sigarda.tolak_peserta_tak_aktif();
create trigger tak_aktif_absensi_hadir before insert or update on public.absensi_hadir for each row execute function sigarda.tolak_peserta_tak_aktif();
create trigger tak_aktif_iuran before insert or update on public.iuran for each row execute function sigarda.tolak_peserta_tak_aktif();
create trigger tak_aktif_iuran_log before insert or update on public.iuran_log for each row execute function sigarda.tolak_peserta_tak_aktif();
create trigger tak_aktif_asisten_iuran before insert or update on public.asisten_iuran for each row execute function sigarda.tolak_peserta_tak_aktif();
create trigger tak_aktif_portofolio before insert or update on public.portofolio for each row execute function sigarda.tolak_peserta_tak_aktif();
create trigger tak_aktif_portofolio_jurnal before insert or update on public.portofolio_jurnal for each row execute function sigarda.tolak_peserta_tak_aktif();
create trigger tak_aktif_sku_penilaian before insert or update on public.sku_penilaian for each row execute function sigarda.tolak_peserta_tak_aktif();
create trigger tak_aktif_raport before insert or update on public.raport for each row execute function sigarda.tolak_peserta_tak_aktif();
create trigger tak_aktif_sku_pra_uji before insert or update on public.sku_pra_uji for each row execute function sigarda.tolak_peserta_tak_aktif();
create trigger tak_aktif_sesi_peserta before insert or update on public.sesi_ujian_peserta for each row execute function sigarda.tolak_peserta_tak_aktif();
-- ===== Pelantikan dan Saka (Tahap 2, G1): pemicu =====
create trigger tak_aktif_pelantikan before insert or update on public.pelantikan for each row execute function sigarda.tolak_peserta_tak_aktif();
create trigger tak_aktif_saka_anggota before insert or update on public.saka_anggota for each row execute function sigarda.tolak_peserta_tak_aktif();
-- ===== akhir pemicu pelantikan dan saka =====
-- ===== TKK (Tahap 2, G2): pemicu =====
create trigger tak_aktif_tkk_capaian before insert or update on public.tkk_capaian for each row execute function sigarda.tolak_peserta_tak_aktif();
create trigger tak_aktif_siaga_garuda before insert or update on public.siaga_garuda for each row execute function sigarda.tolak_peserta_tak_aktif();
create trigger tak_aktif_tkk_siaga before insert or update on public.tkk_siaga for each row execute function sigarda.tolak_peserta_tak_aktif();
create trigger tak_aktif_tkk_krida before insert or update on public.tkk_krida for each row execute function sigarda.tolak_peserta_tak_aktif();
-- ===== akhir pemicu tkk =====
-- ===== TKK pengajuan (Tahap 2, G2b): pemicu tak aktif =====
create trigger tak_aktif_tkk_pengajuan before insert or update on public.tkk_pengajuan for each row execute function sigarda.tolak_peserta_tak_aktif();
-- ===== akhir pemicu tak aktif tkk pengajuan =====
-- ===== SPG (Tahap 2, G3): pemicu =====
create trigger tak_aktif_spg_penetapan before insert or update on public.spg_penetapan for each row execute function sigarda.tolak_peserta_tak_aktif();
-- ===== akhir pemicu spg =====
-- ===== Gerbang calon Garuda (Tahap 2, G4): pemicu =====
create trigger tak_aktif_tanggal_lahir before insert or update on public.tanggal_lahir for each row execute function sigarda.tolak_peserta_tak_aktif();
-- ===== akhir pemicu gerbang =====
-- ===== Isian Penegak (Tahap 3, H1): pemicu =====
create trigger tak_aktif_penegak_isian before insert or update on public.penegak_isian for each row execute function sigarda.tolak_peserta_tak_aktif();
create trigger tak_aktif_tabungan_cek before insert or update on public.tabungan_cek for each row execute function sigarda.tolak_peserta_tak_aktif();
-- ===== akhir pemicu isian penegak =====

-- Status Calon Garuda hanya untuk Penegak yang aktif (diberikan sendiri lewat sg_calon_garuda_daftar atau oleh Admin lewat sg_anggota_ubah).
create function sigarda.tolak_calon_garuda_tak_aktif() returns trigger language plpgsql as
$$
begin
  if new.calon_garuda is not null and new.calon_garuda is distinct from old.calon_garuda and new.status <> 'aktif' then
    raise exception 'Status Calon Garuda hanya dapat diberikan kepada Penegak yang aktif.';
  end if;
  return new;
end $$;
create trigger tak_aktif_calon_garuda before update of calon_garuda on public.profiles for each row execute function sigarda.tolak_calon_garuda_tak_aktif();

-- Tingkat kelas dari rombel baku: X = 1, XI = 2, XII = 3 (kosong bila bukan rombel baku). Dicerminkan src/lib/naikKelasLogic.js.
create function sigarda.tingkat_rombel(p_rombel text) returns int language sql immutable as
$$ select case when sigarda.rombel_sah(p_rombel) then array_position(array['X', 'XI', 'XII'], split_part(p_rombel, '-', 1)) end $$;

-- Membatalkan pengajuan dan pengujian yang masih berjalan milik satu Penegak (mengeluarkannya dari sesi ujian yang belum selesai dan mencabut
-- penunjukannya sebagai asisten bendahara), sebelum ia dinonaktifkan atau menjadi alumni. Mengembalikan jumlah pengajuan yang dibatalkan.
-- Dipanggil SEBELUM status diubah.
create function sigarda.batalkan_pengajuan_berjalan(p_peserta uuid, p_alasan text) returns int
language plpgsql security definer set search_path = public as
$$
declare v_n int := 0; v_sku text;
begin
  for v_sku in select sku_id from public.sku_progress where peserta_id = p_peserta and status in ('diajukan', 'proses') loop
    update public.sku_progress
      set status = 'belum', penguji_id = null, tanggal_uji = null, jadwal = null, nilai = null, catatan = '', catatan_peserta = '',
          verifikasi = null, diverifikasi_pada = null, verifikasi_token = null, diubah = now()
      where peserta_id = p_peserta and sku_id = v_sku;
    insert into public.sku_riwayat (peserta_id, sku_id, teks, oleh) values (p_peserta, v_sku, p_alasan, auth.uid());
    v_n := v_n + 1;
  end loop;
  for v_sku in select sku_id from public.sku_pra_uji where peserta_id = p_peserta and status = 'menunggu' loop
    update public.sku_pra_uji set status = 'dibatalkan', diputuskan_pada = now() where peserta_id = p_peserta and sku_id = v_sku and status = 'menunggu';
    insert into public.sku_riwayat (peserta_id, sku_id, teks, oleh) values (p_peserta, v_sku, p_alasan, auth.uid());
    v_n := v_n + 1;
  end loop;
  delete from public.sesi_ujian_peserta sp using public.sesi_ujian s
    where s.id = sp.sesi_id and sp.peserta_id = p_peserta and s.status <> 'selesai';
  delete from public.asisten_iuran where peserta_id = p_peserta;
  return v_n;
end $$;

-- Kenaikan kelas massal (Admin Gudep). p_tahun_ajaran = tahun ajaran yang BARU dimulai (mis. 2027/2028). p_data = [{"username": "10231", "rombel": "XI-04",
-- "aksi": "lanjut"}, ...] (username = NIS). aksi: 'lanjut' (aktif di rombel baru), 'tidak_lanjut' (nonaktif; rombel baru boleh kosong = rombel terakhir tetap),
-- 'lulus' (alumni; lulus pada tahun ajaran sebelum p_tahun_ajaran). Baris tanpa aksi dilewati oleh klien.
-- p_terapkan = false: PRATINJAU (tidak mengubah apa pun). true: menerapkan SEMUA atau tidak sama sekali (satu baris keliru membatalkan semuanya) dan membuat
-- batch yang dapat dibatalkan (sg_naik_kelas_batalkan). Hasil: { galat, ringkasan, baris: [{ no, id, username, nama, aksi, dari_kelas, dari_status, ke_kelas,
-- ke_status, hasil: 'ubah' | 'sama' | 'galat', pesan: [...] }], batch }. Penegak yang menjadi nonaktif atau alumni kehilangan pengajuan uji yang masih berjalan.
create function public.sg_naik_kelas(p_tahun_ajaran text, p_data jsonb, p_terapkan boolean default false) returns jsonb
language plpgsql security definer set search_path = public as
$$
declare
  v_e jsonb; v_no int := 0; v_user text; v_aksi text; v_rombel text; v_t public.profiles; v_ke_kelas text; v_ke_status text;
  v_hasil text; v_pesan text[]; v_baris jsonb := '[]'::jsonb; v_pakai text[] := '{}'; v_galat int := 0;
  v_lanjut int := 0; v_tidak int := 0; v_lulus int := 0; v_sama int := 0; v_berjalan int; v_berjalan_total int := 0; v_batal int := 0;
  v_ringkas jsonb; v_batch bigint; v_oleh text; v_lulus_ta text; v_tk_lama int; v_tk_baru int; v_id uuid; v_teks text;
begin
  perform sigarda.wajib_admin('Hanya Admin Gudep yang dapat menaikkan kelas.');
  if not sigarda.tahun_ajaran_sah(p_tahun_ajaran) then raise exception 'Tahun ajaran tidak sah. Contoh: 2027/2028.'; end if;
  if p_data is null or jsonb_typeof(p_data) <> 'array' then raise exception 'Data naik kelas tidak valid.'; end if;
  if jsonb_array_length(p_data) > 1500 then raise exception 'Maksimal 1500 baris per permintaan.'; end if;
  v_lulus_ta := (split_part(p_tahun_ajaran, '/', 1)::int - 1) || '/' || split_part(p_tahun_ajaran, '/', 1);

  for v_e in select * from jsonb_array_elements(p_data) loop
    v_no := v_no + 1;
    v_user := lower(btrim(coalesce(v_e ->> 'username', '')));
    v_aksi := lower(btrim(coalesce(v_e ->> 'aksi', '')));
    v_rombel := nullif(sigarda.rombel_baku(v_e ->> 'rombel'), '');
    v_pesan := '{}'; v_hasil := 'ubah'; v_ke_kelas := null; v_ke_status := null; v_berjalan := 0;
    select * into v_t from public.profiles where username = v_user and role = 'peserta';
    if not found then
      v_hasil := 'galat'; v_pesan := array['Penegak dengan NIS "' || v_user || '" tidak ditemukan.'];
    elsif v_user = any (v_pakai) then
      v_hasil := 'galat'; v_pesan := array['NIS ' || v_user || ' muncul lebih dari sekali dalam berkas.'];
    elsif v_aksi not in ('lanjut', 'tidak_lanjut', 'lulus') then
      v_hasil := 'galat'; v_pesan := array['Aksi "' || v_aksi || '" tidak dikenal. Gunakan Lanjut, Tidak lanjut, atau Lulus.'];
    elsif v_t.status = 'alumni' then
      v_hasil := 'galat'; v_pesan := array['Sudah alumni. Aktifkan kembali lebih dulu di menu Anggota bila perlu.'];
    elsif v_aksi = 'lanjut' and not sigarda.rombel_sah(v_rombel) then
      v_hasil := 'galat'; v_pesan := array['Rombel baru wajib diisi dengan benar (X-01 sampai X-10, XI-01 sampai XI-10, XII-01 sampai XII-10).'];
    elsif v_aksi = 'tidak_lanjut' and v_rombel is not null and not sigarda.rombel_sah(v_rombel) then
      v_hasil := 'galat'; v_pesan := array['Rombel baru "' || v_rombel || '" tidak sah.'];
    end if;
    if v_user <> '' then v_pakai := v_pakai || v_user; end if;

    if v_hasil = 'ubah' then
      if v_aksi = 'lanjut' then v_ke_kelas := v_rombel; v_ke_status := 'aktif';
      elsif v_aksi = 'tidak_lanjut' then v_ke_kelas := coalesce(v_rombel, v_t.kelas); v_ke_status := 'nonaktif';
      else v_ke_kelas := v_t.kelas; v_ke_status := 'alumni'; end if;
      if v_ke_kelas is not distinct from v_t.kelas and v_ke_status = v_t.status then
        v_hasil := 'sama'; v_sama := v_sama + 1;
      else
        v_tk_lama := sigarda.tingkat_rombel(v_t.kelas); v_tk_baru := sigarda.tingkat_rombel(v_ke_kelas);
        if v_aksi <> 'lulus' and v_ke_kelas is distinct from v_t.kelas and v_tk_lama is not null and v_tk_baru is not null then
          if v_tk_baru = v_tk_lama then v_pesan := v_pesan || ('Tingkat tidak naik (' || v_t.kelas || ' ke ' || v_ke_kelas || ').');
          elsif v_tk_baru < v_tk_lama then v_pesan := v_pesan || ('Tingkat turun (' || v_t.kelas || ' ke ' || v_ke_kelas || ').');
          elsif v_tk_baru > v_tk_lama + 1 then v_pesan := v_pesan || ('Tingkat melompat (' || v_t.kelas || ' ke ' || v_ke_kelas || ').'); end if;
        end if;
        if v_aksi = 'lulus' and coalesce(v_tk_lama, 0) <> 3 then v_pesan := v_pesan || ('Bukan kelas XII (kelas ' || coalesce(v_t.kelas, '-') || ').'); end if;
        if v_ke_status <> 'aktif' then
          select count(*)::int into v_berjalan from public.sku_progress where peserta_id = v_t.id and status in ('diajukan', 'proses');
          if v_berjalan > 0 then v_pesan := v_pesan || (v_berjalan || ' pengajuan uji yang masih berjalan akan dibatalkan.'); end if;
          if v_t.calon_garuda is not null then v_pesan := array_append(v_pesan, 'Calon Garuda: pastikan portofolio dan penilaian Garuda sudah selesai; sesudah ini hanya dapat dilihat.'); end if;
          if v_t.jabatan_dewan is not null then v_pesan := array_append(v_pesan, 'Jabatan Dewan Ambalan (' || v_t.jabatan_dewan || ') akan dicabut.'); end if;
        end if;
        v_berjalan_total := v_berjalan_total + v_berjalan;
        if v_aksi = 'lanjut' then v_lanjut := v_lanjut + 1; elsif v_aksi = 'tidak_lanjut' then v_tidak := v_tidak + 1; else v_lulus := v_lulus + 1; end if;
      end if;
    else
      v_galat := v_galat + 1;
    end if;

    v_baris := v_baris || jsonb_build_array(jsonb_build_object(
      'no', v_no, 'id', v_t.id, 'username', v_user, 'nama', coalesce(v_t.nama, ''), 'aksi', v_aksi, 'dari_kelas', v_t.kelas, 'dari_status', v_t.status,
      'ke_kelas', v_ke_kelas, 'ke_status', v_ke_status, 'hasil', v_hasil, 'pesan', to_jsonb(v_pesan)));
  end loop;

  v_ringkas := jsonb_build_object('lanjut', v_lanjut, 'tidak_lanjut', v_tidak, 'lulus', v_lulus, 'sama', v_sama, 'galat', v_galat, 'pengajuan_batal', v_berjalan_total);

  if p_terapkan then
    if v_galat > 0 then raise exception 'Ada % baris bermasalah, jadi tidak ada yang diubah. Periksa pratinjau, perbaiki berkas, lalu coba lagi.', v_galat; end if;
    if v_lanjut + v_tidak + v_lulus = 0 then raise exception 'Tidak ada perubahan yang perlu diterapkan.'; end if;
    select nama into v_oleh from public.profiles where id = auth.uid();
    insert into public.naik_kelas_batch (tahun_ajaran, ringkasan, oleh, oleh_nama)
    values (p_tahun_ajaran, v_ringkas, auth.uid(), coalesce(v_oleh, '')) returning id into v_batch;
    for v_e in select * from jsonb_array_elements(v_baris) loop
      if v_e ->> 'hasil' <> 'ubah' then continue; end if;
      v_id := (v_e ->> 'id')::uuid;
      v_ke_status := v_e ->> 'ke_status';
      if v_ke_status <> 'aktif' then
        v_teks := case when v_ke_status = 'alumni' then 'Pengajuan dibatalkan: Penegak menjadi alumni' else 'Pengajuan dibatalkan: Penegak tidak melanjutkan Pramuka' end;
        v_batal := v_batal + sigarda.batalkan_pengajuan_berjalan(v_id, v_teks);
        perform sigarda.jabatan_dewan_lepas(v_id, case when v_ke_status = 'alumni' then 'Penegak menjadi alumni' else 'Penegak tidak melanjutkan Pramuka' end);
      end if;
      select * into v_t from public.profiles where id = v_id;
      insert into public.naik_kelas_log (batch_id, peserta_id, peserta_nama, nis, aksi, dari_kelas, ke_kelas, dari_status, ke_status, dari_status_pada, dari_lulus_ta, catatan, oleh, oleh_nama)
      values (v_batch, v_id, v_t.nama, coalesce(v_t.nis, v_t.username), v_e ->> 'aksi', v_t.kelas, v_e ->> 'ke_kelas', v_t.status, v_ke_status, v_t.status_pada, v_t.lulus_ta,
              left('Tahun ajaran ' || p_tahun_ajaran, 200), auth.uid(), coalesce(v_oleh, ''));
      update public.profiles
        set kelas = v_e ->> 'ke_kelas', status = v_ke_status, status_pada = sigarda.hari_ini(),
            lulus_ta = case when v_ke_status = 'alumni' then v_lulus_ta else null end
        where id = v_id;
    end loop;
  end if;

  return jsonb_build_object('galat', v_galat, 'ringkasan', v_ringkas, 'baris', v_baris, 'batch', v_batch);
end $$;

-- Membatalkan satu kenaikan kelas massal (Admin Gudep): mengembalikan kelas, status, dan tahun kelulusan semua Penegak di batch itu. Hanya kenaikan TERAKHIR
-- yang belum dibatalkan, dan hanya bila tak seorang pun dari mereka diubah lagi sesudahnya. Pengajuan uji yang sudah dibatalkan saat kenaikan TIDAK dikembalikan.
create function public.sg_naik_kelas_batalkan(p_batch bigint) returns int
language plpgsql security definer set search_path = public as
$$
declare v_b public.naik_kelas_batch; v_l record; v_n int := 0; v_beda int;
begin
  perform sigarda.wajib_admin('Hanya Admin Gudep yang dapat membatalkan kenaikan kelas.');
  select * into v_b from public.naik_kelas_batch where id = p_batch;
  if not found then raise exception 'Kenaikan kelas tidak ditemukan.'; end if;
  if v_b.dibatalkan_pada is not null then raise exception 'Kenaikan kelas ini sudah dibatalkan.'; end if;
  if exists (select 1 from public.naik_kelas_batch where id > p_batch and dibatalkan_pada is null) then
    raise exception 'Hanya kenaikan kelas yang paling akhir yang dapat dibatalkan. Batalkan yang lebih baru lebih dulu.';
  end if;
  select count(*)::int into v_beda from public.naik_kelas_log l join public.profiles p on p.id = l.peserta_id
    where l.batch_id = p_batch and (p.kelas is distinct from l.ke_kelas or p.status <> l.ke_status);
  if v_beda > 0 then
    raise exception '% Penegak sudah diubah lagi sesudah kenaikan ini, jadi kenaikan ini tidak dapat dibatalkan seluruhnya. Ubah mereka satu per satu di menu Anggota.', v_beda;
  end if;
  for v_l in select * from public.naik_kelas_log where batch_id = p_batch and peserta_id is not null loop
    update public.profiles set kelas = v_l.dari_kelas, status = v_l.dari_status, status_pada = v_l.dari_status_pada, lulus_ta = v_l.dari_lulus_ta where id = v_l.peserta_id;
    v_n := v_n + 1;
  end loop;
  update public.naik_kelas_batch set dibatalkan_pada = now(), dibatalkan_oleh = auth.uid() where id = p_batch;
  return v_n;
end $$;

-- Mengubah status SATU Penegak (Pembina atau Admin Gudep; menjadikan alumni hanya Admin). p_status 'aktif' (aktifkan kembali; p_rombel wajib), 'nonaktif', atau 'alumni'.
-- Tercatat di naik_kelas_log. Penegak yang menjadi nonaktif atau alumni kehilangan pengajuan uji yang masih berjalan.
create function public.sg_anggota_status_atur(p_id uuid, p_status text, p_rombel text default null, p_catatan text default '') returns void
language plpgsql security definer set search_path = public as
$$
declare v_t public.profiles; v_rombel text := sigarda.rombel_baku(p_rombel); v_cat text := sigarda.rapikan(p_catatan); v_oleh text; v_aksi text; v_kelas text; v_teks text;
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pembina_atau_admin() then raise exception 'Hanya Pembina dan Admin Gudep yang dapat mengubah status anggota.'; end if;
  if coalesce(p_status, '') not in ('aktif', 'nonaktif', 'alumni') then raise exception 'Status tidak dikenal.'; end if;
  if p_status = 'alumni' and sigarda.peran() <> 'admin' then raise exception 'Hanya Admin Gudep yang dapat menetapkan alumni.'; end if;
  if char_length(v_cat) > 200 then raise exception 'Catatan maksimal 200 karakter.'; end if;
  select * into v_t from public.profiles where id = p_id and role = 'peserta';
  if not found then raise exception 'Penegak tidak ditemukan.'; end if;
  if v_t.status = p_status then raise exception 'Penegak ini sudah berstatus %.', p_status; end if;
  if p_status = 'nonaktif' and v_t.status = 'alumni' then raise exception 'Alumni tidak dapat dinonaktifkan. Aktifkan kembali lebih dulu bila perlu.'; end if;
  v_kelas := v_t.kelas;
  if p_status = 'aktif' then
    if not sigarda.rombel_sah(v_rombel) then raise exception 'Rombel wajib diisi dengan benar (X-01 sampai X-10, XI-01 sampai XI-10, XII-01 sampai XII-10).'; end if;
    v_kelas := v_rombel; v_aksi := 'aktifkan';
  else
    if p_status = 'alumni' then v_aksi := 'lulus'; else v_aksi := 'nonaktifkan'; end if;
    v_teks := case when p_status = 'alumni' then 'Pengajuan dibatalkan: Penegak menjadi alumni' else 'Pengajuan dibatalkan: Penegak tidak melanjutkan Pramuka' end;
    perform sigarda.batalkan_pengajuan_berjalan(p_id, v_teks);
    perform sigarda.jabatan_dewan_lepas(p_id, case when p_status = 'alumni' then 'Penegak menjadi alumni' else 'Penegak tidak melanjutkan Pramuka' end);
  end if;
  select nama into v_oleh from public.profiles where id = auth.uid();
  insert into public.naik_kelas_log (batch_id, peserta_id, peserta_nama, nis, aksi, dari_kelas, ke_kelas, dari_status, ke_status, dari_status_pada, dari_lulus_ta, catatan, oleh, oleh_nama)
  values (null, p_id, v_t.nama, coalesce(v_t.nis, v_t.username), v_aksi, v_t.kelas, v_kelas, v_t.status, p_status, v_t.status_pada, v_t.lulus_ta, v_cat, auth.uid(), coalesce(v_oleh, ''));
  update public.profiles
    set kelas = v_kelas, status = p_status, status_pada = sigarda.hari_ini(),
        lulus_ta = case when p_status = 'alumni' then sigarda.tahun_ajaran_kini() else null end
    where id = p_id;
end $$;
-- ===== akhir fungsi naik kelas =====

-- ===== Data anggota (Admin Gudep). Pembuatan dan penghapusan akun lewat Edge Function. =====
create function public.sg_anggota_ubah(
  p_id uuid, p_nama text, p_kelas text default null, p_sangga text default null,
  p_agama text default null, p_calon_garuda boolean default null
) returns void language plpgsql security definer set search_path = public as
$$
declare v_t public.profiles; v_nama text := sigarda.rapikan(p_nama); v_kelas text; v_sangga text;
begin
  perform sigarda.wajib_aktif();
  if coalesce((select role from public.profiles where id = auth.uid()), '') <> 'admin' then
    raise exception 'Hanya Admin Gudep yang dapat mengubah data anggota.';
  end if;
  select * into v_t from public.profiles where id = p_id;
  if not found then raise exception 'Anggota tidak ditemukan.'; end if;
  if v_nama = '' then raise exception 'Nama wajib diisi.'; end if;
  if char_length(v_nama) > 120 then raise exception 'Nama maksimal 120 karakter.'; end if;

  if v_t.role <> 'peserta' then
    update public.profiles set nama = v_nama where id = p_id;
    -- Agama Pembina (butir agama hanya boleh diuji Pembina yang seagama): null = tidak diubah, '' = dikosongkan. Dewan dan Admin tidak berAgama.
    if v_t.role = 'penguji' and v_t.jabatan = 'Pembina' and p_agama is not null then
      if p_agama <> '' and p_agama not in ('Islam','Katolik','Protestan','Hindu','Buddha','Khonghucu') then raise exception 'Agama tidak dikenal.'; end if;
      update public.profiles set agama = nullif(p_agama, '') where id = p_id;
    end if;
    return;
  end if;

  v_kelas := sigarda.rapikan(p_kelas);
  v_sangga := sigarda.rapikan(p_sangga);
  -- Hanya rombel yang wajib. Sangga boleh kosong (dibagi Pembina/Bina Damping). Agama: kosong = tidak diubah (Penegak mengisinya sendiri; agama yang sudah ada tidak dapat dikosongkan).
  if v_kelas = '' then raise exception 'Kelas (rombel) peserta wajib diisi.'; end if;
  if coalesce(p_agama, '') <> '' and p_agama not in ('Islam','Katolik','Protestan','Hindu','Buddha','Khonghucu') then raise exception 'Agama tidak dikenal.'; end if;
  -- Kelas berupa rombel baku (X-01..XII-10). Nilai lama yang tidak diubah (mis. "X") dibiarkan agar data lain tetap dapat diubah;
  -- rapikan massal lewat sg_rombel_perbarui.
  if lower(v_kelas) = lower(coalesce(v_t.kelas, '')) then
    v_kelas := v_t.kelas;
  else
    v_kelas := sigarda.rombel_baku(v_kelas);
    if not sigarda.rombel_sah(v_kelas) then raise exception 'Kelas harus berupa rombel: X-01 sampai X-10, XI-01 sampai XI-10, atau XII-01 sampai XII-10.'; end if;
  end if;
  if v_sangga <> '' then v_sangga := coalesce((select sangga from public.profiles where role = 'peserta' and lower(sangga) = lower(v_sangga) limit 1), v_sangga); end if;

  update public.profiles set nama = v_nama, kelas = v_kelas, sangga = nullif(v_sangga, ''), agama = coalesce(nullif(p_agama, ''), agama) where id = p_id;

  if p_calon_garuda is true then
    if v_t.calon_garuda is null then
      if sigarda.layak_garuda(p_id) then
        update public.profiles set calon_garuda = sigarda.hari_ini() where id = p_id;
      else
        raise exception 'Status Calon Garuda hanya untuk peserta yang seluruh SKU Bantara dan Laksana-nya lulus.';
      end if;
    end if;
  elsif p_calon_garuda is false then
    update public.profiles set calon_garuda = null where id = p_id;
  end if;
end $$;

-- Agama Pembina, oleh Admin Gudep. p_data = [{"username": "budi.santoso", "agama": "Islam"}, ...]; agama kosong menghapus. Hanya untuk Pembina
-- (Dewan Ambalan dan Admin tidak berAgama). Dipakai import Excel Pembina (agama diisi sesudah akun dibuat). Mengembalikan jumlah Pembina yang diperbarui.
create function public.sg_anggota_agama_atur(p_data jsonb) returns int
language plpgsql security definer set search_path = public as
$$
declare v_e jsonb; v_user text; v_agama text; v_n int := 0; v_k int;
begin
  perform sigarda.wajib_admin('Hanya Admin Gudep yang dapat mengubah agama Pembina.');
  if p_data is null or jsonb_typeof(p_data) <> 'array' then raise exception 'Data agama tidak valid.'; end if;
  if jsonb_array_length(p_data) > 500 then raise exception 'Maksimal 500 baris agama per permintaan.'; end if;
  for v_e in select * from jsonb_array_elements(p_data) loop
    v_user := lower(btrim(coalesce(v_e ->> 'username', '')));
    v_agama := sigarda.rapikan(coalesce(v_e ->> 'agama', ''));
    if v_user = '' then raise exception 'Nama pengguna Pembina wajib diisi.'; end if;
    if v_agama <> '' and v_agama not in ('Islam','Katolik','Protestan','Hindu','Buddha','Khonghucu') then raise exception 'Agama "%" tidak dikenal.', v_agama; end if;
    update public.profiles set agama = nullif(v_agama, '') where username = v_user and role = 'penguji' and jabatan = 'Pembina';
    get diagnostics v_k = row_count;
    v_n := v_n + v_k;
  end loop;
  return v_n;
end $$;

-- NTA (Nomor Tanda Anggota) anggota, oleh Admin Gudep. p_data = [{"username": "10231", "nta": "11.03.10.701.00123"}, ...]; nta kosong menghapus NTA.
-- Dipakai formulir ubah anggota dan import Excel (NTA diisi sesudah akun dibuat). Mengembalikan jumlah anggota yang ditemukan dan diperbarui.
create function public.sg_anggota_nta_atur(p_data jsonb) returns int
language plpgsql security definer set search_path = public as
$$
declare v_e jsonb; v_user text; v_nta text; v_n int := 0; v_k int;
begin
  perform sigarda.wajib_aktif();
  if coalesce((select role from public.profiles where id = auth.uid()), '') <> 'admin' then
    raise exception 'Hanya Admin Gudep yang dapat mengubah NTA anggota.';
  end if;
  if p_data is null or jsonb_typeof(p_data) <> 'array' then raise exception 'Data NTA tidak valid.'; end if;
  if jsonb_array_length(p_data) > 500 then raise exception 'Maksimal 500 baris NTA per permintaan.'; end if;
  for v_e in select * from jsonb_array_elements(p_data) loop
    v_user := lower(btrim(coalesce(v_e ->> 'username', '')));
    v_nta := sigarda.rapikan(coalesce(v_e ->> 'nta', ''));
    if v_user = '' then raise exception 'Nama pengguna anggota wajib diisi.'; end if;
    if v_nta <> '' and v_nta !~ '^[0-9A-Za-z./ -]{1,40}$' then
      raise exception 'NTA "%" tidak valid: maksimal 40 karakter (huruf, angka, titik, garis miring, strip, spasi).', v_nta;
    end if;
    update public.profiles set nta = nullif(v_nta, '') where username = v_user;
    get diagnostics v_k = row_count;
    v_n := v_n + v_k;
  end loop;
  return v_n;
end $$;

-- ===== Jenis kelamin: fungsi =====
-- Jenis kelamin anggota (semua peran), oleh Admin Gudep. p_data = [{"username": "10231", "jk": "L"}, ...]; jk 'L' (laki-laki) atau 'P' (perempuan); jk kosong
-- menghapus. Dipakai formulir tambah dan ubah anggota, import Excel (diisi sesudah akun dibuat; Edge Function tidak membawanya), dan "Lengkapi jenis kelamin"
-- untuk anggota lama. Semua atau tidak sama sekali. Mengembalikan jumlah anggota yang ditemukan dan diperbarui.
create function public.sg_anggota_jk_atur(p_data jsonb) returns int
language plpgsql security definer set search_path = public as
$$
declare v_e jsonb; v_user text; v_jk text; v_n int := 0; v_k int;
begin
  perform sigarda.wajib_admin('Hanya Admin Gudep yang dapat mengubah jenis kelamin anggota.');
  if p_data is null or jsonb_typeof(p_data) <> 'array' then raise exception 'Data jenis kelamin tidak valid.'; end if;
  if jsonb_array_length(p_data) > 500 then raise exception 'Maksimal 500 baris jenis kelamin per permintaan.'; end if;
  for v_e in select * from jsonb_array_elements(p_data) loop
    v_user := lower(btrim(coalesce(v_e ->> 'username', '')));
    v_jk := upper(btrim(coalesce(v_e ->> 'jk', '')));
    if v_user = '' then raise exception 'Nama pengguna anggota wajib diisi.'; end if;
    if v_jk not in ('', 'L', 'P') then raise exception 'Jenis kelamin "%" tidak dikenal (pilih L atau P).', v_e ->> 'jk'; end if;
    update public.profiles set jenis_kelamin = nullif(v_jk, '') where username = v_user;
    get diagnostics v_k = row_count;
    v_n := v_n + v_k;
  end loop;
  return v_n;
end $$;
-- ===== akhir fungsi jenis kelamin =====

-- ===== Jabatan Dewan Ambalan: fungsi =====
-- Jabatan Dewan Ambalan pada akun PENEGAK (isian bebas, mis. Pradana, Pradani, Pemangku Adat, Wakil Pradana, Sekretaris, Bendahara, Ketua Bidang Kegiatan), oleh Pembina atau Admin Gudep.
-- p_data = [{"username": "10231", "jabatan": "Pradana"}, ...] (username = NIS Penegak); jabatan kosong mencabut jabatan (penugasan penguji ikut dihapus). Jabatan hanya untuk
-- Penegak yang AKTIF. Pradana, Pradani, dan Pemangku Adat masing-masing hanya satu pemegang (sigarda.jabatan_tunggal): pemegang lama harus dikosongkan lebih dulu (boleh pada permintaan yang sama,
-- mis. [{"username": "lama", "jabatan": ""}, {"username": "baru", "jabatan": "Pradana"}]). Semua atau tidak sama sekali. Pemangku Adat menjadi ketua sidang (cadangannya Pradana); Pradana dan Pradani
-- menandatangani Surat Tanda Lulus. Dewan Ambalan berupa atribut akun Penegak (bukan akun terpisah): pemegang jabatan dapat memakai tampilan Dewan.
-- Tercatat di kepengurusan_log. Mengembalikan jumlah anggota yang berubah.
create function public.sg_anggota_jabatan_dewan_atur(p_data jsonb) returns int
language plpgsql security definer set search_path = public as
$$
declare v_e jsonb; v_user text; v_jab text; v_n int := 0; v_lain text; v_t public.profiles; v_oleh text;
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pembina_atau_admin() then raise exception 'Hanya Pembina dan Admin Gudep yang dapat mengubah jabatan Dewan Ambalan.'; end if;
  if p_data is null or jsonb_typeof(p_data) <> 'array' then raise exception 'Data jabatan tidak valid.'; end if;
  if jsonb_array_length(p_data) > 100 then raise exception 'Maksimal 100 baris jabatan per permintaan.'; end if;
  select nama into v_oleh from public.profiles where id = auth.uid();
  for v_e in select * from jsonb_array_elements(p_data) loop
    v_user := lower(btrim(coalesce(v_e ->> 'username', '')));
    v_jab := sigarda.jabatan_baku(coalesce(v_e ->> 'jabatan', ''));
    if v_user = '' then raise exception 'NIS Penegak wajib diisi.'; end if;
    if v_jab <> '' and (char_length(v_jab) not between 2 and 60 or v_jab ~ '[[:cntrl:]<>]') then
      raise exception 'Jabatan Dewan Ambalan harus 2 sampai 60 karakter tanpa tanda < atau >.';
    end if;
    select * into v_t from public.profiles where username = v_user;
    if not found then raise exception 'Anggota "%" tidak ditemukan.', v_user; end if;
    if v_jab = '' then
      if v_t.jabatan_dewan is not null then
        perform sigarda.jabatan_dewan_lepas(v_t.id, 'Jabatan dicabut oleh ' || coalesce(v_oleh, 'pengelola'));
        v_n := v_n + 1;
      end if;
      continue;
    end if;
    if v_t.role <> 'peserta' then raise exception '% bukan Penegak. Jabatan Dewan Ambalan hanya untuk Penegak.', v_t.nama; end if;
    if v_t.status <> 'aktif' then raise exception '% berstatus % dan tidak dapat menjabat. Aktifkan kembali lebih dulu.', v_t.nama, v_t.status; end if;
    if sigarda.jabatan_tunggal(v_jab) then
      select nama into v_lain from public.profiles where jabatan_dewan = v_jab and id <> v_t.id limit 1;
      if found then raise exception '% sudah dijabat oleh %. Kosongkan jabatan itu lebih dulu.', v_jab, v_lain; end if;
    end if;
    if v_t.jabatan_dewan is not distinct from v_jab then continue; end if;
    update public.profiles set jabatan_dewan = v_jab where id = v_t.id;
    insert into public.kepengurusan_log (peserta_id, peserta_nama, nis, tindakan, jabatan_lama, jabatan_baru, alasan, oleh, oleh_nama)
    values (v_t.id, v_t.nama, coalesce(v_t.nis, v_t.username), case when v_t.jabatan_dewan is null then 'beri' else 'ganti' end, v_t.jabatan_dewan, v_jab, '', auth.uid(), coalesce(v_oleh, ''));
    v_n := v_n + 1;
  end loop;
  return v_n;
end $$;

-- Kepengurusan Dewan Ambalan lewat berkas (Pembina atau Admin Gudep). p_data = [{"username": "10231", "jabatan": "Pradana"}, ...] (username = NIS; jabatan bebas).
-- p_ganti = true: SELURUH kepengurusan diganti (pemegang jabatan yang tidak ada di berkas dicabut; termasuk jabatan pada akun Dewan lama). false: hanya yang ada di berkas
-- diberi atau diubah (jabatan tunggal yang berpindah tangan, yaitu Pradana, Pradani, atau Pemangku Adat, tetap mencabut pemegang lamanya). p_terapkan = false: PRATINJAU (tidak mengubah apa pun); true: menerapkan
-- SEMUA atau tidak sama sekali. Hasil { galat, ringkasan { beri, ganti, cabut, sama, galat }, baris: [{ no, id, username, nama, kelas, dari_jabatan, jabatan, hasil:
-- 'beri' | 'ganti' | 'sama' | 'cabut' | 'galat', pesan: [...] }] }. Peringatan (bukan galat): belum menyelesaikan seluruh butir Bantara.
create function public.sg_kepengurusan_terapkan(p_data jsonb, p_ganti boolean default true, p_terapkan boolean default false) returns jsonb
language plpgsql security definer set search_path = public as
$$
declare
  v_e jsonb; v_no int := 0; v_user text; v_jab text; v_t public.profiles; v_hasil text; v_pesan text[]; v_baris jsonb := '[]'::jsonb; v_pakai text[] := '{}'; v_tunggal text[] := '{}';
  v_galat int := 0; v_beri int := 0; v_ganti int := 0; v_cabut int := 0; v_sama int := 0; v_oleh text; v_r record; v_x jsonb; v_ids uuid[] := '{}';
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pembina_atau_admin() then raise exception 'Hanya Pembina dan Admin Gudep yang dapat mengatur kepengurusan Dewan Ambalan.'; end if;
  if p_data is null or jsonb_typeof(p_data) <> 'array' then raise exception 'Data kepengurusan tidak valid.'; end if;
  if jsonb_array_length(p_data) > 200 then raise exception 'Maksimal 200 baris per permintaan.'; end if;

  for v_e in select * from jsonb_array_elements(p_data) loop
    v_no := v_no + 1;
    v_user := lower(btrim(coalesce(v_e ->> 'username', '')));
    v_jab := sigarda.jabatan_baku(coalesce(v_e ->> 'jabatan', ''));
    v_pesan := '{}'; v_hasil := 'ubah';
    select * into v_t from public.profiles where username = v_user and role = 'peserta';
    if not found then
      v_hasil := 'galat'; v_pesan := array['Penegak dengan NIS "' || v_user || '" tidak ditemukan.'];
    elsif v_user = any (v_pakai) then
      v_hasil := 'galat'; v_pesan := array['NIS ' || v_user || ' muncul lebih dari sekali dalam berkas.'];
    elsif v_t.status <> 'aktif' then
      v_hasil := 'galat'; v_pesan := array['Penegak berstatus ' || v_t.status || ' dan tidak dapat menjabat. Aktifkan kembali lebih dulu di menu Anggota.'];
    elsif v_jab = '' then
      v_hasil := 'galat'; v_pesan := array['Jabatan Dewan Ambalan kosong.'];
    elsif char_length(v_jab) not between 2 and 60 or v_jab ~ '[[:cntrl:]<>]' then
      v_hasil := 'galat'; v_pesan := array['Jabatan harus 2 sampai 60 karakter tanpa tanda < atau >.'];
    elsif sigarda.jabatan_tunggal(v_jab) and v_jab = any (v_tunggal) then
      v_hasil := 'galat'; v_pesan := array[v_jab || ' hanya boleh satu orang, tetapi muncul lebih dari sekali dalam berkas.'];
    end if;
    if v_user <> '' then v_pakai := v_pakai || v_user; end if;
    if v_hasil = 'ubah' then
      if sigarda.jabatan_tunggal(v_jab) then v_tunggal := v_tunggal || v_jab; end if;
      if v_t.jabatan_dewan is not distinct from v_jab then v_hasil := 'sama'; v_sama := v_sama + 1;
      elsif v_t.jabatan_dewan is null then v_hasil := 'beri'; v_beri := v_beri + 1;
      else v_hasil := 'ganti'; v_ganti := v_ganti + 1; v_pesan := v_pesan || ('Jabatan berubah dari ' || v_t.jabatan_dewan || '.'); end if;
      if not sigarda.tingkat_selesai(v_t.id, 'Bantara') then v_pesan := array_append(v_pesan, 'Belum menyelesaikan seluruh butir Bantara (peringatan; jabatan tetap dapat diberikan).'); end if;
    else
      v_galat := v_galat + 1;
    end if;
    v_baris := v_baris || jsonb_build_array(jsonb_build_object(
      'no', v_no, 'id', v_t.id, 'username', v_user, 'nama', coalesce(v_t.nama, ''), 'kelas', v_t.kelas, 'dari_jabatan', v_t.jabatan_dewan, 'jabatan', nullif(v_jab, ''),
      'hasil', v_hasil, 'pesan', to_jsonb(v_pesan)));
  end loop;

  -- Pemegang jabatan yang dicabut: semua yang tidak ada di berkas (p_ganti), atau pemegang jabatan tunggal (Pradana, Pradani, Pemangku Adat) yang jabatannya berpindah ke orang lain di berkas.
  for v_r in
    select p.id, p.username, p.nama, p.kelas, p.role, p.jabatan_dewan from public.profiles p
    where p.jabatan_dewan is not null and p.username <> all (v_pakai)
      and (p_ganti or (sigarda.jabatan_tunggal(p.jabatan_dewan) and p.jabatan_dewan = any (v_tunggal)))
    order by p.nama
  loop
    v_cabut := v_cabut + 1;
    v_ids := v_ids || v_r.id;
    v_baris := v_baris || jsonb_build_array(jsonb_build_object(
      'no', null, 'id', v_r.id, 'username', v_r.username, 'nama', v_r.nama, 'kelas', v_r.kelas, 'dari_jabatan', v_r.jabatan_dewan, 'jabatan', null, 'hasil', 'cabut',
      'pesan', to_jsonb(case when v_r.role = 'penguji' then array['Akun Dewan lama.'] else '{}'::text[] end)));
  end loop;

  v_x := jsonb_build_object('beri', v_beri, 'ganti', v_ganti, 'cabut', v_cabut, 'sama', v_sama, 'galat', v_galat);
  if p_terapkan then
    if v_galat > 0 then raise exception 'Ada % baris bermasalah, jadi tidak ada yang diubah. Periksa pratinjau, perbaiki berkas, lalu coba lagi.', v_galat; end if;
    if v_beri + v_ganti + v_cabut = 0 then raise exception 'Tidak ada perubahan yang perlu diterapkan.'; end if;
    select nama into v_oleh from public.profiles where id = auth.uid();
    -- mencabut lebih dulu agar jabatan tunggal berpindah tangan tanpa bentrok
    for v_r in select id from public.profiles where id = any (v_ids) loop
      perform sigarda.jabatan_dewan_lepas(v_r.id, case when p_ganti then 'Kepengurusan diganti' else 'Jabatan berpindah' end);
    end loop;
    -- yang berganti jabatan dikosongkan sebentar agar pertukaran jabatan tunggal tidak bentrok dengan indeks unik
    update public.profiles set jabatan_dewan = null
      where id in (select (x ->> 'id')::uuid from jsonb_array_elements(v_baris) x where x ->> 'hasil' = 'ganti');
    for v_e in select * from jsonb_array_elements(v_baris) loop
      if v_e ->> 'hasil' not in ('beri', 'ganti') then continue; end if;
      select * into v_t from public.profiles where id = (v_e ->> 'id')::uuid;
      update public.profiles set jabatan_dewan = v_e ->> 'jabatan' where id = v_t.id;
      insert into public.kepengurusan_log (peserta_id, peserta_nama, nis, tindakan, jabatan_lama, jabatan_baru, alasan, oleh, oleh_nama)
      values (v_t.id, v_t.nama, coalesce(v_t.nis, v_t.username), v_e ->> 'hasil', v_e ->> 'dari_jabatan', v_e ->> 'jabatan', left('Musyawarah Ambalan (berkas)', 200), auth.uid(), coalesce(v_oleh, ''));
    end loop;
  end if;
  return jsonb_build_object('galat', v_galat, 'ringkasan', v_x, 'baris', v_baris);
end $$;

-- Mengarsipkan akun Dewan Ambalan LAMA (akun penguji berjabatan Dewan Ambalan; kini Dewan adalah atribut akun Penegak), oleh Admin Gudep. Arsip = status nonaktif:
-- akun tidak lagi menjadi penguji atau pengurus, riwayat penilaian dan iuran atas nama akun itu tetap. p_aktifkan = true membatalkan arsip. Mengembalikan jumlah akun
-- yang berubah. Jabatan Dewan yang masih dipegang akun itu dicabut lebih dulu dan pengajuan uji yang menunggunya kembali ke antrian rombel.
create function public.sg_dewan_lama_arsipkan(p_ids uuid[], p_aktifkan boolean default false) returns int
language plpgsql security definer set search_path = public as
$$
declare v_id uuid; v_n int := 0; v_t public.profiles;
begin
  perform sigarda.wajib_admin('Hanya Admin Gudep yang dapat mengarsipkan akun Dewan Ambalan lama.');
  if coalesce(cardinality(p_ids), 0) = 0 then return 0; end if;
  if cardinality(p_ids) > 200 then raise exception 'Maksimal 200 akun per permintaan.'; end if;
  foreach v_id in array p_ids loop
    select * into v_t from public.profiles where id = v_id and role = 'penguji' and jabatan = 'Dewan Ambalan';
    if not found then raise exception 'Akun Dewan Ambalan lama tidak ditemukan.'; end if;
    if p_aktifkan then
      if v_t.status = 'aktif' then continue; end if;
      update public.profiles set status = 'aktif', status_pada = sigarda.hari_ini() where id = v_id;
    else
      if v_t.status <> 'aktif' then continue; end if;
      perform sigarda.jabatan_dewan_lepas(v_id, 'Akun Dewan lama diarsipkan');
      update public.sku_progress set penguji_id = null, diubah = now() where penguji_id = v_id and status = 'diajukan';
      delete from public.penugasan_rombel where penguji_id = v_id;
      delete from public.penugasan_peserta where penguji_id = v_id;
      update public.profiles set status = 'nonaktif', status_pada = sigarda.hari_ini() where id = v_id;
    end if;
    v_n := v_n + 1;
  end loop;
  return v_n;
end $$;

-- Berita acara sidang memuat QR verifikasi. Token dan kode dibuat saat berita acara pertama kali dicetak (idempoten: cetak ulang memakai yang sama).
-- Dewan Ambalan, Pembina, dan Admin Gudep. Mengembalikan { token, kode }. Token dijawab sg_verifikasi_token; kode dijawab sg_verifikasi_kode.
create function public.sg_sidang_token(p_id int) returns jsonb
language plpgsql security definer set search_path = public as
$$
declare v_s public.sidang_dk; v_token text;
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pengurus() then raise exception 'Hanya Dewan Ambalan, Pembina, atau Admin Gudep yang dapat mencetak berita acara.'; end if;
  select * into v_s from public.sidang_dk where id = p_id;
  if not found then raise exception 'Catatan sidang tidak ditemukan.'; end if;
  if v_s.token is null then
    v_token := sigarda.token_acak();
    update public.sidang_dk set token = v_token, kode = sigarda.kode_verifikasi(array[v_token, 'berita_acara_sidang', v_s.nomor_ba])
    where id = p_id and token is null;
    select * into v_s from public.sidang_dk where id = p_id;
  end if;
  return jsonb_build_object('token', v_s.token, 'kode', v_s.kode);
end $$;
-- ===== akhir fungsi jabatan dewan =====


-- ===== Pengukuhan Dewan Ambalan (Fase A): fungsi =====
-- Mencatat pengukuhan kepengurusan Dewan Ambalan oleh Ketua Kwartir Ranting untuk satu tahun ajaran (Pembina atau Admin Gudep): nomor dan tanggal SK, dan (opsional, berpasangan)
-- nomor dan tanggal rekomendasi Ketua Mabigus. Tanggal tidak boleh di masa depan (WIB) dan rekomendasi tidak boleh sesudah SK. Simpan ulang = perbarui.
-- Aturan isian dicerminkan periksaPengukuhan di src/lib/dewanLogic.js (dijaga oleh pengujian).
create function public.sg_pengukuhan_dewan_simpan(
  p_tahun_ajaran text, p_nomor_sk text, p_tanggal_sk date, p_rekomendasi_nomor text default '', p_rekomendasi_tanggal date default null, p_catatan text default ''
) returns void language plpgsql security definer set search_path = public as
$$
declare v_nomor text := sigarda.rapikan(p_nomor_sk); v_rn text := sigarda.rapikan(p_rekomendasi_nomor); v_cat text := sigarda.rapikan(p_catatan);
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pembina_atau_admin() then raise exception 'Hanya Pembina dan Admin Gudep yang dapat mencatat pengukuhan Dewan Ambalan.'; end if;
  if not sigarda.tahun_ajaran_sah(p_tahun_ajaran) then raise exception 'Tahun ajaran tidak sah. Contoh: 2026/2027.'; end if;
  if char_length(v_nomor) not between 1 and 80 or v_nomor ~ '[[:cntrl:]<>]' then raise exception 'Nomor SK pengukuhan wajib diisi (maksimal 80 karakter, tanpa tanda < atau >).'; end if;
  if p_tanggal_sk is null then raise exception 'Tanggal SK pengukuhan wajib diisi.'; end if;
  if p_tanggal_sk < date '2000-01-01' or p_tanggal_sk > sigarda.hari_ini() then raise exception 'Tanggal SK pengukuhan tidak boleh sebelum tahun 2000 atau di masa depan.'; end if;
  if char_length(v_rn) > 80 or v_rn ~ '[[:cntrl:]<>]' then raise exception 'Nomor rekomendasi maksimal 80 karakter, tanpa tanda < atau >.'; end if;
  if (v_rn = '') <> (p_rekomendasi_tanggal is null) then raise exception 'Isi nomor dan tanggal rekomendasi Ketua Mabigus sekaligus, atau kosongkan keduanya.'; end if;
  if p_rekomendasi_tanggal is not null and (p_rekomendasi_tanggal < date '2000-01-01' or p_rekomendasi_tanggal > p_tanggal_sk) then
    raise exception 'Tanggal rekomendasi tidak boleh sebelum tahun 2000 atau sesudah tanggal SK.';
  end if;
  if char_length(v_cat) > 200 then raise exception 'Catatan maksimal 200 karakter.'; end if;
  insert into public.pengukuhan_dewan (tahun_ajaran, nomor_sk, tanggal_sk, rekomendasi_nomor, rekomendasi_tanggal, catatan, diubah_oleh, diubah_pada)
  values (p_tahun_ajaran, v_nomor, p_tanggal_sk, v_rn, p_rekomendasi_tanggal, v_cat, auth.uid(), now())
  on conflict (tahun_ajaran) do update
    set nomor_sk = excluded.nomor_sk, tanggal_sk = excluded.tanggal_sk, rekomendasi_nomor = excluded.rekomendasi_nomor, rekomendasi_tanggal = excluded.rekomendasi_tanggal,
        catatan = excluded.catatan, diubah_oleh = excluded.diubah_oleh, diubah_pada = excluded.diubah_pada;
end $$;

-- Menghapus catatan pengukuhan satu tahun ajaran (Pembina atau Admin Gudep), mis. salah tahun ajaran.
create function public.sg_pengukuhan_dewan_hapus(p_tahun_ajaran text) returns void language plpgsql security definer set search_path = public as
$$
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pembina_atau_admin() then raise exception 'Hanya Pembina dan Admin Gudep yang dapat menghapus catatan pengukuhan Dewan Ambalan.'; end if;
  delete from public.pengukuhan_dewan where tahun_ajaran = p_tahun_ajaran;
  if not found then raise exception 'Belum ada catatan pengukuhan untuk tahun ajaran itu.'; end if;
end $$;
-- ===== akhir fungsi pengukuhan dewan =====
-- ===== Materi SKU (Pembina dan Admin Gudep) =====
create function public.sg_materi_simpan(
  p_id uuid, p_judul text, p_deskripsi text, p_tautan text, p_file_id text, p_resource_key text,
  p_butir text[], p_bagian jsonb
) returns uuid language plpgsql security definer set search_path = public as
$$
declare v_id uuid; v_judul text := sigarda.rapikan(p_judul); v_b jsonb; v_butir text[];
begin
  perform sigarda.wajib_aktif();
  if not sigarda.kelola_materi() then raise exception 'Hanya Pembina dan Admin Gudep yang dapat mengelola materi.'; end if;
  if v_judul = '' then raise exception 'Judul materi wajib diisi.'; end if;
  if char_length(v_judul) > 120 then raise exception 'Judul materi maksimal 120 karakter.'; end if;
  if char_length(coalesce(p_deskripsi, '')) > 400 then raise exception 'Deskripsi maksimal 400 karakter.'; end if;
  if coalesce(p_file_id, '') !~ '^[A-Za-z0-9_-]{15,120}$' then raise exception 'ID file Google Drive tidak sah.'; end if;
  if coalesce(p_tautan, '') !~ '^https?://' then raise exception 'Tautan tidak sah.'; end if;

  select coalesce(array_agg(distinct b), '{}') into v_butir from unnest(coalesce(p_butir, '{}')) b;
  if exists (select 1 from unnest(v_butir) b where b not in (select id from public.sku_butir)) then
    raise exception 'Ada kode butir SKU yang tidak dikenal.';
  end if;

  p_bagian := coalesce(p_bagian, '[]'::jsonb);
  if jsonb_typeof(p_bagian) <> 'array' or jsonb_array_length(p_bagian) > 60 then raise exception 'Daftar isi tidak sah (maksimal 60 bagian).'; end if;
  for v_b in select * from jsonb_array_elements(p_bagian) loop
    if jsonb_typeof(v_b) <> 'object' or char_length(btrim(coalesce(v_b->>'judul', ''))) not between 1 and 120 then
      raise exception 'Setiap bagian daftar isi wajib berjudul (maksimal 120 karakter).';
    end if;
    if coalesce(v_b->>'halaman', '') !~ '^(\d{1,4}(-\d{1,4})?)?$' then
      raise exception 'Halaman pada daftar isi harus berupa angka, mis. 3 atau 3-5.';
    end if;
  end loop;

  begin
    if p_id is null then
      insert into public.materi (urutan, judul, deskripsi, tautan, file_id, resource_key, butir, bagian, dibuat_oleh)
      values ((select coalesce(max(urutan), 0) + 1 from public.materi), v_judul, btrim(coalesce(p_deskripsi, '')), btrim(p_tautan),
              p_file_id, coalesce(p_resource_key, ''), v_butir, p_bagian, auth.uid())
      returning id into v_id;
    else
      update public.materi
        set judul = v_judul, deskripsi = btrim(coalesce(p_deskripsi, '')), tautan = btrim(p_tautan), file_id = p_file_id,
            resource_key = coalesce(p_resource_key, ''), butir = v_butir, bagian = p_bagian
        where id = p_id returning id into v_id;
      if v_id is null then raise exception 'Materi tidak ditemukan. Mungkin sudah dihapus.'; end if;
    end if;
  exception when unique_violation then
    raise exception 'File ini sudah dipakai pada materi lain. Hubungkan butir tambahan pada materi tersebut.';
  end;
  return v_id;
end $$;

create function public.sg_materi_hapus(p_id uuid) returns void
language plpgsql security definer set search_path = public as
$$
begin
  perform sigarda.wajib_aktif();
  if not sigarda.kelola_materi() then raise exception 'Hanya Pembina dan Admin Gudep yang dapat mengelola materi.'; end if;
  delete from public.materi where id = p_id;
end $$;

create function public.sg_materi_geser(p_id uuid, p_arah int) returns void
language plpgsql security definer set search_path = public as
$$
declare v_u int; v_tetangga uuid; v_ut int;
begin
  perform sigarda.wajib_aktif();
  if not sigarda.kelola_materi() then raise exception 'Hanya Pembina dan Admin Gudep yang dapat mengelola materi.'; end if;
  select urutan into v_u from public.materi where id = p_id;
  if v_u is null then return; end if;
  if p_arah < 0 then
    select id, urutan into v_tetangga, v_ut from public.materi where urutan < v_u order by urutan desc limit 1;
  else
    select id, urutan into v_tetangga, v_ut from public.materi where urutan > v_u order by urutan asc limit 1;
  end if;
  if v_tetangga is null then return; end if;
  update public.materi set urutan = case when id = p_id then v_ut else v_u end where id in (p_id, v_tetangga);
end $$;

-- ===== Pengaturan dan Sidang Dewan Kehormatan =====
-- Kunci pengaturan yang dikenal (nilai bertipe teks). Bawaan dipakai bila belum diatur:
--   sidang.format_nomor   {no3}/DK/{tahun}
--   sidang.nama_ketua     (kosong: dicetak garis untuk tanda tangan)   } hanya cadangan: ketua sidang kini Pradana pada data gudep
--   sidang.sebutan_ketua  Ketua Dewan Penegak / Pemangku Adat        } (sigarda.ketua_sidang); dipakai bila data gudep belum diisi
--   surat.format_nomor    {no3}/SP/{tahun}  (nomor surat pengantar agama; tanpa kode {tingkat}; hanya Pembina atau Admin yang mengubah)
create function public.sg_pengaturan_simpan(p_kunci text, p_nilai jsonb) returns void
language plpgsql security definer set search_path = public as
$$
declare v text; v_tok text;
begin
  perform sigarda.wajib_aktif();
  if p_kunci is null or p_kunci not in ('sidang.format_nomor', 'sidang.nama_ketua', 'sidang.sebutan_ketua', 'surat.format_nomor') then
    raise exception 'Pengaturan tidak dikenal.';
  end if;
  if not sigarda.pengurus() then raise exception 'Hanya Dewan Ambalan, Pembina, atau Admin Gudep yang dapat mengubah pengaturan sidang.'; end if;
  if p_kunci = 'surat.format_nomor' and not sigarda.pembina_atau_admin() then raise exception 'Hanya Pembina atau Admin Gudep yang dapat mengubah format nomor surat.'; end if;
  if p_nilai is null or jsonb_typeof(p_nilai) <> 'string' then raise exception 'Nilai pengaturan tidak sah.'; end if;
  v := sigarda.rapikan(p_nilai #>> '{}');

  if p_kunci in ('sidang.format_nomor', 'surat.format_nomor') then
    if v = '' then raise exception 'Format nomor wajib diisi.'; end if;
    if char_length(v) > 80 then raise exception 'Format nomor maksimal 80 karakter.'; end if;
    if v !~ '^[A-Za-z0-9 /._(){}-]+$' then
      raise exception 'Format nomor hanya boleh berisi huruf, angka, spasi, dan tanda / . - _ ( ) serta kode dalam kurung kurawal.';
    end if;
    for v_tok in select (regexp_matches(v, '\{[^}]*\}', 'g'))[1] loop
      if v_tok not in ('{no}', '{no2}', '{no3}', '{no4}', '{no5}', '{no6}', '{tahun}', '{bulan}', '{romawi}') and not (v_tok = '{tingkat}' and p_kunci = 'sidang.format_nomor') then
        raise exception 'Kode % tidak dikenal. Kode yang tersedia: {no} {no2} {no3} {no4} {no5} {no6} {tahun} {bulan} {romawi} {tingkat}.', v_tok;
      end if;
    end loop;
    if regexp_replace(v, '\{(no|no[2-6]|tahun|bulan|romawi|tingkat)\}', '', 'g') ~ '[{}]' then
      raise exception 'Tanda kurung kurawal pada format nomor tidak lengkap.';
    end if;
    if v !~ '\{no[2-6]?\}' then raise exception 'Format nomor harus memuat kode nomor urut, mis. {no4} (0002) atau {no} (2).'; end if;
    if position('{tahun}' in v) = 0 then raise exception 'Format nomor harus memuat {tahun} agar nomor tidak sama antar tahun.'; end if;
  elsif p_kunci = 'sidang.nama_ketua' then
    if char_length(v) > 120 then raise exception 'Nama ketua maksimal 120 karakter.'; end if;
  else
    if v = '' then raise exception 'Sebutan jabatan wajib diisi.'; end if;
    if char_length(v) > 80 then raise exception 'Sebutan jabatan maksimal 80 karakter.'; end if;
  end if;

  insert into public.pengaturan (kunci, nilai, diubah_oleh, diubah_pada) values (p_kunci, to_jsonb(v), auth.uid(), now())
  on conflict (kunci) do update set nilai = excluded.nilai, diubah_oleh = excluded.diubah_oleh, diubah_pada = excluded.diubah_pada;
end $$;

-- Mencatat keputusan sidang. "Layak" hanya bila seluruh butir tingkat itu lulus (aturan sama dengan tingkat_selesai).
-- Nomor berita acara dibuat otomatis dari format pengaturan (atau diisi manual). Nama ketua dan sebutannya dicatat saat ini.
create function public.sg_sidang_simpan(
  p_peserta_id uuid, p_tingkat text, p_tanggal date, p_keputusan text,
  p_magang text, p_tugas_adat text, p_tugas_adat_ket text, p_catatan text,
  p_nomor_manual text default null, p_nta text default null
) returns int language plpgsql security definer set search_path = public as
$$
declare
  v_p public.profiles; v_lulus int; v_total int; v_belum text[]; v_selesai boolean;
  v_ket text := sigarda.rapikan(p_tugas_adat_ket); v_cat text := btrim(coalesce(p_catatan, ''));
  v_manual text := sigarda.rapikan(p_nomor_manual); v_nta text := sigarda.rapikan(p_nta);
  v_tahun int; v_urut int; v_nomor text; v_id int;
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pengurus() then raise exception 'Hanya Dewan Ambalan, Pembina, atau Admin Gudep yang dapat mencatat keputusan sidang.'; end if;
  select * into v_p from public.profiles where id = p_peserta_id and role = 'peserta';
  if not found then raise exception 'Peserta tidak ditemukan.'; end if;
  if p_tingkat is null or p_tingkat not in ('Bantara', 'Laksana') then raise exception 'Tingkat SKU tidak dikenal.'; end if;
  if p_tanggal is null or p_tanggal < date '2000-01-01' or p_tanggal > sigarda.hari_ini() then
    raise exception 'Tanggal sidang tidak valid (tidak boleh melewati hari ini).';
  end if;
  if p_keputusan is null or p_keputusan not in ('layak', 'tunda') then raise exception 'Pilih keputusan sidang.'; end if;
  if p_magang is null or p_magang not in ('memenuhi', 'tidak') then raise exception 'Pilih hasil pemeriksaan masa magang atau masa tamu ambalan.'; end if;
  if p_tugas_adat is null or p_tugas_adat not in ('lulus', 'tidak') then raise exception 'Pilih hasil tugas tambahan adat ambalan.'; end if;
  if char_length(v_ket) > 60 then raise exception 'Jenis tugas adat maksimal 60 karakter.'; end if;
  if char_length(v_cat) > 500 then raise exception 'Catatan maksimal 500 karakter.'; end if;
  if v_nta <> '' and v_nta !~ '^[0-9A-Za-z./ -]{1,40}$' then raise exception 'NTA hanya boleh berisi huruf, angka, spasi, dan tanda / . - (maksimal 40 karakter).'; end if;

  select coalesce(array_agg(u.id order by u.id) filter (where coalesce(g.status, 'belum') <> 'lulus'), '{}')
    into v_belum
  from public.sku_unit u
  left join public.sku_progress g on g.sku_id = u.id and g.peserta_id = p_peserta_id
  where u.tingkat = p_tingkat and (u.agama is null or u.agama = v_p.agama);
  -- Capaian dihitung per BUTIR (butir agama lulus bila seluruh sub-butirnya lulus), sama dengan hitungProgres di aplikasi
  select count(*) filter (where b.lulus), count(*) into v_lulus, v_total from (
    select bool_and(coalesce(g.status, 'belum') = 'lulus') as lulus
    from public.sku_unit u
    left join public.sku_progress g on g.sku_id = u.id and g.peserta_id = p_peserta_id
    where u.tingkat = p_tingkat and (u.agama is null or u.agama = v_p.agama)
    group by u.butir_id
  ) b;
  v_selesai := v_total > 0 and v_lulus = v_total;

  if p_keputusan = 'layak' then
    if not v_selesai then
      raise exception 'Belum dapat dinyatakan Layak dan Lulus: capaian SKU % baru % dari % butir.', p_tingkat, v_lulus, v_total;
    end if;
    if exists (select 1 from public.sidang_dk where peserta_id = p_peserta_id and tingkat = p_tingkat and keputusan = 'layak') then
      raise exception 'Peserta ini sudah dinyatakan Layak dan Lulus untuk SKU % pada sidang sebelumnya.', p_tingkat;
    end if;
  elsif cardinality(v_belum) = 0 and v_cat = '' then
    raise exception 'Seluruh butir sudah lulus; isi catatan alasan penundaan.';
  end if;

  v_tahun := extract(year from p_tanggal)::int;
  if v_manual <> '' then
    if char_length(v_manual) > 80 then raise exception 'Nomor berita acara maksimal 80 karakter.'; end if;
    v_nomor := v_manual;
    v_urut := null;
  else
    insert into public.sidang_urut as s (tahun, terakhir) values (v_tahun, 1)
    on conflict (tahun) do update set terakhir = s.terakhir + 1
    returning s.terakhir into v_urut;
    v_nomor := sigarda.format_nomor(sigarda.pengaturan_teks('sidang.format_nomor', '{no3}/DK/{tahun}'), v_urut, p_tanggal, p_tingkat);
  end if;
  if exists (select 1 from public.sidang_dk where nomor_ba = v_nomor) then
    raise exception 'Nomor berita acara % sudah dipakai.', v_nomor;
  end if;

  insert into public.sidang_dk (
    peserta_id, tingkat, tanggal, keputusan, magang, tugas_adat, tugas_adat_ket, catatan, nomor_ba, nomor_urut,
    capaian_lulus, capaian_total, butir_belum, nta, ketua_nama, ketua_sebutan, dibuat_oleh
  ) values (
    p_peserta_id, p_tingkat, p_tanggal, p_keputusan, p_magang, p_tugas_adat, v_ket, v_cat, v_nomor, v_urut,
    v_lulus, v_total, v_belum, coalesce(nullif(v_nta, ''), coalesce(v_p.nta, '')),
    (select o_nama from sigarda.ketua_sidang()),
    (select o_sebutan from sigarda.ketua_sidang()),
    auth.uid()
  ) returning id into v_id;

  -- NTA yang diisi saat sidang disimpan ke profil agar terisi otomatis pada sidang berikutnya
  if v_nta <> '' and v_nta is distinct from v_p.nta then update public.profiles set nta = v_nta where id = p_peserta_id; end if;
  return v_id;
end $$;

-- Mengatur nomor urut berikutnya untuk satu tahun (mis. melanjutkan nomor yang sudah berjalan di kertas). Nomor yang diminta
-- harus lebih besar dari nomor urut tertinggi yang sudah tercatat pada tahun itu, agar tidak ada nomor ganda.
create function public.sg_sidang_urut_atur(p_tahun int, p_berikutnya int) returns void
language plpgsql security definer set search_path = public as
$$
declare v_maks int;
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pengurus() then raise exception 'Hanya Dewan Ambalan, Pembina, atau Admin Gudep yang dapat mengatur nomor urut.'; end if;
  if p_tahun is null or p_tahun < 2000 or p_tahun > 2100 then raise exception 'Tahun tidak valid.'; end if;
  if p_berikutnya is null or p_berikutnya < 1 or p_berikutnya > 999999 then raise exception 'Nomor urut berikutnya harus antara 1 dan 999999.'; end if;
  select coalesce(max(nomor_urut), 0) into v_maks from public.sidang_dk where nomor_urut is not null and extract(year from tanggal)::int = p_tahun;
  if p_berikutnya <= v_maks then
    raise exception 'Nomor % sudah terpakai pada catatan sidang tahun % (nomor urut tertinggi: %). Isi angka yang lebih besar.', p_berikutnya, p_tahun, v_maks;
  end if;
  insert into public.sidang_urut (tahun, terakhir) values (p_tahun, p_berikutnya - 1)
  on conflict (tahun) do update set terakhir = excluded.terakhir;
end $$;

-- Hanya Pembina dan Admin Gudep yang dapat menghapus catatan sidang (mis. salah isi). Nomor urut tidak dipakai ulang;
-- gunakan isian nomor manual bila ingin memakai nomor yang sama.
create function public.sg_sidang_hapus(p_id int) returns void
language plpgsql security definer set search_path = public as
$$
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pembina_atau_admin() then raise exception 'Hanya Pembina dan Admin Gudep yang dapat menghapus catatan sidang.'; end if;
  delete from public.sidang_dk where id = p_id;
end $$;

-- ===== Nilai raport ekstrakurikuler =====
-- Pengaturan raport (pita nilai, bobot, target butir per semester) disimpan sebagai satu objek pada kunci 'raport.pengaturan'.
create function public.sg_raport_pengaturan_simpan(p_nilai jsonb) returns void
language plpgsql security definer set search_path = public as
$$
declare
  v_jalur text[]; v_n int; v_sb int; v_b int; v_c int; v_wh int; v_wc int; v_ws int; v_tb int; v_tl int; v_baru jsonb;
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pembina_atau_admin() then raise exception 'Hanya Pembina dan Admin Gudep yang dapat mengubah pengaturan raport.'; end if;
  if p_nilai is null or jsonb_typeof(p_nilai) <> 'object' then raise exception 'Pengaturan raport tidak sah.'; end if;
  foreach v_jalur slice 1 in array array[
    array['pita','sangatBaik'], array['pita','baik'], array['pita','cukup'],
    array['bobot','kehadiran'], array['bobot','capaian'], array['bobot','sikap'],
    array['target','Bantara'], array['target','Laksana']
  ] loop
    if coalesce(p_nilai #>> v_jalur, '') !~ '^[0-9]{1,3}$' then
      raise exception 'Pengaturan raport: nilai % harus berupa bilangan bulat.', array_to_string(v_jalur, '.');
    end if;
  end loop;
  v_sb := (p_nilai #>> '{pita,sangatBaik}')::int; v_b := (p_nilai #>> '{pita,baik}')::int; v_c := (p_nilai #>> '{pita,cukup}')::int;
  v_wh := (p_nilai #>> '{bobot,kehadiran}')::int; v_wc := (p_nilai #>> '{bobot,capaian}')::int; v_ws := (p_nilai #>> '{bobot,sikap}')::int;
  v_tb := (p_nilai #>> '{target,Bantara}')::int; v_tl := (p_nilai #>> '{target,Laksana}')::int;
  if not (v_sb <= 100 and v_sb > v_b and v_b > v_c and v_c >= 1) then
    raise exception 'Batas nilai harus berurutan: Sangat Baik (maks. 100) lebih besar dari Baik, Baik lebih besar dari Cukup, Cukup minimal 1.';
  end if;
  if v_wh + v_wc + v_ws <> 100 then raise exception 'Jumlah bobot harus 100 (sekarang %).', v_wh + v_wc + v_ws; end if;
  if v_wc < 1 then raise exception 'Bobot capaian SKU minimal 1.'; end if;
  if v_tb < 1 or v_tb > 60 or v_tl < 1 or v_tl > 60 then raise exception 'Target butir per semester harus antara 1 dan 60.'; end if;
  v_baru := jsonb_build_object(
    'pita', jsonb_build_object('sangatBaik', v_sb, 'baik', v_b, 'cukup', v_c),
    'bobot', jsonb_build_object('kehadiran', v_wh, 'capaian', v_wc, 'sikap', v_ws),
    'target', jsonb_build_object('Bantara', v_tb, 'Laksana', v_tl));
  insert into public.pengaturan (kunci, nilai, diubah_oleh, diubah_pada) values ('raport.pengaturan', v_baru, auth.uid(), now())
  on conflict (kunci) do update set nilai = excluded.nilai, diubah_oleh = excluded.diubah_oleh, diubah_pada = excluded.diubah_pada;
end $$;

-- Menyimpan nilai raport satu peserta pada satu semester. Kehadiran dan capaian SKU dihitung ulang di server dari data absensi dan
-- progres SKU; skor dan predikat hitung dari pengaturan yang berlaku. Pembina hanya mengisi sikap, karakter, SKK, deskripsi, dan
-- (bila perlu) predikat akhir yang berbeda dari hasil hitung, wajib disertai catatan. Status 'final' = keputusan Pembina.
create function public.sg_raport_simpan(
  p_peserta_id uuid, p_tahun_ajaran text, p_semester text, p_tingkat text,
  p_sikap int, p_karakter text[], p_skk int,
  p_predikat_akhir text, p_catatan text, p_deskripsi text, p_final boolean
) returns void language plpgsql security definer set search_path = public as
$$
declare
  v_kar text[]; v_cat text := sigarda.rapikan(p_catatan); v_des text := btrim(coalesce(p_deskripsi, ''));
  v_h record; v_persen int; v_skor int; v_hitung text; v_akhir text := p_predikat_akhir;
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pembina_atau_admin() then raise exception 'Hanya Pembina dan Admin Gudep yang dapat mengisi nilai raport.'; end if;
  if not exists (select 1 from public.profiles where id = p_peserta_id and role = 'peserta') then raise exception 'Peserta tidak ditemukan.'; end if;
  if p_tahun_ajaran is null or p_tahun_ajaran !~ '^[0-9]{4}/[0-9]{4}$'
     or split_part(p_tahun_ajaran, '/', 2)::int <> split_part(p_tahun_ajaran, '/', 1)::int + 1
     or split_part(p_tahun_ajaran, '/', 1)::int not between 2000 and 2100 then
    raise exception 'Tahun ajaran tidak valid (contoh: 2026/2027).';
  end if;
  if p_semester is null or p_semester not in ('ganjil', 'genap') then raise exception 'Semester harus ganjil atau genap.'; end if;
  if p_tingkat is null or p_tingkat not in ('Bantara', 'Laksana') then raise exception 'Tingkat SKU tidak dikenal.'; end if;
  if p_sikap is not null and p_sikap not between 1 and 5 then raise exception 'Nilai sikap harus antara 1 dan 5.'; end if;
  if p_skk is not null and p_skk not between 0 and 99 then raise exception 'Jumlah SKK harus antara 0 dan 99.'; end if;
  if v_akhir is not null and v_akhir not in ('A', 'B', 'C', 'D') then raise exception 'Predikat akhir tidak dikenal.'; end if;
  if char_length(v_cat) > 300 then raise exception 'Catatan predikat maksimal 300 karakter.'; end if;
  if char_length(v_des) > 1200 then raise exception 'Deskripsi capaian maksimal 1200 karakter.'; end if;

  -- karakter: dirapikan, tanpa kembar (huruf besar/kecil dianggap sama), urutan dipertahankan
  select coalesce(array_agg(d.t order by d.n), '{}') into v_kar from (
    select distinct on (lower(s.t)) s.t, s.n from (
      select sigarda.rapikan(x) as t, n from unnest(coalesce(p_karakter, '{}')) with ordinality as a(x, n)
    ) s where s.t <> '' order by lower(s.t), s.n
  ) d;
  if cardinality(v_kar) > 6 then raise exception 'Karakter yang dipilih maksimal 6.'; end if;
  if exists (select 1 from unnest(v_kar) k where char_length(k) > 30) then raise exception 'Setiap karakter maksimal 30 huruf.'; end if;

  select * into v_h from sigarda.raport_hitung(p_peserta_id, p_tahun_ajaran, p_semester, p_tingkat);
  v_persen := case when v_h.o_dicatat > 0 then round(v_h.o_hadir * 100.0 / v_h.o_dicatat)::int end;
  v_skor := sigarda.raport_skor(v_persen, v_h.o_lulus, v_h.o_target, p_sikap);
  if v_skor is null then raise exception 'Belum ada komponen yang dapat dinilai.'; end if;
  v_hitung := sigarda.raport_predikat(v_skor);

  if v_akhir is not null and v_akhir = v_hitung then v_akhir := null; end if;
  if v_akhir is null then v_cat := '';
  elsif v_cat = '' then raise exception 'Predikat akhir berbeda dari hasil hitung (%); isi catatan alasan perubahannya.', v_hitung;
  end if;
  if coalesce(p_final, false) then
    if p_sikap is null then raise exception 'Isi penilaian sikap sebelum menandai final.'; end if;
    if v_des = '' then raise exception 'Isi deskripsi capaian sebelum menandai final.'; end if;
  end if;

  insert into public.raport (
    peserta_id, tahun_ajaran, semester, tingkat, sikap, karakter, skk, kehadiran_persen, hadir, pertemuan,
    capaian_lulus, capaian_target, skor, predikat_hitung, predikat_akhir, catatan_predikat, deskripsi, status, diubah_oleh, diubah_pada
  ) values (
    p_peserta_id, p_tahun_ajaran, p_semester, p_tingkat, p_sikap, v_kar, p_skk, v_persen, v_h.o_hadir, v_h.o_dicatat,
    v_h.o_lulus, v_h.o_target, v_skor, v_hitung, v_akhir, v_cat, v_des, case when coalesce(p_final, false) then 'final' else 'draf' end, auth.uid(), now()
  ) on conflict (peserta_id, tahun_ajaran, semester) do update set
    tingkat = excluded.tingkat, sikap = excluded.sikap, karakter = excluded.karakter, skk = excluded.skk,
    kehadiran_persen = excluded.kehadiran_persen, hadir = excluded.hadir, pertemuan = excluded.pertemuan,
    capaian_lulus = excluded.capaian_lulus, capaian_target = excluded.capaian_target, skor = excluded.skor,
    predikat_hitung = excluded.predikat_hitung, predikat_akhir = excluded.predikat_akhir, catatan_predikat = excluded.catatan_predikat,
    deskripsi = excluded.deskripsi, status = excluded.status, diubah_oleh = excluded.diubah_oleh, diubah_pada = excluded.diubah_pada;
end $$;

create function public.sg_raport_hapus(p_peserta_id uuid, p_tahun_ajaran text, p_semester text) returns void
language plpgsql security definer set search_path = public as
$$
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pembina_atau_admin() then raise exception 'Hanya Pembina dan Admin Gudep yang dapat menghapus nilai raport.'; end if;
  delete from public.raport where peserta_id = p_peserta_id and tahun_ajaran = p_tahun_ajaran and semester = p_semester;
end $$;

-- ===== Instrumen penilaian (Pembina dan Admin) =====
-- Menyimpan satu instrumen: cara uji, instruksi penguji, dan daftar kriteria (urutan = urutan dalam array). Kriteria yang menyertakan
-- id diperbarui di tempat (id dipertahankan), yang tanpa id ditambahkan, dan yang tidak ada dalam daftar dihapus.
-- p_kriteria: [{"id":123,"jenis":"Lisan","teks":"...","bobot":1,"wajib":false,"panduan":"..."}]
create function public.sg_instrumen_simpan(p_sku_id text, p_cara_uji text, p_instruksi text, p_kriteria jsonb, p_status text)
returns void language plpgsql security definer set search_path = public as
$$
declare
  v_cara text := btrim(coalesce(p_cara_uji, '')); v_ins text := btrim(coalesce(p_instruksi, ''));
  v_e jsonb; v_n int; v_i int := 0; v_id bigint; v_pertahankan bigint[] := '{}'; v_iuran int := 0;
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pembina_atau_admin() then raise exception 'Hanya Pembina dan Admin Gudep yang dapat mengubah instrumen.'; end if;
  if p_sku_id is null or not exists (select 1 from public.sku_unit where id = p_sku_id) then raise exception 'Butir SKU tidak ditemukan.'; end if;
  if p_status is null or p_status not in ('draf', 'ditetapkan') then raise exception 'Status instrumen harus draf atau ditetapkan.'; end if;
  if char_length(v_cara) > 300 then raise exception 'Cara uji maksimal 300 karakter.'; end if;
  if char_length(v_ins) > 1500 then raise exception 'Instruksi penguji maksimal 1500 karakter.'; end if;
  if p_kriteria is null or jsonb_typeof(p_kriteria) <> 'array' then raise exception 'Daftar kriteria tidak sah.'; end if;
  v_n := jsonb_array_length(p_kriteria);
  if v_n > 15 then raise exception 'Kriteria maksimal 15 per butir.'; end if;
  if p_status = 'ditetapkan' and v_n = 0 then raise exception 'Instrumen yang ditetapkan harus memiliki minimal satu kriteria.'; end if;

  for v_e in select value from jsonb_array_elements(p_kriteria) loop
    v_i := v_i + 1;
    if jsonb_typeof(v_e) <> 'object' then raise exception 'Kriteria % tidak sah.', v_i; end if;
    if coalesce(v_e ->> 'jenis', '') not in ('Lisan', 'Praktik', 'Bukti kegiatan', 'Pengamatan') then raise exception 'Kriteria %: pilih jenis penilaian.', v_i; end if;
    if char_length(btrim(coalesce(v_e ->> 'teks', ''))) not between 1 and 400 then raise exception 'Kriteria %: teks wajib diisi (maksimal 400 karakter).', v_i; end if;
    if coalesce(v_e ->> 'bobot', '') !~ '^[1-5]$' then raise exception 'Kriteria %: bobot harus 1 sampai 5.', v_i; end if;
    if v_e ? 'wajib' and jsonb_typeof(v_e -> 'wajib') <> 'boolean' then raise exception 'Kriteria %: penanda wajib tidak sah.', v_i; end if;
    if coalesce(v_e ->> 'sumber', 'manual') not in ('manual', 'iuran') then raise exception 'Kriteria %: sumber nilai tidak dikenal.', v_i; end if;
    if coalesce(v_e ->> 'sumber', 'manual') = 'iuran' then
      if p_sku_id not in ('BAN-06', 'LAK-06') then raise exception 'Kriteria %: sumber nilai iuran hanya untuk butir iuran (Bantara 6 dan Laksana 6).', v_i; end if;
      v_iuran := v_iuran + 1;
    end if;
    if char_length(coalesce(v_e ->> 'panduan', '')) > 1500 then raise exception 'Kriteria %: panduan maksimal 1500 karakter.', v_i; end if;
    if v_e ? 'id' and jsonb_typeof(v_e -> 'id') <> 'null' then
      if coalesce(v_e ->> 'id', '') !~ '^[0-9]{1,18}$' then raise exception 'Kriteria %: id tidak sah.', v_i; end if;
      if not exists (select 1 from public.instrumen_kriteria where id = (v_e ->> 'id')::bigint and sku_id = p_sku_id) then
        raise exception 'Kriteria % tidak ditemukan pada butir ini (mungkin sudah diubah orang lain). Muat ulang.', v_i;
      end if;
      v_pertahankan := v_pertahankan || (v_e ->> 'id')::bigint;
    end if;
  end loop;
  if cardinality(v_pertahankan) <> (select count(distinct x) from unnest(v_pertahankan) x) then raise exception 'Ada kriteria yang ganda.'; end if;
  if v_iuran > 1 then raise exception 'Hanya satu kriteria yang boleh bersumber iuran.'; end if;

  insert into public.instrumen (sku_id, cara_uji, status, diubah_oleh, diubah_pada) values (p_sku_id, v_cara, p_status, auth.uid(), now())
  on conflict (sku_id) do update set cara_uji = excluded.cara_uji, status = excluded.status, diubah_oleh = excluded.diubah_oleh, diubah_pada = excluded.diubah_pada;
  insert into public.instrumen_penguji (sku_id, instruksi) values (p_sku_id, v_ins)
  on conflict (sku_id) do update set instruksi = excluded.instruksi;
  delete from public.instrumen_kriteria where sku_id = p_sku_id and not (id = any (v_pertahankan));

  v_i := 0;
  for v_e in select value from jsonb_array_elements(p_kriteria) loop
    v_i := v_i + 1;
    if v_e ? 'id' and jsonb_typeof(v_e -> 'id') <> 'null' then
      v_id := (v_e ->> 'id')::bigint;
      update public.instrumen_kriteria
        set urutan = v_i, jenis = v_e ->> 'jenis', teks = btrim(v_e ->> 'teks'), bobot = (v_e ->> 'bobot')::int, wajib = coalesce((v_e ->> 'wajib')::boolean, false),
            sumber = coalesce(v_e ->> 'sumber', 'manual')
        where id = v_id;
    else
      insert into public.instrumen_kriteria (sku_id, urutan, jenis, teks, bobot, wajib, sumber)
      values (p_sku_id, v_i, v_e ->> 'jenis', btrim(v_e ->> 'teks'), (v_e ->> 'bobot')::int, coalesce((v_e ->> 'wajib')::boolean, false), coalesce(v_e ->> 'sumber', 'manual'))
      returning id into v_id;
    end if;
    insert into public.instrumen_panduan (kriteria_id, panduan) values (v_id, btrim(coalesce(v_e ->> 'panduan', '')))
    on conflict (kriteria_id) do update set panduan = excluded.panduan;
  end loop;
end $$;

-- Menetapkan (dipakai menilai) atau mengembalikan ke draf beberapa instrumen sekaligus.
create function public.sg_instrumen_status(p_sku_ids text[], p_status text) returns void
language plpgsql security definer set search_path = public as
$$
declare v_ids text[]; v_kosong text; v_n int;
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pembina_atau_admin() then raise exception 'Hanya Pembina dan Admin Gudep yang dapat mengubah status instrumen.'; end if;
  if p_status is null or p_status not in ('draf', 'ditetapkan') then raise exception 'Status instrumen harus draf atau ditetapkan.'; end if;
  select coalesce(array_agg(distinct x), '{}') into v_ids from unnest(coalesce(p_sku_ids, '{}')) x;
  if cardinality(v_ids) = 0 then raise exception 'Pilih minimal satu butir.'; end if;
  if cardinality(v_ids) > 200 then raise exception 'Maksimal 200 butir sekaligus.'; end if;
  if (select count(*) from public.instrumen where sku_id = any (v_ids)) <> cardinality(v_ids) then
    raise exception 'Sebagian butir belum memiliki instrumen.';
  end if;
  if p_status = 'ditetapkan' then
    select string_agg(x, ', ') into v_kosong from unnest(v_ids) x where not exists (select 1 from public.instrumen_kriteria k where k.sku_id = x);
    if v_kosong is not null then raise exception 'Belum memiliki kriteria: %.', v_kosong; end if;
  end if;
  update public.instrumen set status = p_status, diubah_oleh = auth.uid(), diubah_pada = now() where sku_id = any (v_ids);
  get diagnostics v_n = row_count;
end $$;

-- Pengaturan penilaian instrumen: ambang lulus, batas predikat, dan aturan kriteria wajib.
create function public.sg_instrumen_pengaturan_simpan(p_nilai jsonb) returns void
language plpgsql security definer set search_path = public as
$$
declare v_kunci text; v_a int; v_sb int; v_b int; v_c int; v_m int; v_baru jsonb;
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pembina_atau_admin() then raise exception 'Hanya Pembina dan Admin Gudep yang dapat mengubah pengaturan instrumen.'; end if;
  if p_nilai is null or jsonb_typeof(p_nilai) <> 'object' then raise exception 'Pengaturan instrumen tidak sah.'; end if;
  foreach v_kunci in array array['ambang', 'pita.sangatBaik', 'pita.baik', 'pita.cukup', 'nilaiWajibMin'] loop
    if coalesce(p_nilai #>> string_to_array(v_kunci, '.'), '') !~ '^[0-9]{1,3}$' then
      raise exception 'Pengaturan instrumen: nilai % harus berupa bilangan bulat.', v_kunci;
    end if;
  end loop;
  if jsonb_typeof(p_nilai -> 'gerbangWajib') is distinct from 'boolean' then raise exception 'Pengaturan instrumen: gerbangWajib harus benar atau salah.'; end if;
  v_a := (p_nilai ->> 'ambang')::int; v_sb := (p_nilai #>> '{pita,sangatBaik}')::int; v_b := (p_nilai #>> '{pita,baik}')::int;
  v_c := (p_nilai #>> '{pita,cukup}')::int; v_m := (p_nilai ->> 'nilaiWajibMin')::int;
  if not (v_sb <= 100 and v_sb > v_b and v_b > v_c and v_c >= 1) then
    raise exception 'Batas nilai harus berurutan: Sangat Baik (maks. 100) lebih besar dari Baik, Baik lebih besar dari Cukup, Cukup minimal 1.';
  end if;
  if v_a < 1 or v_a > 100 then raise exception 'Ambang lulus harus antara 1 dan 100.'; end if;
  if v_m < 2 or v_m > 5 then raise exception 'Nilai minimal kriteria wajib harus antara 2 dan 5.'; end if;
  v_baru := jsonb_build_object('ambang', v_a, 'pita', jsonb_build_object('sangatBaik', v_sb, 'baik', v_b, 'cukup', v_c),
                               'gerbangWajib', (p_nilai ->> 'gerbangWajib')::boolean, 'nilaiWajibMin', v_m);
  insert into public.pengaturan (kunci, nilai, diubah_oleh, diubah_pada) values ('instrumen.pengaturan', v_baru, auth.uid(), now())
  on conflict (kunci) do update set nilai = excluded.nilai, diubah_oleh = excluded.diubah_oleh, diubah_pada = excluded.diubah_pada;
end $$;

-- ===== Verifikasi keaslian dokumen (QR). DAPAT DIPANGGIL TANPA LOGIN (peran anon): hanya membaca, hanya mengembalikan data seperlunya. =====
-- Token QR (32 heksadesimal, 128 bit acak) tidak dapat ditebak. Nama lengkap hanya keluar untuk pemegang token yang sah.
-- Kode pendek VRF-XXXXXXX (28 bit, tercetak di dokumen) dapat ditebak, jadi jawabannya hanya sah/tidak beserta tingkat, butir, dan tanggal: TANPA nama.
create function public.sg_verifikasi_token(p_token text) returns jsonb
language plpgsql stable security definer set search_path = public as
$$
declare
  v_t text := lower(btrim(coalesce(p_token, ''))); v_g public.sku_progress; v_s public.sertifikat_tingkat; v_unit public.sku_unit;
  v_nama text; v_agama text; v_pen text; v_jab text; v_pen_id uuid; v_tgl date; v_total int; v_d public.dokumen_terbit;
  v_b public.sidang_dk; v_nis text; v_kelas text; v_pembina text;
begin
  if v_t !~ '^[0-9a-f]{32}$' then return jsonb_build_object('ditemukan', false); end if;

  select * into v_g from public.sku_progress where verifikasi_token = v_t and status = 'lulus';
  if found then
    select nama into v_nama from public.profiles where id = v_g.peserta_id;
    select * into v_unit from public.sku_unit where id = v_g.sku_id;
    select nama, jabatan into v_pen, v_jab from public.profiles where id = v_g.penguji_id;
    return jsonb_build_object('ditemukan', true, 'jenis', 'butir', 'nama', v_nama, 'sku_id', v_g.sku_id, 'tingkat', v_unit.tingkat,
      'butir_no', v_unit.butir_no, 'sub', v_unit.sub, 'tanggal', v_g.tanggal_uji, 'penguji', v_pen, 'jabatan_penguji', v_jab, 'kode', v_g.verifikasi);
  end if;

  select * into v_s from public.sertifikat_tingkat where token = v_t;
  if found and sigarda.tingkat_selesai(v_s.peserta_id, v_s.tingkat) then
    select nama, agama into v_nama, v_agama from public.profiles where id = v_s.peserta_id;
    select count(distinct u.butir_id) into v_total from public.sku_unit u where u.tingkat = v_s.tingkat and (u.agama is null or u.agama = v_agama);
    select g.tanggal_uji, g.penguji_id into v_tgl, v_pen_id
    from public.sku_progress g join public.sku_unit u on u.id = g.sku_id
    where g.peserta_id = v_s.peserta_id and u.tingkat = v_s.tingkat and g.status = 'lulus'
    order by g.tanggal_uji desc nulls last, g.diubah desc limit 1;
    select nama, jabatan into v_pen, v_jab from public.profiles where id = v_pen_id;
    return jsonb_build_object('ditemukan', true, 'jenis', 'tingkat', 'nama', v_nama, 'tingkat', v_s.tingkat, 'jumlah_butir', v_total,
      'tanggal', v_tgl, 'penguji', v_pen, 'jabatan_penguji', v_jab, 'diterbitkan', v_s.diterbitkan_pada);
  end if;

  -- Dokumen terbit (surat pengantar agama, dst.): dokumen yang dicabut tetap dijawab, tetapi ditandai dicabut dan tanpa data Penegak.
  select * into v_d from public.dokumen_terbit where token = v_t;
  if found then
    if v_d.dicabut_pada is not null then
      return jsonb_build_object('ditemukan', true, 'jenis', 'dokumen', 'jenis_dokumen', v_d.jenis, 'nomor', v_d.nomor, 'dicabut', true, 'dicabut_pada', v_d.dicabut_pada);
    end if;
    return jsonb_build_object('ditemukan', true, 'jenis', 'dokumen', 'jenis_dokumen', v_d.jenis, 'dicabut', false, 'nomor', v_d.nomor, 'tanggal', v_d.tanggal,
      'penerbit', v_d.penerbit, 'dibuat_oleh', v_d.dibuat_oleh_nama, 'jabatan_pembuat', v_d.dibuat_oleh_jabatan,
      'penanda_tangan', v_d.penanda_tangan_nama, 'jabatan_penanda_tangan', v_d.penanda_tangan_jabatan,
      'nama', v_d.peserta_nama, 'nis', v_d.payload ->> 'nis', 'kelas', v_d.payload ->> 'kelas', 'agama', v_d.payload ->> 'agama',
      'guru', v_d.payload -> 'guru' ->> 'nama', 'butir', coalesce(v_d.payload -> 'butir', '[]'::jsonb), 'kode', v_d.kode, 'diterbitkan', v_d.dibuat_pada);
  end if;

  -- Berita acara sidang (token dibuat saat dicetak). Catatan sidang yang dihapus tidak lagi dijawab.
  select * into v_b from public.sidang_dk where token = v_t;
  if found then
    select nama, nis, kelas into v_nama, v_nis, v_kelas from public.profiles where id = v_b.peserta_id;
    select nama, jabatan into v_pen, v_jab from public.profiles where id = v_b.dibuat_oleh;
    select nilai #>> '{pembina,nama}' into v_pembina from public.pengaturan where kunci = 'gudep.data';
    return jsonb_build_object('ditemukan', true, 'jenis', 'dokumen', 'jenis_dokumen', 'berita_acara_sidang', 'dicabut', false, 'nomor', v_b.nomor_ba, 'tanggal', v_b.tanggal,
      'dibuat_oleh', v_pen, 'jabatan_pembuat', v_jab, 'penanda_tangan', nullif(v_b.ketua_nama, ''), 'jabatan_penanda_tangan', v_b.ketua_sebutan, 'pembina', nullif(v_pembina, ''),
      'nama', v_nama, 'nis', v_nis, 'kelas', v_kelas, 'tingkat', v_b.tingkat, 'keputusan', v_b.keputusan, 'kode', v_b.kode, 'diterbitkan', v_b.dibuat_pada);
  end if;
  return jsonb_build_object('ditemukan', false);
end $$;

create function public.sg_verifikasi_kode(p_kode text) returns jsonb
language plpgsql stable security definer set search_path = public as
$$
declare v_k text := upper(btrim(coalesce(p_kode, ''))); v_tingkat text; v_no int; v_tgl date; v_d public.dokumen_terbit; v_b public.sidang_dk;
begin
  if v_k !~ '^VRF-[0-9A-F]{7}$' then return jsonb_build_object('ditemukan', false); end if;
  select u.tingkat, u.butir_no, g.tanggal_uji into v_tingkat, v_no, v_tgl
  from public.sku_progress g join public.sku_unit u on u.id = g.sku_id
  where g.verifikasi = v_k and g.status = 'lulus' order by g.tanggal_uji nulls last limit 1;
  if not found then
    -- Kode dokumen terbit: hanya jenis, nomor, tanggal, dan status (tanpa nama)
    select * into v_d from public.dokumen_terbit where kode = v_k order by dibuat_pada limit 1;
    if not found then
      select * into v_b from public.sidang_dk where kode = v_k order by dibuat_pada limit 1;
      if not found then return jsonb_build_object('ditemukan', false); end if;
      return jsonb_build_object('ditemukan', true, 'jenis', 'dokumen', 'jenis_dokumen', 'berita_acara_sidang', 'nomor', v_b.nomor_ba, 'tanggal', v_b.tanggal, 'dicabut', false);
    end if;
    return jsonb_build_object('ditemukan', true, 'jenis', 'dokumen', 'jenis_dokumen', v_d.jenis, 'nomor', v_d.nomor, 'tanggal', v_d.tanggal, 'dicabut', v_d.dicabut_pada is not null);
  end if;
  return jsonb_build_object('ditemukan', true, 'tingkat', v_tingkat, 'butir_no', v_no, 'tanggal', v_tgl);
end $$;

-- Token untuk Surat Tanda Lulus satu tingkat. Untuk Penegak itu sendiri atau pengurus; hanya bila seluruh butir tingkat itu lulus. Idempoten.
create function public.sg_sertifikat_tingkat(p_peserta_id uuid, p_tingkat text) returns text
language plpgsql security definer set search_path = public as
$$
declare v_uid uuid := auth.uid(); v_token text; v_p public.profiles;
begin
  perform sigarda.wajib_aktif();
  if p_tingkat is null or p_tingkat not in ('Bantara', 'Laksana', 'Mula', 'Bantu', 'Tata') then raise exception 'Tingkat SKU tidak dikenal.'; end if;
  select * into v_p from public.profiles where id = p_peserta_id and role = 'peserta';
  if not found then raise exception 'Peserta tidak ditemukan.'; end if;
  -- Tingkat Siaga (Mula, Bantu, Tata) hanya untuk anggota Siaga; Bantara dan Laksana hanya untuk Penegak.
  if (v_p.tanpa_akun or sigarda.kelas_siaga(v_p.kelas)) <> (p_tingkat in ('Mula', 'Bantu', 'Tata')) then raise exception 'Tingkat % tidak berlaku bagi anggota ini.', p_tingkat; end if;
  if p_peserta_id is distinct from v_uid and not sigarda.pengurus() then raise exception 'Anda tidak berwenang menerbitkan surat untuk peserta ini.'; end if;
  if not sigarda.tingkat_selesai(p_peserta_id, p_tingkat) then raise exception 'Surat Tanda Lulus hanya untuk tingkat yang seluruh butirnya sudah lulus.'; end if;
  insert into public.sertifikat_tingkat (token, peserta_id, tingkat, diterbitkan_oleh) values (sigarda.token_acak(), p_peserta_id, p_tingkat, v_uid)
  on conflict (peserta_id, tingkat) do nothing;
  select token into v_token from public.sertifikat_tingkat where peserta_id = p_peserta_id and tingkat = p_tingkat;
  return v_token;
end $$;

-- ===== Berkas Calon Garuda (tahap L7): fungsi =====
-- Isi lengkap berkas satu Calon Garuda (kartu SKU Bantara+Laksana MENTAH, portofolio, jurnal, daftar penguji terkait) sebagai
-- satu JSON, dipetakan ulang di klien (src/lib/mapDb.js) memakai susunProgress/susunPortofolio yang SAMA dengan halaman biasa
-- (jadi tampilannya seragam dengan Kartu SKU dan Portofolio yang sudah ada). Dipakai bersama oleh sg_garuda_berkas_baca
-- (Pembina/Admin, sudah login) dan sg_garuda_token_baca (tautan berbagi, tanpa login) -- satu sumber, dua jalur akses.
create function sigarda.garuda_berkas_json(p_peserta_id uuid) returns jsonb language sql stable security definer set search_path = public as
$$
  select jsonb_build_object(
    'peserta', (select jsonb_build_object('id', id, 'nama', nama, 'nis', nis, 'kelas', kelas, 'sangga', sangga, 'agama', agama,
                  'nta', nta, 'jenis_kelamin', jenis_kelamin, 'calon_garuda', calon_garuda)
                from public.profiles where id = p_peserta_id),
    'sku_progress', (select coalesce(jsonb_agg(to_jsonb(g)), '[]'::jsonb) from public.sku_progress g
                      join public.sku_unit u on u.id = g.sku_id where g.peserta_id = p_peserta_id and u.tingkat in ('Bantara','Laksana')),
    'sku_riwayat', (select coalesce(jsonb_agg(to_jsonb(r)), '[]'::jsonb) from public.sku_riwayat r
                     join public.sku_unit u on u.id = r.sku_id where r.peserta_id = p_peserta_id and u.tingkat in ('Bantara','Laksana')),
    'portofolio', (select coalesce(jsonb_agg(to_jsonb(p)), '[]'::jsonb) from public.portofolio p where p.peserta_id = p_peserta_id),
    'portofolio_jurnal', (select coalesce(jsonb_agg(to_jsonb(j)), '[]'::jsonb) from public.portofolio_jurnal j where j.peserta_id = p_peserta_id),
    'users', (select coalesce(jsonb_agg(jsonb_build_object('id', pr.id, 'nama', pr.nama, 'jabatan', pr.jabatan)), '[]'::jsonb)
              from public.profiles pr where pr.id in (
                select penguji_id from public.sku_progress g2 join public.sku_unit u2 on u2.id = g2.sku_id
                  where g2.peserta_id = p_peserta_id and u2.tingkat in ('Bantara','Laksana') and penguji_id is not null
                union
                select catatan_penguji_oleh from public.portofolio where peserta_id = p_peserta_id and catatan_penguji_oleh is not null
                union
                select oleh from public.portofolio_jurnal where peserta_id = p_peserta_id and oleh is not null
              ))
  )
$$;

-- Pembina dan Admin membuka berkas lengkap seorang Calon Garuda (untuk ditinjau atau dicetak sendiri).
create function public.sg_garuda_berkas_baca(p_peserta_id uuid) returns jsonb
language plpgsql stable security definer set search_path = public as
$$
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pembina_atau_admin() then raise exception 'Hanya Pembina dan Admin Gudep yang dapat membuka berkas Calon Garuda.'; end if;
  if not exists (select 1 from public.profiles where id = p_peserta_id and role = 'peserta') then raise exception 'Peserta tidak ditemukan.'; end if;
  if not exists (select 1 from public.profiles where id = p_peserta_id and calon_garuda is not null) then
    raise exception 'Peserta ini belum mendaftar sebagai Calon Garuda.';
  end if;
  if not sigarda.layak_garuda(p_peserta_id) then raise exception 'Peserta ini belum menyelesaikan seluruh SKU Bantara dan Laksana.'; end if;
  return sigarda.garuda_berkas_json(p_peserta_id)
    || jsonb_build_object('token', (select token from public.garuda_berkas_token where peserta_id = p_peserta_id and dicabut_pada is null));
end $$;

-- Membuat (atau mengganti) tautan berbagi baca-saja untuk satu Calon Garuda. Hanya Pembina dan Admin (sama dengan hak
-- membuka berkas di atas, TIDAK sama dengan hak menilai portofolio sehari-hari yang juga mengikutkan Dewan Ambalan --
-- mengirim data ke pihak luar organisasi sengaja lebih ketat). Token lama (bila ada) otomatis dicabut oleh token baru:
-- regenerasi berarti mengganti tautan, bukan menambah tautan lain yang masih aktif.
create function public.sg_garuda_token_buat(p_peserta_id uuid) returns text
language plpgsql security definer set search_path = public as
$$
declare v_uid uuid := auth.uid(); v_nama text; v_token text;
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pembina_atau_admin() then raise exception 'Hanya Pembina dan Admin Gudep yang dapat membuat tautan berbagi.'; end if;
  if not exists (select 1 from public.profiles where id = p_peserta_id and role = 'peserta') then raise exception 'Peserta tidak ditemukan.'; end if;
  if not exists (select 1 from public.profiles where id = p_peserta_id and calon_garuda is not null) then
    raise exception 'Peserta ini belum mendaftar sebagai Calon Garuda.';
  end if;
  if not sigarda.layak_garuda(p_peserta_id) then raise exception 'Tautan berbagi hanya untuk Penegak yang seluruh SKU Bantara dan Laksana-nya sudah lulus.'; end if;
  update public.garuda_berkas_token set dicabut_pada = now(), dicabut_oleh = v_uid where peserta_id = p_peserta_id and dicabut_pada is null;
  select nama into v_nama from public.profiles where id = v_uid;
  v_token := sigarda.token_acak();
  insert into public.garuda_berkas_token (peserta_id, token, dibuat_oleh, dibuat_oleh_nama) values (p_peserta_id, v_token, v_uid, coalesce(v_nama, ''));
  return v_token;
end $$;

-- Mencabut tautan berbagi yang sedang aktif (tidak ada efek bila sudah tidak ada yang aktif). Tanpa kedaluwarsa otomatis,
-- jadi ini satu-satunya cara menghentikan akses baca lewat tautan yang pernah dibagikan.
create function public.sg_garuda_token_cabut(p_peserta_id uuid) returns void
language plpgsql security definer set search_path = public as
$$
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pembina_atau_admin() then raise exception 'Hanya Pembina dan Admin Gudep yang dapat mencabut tautan berbagi.'; end if;
  update public.garuda_berkas_token set dicabut_pada = now(), dicabut_oleh = auth.uid() where peserta_id = p_peserta_id and dicabut_pada is null;
end $$;

-- DAPAT DIPANGGIL TANPA LOGIN (peran anon): tautan berbagi baca-saja untuk penilai kwarran/kwarcab. Token 128 bit acak, tidak
-- dapat ditebak. BEDA dari sg_verifikasi_token/kode (yang hanya menjawab ringkasan): fungsi ini mengembalikan ISI LENGKAP
-- berkas. Token yang tidak dikenal atau sudah dicabut menjawab { ditemukan: false } (bukan galat keras, sama pola dengan
-- sg_verifikasi_token) supaya halaman publik dapat menampilkan pesan yang ramah tanpa membedakan sebab.
create function public.sg_garuda_token_baca(p_token text) returns jsonb
language plpgsql stable security definer set search_path = public as
$$
declare v_t text := lower(btrim(coalesce(p_token, ''))); v_row public.garuda_berkas_token;
begin
  if v_t !~ '^[0-9a-f]{32}$' then return jsonb_build_object('ditemukan', false); end if;
  select * into v_row from public.garuda_berkas_token where token = v_t;
  if not found or v_row.dicabut_pada is not null then return jsonb_build_object('ditemukan', false); end if;
  return jsonb_build_object('ditemukan', true) || sigarda.garuda_berkas_json(v_row.peserta_id);
end $$;
-- ===== akhir fungsi berkas garuda =====

-- ===== Data gudep: fungsi =====
-- Identitas Gugus Depan dan pejabatnya disimpan sebagai satu objek JSON pada pengaturan 'gudep.data' (dibaca semua pengguna yang sudah masuk
-- lewat kebijakan baca_pengaturan; diubah hanya Admin Gudep lewat sg_gudep_simpan). Belum ada baris = aplikasi memakai nilai bawaan (src/config.js).
--   teks   : nama, singkat (nama ambalan), sekolah, alamat, kota, nomorGudep, kwarran, kwarcab, kodeSurat, telepon, email
--   orang  : pembina (Pembina Gudep / Ka Gudep, surat intern sekolah), kamabigus (Kepala Sekolah / Kamabigus, surat keluar sekolah);
--            masing-masing { jabatan, nama, nta, nip }. Pradana dan Pradani TIDAK disimpan di sini: diambil dari anggota Dewan Ambalan
--            (jabatan_dewan). Kunci pradana dan pradani tetap diterima (klien lama) tetapi diabaikan.
-- Aturan isian sama dengan periksaGudep di src/lib/gudepLogic.js (dijaga oleh pengujian).
create function public.sg_gudep_simpan(p_nilai jsonb) returns void
language plpgsql security definer set search_path = public as
$$
declare
  v_teks text[] := array['nama', 'singkat', 'sekolah', 'alamat', 'kota', 'nomorGudep', 'kwarran', 'kwarcab', 'kodeSurat', 'telepon', 'email'];
  v_orang text[] := array['pembina', 'kamabigus', 'pradana', 'pradani'];
  v_batas jsonb := '{"nama":120,"singkat":120,"sekolah":120,"alamat":200,"kota":60,"nomorGudep":40,"kwarran":80,"kwarcab":80,"kodeSurat":30,"telepon":40,"email":100}';
  v_baru jsonb := '{}'::jsonb; v_o jsonb; v_h jsonb; v_k text; v_f text; v_v text;
begin
  perform sigarda.wajib_admin('Hanya Admin Gudep yang dapat mengubah data gudep.');
  if p_nilai is null or jsonb_typeof(p_nilai) <> 'object' then raise exception 'Data gudep tidak sah.'; end if;
  for v_k in select jsonb_object_keys(p_nilai) loop
    if not (v_k = any (v_teks) or v_k = any (v_orang)) then raise exception 'Isian "%" tidak dikenal.', v_k; end if;
  end loop;

  foreach v_k in array v_teks loop
    if p_nilai -> v_k is not null and jsonb_typeof(p_nilai -> v_k) not in ('string', 'null') then raise exception 'Isian "%" harus berupa teks.', v_k; end if;
    v_v := sigarda.rapikan(p_nilai ->> v_k);
    if char_length(v_v) > (v_batas ->> v_k)::int then raise exception 'Isian "%" maksimal % karakter.', v_k, v_batas ->> v_k; end if;
    if v_k in ('nama', 'singkat', 'sekolah', 'kota') and v_v = '' then raise exception 'Isian "%" wajib diisi.', v_k; end if;
    if v_k = 'kodeSurat' and v_v !~ '^[A-Za-z0-9._/-]*$' then raise exception 'Kode surat hanya boleh berisi huruf, angka, dan tanda . _ / -.'; end if;
    if v_k = 'telepon' and v_v !~ '^[0-9 +()./-]*$' then raise exception 'Telepon hanya boleh berisi angka, spasi, dan tanda + ( ) . / -.'; end if;
    if v_k = 'email' and v_v <> '' and v_v !~ '^[^@ ]+@[^@ ]+\.[^@ ]+$' then raise exception 'Alamat email tidak sah.'; end if;
    v_baru := v_baru || jsonb_build_object(v_k, v_v);
  end loop;

  foreach v_k in array v_orang loop
    v_o := coalesce(p_nilai -> v_k, '{}'::jsonb);
    if jsonb_typeof(v_o) <> 'object' then raise exception 'Isian "%" tidak sah.', v_k; end if;
    v_h := '{}'::jsonb;
    for v_f in select jsonb_object_keys(v_o) loop
      if v_f not in ('jabatan', 'nama', 'nta', 'nip') then raise exception 'Isian "%.%" tidak dikenal.', v_k, v_f; end if;
    end loop;
    foreach v_f in array array['jabatan', 'nama', 'nta', 'nip'] loop
      if v_o -> v_f is not null and jsonb_typeof(v_o -> v_f) not in ('string', 'null') then raise exception 'Isian "%.%" harus berupa teks.', v_k, v_f; end if;
      v_v := sigarda.rapikan(v_o ->> v_f);
      if v_f = 'jabatan' and char_length(v_v) > 80 then raise exception 'Jabatan % maksimal 80 karakter.', v_k; end if;
      if v_f = 'nama' and char_length(v_v) > 120 then raise exception 'Nama % maksimal 120 karakter.', v_k; end if;
      if v_f in ('nta', 'nip') and v_v !~ '^[0-9A-Za-z./ -]{0,40}$' then raise exception '% % hanya boleh berisi huruf, angka, spasi, dan tanda / . - (maksimal 40 karakter).', upper(v_f), v_k; end if;
      v_h := v_h || jsonb_build_object(v_f, v_v);
    end loop;
    if v_k = 'pembina' and (v_h ->> 'nama' = '' or v_h ->> 'jabatan' = '') then raise exception 'Nama dan jabatan Pembina Gudep wajib diisi.'; end if;
    if v_k in ('pembina', 'kamabigus') then v_baru := v_baru || jsonb_build_object(v_k, v_h); end if;
  end loop;

  insert into public.pengaturan (kunci, nilai, diubah_oleh, diubah_pada) values ('gudep.data', v_baru, auth.uid(), now())
  on conflict (kunci) do update set nilai = excluded.nilai, diubah_oleh = excluded.diubah_oleh, diubah_pada = excluded.diubah_pada;
end $$;

-- Identitas gudep yang boleh dilihat tanpa login (halaman masuk dan halaman verifikasi): hanya nama gudep, ambalan, sekolah, dan kota.
-- Nama pejabat, NTA, alamat, dan kontak TIDAK dikeluarkan. Belum ada data = objek kosong (aplikasi memakai nilai bawaan).
create function public.sg_gudep_publik() returns jsonb
language sql stable security definer set search_path = public as
$$
  select coalesce(
    (select jsonb_strip_nulls(jsonb_build_object('nama', p.nilai -> 'nama', 'singkat', p.nilai -> 'singkat', 'sekolah', p.nilai -> 'sekolah', 'kota', p.nilai -> 'kota'))
     from public.pengaturan p where p.kunci = 'gudep.data'), '{}'::jsonb)
$$;
-- ===== Ketua sidang (Fase A): fungsi =====
-- Ketua sidang untuk berita acara = anggota Dewan Ambalan berjabatan PEMANGKU ADAT (sebutan "Pemangku Adat Dewan Ambalan"): Dewan Kehormatan Penegak diketuai
-- Pemangku Adat (Jukran Kwarnas 05/2026 Pasal 24 ayat (15), yang menggantikan SK 231/2007; SK Kwarnas 176/2013 butir 7 c). Bila belum ada Pemangku Adat, dipakai Pradana ("Pradana Dewan Ambalan").
-- Bila belum ada keduanya, dipakai pengaturan lama sidang.nama_ketua dan sidang.sebutan_ketua (bawaan: kosong dan "Ketua Dewan Penegak / Pemangku Adat").
-- Cermin ketuaSidang di src/lib/dewanLogic.js (dijaga oleh pengujian).
create function sigarda.ketua_sidang(out o_nama text, out o_sebutan text) language plpgsql stable security definer set search_path = public as
$$
begin
  select sigarda.rapikan(nama), jabatan_dewan || ' Dewan Ambalan' into o_nama, o_sebutan
  from public.profiles
  where jabatan_dewan in ('Pemangku Adat', 'Pradana') and status = 'aktif' and (role = 'peserta' or (role = 'penguji' and jabatan = 'Dewan Ambalan'))
  order by case jabatan_dewan when 'Pemangku Adat' then 0 else 1 end limit 1;
  if not found then
    o_nama := sigarda.pengaturan_teks('sidang.nama_ketua', '');
    o_sebutan := sigarda.pengaturan_teks('sidang.sebutan_ketua', 'Ketua Dewan Penegak / Pemangku Adat');
  end if;
end $$;
-- ===== akhir fungsi ketua sidang =====
-- ===== akhir fungsi gudep =====

-- ===== Beranda publik (Fase 1 landing page): aksi =====
-- Halaman muka publik (landing page) menampilkan isi yang diatur pengurus di menu Kelola Beranda, disimpan pada pengaturan 'beranda.kontak' (satu objek JSON,
-- dibaca semua pengguna yang sudah masuk lewat kebijakan baca_pengaturan; diubah hanya lewat sg_beranda_kontak_simpan). Belum ada baris = beranda hanya
-- menampilkan isi bawaan.
--   teks       : whatsapp, email, telepon, jadwal (jadwal latihan), instagram, youtube, facebook, tiktok, peta (tautan Google Maps)
--   paragraf   : sambutanPembina, sambutanKepsek, cerita (boleh berbaris banyak; baris kosong = pemisah paragraf)
-- Tautan wajib https dengan nama host bertitik (mencegah javascript: dan sejenisnya). Aturan isian sama dengan periksaKontak di src/lib/berandaLogic.js
-- (dijaga oleh pengujian, dibandingkan langsung dengan fungsi ini).
-- Satu baris: semua spasi, tab, dan baris baru berturut-turut menjadi satu spasi, lalu tepi dibuang (btrim saja hanya membuang spasi, bukan tab; itu sebabnya bukan sigarda.rapikan).
create function sigarda.rapikan_baris(p_teks text) returns text language sql immutable as
$$ select btrim(regexp_replace(coalesce(p_teks, ''), '\s+', ' ', 'g')) $$;
-- Berparagraf: baris baru dipertahankan; tab dan spasi ganda menjadi satu spasi; spasi di tepi baris dibuang; baris kosong berturut-turut menjadi satu; tepi teks dibuang.
create function sigarda.rapikan_paragraf(p_teks text) returns text language sql immutable as
$$
  select btrim(regexp_replace(regexp_replace(regexp_replace(regexp_replace(coalesce(p_teks, ''), E'\\r\\n?', E'\n', 'g'), E'[ \\t]+', ' ', 'g'), E' *\\n *', E'\n', 'g'), E'\\n{3,}', E'\n\n', 'g'), E' \n')
$$;

create function public.sg_beranda_kontak_simpan(p_nilai jsonb) returns void
language plpgsql security definer set search_path = public as
$$
declare
  v_teks text[] := array['whatsapp', 'email', 'telepon', 'jadwal', 'instagram', 'youtube', 'facebook', 'tiktok', 'peta'];
  v_para text[] := array['sambutanPembina', 'sambutanKepsek', 'cerita'];
  v_tautan text[] := array['instagram', 'youtube', 'facebook', 'tiktok', 'peta'];
  v_batas jsonb := '{"whatsapp":20,"email":100,"telepon":40,"jadwal":120,"instagram":300,"youtube":300,"facebook":300,"tiktok":300,"peta":300,"sambutanPembina":1500,"sambutanKepsek":1500,"cerita":2000}';
  v_baru jsonb := '{}'::jsonb; v_k text; v_v text;
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pengurus() then raise exception 'Hanya pengurus (Pembina, Admin Gudep, dan Dewan Ambalan) yang dapat mengubah isi beranda.'; end if;
  if p_nilai is null or jsonb_typeof(p_nilai) <> 'object' then raise exception 'Isian beranda tidak sah.'; end if;
  for v_k in select jsonb_object_keys(p_nilai) loop
    if not (v_k = any (v_teks) or v_k = any (v_para)) then raise exception 'Isian "%" tidak dikenal.', v_k; end if;
  end loop;

  foreach v_k in array v_teks || v_para loop
    if p_nilai -> v_k is not null and jsonb_typeof(p_nilai -> v_k) not in ('string', 'null') then raise exception 'Isian "%" harus berupa teks.', v_k; end if;
    v_v := case when v_k = any (v_para) then sigarda.rapikan_paragraf(p_nilai ->> v_k) else sigarda.rapikan_baris(p_nilai ->> v_k) end;
    if char_length(v_v) > (v_batas ->> v_k)::int then raise exception 'Isian "%" maksimal % karakter.', v_k, v_batas ->> v_k; end if;
    if v_k = 'whatsapp' and v_v <> '' and v_v !~ '^[0-9 +()./-]{8,20}$' then raise exception 'Nomor WhatsApp hanya boleh berisi angka, spasi, dan tanda + ( ) . / - (8-20 karakter).'; end if;
    if v_k = 'telepon' and v_v !~ '^[0-9 +()./-]*$' then raise exception 'Telepon hanya boleh berisi angka, spasi, dan tanda + ( ) . / -.'; end if;
    if v_k = 'email' and v_v <> '' and v_v !~ '^[^@ ]+@[^@ ]+\.[^@ ]+$' then raise exception 'Alamat email tidak sah.'; end if;
    if v_k = any (v_tautan) and v_v <> '' and v_v !~ '^https://[A-Za-z0-9.-]+\.[A-Za-z]{2,}([/?#][^ ]*)?$' then raise exception 'Tautan "%" harus diawali https:// dan berupa alamat yang sah.', v_k; end if;
    v_baru := v_baru || jsonb_build_object(v_k, v_v);
  end loop;

  insert into public.pengaturan (kunci, nilai, diubah_oleh, diubah_pada) values ('beranda.kontak', v_baru, auth.uid(), now())
  on conflict (kunci) do update set nilai = excluded.nilai, diubah_oleh = excluded.diubah_oleh, diubah_pada = excluded.diubah_pada;
end $$;

-- Isi beranda yang boleh dilihat TANPA login (hanya membaca), satu panggilan:
--   gudep     : nama, singkat (ambalan), sekolah, kota, alamat, nomorGudep, kwarran, kwarcab (identitas organisasi, bukan data pribadi)
--   pembina, kamabigus : { jabatan, nama } SAJA (NTA dan NIP tidak keluar)
--   kontak    : isian beranda.kontak; email dan telepon yang kosong dilengkapi dari Data Gudep
--   agenda    : paling banyak 6 kegiatan mendatang (hari ini WIB dan sesudahnya) berisi jenis, judul, tanggal SAJA; keterangan dan
--               peserta_terkait tidak pernah keluar
--   berita    : paling banyak 6 berita TERBIT dan sudah waktunya (terbit_pada <= sekarang), terbaru dulu; kategori, judul, ringkasan, isi, sampul, tanggal SAJA
--   prestasi  : paling banyak 6 prestasi TERBIT, tahun terbaru dulu; judul, tingkat, peringkat, tahun, diraih_oleh, foto SAJA (sisanya lewat sg_prestasi_lagi)
--   galeri    : paling banyak 6 album TERBIT, terbaru dulu; judul, tautan, sampul, kelompok SAJA (sisanya lewat sg_galeri_lagi)
--   sosial    : paling banyak 6 kiriman media sosial yang tampil, terbaru dulu; platform, tautan, keterangan, gambar SAJA (sisanya lewat sg_sosial_lagi)
--   faq       : semua pertanyaan umum, urut sesuai pengaturan Pembina/Admin (kosong = klien memakai daftar bawaan)
-- Data anggota, hasil SKU, catatan tinjauan, dan siapa yang menulis/meninjau TIDAK PERNAH keluar dari sini (fungsi ini publik).
create function public.sg_beranda_publik() returns jsonb
language plpgsql stable security definer set search_path = public as
$$
declare
  v_g jsonb := coalesce((select nilai from public.pengaturan where kunci = 'gudep.data'), '{}'::jsonb);
  v_k jsonb := coalesce((select nilai from public.pengaturan where kunci = 'beranda.kontak'), '{}'::jsonb);
begin
  return jsonb_build_object(
    'gudep', jsonb_strip_nulls(jsonb_build_object('nama', v_g -> 'nama', 'singkat', v_g -> 'singkat', 'sekolah', v_g -> 'sekolah', 'kota', v_g -> 'kota',
      'alamat', v_g -> 'alamat', 'nomorGudep', v_g -> 'nomorGudep', 'kwarran', v_g -> 'kwarran', 'kwarcab', v_g -> 'kwarcab')),
    'pembina', jsonb_strip_nulls(jsonb_build_object('jabatan', v_g #> '{pembina,jabatan}', 'nama', v_g #> '{pembina,nama}')),
    'kamabigus', jsonb_strip_nulls(jsonb_build_object('jabatan', v_g #> '{kamabigus,jabatan}', 'nama', v_g #> '{kamabigus,nama}')),
    'kontak', v_k
      || jsonb_build_object('email', coalesce(nullif(v_k ->> 'email', ''), v_g ->> 'email', ''), 'telepon', coalesce(nullif(v_k ->> 'telepon', ''), v_g ->> 'telepon', '')),
    'agenda', coalesce((
      select jsonb_agg(jsonb_build_object('jenis', a.jenis, 'judul', a.judul, 'tanggal', a.tanggal) order by a.tanggal, a.id)
      from (select id, jenis, judul, tanggal from public.agenda where tanggal >= sigarda.hari_ini() order by tanggal, id limit 6) a
    ), '[]'::jsonb),
    'berita', coalesce((
      select jsonb_agg(jsonb_build_object('kategori', b.kategori, 'judul', b.judul, 'ringkasan', b.ringkasan, 'isi', b.isi, 'sampulUrl', b.sampul_url, 'terbitPada', b.terbit_pada) order by b.terbit_pada desc, b.id desc)
      from (select id, kategori, judul, ringkasan, isi, sampul_url, terbit_pada from public.beranda_berita where status = 'terbit' and terbit_pada <= now() order by terbit_pada desc, id desc limit 6) b
    ), '[]'::jsonb),
    'prestasi', coalesce((
      select jsonb_agg(jsonb_build_object('judul', p.judul, 'tingkat', p.tingkat, 'peringkat', p.peringkat, 'tahun', p.tahun, 'diraihOleh', p.diraih_oleh, 'fotoUrl', p.foto_url) order by p.tahun desc, p.id desc)
      from (select id, judul, tingkat, peringkat, tahun, diraih_oleh, foto_url from public.beranda_prestasi where status = 'terbit' order by tahun desc, id desc limit 6) p
    ), '[]'::jsonb),
    'galeri', coalesce((
      select jsonb_agg(jsonb_build_object('judul', g.judul, 'tautan', g.tautan, 'sampulUrl', g.sampul_url, 'kelompok', g.kelompok) order by g.dibuat_pada desc, g.id desc)
      from (select id, judul, tautan, sampul_url, kelompok, dibuat_pada from public.beranda_galeri where status = 'terbit' order by dibuat_pada desc, id desc limit 6) g
    ), '[]'::jsonb),
    'sosial', coalesce((
      select jsonb_agg(jsonb_build_object('platform', s.platform, 'tautan', s.tautan, 'keterangan', s.keterangan, 'gambarUrl', s.gambar_url) order by s.dibuat_pada desc, s.id desc)
      from (select id, platform, tautan, keterangan, gambar_url, dibuat_pada from public.beranda_sosial where tampil order by dibuat_pada desc, id desc limit 6) s
    ), '[]'::jsonb),
    'faq', coalesce((
      select jsonb_agg(jsonb_build_object('pertanyaan', f.pertanyaan, 'jawaban', f.jawaban) order by f.urutan, f.id)
      from public.beranda_faq f
    ), '[]'::jsonb)
  );
end $$;
-- ===== akhir aksi beranda =====
-- ===== Kelola Beranda (Fase 2 landing page): aksi =====
-- Berita, Prestasi, dan Galeri berbagi alur tinjauan yang sama (lihat catatan di 28-tabel-beranda-konten.sql). Fungsi bantu ini hanya
-- menentukan siapa boleh MENGUBAH atau MENGHAPUS satu baris: Pembina dan Admin Gudep kapan saja; penulisnya sendiri selama belum terbit
-- (draf, menunggu, atau ditolak -- termasuk membatalkan pengajuan sendiri).
create function sigarda.beranda_konten_boleh_ubah(p_dibuat_oleh uuid, p_status text) returns boolean
language sql stable security definer set search_path = public as
$$ select sigarda.pembina_atau_admin() or (p_dibuat_oleh = auth.uid() and p_status in ('draf', 'menunggu', 'ditolak')) $$;

-- Nama pengguna saat ini, dirapikan (disalin ke kolom *_nama karena Penegak tak selalu dapat membaca profil pengurus lain di tampilan Dewan lama).
create function sigarda.nama_saya() returns text language sql stable security definer set search_path = public as
$$ select sigarda.rapikan((select nama from public.profiles where id = auth.uid())) $$;

-- ===== Berita =====
-- p_id null = tulis baru. p_status: 'draf' (hanya penulis melihat lewat menu Kelola Beranda), 'menunggu' (diajukan ke Pembina), atau
-- 'terbit' (HANYA Pembina/Admin Gudep; p_terbit_pada boleh masa depan untuk menjadwalkan). Mengubah baris yang sudah 'terbit' juga hanya
-- Pembina/Admin Gudep. Mengembalikan id baris.
create function public.sg_berita_simpan(p_id bigint, p_kategori text, p_judul text, p_ringkasan text, p_isi text, p_sampul_url text, p_status text, p_terbit_pada timestamptz) returns bigint
language plpgsql security definer set search_path = public as
$$
declare
  v_judul text := sigarda.rapikan(p_judul); v_ringkasan text := sigarda.rapikan(p_ringkasan); v_isi text := sigarda.rapikan_paragraf(p_isi);
  v_sampul text := sigarda.rapikan(p_sampul_url); v_status text := coalesce(p_status, 'draf'); v_lama public.beranda_berita; v_id bigint;
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pengurus() then raise exception 'Hanya pengurus (Pembina, Admin Gudep, dan Dewan Ambalan) yang dapat menulis berita.'; end if;
  if p_kategori not in ('kegiatan', 'pengumuman', 'lainnya') then raise exception 'Kategori berita tidak dikenal.'; end if;
  if char_length(v_judul) < 1 or char_length(v_judul) > 150 then raise exception 'Judul berita wajib diisi, maksimal 150 karakter.'; end if;
  if char_length(v_ringkasan) > 200 then raise exception 'Ringkasan berita maksimal 200 karakter.'; end if;
  if char_length(v_isi) < 1 or char_length(v_isi) > 4000 then raise exception 'Isi berita wajib diisi, maksimal 4000 karakter.'; end if;
  if v_sampul <> '' and v_sampul !~ '^https://[A-Za-z0-9.-]+\.[A-Za-z]{2,}([/?#][^ ]*)?$' then raise exception 'Gambar sampul harus diawali https:// dan berupa alamat yang sah.'; end if;
  if v_status not in ('draf', 'menunggu', 'terbit') then raise exception 'Status berita tidak sah.'; end if;
  if v_status = 'terbit' and not sigarda.pembina_atau_admin() then raise exception 'Hanya Pembina dan Admin Gudep yang dapat menerbitkan berita.'; end if;
  if p_terbit_pada is not null and (p_terbit_pada < timestamptz '2015-01-01 00:00:00+07' or p_terbit_pada > now() + interval '366 days') then
    raise exception 'Tanggal terbit tidak sah (paling awal 2015, paling jauh satu tahun ke depan).';
  end if;

  if p_id is not null then
    select * into v_lama from public.beranda_berita where id = p_id;
    if v_lama.id is null then raise exception 'Berita tidak ditemukan.'; end if;
    if not sigarda.beranda_konten_boleh_ubah(v_lama.dibuat_oleh, v_lama.status) then
      raise exception 'Anda hanya dapat mengubah berita sendiri yang belum terbit; berita yang sudah terbit hanya diubah Pembina atau Admin Gudep.';
    end if;
    update public.beranda_berita set kategori = p_kategori, judul = v_judul, ringkasan = v_ringkasan, isi = v_isi, sampul_url = v_sampul,
        status = v_status, terbit_pada = case when v_status = 'terbit' then coalesce(p_terbit_pada, now()) else p_terbit_pada end,
        catatan_tinjauan = case when v_status = 'ditolak' then catatan_tinjauan else '' end, diubah_pada = now()
      where id = p_id returning id into v_id;
  else
    insert into public.beranda_berita (kategori, judul, ringkasan, isi, sampul_url, status, terbit_pada, dibuat_oleh, dibuat_oleh_nama)
      values (p_kategori, v_judul, v_ringkasan, v_isi, v_sampul, v_status, case when v_status = 'terbit' then coalesce(p_terbit_pada, now()) else p_terbit_pada end, auth.uid(), sigarda.nama_saya())
      returning id into v_id;
  end if;
  return v_id;
end $$;

create function public.sg_berita_hapus(p_id bigint) returns void language plpgsql security definer set search_path = public as
$$
declare v_lama public.beranda_berita;
begin
  perform sigarda.wajib_aktif();
  select * into v_lama from public.beranda_berita where id = p_id;
  if v_lama.id is null then raise exception 'Berita tidak ditemukan.'; end if;
  if not sigarda.beranda_konten_boleh_ubah(v_lama.dibuat_oleh, v_lama.status) then
    raise exception 'Anda hanya dapat menghapus berita sendiri yang belum terbit; berita yang sudah terbit hanya dihapus Pembina atau Admin Gudep.';
  end if;
  delete from public.beranda_berita where id = p_id;
end $$;

-- Meninjau pengajuan ('menunggu' saja); p_keputusan 'terbit' menerbitkan seketika, 'ditolak' wajib catatan (minimal 5 karakter).
create function public.sg_berita_tinjau(p_id bigint, p_keputusan text, p_catatan text) returns void language plpgsql security definer set search_path = public as
$$
declare v_catatan text := sigarda.rapikan(p_catatan); v_ada boolean;
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pembina_atau_admin() then raise exception 'Hanya Pembina dan Admin Gudep yang dapat meninjau berita.'; end if;
  if p_keputusan not in ('terbit', 'ditolak') then raise exception 'Keputusan harus terbit atau ditolak.'; end if;
  if p_keputusan = 'ditolak' and char_length(v_catatan) < 5 then raise exception 'Alasan penolakan wajib diisi, minimal 5 karakter.'; end if;
  select true into v_ada from public.beranda_berita where id = p_id and status = 'menunggu';
  if v_ada is null then raise exception 'Pengajuan berita tidak ditemukan atau sudah ditinjau.'; end if;
  update public.beranda_berita set status = p_keputusan, terbit_pada = case when p_keputusan = 'terbit' then coalesce(terbit_pada, now()) else terbit_pada end,
      catatan_tinjauan = case when p_keputusan = 'ditolak' then v_catatan else '' end,
      ditinjau_oleh = auth.uid(), ditinjau_oleh_nama = sigarda.nama_saya(), ditinjau_pada = now(), diubah_pada = now()
    where id = p_id;
end $$;
-- ===== akhir berita =====

-- ===== Prestasi =====
create function public.sg_prestasi_simpan(p_id bigint, p_judul text, p_tingkat text, p_peringkat text, p_tahun int, p_diraih_oleh text, p_foto_url text, p_status text) returns bigint
language plpgsql security definer set search_path = public as
$$
declare
  v_judul text := sigarda.rapikan(p_judul); v_peringkat text := sigarda.rapikan(p_peringkat); v_diraih text := sigarda.rapikan(p_diraih_oleh);
  v_foto text := sigarda.rapikan(p_foto_url); v_status text := coalesce(p_status, 'draf'); v_lama public.beranda_prestasi; v_id bigint;
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pengurus() then raise exception 'Hanya pengurus (Pembina, Admin Gudep, dan Dewan Ambalan) yang dapat menambah prestasi.'; end if;
  if p_tingkat not in ('gudep', 'ranting', 'cabang', 'provinsi', 'nasional') then raise exception 'Tingkat prestasi tidak dikenal.'; end if;
  if char_length(v_judul) < 1 or char_length(v_judul) > 150 then raise exception 'Nama lomba atau penghargaan wajib diisi, maksimal 150 karakter.'; end if;
  if char_length(v_peringkat) < 1 or char_length(v_peringkat) > 60 then raise exception 'Peringkat wajib diisi, maksimal 60 karakter.'; end if;
  if p_tahun is null or p_tahun < 2000 or p_tahun > extract(year from sigarda.hari_ini())::int then raise exception 'Tahun tidak sah.'; end if;
  if char_length(v_diraih) < 1 or char_length(v_diraih) > 150 then raise exception 'Nama regu, tim, atau gudep yang meraih wajib diisi, maksimal 150 karakter.'; end if;
  if v_foto <> '' and v_foto !~ '^https://[A-Za-z0-9.-]+\.[A-Za-z]{2,}([/?#][^ ]*)?$' then raise exception 'Foto harus diawali https:// dan berupa alamat yang sah.'; end if;
  if v_status not in ('draf', 'menunggu', 'terbit') then raise exception 'Status prestasi tidak sah.'; end if;
  if v_status = 'terbit' and not sigarda.pembina_atau_admin() then raise exception 'Hanya Pembina dan Admin Gudep yang dapat menerbitkan prestasi.'; end if;

  if p_id is not null then
    select * into v_lama from public.beranda_prestasi where id = p_id;
    if v_lama.id is null then raise exception 'Prestasi tidak ditemukan.'; end if;
    if not sigarda.beranda_konten_boleh_ubah(v_lama.dibuat_oleh, v_lama.status) then
      raise exception 'Anda hanya dapat mengubah prestasi sendiri yang belum terbit; yang sudah terbit hanya diubah Pembina atau Admin Gudep.';
    end if;
    update public.beranda_prestasi set judul = v_judul, tingkat = p_tingkat, peringkat = v_peringkat, tahun = p_tahun, diraih_oleh = v_diraih,
        foto_url = v_foto, status = v_status, catatan_tinjauan = case when v_status = 'ditolak' then catatan_tinjauan else '' end, diubah_pada = now()
      where id = p_id returning id into v_id;
  else
    insert into public.beranda_prestasi (judul, tingkat, peringkat, tahun, diraih_oleh, foto_url, status, dibuat_oleh, dibuat_oleh_nama)
      values (v_judul, p_tingkat, v_peringkat, p_tahun, v_diraih, v_foto, v_status, auth.uid(), sigarda.nama_saya())
      returning id into v_id;
  end if;
  return v_id;
end $$;

create function public.sg_prestasi_hapus(p_id bigint) returns void language plpgsql security definer set search_path = public as
$$
declare v_lama public.beranda_prestasi;
begin
  perform sigarda.wajib_aktif();
  select * into v_lama from public.beranda_prestasi where id = p_id;
  if v_lama.id is null then raise exception 'Prestasi tidak ditemukan.'; end if;
  if not sigarda.beranda_konten_boleh_ubah(v_lama.dibuat_oleh, v_lama.status) then
    raise exception 'Anda hanya dapat menghapus prestasi sendiri yang belum terbit; yang sudah terbit hanya dihapus Pembina atau Admin Gudep.';
  end if;
  delete from public.beranda_prestasi where id = p_id;
end $$;

create function public.sg_prestasi_tinjau(p_id bigint, p_keputusan text, p_catatan text) returns void language plpgsql security definer set search_path = public as
$$
declare v_catatan text := sigarda.rapikan(p_catatan); v_ada boolean;
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pembina_atau_admin() then raise exception 'Hanya Pembina dan Admin Gudep yang dapat meninjau prestasi.'; end if;
  if p_keputusan not in ('terbit', 'ditolak') then raise exception 'Keputusan harus terbit atau ditolak.'; end if;
  if p_keputusan = 'ditolak' and char_length(v_catatan) < 5 then raise exception 'Alasan penolakan wajib diisi, minimal 5 karakter.'; end if;
  select true into v_ada from public.beranda_prestasi where id = p_id and status = 'menunggu';
  if v_ada is null then raise exception 'Pengajuan prestasi tidak ditemukan atau sudah ditinjau.'; end if;
  update public.beranda_prestasi set status = p_keputusan, catatan_tinjauan = case when p_keputusan = 'ditolak' then v_catatan else '' end,
      ditinjau_oleh = auth.uid(), ditinjau_oleh_nama = sigarda.nama_saya(), ditinjau_pada = now(), diubah_pada = now()
    where id = p_id;
end $$;
-- ===== akhir prestasi =====

-- ===== Galeri =====
create function public.sg_galeri_simpan(p_id bigint, p_judul text, p_tautan text, p_sampul_url text, p_kelompok text, p_status text) returns bigint
language plpgsql security definer set search_path = public as
$$
declare
  v_judul text := sigarda.rapikan(p_judul); v_tautan text := sigarda.rapikan(p_tautan); v_sampul text := sigarda.rapikan(p_sampul_url);
  v_status text := coalesce(p_status, 'draf'); v_lama public.beranda_galeri; v_id bigint;
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pengurus() then raise exception 'Hanya pengurus (Pembina, Admin Gudep, dan Dewan Ambalan) yang dapat menambah album galeri.'; end if;
  if char_length(v_judul) < 1 or char_length(v_judul) > 100 then raise exception 'Nama album wajib diisi, maksimal 100 karakter.'; end if;
  if v_tautan !~ '^https://[A-Za-z0-9.-]+\.[A-Za-z]{2,}([/?#][^ ]*)?$' then raise exception 'Tautan album harus diawali https:// dan berupa alamat yang sah.'; end if;
  if v_sampul <> '' and v_sampul !~ '^https://[A-Za-z0-9.-]+\.[A-Za-z]{2,}([/?#][^ ]*)?$' then raise exception 'Sampul album harus diawali https:// dan berupa alamat yang sah.'; end if;
  if p_kelompok not in ('latihan', 'perkemahan', 'pelantikan', 'lainnya') then raise exception 'Kelompok album tidak dikenal.'; end if;
  if v_status not in ('draf', 'menunggu', 'terbit') then raise exception 'Status album tidak sah.'; end if;
  if v_status = 'terbit' and not sigarda.pembina_atau_admin() then raise exception 'Hanya Pembina dan Admin Gudep yang dapat menampilkan album di beranda.'; end if;

  if p_id is not null then
    select * into v_lama from public.beranda_galeri where id = p_id;
    if v_lama.id is null then raise exception 'Album tidak ditemukan.'; end if;
    if not sigarda.beranda_konten_boleh_ubah(v_lama.dibuat_oleh, v_lama.status) then
      raise exception 'Anda hanya dapat mengubah album sendiri yang belum tampil; yang sudah tampil hanya diubah Pembina atau Admin Gudep.';
    end if;
    update public.beranda_galeri set judul = v_judul, tautan = v_tautan, sampul_url = v_sampul, kelompok = p_kelompok, status = v_status,
        catatan_tinjauan = case when v_status = 'ditolak' then catatan_tinjauan else '' end, diubah_pada = now()
      where id = p_id returning id into v_id;
  else
    insert into public.beranda_galeri (judul, tautan, sampul_url, kelompok, status, dibuat_oleh, dibuat_oleh_nama)
      values (v_judul, v_tautan, v_sampul, p_kelompok, v_status, auth.uid(), sigarda.nama_saya())
      returning id into v_id;
  end if;
  return v_id;
end $$;

create function public.sg_galeri_hapus(p_id bigint) returns void language plpgsql security definer set search_path = public as
$$
declare v_lama public.beranda_galeri;
begin
  perform sigarda.wajib_aktif();
  select * into v_lama from public.beranda_galeri where id = p_id;
  if v_lama.id is null then raise exception 'Album tidak ditemukan.'; end if;
  if not sigarda.beranda_konten_boleh_ubah(v_lama.dibuat_oleh, v_lama.status) then
    raise exception 'Anda hanya dapat menghapus album sendiri yang belum tampil; yang sudah tampil hanya dihapus Pembina atau Admin Gudep.';
  end if;
  delete from public.beranda_galeri where id = p_id;
end $$;

create function public.sg_galeri_tinjau(p_id bigint, p_keputusan text, p_catatan text) returns void language plpgsql security definer set search_path = public as
$$
declare v_catatan text := sigarda.rapikan(p_catatan); v_ada boolean;
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pembina_atau_admin() then raise exception 'Hanya Pembina dan Admin Gudep yang dapat meninjau album galeri.'; end if;
  if p_keputusan not in ('terbit', 'ditolak') then raise exception 'Keputusan harus terbit atau ditolak.'; end if;
  if p_keputusan = 'ditolak' and char_length(v_catatan) < 5 then raise exception 'Alasan penolakan wajib diisi, minimal 5 karakter.'; end if;
  select true into v_ada from public.beranda_galeri where id = p_id and status = 'menunggu';
  if v_ada is null then raise exception 'Pengajuan album tidak ditemukan atau sudah ditinjau.'; end if;
  update public.beranda_galeri set status = p_keputusan, catatan_tinjauan = case when p_keputusan = 'ditolak' then v_catatan else '' end,
      ditinjau_oleh = auth.uid(), ditinjau_oleh_nama = sigarda.nama_saya(), ditinjau_pada = now(), diubah_pada = now()
    where id = p_id;
end $$;
-- ===== akhir galeri =====

-- ===== Media sosial =====
-- Tanpa alur tinjauan: semua pengurus dapat menempel dan langsung tampil. Mengubah/menghapus milik sendiri; Pembina dan Admin Gudep boleh milik siapa pun.
create function public.sg_sosial_simpan(p_id bigint, p_platform text, p_tautan text, p_keterangan text, p_gambar_url text, p_tampil boolean) returns bigint
language plpgsql security definer set search_path = public as
$$
declare
  v_tautan text := sigarda.rapikan(p_tautan); v_ket text := sigarda.rapikan(p_keterangan); v_gbr text := sigarda.rapikan(p_gambar_url);
  v_lama public.beranda_sosial; v_id bigint;
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pengurus() then raise exception 'Hanya pengurus (Pembina, Admin Gudep, dan Dewan Ambalan) yang dapat menempel kiriman media sosial.'; end if;
  if p_platform not in ('instagram', 'youtube', 'facebook', 'tiktok') then raise exception 'Platform tidak dikenal.'; end if;
  if v_tautan !~ '^https://[A-Za-z0-9.-]+\.[A-Za-z]{2,}([/?#][^ ]*)?$' then raise exception 'Tautan kiriman harus diawali https:// dan berupa alamat yang sah.'; end if;
  if char_length(v_ket) > 200 then raise exception 'Keterangan maksimal 200 karakter.'; end if;
  if v_gbr <> '' and v_gbr !~ '^https://[A-Za-z0-9.-]+\.[A-Za-z]{2,}([/?#][^ ]*)?$' then raise exception 'Gambar pratinjau harus diawali https:// dan berupa alamat yang sah.'; end if;
  if p_id is not null then
    select * into v_lama from public.beranda_sosial where id = p_id;
    if v_lama.id is null then raise exception 'Kiriman tidak ditemukan.'; end if;
    if not sigarda.pembina_atau_admin() and v_lama.dibuat_oleh is distinct from auth.uid() then raise exception 'Anda hanya dapat mengubah kiriman milik Anda sendiri.'; end if;
    update public.beranda_sosial set platform = p_platform, tautan = v_tautan, keterangan = v_ket, gambar_url = v_gbr, tampil = coalesce(p_tampil, true), diubah_pada = now()
      where id = p_id returning id into v_id;
  else
    insert into public.beranda_sosial (platform, tautan, keterangan, gambar_url, tampil, dibuat_oleh, dibuat_oleh_nama)
      values (p_platform, v_tautan, v_ket, v_gbr, coalesce(p_tampil, true), auth.uid(), sigarda.nama_saya())
      returning id into v_id;
  end if;
  return v_id;
end $$;

create function public.sg_sosial_hapus(p_id bigint) returns void language plpgsql security definer set search_path = public as
$$
declare v_lama public.beranda_sosial;
begin
  perform sigarda.wajib_aktif();
  select * into v_lama from public.beranda_sosial where id = p_id;
  if v_lama.id is null then raise exception 'Kiriman tidak ditemukan.'; end if;
  if not sigarda.pembina_atau_admin() and v_lama.dibuat_oleh is distinct from auth.uid() then raise exception 'Anda hanya dapat menghapus kiriman milik Anda sendiri.'; end if;
  delete from public.beranda_sosial where id = p_id;
end $$;
-- ===== akhir media sosial =====

-- ===== Pertanyaan umum (FAQ) =====
-- HANYA Pembina dan Admin Gudep (beda dari Berita/Prestasi/Galeri/Media sosial: Dewan Ambalan tidak dapat menulis atau mengusulkan).
create function public.sg_faq_simpan(p_id bigint, p_pertanyaan text, p_jawaban text) returns bigint
language plpgsql security definer set search_path = public as
$$
declare v_p text := sigarda.rapikan(p_pertanyaan); v_j text := sigarda.rapikan(p_jawaban); v_id bigint; v_urutan int;
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pembina_atau_admin() then raise exception 'Hanya Pembina dan Admin Gudep yang dapat mengubah pertanyaan umum.'; end if;
  if char_length(v_p) < 1 or char_length(v_p) > 200 then raise exception 'Pertanyaan wajib diisi, maksimal 200 karakter.'; end if;
  if char_length(v_j) < 1 or char_length(v_j) > 1000 then raise exception 'Jawaban wajib diisi, maksimal 1000 karakter.'; end if;
  if p_id is not null then
    update public.beranda_faq set pertanyaan = v_p, jawaban = v_j, diubah_oleh = auth.uid(), diubah_pada = now() where id = p_id returning id into v_id;
    if v_id is null then raise exception 'Pertanyaan tidak ditemukan.'; end if;
  else
    select coalesce(max(urutan), 0) + 1 into v_urutan from public.beranda_faq;
    insert into public.beranda_faq (pertanyaan, jawaban, urutan, diubah_oleh) values (v_p, v_j, v_urutan, auth.uid()) returning id into v_id;
  end if;
  return v_id;
end $$;

create function public.sg_faq_hapus(p_id bigint) returns void language plpgsql security definer set search_path = public as
$$
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pembina_atau_admin() then raise exception 'Hanya Pembina dan Admin Gudep yang dapat menghapus pertanyaan umum.'; end if;
  delete from public.beranda_faq where id = p_id;
end $$;

-- Menukar urutan dengan tetangga (p_arah < 0 = naik, > 0 = turun); di ujung daftar tidak melakukan apa pun. Pola sama dengan sg_materi_geser.
create function public.sg_faq_geser(p_id bigint, p_arah int) returns void language plpgsql security definer set search_path = public as
$$
declare v_u int; v_tetangga bigint; v_ut int;
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pembina_atau_admin() then raise exception 'Hanya Pembina dan Admin Gudep yang dapat mengubah urutan pertanyaan umum.'; end if;
  select urutan into v_u from public.beranda_faq where id = p_id;
  if v_u is null then return; end if;
  if p_arah < 0 then
    select id, urutan into v_tetangga, v_ut from public.beranda_faq where urutan < v_u order by urutan desc limit 1;
  else
    select id, urutan into v_tetangga, v_ut from public.beranda_faq where urutan > v_u order by urutan asc limit 1;
  end if;
  if v_tetangga is null then return; end if;
  update public.beranda_faq set urutan = case when id = p_id then v_ut else v_u end where id in (p_id, v_tetangga);
end $$;
-- ===== akhir faq =====
-- ===== akhir aksi beranda konten =====

-- ===== Kelola Beranda: notifikasi pengajuan (Fase 3) =====
-- Berita, Prestasi, dan Galeri berbagi satu fungsi (tabel dibedakan lewat TG_TABLE_NAME, kolomnya sama): pengajuan baru atau diajukan ulang
-- (status menjadi 'menunggu') memberi tahu semua Pembina dan Admin Gudep aktif (kecuali pelakunya sendiri, bila kebetulan pengurus); pengajuan
-- yang ditinjau (dari 'menunggu' menjadi 'terbit' atau 'ditolak') memberi tahu penulisnya. Isi tanpa hasil (hanya "diterbitkan"/"ditolak";
-- alasan penolakan dilihat di aplikasi), sama seperti kaidah notifikasi lain.
create function sigarda.notif_beranda_konten() returns trigger language plpgsql security definer set search_path = public as
$$
declare v_x uuid; v_label text; v_kunci text;
begin
  v_label := case TG_TABLE_NAME when 'beranda_berita' then 'Berita' when 'beranda_prestasi' then 'Prestasi' else 'Galeri' end;
  v_kunci := TG_TABLE_NAME || ':' || NEW.id || ':' || NEW.status || ':' || to_char(coalesce(NEW.diubah_pada, now()), 'YYYYMMDDHH24MISS');
  if NEW.status = 'menunggu' and (TG_OP = 'INSERT' or OLD.status is distinct from 'menunggu') then
    for v_x in select id from public.profiles where status = 'aktif' and (role = 'admin' or (role = 'penguji' and jabatan = 'Pembina')) and id is distinct from NEW.dibuat_oleh loop
      perform sigarda.notif_buat(v_x, 'beranda', 'Pengajuan ' || v_label || ' baru',
        coalesce(nullif(NEW.dibuat_oleh_nama, ''), 'Seseorang') || ' mengajukan ' || lower(v_label) || ' "' || NEW.judul || '" di Kelola Beranda.',
        jsonb_build_object('tab', 'kelolaberanda'), v_kunci);
    end loop;
  elsif TG_OP = 'UPDATE' and OLD.status = 'menunggu' and NEW.status in ('terbit', 'ditolak') and NEW.dibuat_oleh is distinct from auth.uid() then
    perform sigarda.notif_buat(NEW.dibuat_oleh, 'beranda', 'Pengajuan ' || v_label || ' ditinjau',
      v_label || ' "' || NEW.judul || '" Anda sudah ' || (case when NEW.status = 'terbit' then 'diterbitkan' else 'ditolak (catatan ada di Kelola Beranda)' end) || '.',
      jsonb_build_object('tab', 'kelolaberanda'), v_kunci);
  end if;
  return null;
end $$;
create trigger notif_berita_status after insert or update of status on public.beranda_berita for each row execute function sigarda.notif_beranda_konten();
create trigger notif_prestasi_status after insert or update of status on public.beranda_prestasi for each row execute function sigarda.notif_beranda_konten();
create trigger notif_galeri_status after insert or update of status on public.beranda_galeri for each row execute function sigarda.notif_beranda_konten();
-- ===== akhir notifikasi beranda konten =====

-- ===== Kelola Beranda: arsip berita publik (Fase 4): aksi =====
-- Semua berita TERBIT yang sudah waktunya (terbit_pada <= sekarang), terbaru dulu, paling banyak 200, TANPA login (hanya membaca). Dipakai build situs untuk
-- membuat satu halaman statis per berita (alamat tetap berdasarkan id, terbaca mesin pencari) dan sitemap; sg_beranda_publik hanya memuat 6 terbaru tanpa id.
-- Kolom: id, kategori, judul, ringkasan, isi, sampulUrl, terbitPada, diubahPada SAJA (tanpa penulis, peninjau, catatan tinjauan, atau status).
create function public.sg_berita_publik() returns jsonb
language sql stable security definer set search_path = public as
$$
  select coalesce(jsonb_agg(jsonb_build_object('id', b.id, 'kategori', b.kategori, 'judul', b.judul, 'ringkasan', b.ringkasan, 'isi', b.isi, 'sampulUrl', b.sampul_url,
    'terbitPada', b.terbit_pada, 'diubahPada', b.diubah_pada) order by b.terbit_pada desc, b.id desc), '[]'::jsonb)
  from (select id, kategori, judul, ringkasan, isi, sampul_url, terbit_pada, diubah_pada from public.beranda_berita
        where status = 'terbit' and terbit_pada <= now() order by terbit_pada desc, id desc limit 200) b
$$;
-- ===== akhir arsip berita publik =====

-- ===== Kelola Beranda: berita lebih lama (tombol "Muat berita lebih lama"): aksi =====
-- Halaman muka menampilkan 6 berita terbaru (sg_beranda_publik). Fungsi ini memberi 6 berita TERBIT berikutnya sesudah p_lewati berita terbaru (yang sudah
-- tampil), TANPA login (hanya membaca), bentuk kolom sama dengan berita pada sg_beranda_publik (tanpa id, penulis, peninjau, atau catatan tinjauan).
-- 'adaLagi' = masih ada berita yang lebih lama lagi (dibaca 7 baris, yang ke-7 tidak dikirim). p_lewati dibatasi 0..1000 supaya tak dapat dipakai memindai tanpa batas.
create function public.sg_berita_lagi(p_lewati int) returns jsonb
language sql stable security definer set search_path = public as
$$
  select jsonb_build_object(
    'berita', coalesce(jsonb_agg(jsonb_build_object('kategori', x.kategori, 'judul', x.judul, 'ringkasan', x.ringkasan, 'isi', x.isi, 'sampulUrl', x.sampul_url,
      'terbitPada', x.terbit_pada) order by x.urut) filter (where x.urut <= 6), '[]'::jsonb),
    'adaLagi', coalesce(bool_or(x.urut > 6), false))
  from (
    select b.kategori, b.judul, b.ringkasan, b.isi, b.sampul_url, b.terbit_pada, row_number() over (order by b.terbit_pada desc, b.id desc) as urut
    from (select id, kategori, judul, ringkasan, isi, sampul_url, terbit_pada from public.beranda_berita
          where status = 'terbit' and terbit_pada <= now() order by terbit_pada desc, id desc
          offset least(greatest(coalesce(p_lewati, 0), 0), 1000) limit 7) b
  ) x
$$;
-- ===== akhir berita lebih lama =====

-- ===== Kelola Beranda: prestasi, galeri, dan media sosial lebih lama (tombol "Muat ... lebih lama"): aksi =====
-- Sama dengan sg_berita_lagi: halaman muka menampilkan 6 yang terbaru (sg_beranda_publik); fungsi-fungsi ini memberi 6 berikutnya sesudah p_lewati yang sudah
-- tampil, TANPA login (hanya membaca), kolom sama dengan yang di sg_beranda_publik (tanpa id, penulis, peninjau, atau catatan tinjauan). 'adaLagi' = masih ada yang
-- lebih lama (dibaca 7 baris, yang ke-7 tidak dikirim). p_lewati dibatasi 0..1000. Urutan SAMA dengan sg_beranda_publik: prestasi menurut tahun (lalu id) terbaru dulu,
-- galeri dan media sosial menurut waktu dibuat terbaru dulu.
create function public.sg_prestasi_lagi(p_lewati int) returns jsonb
language sql stable security definer set search_path = public as
$$
  select jsonb_build_object(
    'prestasi', coalesce(jsonb_agg(jsonb_build_object('judul', x.judul, 'tingkat', x.tingkat, 'peringkat', x.peringkat, 'tahun', x.tahun, 'diraihOleh', x.diraih_oleh,
      'fotoUrl', x.foto_url) order by x.urut) filter (where x.urut <= 6), '[]'::jsonb),
    'adaLagi', coalesce(bool_or(x.urut > 6), false))
  from (
    select p.judul, p.tingkat, p.peringkat, p.tahun, p.diraih_oleh, p.foto_url, row_number() over (order by p.tahun desc, p.id desc) as urut
    from (select id, judul, tingkat, peringkat, tahun, diraih_oleh, foto_url from public.beranda_prestasi
          where status = 'terbit' order by tahun desc, id desc
          offset least(greatest(coalesce(p_lewati, 0), 0), 1000) limit 7) p
  ) x
$$;
create function public.sg_galeri_lagi(p_lewati int) returns jsonb
language sql stable security definer set search_path = public as
$$
  select jsonb_build_object(
    'galeri', coalesce(jsonb_agg(jsonb_build_object('judul', x.judul, 'tautan', x.tautan, 'sampulUrl', x.sampul_url, 'kelompok', x.kelompok) order by x.urut)
      filter (where x.urut <= 6), '[]'::jsonb),
    'adaLagi', coalesce(bool_or(x.urut > 6), false))
  from (
    select g.judul, g.tautan, g.sampul_url, g.kelompok, row_number() over (order by g.dibuat_pada desc, g.id desc) as urut
    from (select id, judul, tautan, sampul_url, kelompok, dibuat_pada from public.beranda_galeri
          where status = 'terbit' order by dibuat_pada desc, id desc
          offset least(greatest(coalesce(p_lewati, 0), 0), 1000) limit 7) g
  ) x
$$;
create function public.sg_sosial_lagi(p_lewati int) returns jsonb
language sql stable security definer set search_path = public as
$$
  select jsonb_build_object(
    'sosial', coalesce(jsonb_agg(jsonb_build_object('platform', x.platform, 'tautan', x.tautan, 'keterangan', x.keterangan, 'gambarUrl', x.gambar_url) order by x.urut)
      filter (where x.urut <= 6), '[]'::jsonb),
    'adaLagi', coalesce(bool_or(x.urut > 6), false))
  from (
    select s.platform, s.tautan, s.keterangan, s.gambar_url, row_number() over (order by s.dibuat_pada desc, s.id desc) as urut
    from (select id, platform, tautan, keterangan, gambar_url, dibuat_pada from public.beranda_sosial
          where tampil order by dibuat_pada desc, id desc
          offset least(greatest(coalesce(p_lewati, 0), 0), 1000) limit 7) s
  ) x
$$;
-- ===== akhir sisa lebih lama =====
-- ===== Dokumen terbit: fungsi aksi =====
-- Menerbitkan surat pengantar ke guru agama untuk butir agama Penegak yang tidak punya Pembina seagama (Pembina atau Admin Gudep).
-- Surat dicetak untuk tanda tangan dan stempel basah; QR memuat token (sg_verifikasi_token). Selama surat berlaku, Pembina mana pun boleh
-- mencatat hasil butir-butir itu (yang dinilai guru agama); riwayat menyebut nama guru dan nomor surat. Hanya butir agama milik Penegak itu.
-- Nomor: dari format pengaturan 'surat.format_nomor' (bawaan {no3}/SP/{tahun}) dan penghitung per tahun, atau diisi manual (p_nomor_manual).
-- Mengembalikan { id, token, nomor }.
create function public.sg_dokumen_surat_agama_terbit(
  p_peserta_id uuid, p_butir text[], p_guru_id bigint, p_guru_nama text, p_tanggal date,
  p_penerbit text, p_penanda_nama text, p_penanda_jabatan text, p_nomor_manual text default null, p_catatan text default ''
) returns jsonb language plpgsql security definer set search_path = public as
$$
declare
  v_uid uuid := auth.uid(); v_p public.profiles; v_pembuat public.profiles; v_butir text[]; v_guru_id bigint; v_guru text; v_guru_ket text := '';
  v_manual text := sigarda.rapikan(p_nomor_manual); v_cat text := btrim(coalesce(p_catatan, '')); v_penerbit text := sigarda.rapikan(p_penerbit);
  v_nama text := sigarda.rapikan(p_penanda_nama); v_jab text := sigarda.rapikan(p_penanda_jabatan);
  v_tahun int; v_urut int; v_nomor text; v_token text := sigarda.token_acak(); v_id bigint; v_b text;
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pembina_atau_admin() then raise exception 'Hanya Pembina atau Admin Gudep yang dapat menerbitkan surat pengantar.'; end if;
  select * into v_p from public.profiles where id = p_peserta_id and role = 'peserta';
  if not found or v_p.agama is null then raise exception 'Peserta tidak ditemukan.'; end if;
  select * into v_pembuat from public.profiles where id = v_uid;
  if exists (select 1 from public.profiles where role = 'penguji' and jabatan = 'Pembina' and agama = v_p.agama) then
    raise exception 'Ada Pembina yang seagama (%) dengan Penegak ini; butir agama diuji oleh Pembina tersebut, jadi surat pengantar tidak diperlukan.', v_p.agama;
  end if;

  select coalesce(array_agg(distinct b order by b), '{}') into v_butir from unnest(coalesce(p_butir, '{}')) b;
  if cardinality(v_butir) = 0 then raise exception 'Pilih sedikitnya satu butir agama.'; end if;
  if cardinality(v_butir) > 30 then raise exception 'Maksimal 30 butir per surat.'; end if;
  foreach v_b in array v_butir loop
    if not exists (select 1 from public.sku_unit where id = v_b and agama = v_p.agama) then
      raise exception 'Butir % bukan butir agama % milik Penegak ini.', v_b, v_p.agama;
    end if;
    if exists (select 1 from public.sku_progress where peserta_id = p_peserta_id and sku_id = v_b and status = 'lulus') then
      raise exception 'Butir % sudah lulus; tidak perlu surat pengantar.', v_b;
    end if;
    if sigarda.surat_agama_aktif(p_peserta_id, v_b) then
      raise exception 'Butir % sudah tercantum pada surat pengantar yang masih berlaku. Cabut surat itu lebih dulu bila perlu membuat ulang.', v_b;
    end if;
  end loop;

  if p_guru_id is not null then
    select id, nama, keterangan into v_guru_id, v_guru, v_guru_ket from public.guru_agama where id = p_guru_id and agama = v_p.agama;
    if not found then raise exception 'Guru agama yang dipilih tidak terdaftar untuk agama %.', v_p.agama; end if;
  else
    v_guru := sigarda.rapikan(p_guru_nama);
    if v_guru = '' then raise exception 'Pilih guru agama atau tulis namanya.'; end if;
    if char_length(v_guru) > 120 then raise exception 'Nama guru agama maksimal 120 karakter.'; end if;
  end if;
  if p_tanggal is null or p_tanggal < date '2000-01-01' or p_tanggal > sigarda.hari_ini() + 30 then raise exception 'Tanggal surat tidak valid.'; end if;
  if v_penerbit = '' or char_length(v_penerbit) > 120 then raise exception 'Nama penerbit wajib diisi (maksimal 120 karakter).'; end if;
  if v_nama = '' or char_length(v_nama) > 120 then raise exception 'Nama penanda tangan wajib diisi (maksimal 120 karakter).'; end if;
  if v_jab = '' or char_length(v_jab) > 80 then raise exception 'Jabatan penanda tangan wajib diisi (maksimal 80 karakter).'; end if;
  if char_length(v_cat) > 300 then raise exception 'Catatan maksimal 300 karakter.'; end if;

  v_tahun := extract(year from p_tanggal)::int;
  if v_manual <> '' then
    if char_length(v_manual) > 80 then raise exception 'Nomor surat maksimal 80 karakter.'; end if;
    v_nomor := v_manual;
  else
    insert into public.dokumen_urut as u (jenis, tahun, terakhir) values ('surat_pengantar_agama', v_tahun, 1)
    on conflict (jenis, tahun) do update set terakhir = u.terakhir + 1
    returning u.terakhir into v_urut;
    v_nomor := sigarda.format_nomor(sigarda.pengaturan_teks('surat.format_nomor', '{no3}/SP/{tahun}'), v_urut, p_tanggal, '');
  end if;
  if exists (select 1 from public.dokumen_terbit where nomor = v_nomor) then raise exception 'Nomor surat % sudah dipakai.', v_nomor; end if;

  insert into public.dokumen_terbit (
    token, kode, jenis, nomor, nomor_urut, tanggal, peserta_id, peserta_nama, penerbit, dibuat_oleh, dibuat_oleh_nama, dibuat_oleh_jabatan,
    penanda_tangan_nama, penanda_tangan_jabatan, payload
  ) values (
    v_token, sigarda.kode_verifikasi(array[v_token, 'surat_pengantar_agama', v_nomor]), 'surat_pengantar_agama', v_nomor, v_urut, p_tanggal,
    p_peserta_id, v_p.nama, v_penerbit, v_uid, v_pembuat.nama, coalesce(v_pembuat.jabatan, ''), v_nama, v_jab,
    jsonb_build_object('agama', v_p.agama, 'nis', coalesce(v_p.nis, ''), 'kelas', coalesce(v_p.kelas, ''), 'sangga', coalesce(v_p.sangga, ''),
      'guru', jsonb_build_object('id', v_guru_id, 'nama', v_guru, 'keterangan', v_guru_ket), 'butir', to_jsonb(v_butir), 'catatan', v_cat)
  ) returning id into v_id;

  foreach v_b in array v_butir loop
    insert into public.sku_riwayat (peserta_id, sku_id, teks, oleh)
    values (p_peserta_id, v_b, 'Surat pengantar nomor ' || v_nomor || ' diterbitkan untuk guru agama ' || v_guru, v_uid);
  end loop;
  return jsonb_build_object('id', v_id, 'token', v_token, 'nomor', v_nomor);
end $$;

-- Mencabut surat (mis. salah isi atau Pembina seagama sudah ada). Setelah dicabut, hasil butir tidak lagi dapat dicatat lewat surat itu,
-- dan QR-nya menjawab "dicabut". Alasan wajib dan tercatat di riwayat butir.
create function public.sg_dokumen_cabut(p_id bigint, p_alasan text) returns void
language plpgsql security definer set search_path = public as
$$
declare v_d public.dokumen_terbit; v_alasan text := sigarda.rapikan(p_alasan); v_b text;
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pembina_atau_admin() then raise exception 'Hanya Pembina atau Admin Gudep yang dapat mencabut surat.'; end if;
  select * into v_d from public.dokumen_terbit where id = p_id;
  if not found then raise exception 'Dokumen tidak ditemukan.'; end if;
  if v_d.dicabut_pada is not null then raise exception 'Dokumen ini sudah dicabut.'; end if;
  if v_alasan = '' then raise exception 'Isi alasan pencabutan.'; end if;
  if char_length(v_alasan) > 200 then raise exception 'Alasan maksimal 200 karakter.'; end if;
  update public.dokumen_terbit set dicabut_pada = now(), dicabut_oleh = auth.uid(), dicabut_alasan = v_alasan where id = p_id;
  if v_d.peserta_id is not null then
    for v_b in select jsonb_array_elements_text(v_d.payload -> 'butir') loop
      insert into public.sku_riwayat (peserta_id, sku_id, teks, oleh)
      values (v_d.peserta_id, v_b, 'Surat pengantar nomor ' || v_d.nomor || ' dicabut. Alasan: ' || v_alasan, auth.uid());
    end loop;
  end if;
end $$;
-- ===== akhir fungsi dokumen =====

-- ===== Notifikasi: fungsi aksi =====
-- Menandai notifikasi milik sendiri sebagai dibaca (p_ids kosong = semua yang belum dibaca). Mengembalikan jumlah yang berubah.
create function public.sg_notifikasi_tandai(p_ids bigint[] default null) returns int language plpgsql security definer set search_path = public as
$$
declare v_n int;
begin
  perform sigarda.wajib_aktif();
  update public.notifikasi set dibaca_pada = now()
    where penerima_id = auth.uid() and dibaca_pada is null and (p_ids is null or id = any (p_ids));
  get diagnostics v_n = row_count;
  return v_n;
end $$;

-- Kunci publik VAPID untuk berlangganan Web Push; kosong bila push belum diatur di server.
create function public.sg_push_kunci() returns text language plpgsql stable security definer set search_path = public as
$$
begin
  perform sigarda.wajib_aktif();
  return (select kunci_publik from public.push_konfigurasi);
end $$;

-- Mendaftarkan perangkat ini untuk akun yang sedang masuk. Perangkat yang sama (endpoint) dialihkan ke akun ini bila sebelumnya milik akun lain.
-- ===== Notifikasi uji: fungsi =====
-- Tombol "Kirim notifikasi uji" di halaman Notifikasi (semua peran): membuat satu notifikasi jenis 'tes' untuk pemanggil sendiri. Pemicu yang sama dengan
-- notifikasi sungguhan (notifikasi_push -> pg_net -> Edge Function notif-push) mengirimnya ke perangkat yang berlangganan, sehingga seluruh jalur dapat diuji
-- tanpa menunggu kejadian nyata. Dibatasi 5 kali per 10 menit. Hasil { id, perangkat (jumlah perangkat berlangganan), terkonfigurasi (push_atur sudah dijalankan),
-- pg_net (ekstensi terpasang) } agar klien dapat menjelaskan bila tidak ada yang terkirim; push_status pada baris notifikasi terisi kemudian oleh Edge Function.
create function public.sg_notifikasi_tes() returns jsonb
language plpgsql security definer set search_path = public as
$$
declare v_uid uuid := auth.uid(); v_id bigint;
begin
  perform sigarda.wajib_aktif();
  if (select count(*) from public.notifikasi where penerima_id = v_uid and jenis = 'tes' and dibuat > now() - interval '10 minutes') >= 5 then
    raise exception 'Terlalu sering. Tunggu beberapa menit sebelum mengirim notifikasi uji lagi.';
  end if;
  insert into public.notifikasi (penerima_id, jenis, judul, isi, tautan)
  values (v_uid, 'tes', 'Notifikasi uji', 'Bila Anda membaca ini, notifikasi SIGARDA berfungsi di perangkat ini.', '{"tab":"notifikasi"}'::jsonb)
  returning id into v_id;
  return jsonb_build_object('id', v_id,
    'perangkat', (select count(*) from public.push_langganan where penerima_id = v_uid),
    'terkonfigurasi', exists (select 1 from public.push_konfigurasi),
    'pg_net', to_regnamespace('net') is not null);
end $$;
-- ===== akhir fungsi notifikasi uji =====

create function public.sg_push_simpan(p_endpoint text, p_p256dh text, p_auth text, p_agen text default '') returns void
language plpgsql security definer set search_path = public as
$$
begin
  perform sigarda.wajib_aktif();
  if auth.uid() is null then raise exception 'Masuk lebih dulu.'; end if;
  if p_endpoint is null or p_endpoint !~ '^https://' or char_length(p_endpoint) > 1000 then raise exception 'Alamat langganan tidak valid.'; end if;
  insert into public.push_langganan (penerima_id, endpoint, p256dh, auth, agen)
  values (auth.uid(), p_endpoint, coalesce(p_p256dh, ''), coalesce(p_auth, ''), left(coalesce(p_agen, ''), 200))
  on conflict (endpoint) do update
    set penerima_id = auth.uid(), p256dh = excluded.p256dh, auth = excluded.auth, agen = excluded.agen, diperbarui = now();
end $$;

-- Berhenti berlangganan di perangkat ini (dipanggil saat Keluar atau dimatikan). Hanya perangkat milik akun sendiri.
create function public.sg_push_hapus(p_endpoint text) returns void language plpgsql security definer set search_path = public as
$$
begin
  perform sigarda.wajib_aktif();
  delete from public.push_langganan where endpoint = p_endpoint and penerima_id = auth.uid();
end $$;

-- ===== Ringkasan perangkat notifikasi: fungsi (dipakai migrasi periksa-dewan) =====
-- Pengurus (Pembina, Dewan Ambalan, Admin): berapa anggota yang punya perangkat notifikasi, dan siapa yang belum.
-- Dewan Ambalan ikut membantu memeriksa (migrasi periksa-dewan); tombol WhatsApp per orang dibatasi di klien menurut peran (eskalasiLogic.bolehDihubungi).
create function public.sg_push_ringkasan() returns jsonb language plpgsql stable security definer set search_path = public as
$$
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pengurus() then raise exception 'Hanya pengurus (Pembina, Dewan Ambalan, dan Admin Gudep) yang dapat melihat ringkasan perangkat.'; end if;
  return (
    with a as (
      select p.id, p.nama, p.role, p.jabatan, p.kelas, exists (select 1 from public.push_langganan l where l.penerima_id = p.id) as ada
      from public.profiles p where p.role in ('peserta', 'penguji') and p.status = 'aktif'
    )
    select jsonb_build_object(
      'total', (select count(*) from a),
      'aktif', (select count(*) from a where ada),
      'tanpa', coalesce((select jsonb_agg(jsonb_build_object('id', t.id, 'nama', t.nama, 'peran', case when t.role = 'peserta' then 'Penegak' else t.jabatan end, 'kelas', t.kelas)
                                          order by t.role desc, t.nama)
                         from (select * from a where not ada order by role desc, nama limit 1000) t), '[]'::jsonb),
      'terkonfigurasi', exists (select 1 from public.push_konfigurasi)
    )
  );
end $$;
-- ===== akhir ringkasan perangkat notifikasi =====

-- ===== Pemeriksaan data (tahap L3): fungsi =====
-- Pengurus (Pembina, Dewan Ambalan, Admin; Dewan ikut membantu memeriksa sejak migrasi periksa-dewan): ringkasan masalah kualitas data yang umum ditemui (kelas belum format rombel baku, NTA kosong, jenis kelamin kosong,
-- rombel tanpa penugasan penguji, Pembina tanpa agama, akun yang belum pernah masuk; dan untuk pra-uji (Fase E): praUjiAktif, rombel tanpa 2 Bina Damping, sangga tanpa Pinsa,
-- pra-uji yang macet). Tiga daftar pra-uji hanya ditampilkan klien bila praUjiAktif. Sebagian besar hanya dapat diperbaiki Admin Gudep
-- (lihat sg_anggota_jk_atur, sg_rombel_perbarui, sg_anggota_nta_atur, sg_anggota_agama_atur); Pembina tetap dapat melihatnya agar tahu apa
-- yang perlu diminta ke Admin. "Perangkat tanpa notifikasi" TIDAK diulang di sini: sudah ada di sg_push_ringkasan. Tiap daftar dibatasi 300 baris.
create function public.sg_pemeriksaan_data() returns jsonb
language plpgsql stable security definer set search_path = public as
$$
declare v_ta text := sigarda.tahun_ajaran_kini(); v_hasil jsonb;
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pengurus() then raise exception 'Hanya pengurus (Pembina, Dewan Ambalan, dan Admin Gudep) yang dapat melihat pemeriksaan data.'; end if;
  v_hasil := jsonb_build_object(
    'praUjiAktif', sigarda.pra_uji_aktif(),
    'kelasLama', coalesce((
      select jsonb_agg(jsonb_build_object('id', x.id, 'nama', x.nama, 'nis', x.nis, 'kelas', x.kelas) order by x.nis)
      from (select id, nama, nis, kelas from public.profiles where role = 'peserta' and status = 'aktif' and not sigarda.rombel_sah(kelas) limit 300) x
    ), '[]'::jsonb),
    'tanpaNta', coalesce((
      select jsonb_agg(jsonb_build_object('id', x.id, 'nama', x.nama, 'nis', x.nis, 'kelas', x.kelas) order by x.nis)
      from (select id, nama, nis, kelas from public.profiles where role = 'peserta' and status = 'aktif' and (nta is null or btrim(nta) = '') limit 300) x
    ), '[]'::jsonb),
    'tanpaJk', coalesce((
      select jsonb_agg(jsonb_build_object('id', x.id, 'nama', x.nama, 'nis', x.nis, 'kelas', x.kelas, 'peran', x.peran) order by x.peran, x.nama)
      from (select id, nama, nis, kelas, case when role = 'peserta' then 'Penegak' when role = 'admin' then 'Admin Gudep' else coalesce(jabatan, 'Dewan Ambalan') end as peran
            from public.profiles where status = 'aktif' and jenis_kelamin is null limit 300) x
    ), '[]'::jsonb),
    'rombelTanpaPenguji', coalesce((
      select jsonb_agg(jsonb_build_object('rombel', x.rombel, 'jumlah', x.jumlah) order by x.rombel)
      from (
        select rb.rombel, (select count(*) from public.profiles p2 where p2.role = 'peserta' and p2.status = 'aktif' and p2.kelas = rb.rombel) as jumlah
        from (select k || '-' || lpad(n::text, 2, '0') as rombel from (values ('X'), ('XI'), ('XII')) t(k), generate_series(1, 10) n) rb
        where exists (select 1 from public.profiles p2 where p2.role = 'peserta' and p2.status = 'aktif' and p2.kelas = rb.rombel)
          and not exists (select 1 from public.penugasan_rombel r where r.tahun_ajaran = v_ta and r.rombel = rb.rombel)
      ) x
    ), '[]'::jsonb),
    'rombelTanpaBinaDamping', coalesce((
      select jsonb_agg(jsonb_build_object('rombel', x.rombel, 'jumlah', x.jumlah, 'binaDamping', x.bd) order by x.rombel)
      from (
        select rb.rombel, (select count(*) from public.profiles p2 where p2.role = 'peserta' and p2.status = 'aktif' and p2.kelas = rb.rombel) as jumlah,
               (select count(*) from public.bina_damping b where b.tahun_ajaran = v_ta and b.rombel = rb.rombel) as bd
        from (select k || '-' || lpad(n::text, 2, '0') as rombel from (values ('X'), ('XI'), ('XII')) t(k), generate_series(1, 10) n) rb
        where exists (select 1 from public.profiles p2 where p2.role = 'peserta' and p2.status = 'aktif' and p2.kelas = rb.rombel)
          and (select count(*) from public.bina_damping b where b.tahun_ajaran = v_ta and b.rombel = rb.rombel) < 2
      ) x
    ), '[]'::jsonb),
    'sanggaTanpaPinsa', coalesce((
      select jsonb_agg(jsonb_build_object('rombel', x.kelas, 'sangga', x.sangga, 'jumlah', x.jumlah) order by x.kelas, x.sangga)
      from (
        -- Pinsa sebuah sangga: anggota berstatus Pinsa, atau Penegak yang ditugaskan (pinsa_tugas) ke sangga itu.
        select g.kelas, g.sangga, g.jumlah from (
          select p.kelas, lower(btrim(p.sangga)) as kunci, min(p.sangga) as sangga, count(*) as jumlah, bool_or(p.pinsa) as ada
          from public.profiles p
          where p.role = 'peserta' and p.status = 'aktif' and sigarda.rombel_sah(p.kelas) and btrim(coalesce(p.sangga, '')) <> ''
          group by p.kelas, lower(btrim(p.sangga))
        ) g
        where not g.ada and not exists (select 1 from public.pinsa_tugas t where t.tahun_ajaran = v_ta and t.rombel = g.kelas and lower(t.sangga) = g.kunci)
        limit 300
      ) x
    ), '[]'::jsonb),
    'praUjiMacet', coalesce((
      select jsonb_agg(jsonb_build_object('id', x.id, 'nama', x.nama, 'kelas', x.kelas, 'butir', x.butir, 'tahap', x.tahap, 'hari', x.hari, 'tanpaPenilai', x.tanpa_penilai) order by x.hari desc)
      from (
        select r.id, p.nama, p.kelas, sigarda.notif_label_butir(r.sku_id) as butir, r.tahap, floor(extract(epoch from now() - r.dibuat) / 86400)::int as hari,
               not exists (select 1 from sigarda.pra_uji_penilai_daftar(r.peserta_id, r.sku_id, r.tahap)) as tanpa_penilai
        from public.sku_pra_uji r join public.profiles p on p.id = r.peserta_id
        where r.status = 'menunggu'
          and (r.dibuat < now() - interval '3 days' or not exists (select 1 from sigarda.pra_uji_penilai_daftar(r.peserta_id, r.sku_id, r.tahap)))
        limit 300
      ) x
    ), '[]'::jsonb),
    'pembinaTanpaAgama', coalesce((
      select jsonb_agg(jsonb_build_object('id', x.id, 'nama', x.nama) order by x.nama)
      from (select id, nama from public.profiles where role = 'penguji' and jabatan = 'Pembina' and status = 'aktif' and agama is null limit 300) x
    ), '[]'::jsonb),
    -- Data diri Penegak yang belum lengkap (Tahap 3, H1): isian POKOK saja (WhatsApp, jenis kelamin, agama, tanggal lahir, tempat lahir, alamat, nama ayah/ibu/wali; cermin
    -- isianLogic.POKOK). Hanya nama dan KODE isian yang kurang, tidak pernah nilainya (bukan data pribadi). Diisi Penegak sendiri, jadi tanpa tombol perbaiki.
    'dataDiriBelum', coalesce((
      select jsonb_agg(jsonb_build_object('id', x.id, 'nama', x.nama, 'nis', x.nis, 'kelas', x.kelas, 'kurang', to_jsonb(x.kurang)) order by x.kelas, x.nama)
      from (
        select y.* from (
          select p.id, p.nama, p.nis, p.kelas,
            array_remove(array[
              case when p.whatsapp is null or btrim(p.whatsapp) = '' then 'whatsapp' end,
              case when p.jenis_kelamin is null then 'jk' end,
              case when p.agama is null then 'agama' end,
              case when not exists (select 1 from public.tanggal_lahir t where t.peserta_id = p.id) then 'lahir' end,
              case when not exists (select 1 from public.penegak_isian i where i.peserta_id = p.id and i.kunci = 'tempat_lahir') then 'tempat_lahir' end,
              case when not exists (select 1 from public.penegak_isian i where i.peserta_id = p.id and i.kunci = 'alamat') then 'alamat' end,
              case when not exists (select 1 from public.penegak_isian i where i.peserta_id = p.id and i.kunci in ('ayah_nama', 'ibu_nama', 'wali_nama')) then 'ortu' end
            ], null) as kurang
          from public.profiles p where p.role = 'peserta' and p.status = 'aktif' and not p.tanpa_akun and not sigarda.kelas_siaga(p.kelas)
        ) y where cardinality(y.kurang) > 0 order by y.kelas, y.nama limit 300
      ) x
    ), '[]'::jsonb),
    -- Safe From Harm (Tahap 4): anggota dewasa aktif yang catatannya belum lengkap. Pembina: pelatihan, pakta_integritas, rekam_jejak; Admin Gudep: pelatihan (kode yang kurang).
    'sfhBelum', coalesce((
      select jsonb_agg(jsonb_build_object('id', x.id, 'nama', x.nama, 'peran', x.peran, 'kurang', to_jsonb(x.kurang)) order by x.peran, x.nama)
      from (
        select y.* from (
          select p.id, p.nama, case when p.role = 'admin' then 'Admin Gudep' else 'Pembina' end as peran,
            array_remove(array[
              case when not exists (select 1 from public.sfh_catatan s where s.anggota_id = p.id and s.jenis = 'pelatihan') then 'pelatihan' end,
              case when p.role = 'penguji' and not exists (select 1 from public.sfh_catatan s where s.anggota_id = p.id and s.jenis = 'pakta_integritas') then 'pakta_integritas' end,
              case when p.role = 'penguji' and not exists (select 1 from public.sfh_catatan s where s.anggota_id = p.id and s.jenis = 'rekam_jejak') then 'rekam_jejak' end
            ], null) as kurang
          from public.profiles p
          where p.status = 'aktif' and (p.role = 'admin' or (p.role = 'penguji' and p.jabatan = 'Pembina'))
        ) y where cardinality(y.kurang) > 0 order by y.peran, y.nama limit 300
      ) x
    ), '[]'::jsonb),
    'belumPernahMasuk', coalesce((
      select jsonb_agg(jsonb_build_object('id', x.id, 'nama', x.nama, 'peran', x.peran, 'dibuat', x.dibuat) order by x.dibuat)
      from (
        select p.id, p.nama, case when p.role = 'peserta' then 'Penegak' when p.role = 'admin' then 'Admin Gudep' else coalesce(p.jabatan, 'Dewan Ambalan') end as peran, p.dibuat
        from public.profiles p join auth.users u on u.id = p.id
        where p.status = 'aktif' and u.last_sign_in_at is null
        limit 300
      ) x
    ), '[]'::jsonb)
  );
  -- Jumlah SEBENARNYA untuk daftar yang bisa lebih dari 300 baris (700 Penegak: hari peluncuran data diri dan NTA belum terisi): dihitung hanya bila daftarnya penuh, jadi
  -- biasanya tanpa biaya tambahan. Klien menampilkan "300 dari N" (pemeriksaanLogic.jumlahKategori).
  return v_hasil || jsonb_build_object('jumlahSebenarnya', jsonb_build_object(
    'kelasLama', case when jsonb_array_length(v_hasil -> 'kelasLama') < 300 then jsonb_array_length(v_hasil -> 'kelasLama')
      else (select count(*) from public.profiles where role = 'peserta' and status = 'aktif' and not sigarda.rombel_sah(kelas)) end,
    'tanpaNta', case when jsonb_array_length(v_hasil -> 'tanpaNta') < 300 then jsonb_array_length(v_hasil -> 'tanpaNta')
      else (select count(*) from public.profiles where role = 'peserta' and status = 'aktif' and (nta is null or btrim(nta) = '')) end,
    'tanpaJk', case when jsonb_array_length(v_hasil -> 'tanpaJk') < 300 then jsonb_array_length(v_hasil -> 'tanpaJk')
      else (select count(*) from public.profiles where status = 'aktif' and jenis_kelamin is null) end,
    'dataDiriBelum', case when jsonb_array_length(v_hasil -> 'dataDiriBelum') < 300 then jsonb_array_length(v_hasil -> 'dataDiriBelum')
      else (select count(*) from public.profiles p where p.role = 'peserta' and p.status = 'aktif' and not p.tanpa_akun and not sigarda.kelas_siaga(p.kelas) and (
        p.whatsapp is null or btrim(p.whatsapp) = '' or p.jenis_kelamin is null or p.agama is null
        or not exists (select 1 from public.tanggal_lahir t where t.peserta_id = p.id)
        or not exists (select 1 from public.penegak_isian i where i.peserta_id = p.id and i.kunci = 'tempat_lahir')
        or not exists (select 1 from public.penegak_isian i where i.peserta_id = p.id and i.kunci = 'alamat')
        or not exists (select 1 from public.penegak_isian i where i.peserta_id = p.id and i.kunci in ('ayah_nama', 'ibu_nama', 'wali_nama')))) end,
    'belumPernahMasuk', case when jsonb_array_length(v_hasil -> 'belumPernahMasuk') < 300 then jsonb_array_length(v_hasil -> 'belumPernahMasuk')
      else (select count(*) from public.profiles p join auth.users u on u.id = p.id where p.status = 'aktif' and u.last_sign_in_at is null) end
  ));
end $$;
-- ===== akhir fungsi pemeriksaan data =====

-- ===== Cadangan (tahap L4): fungsi =====
-- Ekspor manual dari menu Data Gudep (Admin Gudep): satu berkas JSON berisi isi tabel data aplikasi, untuk disimpan sendiri sebagai
-- cadangan ringan tanpa layanan berbayar. TIDAK menyentuh auth.users/auth.identities atau hash PIN sama sekali: bila database perlu
-- dipulihkan, akun dibuat ulang lewat undang anggota (PIN baru), baru berkas ini dipulihkan manual bila perlu. Tabel yang berisi
-- rahasia atau bersifat sementara (login_gagal, push_konfigurasi, push_langganan, notifikasi) TIDAK disertakan. Untuk cadangan penuh
-- level basis data (termasuk akun login), tetap pakai Cadangkan-SIGARDA.bat. Memanggil fungsi ini mencatat waktunya (pengaturan
-- 'cadangan.terakhir') supaya pengingat bulanan (sigarda.notif_pengingat) berhenti selama cadangan masih baru.
create function public.sg_cadangan_admin() returns jsonb language plpgsql security definer set search_path = public as
$$
declare v_hasil jsonb;
begin
  perform sigarda.wajib_admin('Hanya Admin Gudep yang dapat mengunduh cadangan.');
  select jsonb_build_object(
    'dibuat_pada', now(),
    'tabel', jsonb_build_object(
      'profiles', (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from public.profiles t),
      'sku_butir', (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from public.sku_butir t),
      'sku_unit', (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from public.sku_unit t),
      'pf_item', (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from public.pf_item t),
      'sku_progress', (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from public.sku_progress t),
      'sku_riwayat', (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from public.sku_riwayat t),
      'absensi_sesi', (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from public.absensi_sesi t),
      'absensi_hadir', (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from public.absensi_hadir t),
      'iuran', (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from public.iuran t),
      'iuran_log', (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from public.iuran_log t),
      'iuran_kas', (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from public.iuran_kas t),
      'asisten_iuran', (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from public.asisten_iuran t),
      'penugasan_rombel', (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from public.penugasan_rombel t),
      'penugasan_log', (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from public.penugasan_log t),
      'penugasan_peserta', (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from public.penugasan_peserta t),
      'kepengurusan_log', (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from public.kepengurusan_log t),
      'pengukuhan_dewan', (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from public.pengukuhan_dewan t),
      'guru_agama', (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from public.guru_agama t),
      'dokumen_terbit', (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from public.dokumen_terbit t),
      'dokumen_urut', (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from public.dokumen_urut t),
      'naik_kelas_batch', (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from public.naik_kelas_batch t),
      'naik_kelas_log', (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from public.naik_kelas_log t),
      'portofolio', (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from public.portofolio t),
      'portofolio_jurnal', (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from public.portofolio_jurnal t),
      'materi', (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from public.materi t),
      'pengaturan', (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from public.pengaturan t),
      'sidang_urut', (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from public.sidang_urut t),
      'sidang_dk', (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from public.sidang_dk t),
      'raport', (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from public.raport t),
      'instrumen', (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from public.instrumen t),
      'instrumen_kriteria', (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from public.instrumen_kriteria t),
      'instrumen_penguji', (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from public.instrumen_penguji t),
      'instrumen_panduan', (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from public.instrumen_panduan t),
      'sku_penilaian', (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from public.sku_penilaian t),
      'sertifikat_tingkat', (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from public.sertifikat_tingkat t),
      'sesi_ujian', (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from public.sesi_ujian t),
      'sesi_ujian_butir', (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from public.sesi_ujian_butir t),
      'sesi_ujian_peserta', (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from public.sesi_ujian_peserta t)
    -- PostgreSQL membatasi 100 argumen per fungsi (50 pasang): daftar tabel dibagi dua objek yang digabung dengan ||
    ) || jsonb_build_object(
      'agenda', (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from public.agenda t),
      'kegiatan_usulan', (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from public.kegiatan_usulan t),
      'bina_damping', (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from public.bina_damping t),
      'pinsa_tugas', (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from public.pinsa_tugas t),
      'sku_pra_uji', (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from public.sku_pra_uji t),
      'pelantikan', (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from public.pelantikan t),
      'saka_anggota', (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from public.saka_anggota t),
      'tkk_capaian', (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from public.tkk_capaian t),
      'tkk_krida', (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from public.tkk_krida t),
      'tkk_pengajuan', (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from public.tkk_pengajuan t),
      'spg_penetapan', (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from public.spg_penetapan t),
      'tanggal_lahir', (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from public.tanggal_lahir t),
      'tim_penilai', (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from public.tim_penilai t),
      'tim_penilai_anggota', (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from public.tim_penilai_anggota t),
      'garuda_tahap', (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from public.garuda_tahap t),
      'penegak_isian', (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from public.penegak_isian t),
      'dokumen_templat', (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from public.dokumen_templat t),
      'portofolio_snapshot', (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from public.portofolio_snapshot t),
      'siaga_garuda', (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from public.siaga_garuda t),
      'tkk_siaga', (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from public.tkk_siaga t),
      'tabungan_cek', (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from public.tabungan_cek t),
      'sfh_catatan', (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from public.sfh_catatan t),
      'beranda_berita', (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from public.beranda_berita t),
      'beranda_prestasi', (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from public.beranda_prestasi t),
      'beranda_galeri', (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from public.beranda_galeri t),
      'beranda_sosial', (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from public.beranda_sosial t),
      'beranda_faq', (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from public.beranda_faq t)
    )
  ) into v_hasil;
  insert into public.pengaturan (kunci, nilai, diubah_oleh, diubah_pada)
    values ('cadangan.terakhir', jsonb_build_object('pada', now(), 'oleh', (select nama from public.profiles where id = auth.uid())), auth.uid(), now())
    on conflict (kunci) do update set nilai = excluded.nilai, diubah_oleh = excluded.diubah_oleh, diubah_pada = excluded.diubah_pada;
  return v_hasil;
end $$;

-- Kapan dan siapa yang terakhir mengunduh cadangan, untuk ditampilkan di menu Data Gudep tanpa mengambil seluruh data;
-- { pada, oleh } atau objek kosong bila belum pernah diunduh.
create function public.sg_cadangan_status() returns jsonb language plpgsql stable security definer set search_path = public as
$$
begin
  perform sigarda.wajib_admin('Hanya Admin Gudep yang dapat melihat status cadangan.');
  return coalesce((select nilai from public.pengaturan where kunci = 'cadangan.terakhir'), '{}'::jsonb);
end $$;
-- ===== akhir fungsi cadangan =====

-- ===== Eskalasi (tahap L5): fungsi =====
-- Nomor WhatsApp diisi SENDIRI oleh pemilik akun (semua peran), dipakai tombol "Buka WhatsApp" di daftar Tindak Lanjut. Hanya FORMAT yang
-- diperiksa (sama seperti "Telepon" pada Data Gudep); TIDAK ada pemeriksaan nomor benar-benar terdaftar/aktif di WhatsApp (itu perlu layanan
-- WhatsApp Business API berbayar, di luar cakupan). Kosongkan dengan mengirim teks kosong.
create function public.sg_profil_whatsapp_atur(p_whatsapp text) returns void language plpgsql security definer set search_path = public as
$$
declare v_v text := sigarda.rapikan(p_whatsapp);
begin
  perform sigarda.wajib_aktif();
  if v_v <> '' and v_v !~ '^[0-9 +()./-]{8,20}$' then
    raise exception 'Nomor WhatsApp hanya boleh berisi angka, spasi, dan tanda + ( ) . / - (8-20 karakter).';
  end if;
  update public.profiles set whatsapp = nullif(v_v, '') where id = auth.uid();
end $$;

-- Tangga eskalasi untuk Penegak yang "tidak bergerak", dijalankan dari sigarda.notif_pengingat() (pengingat harian 07.00 WIB, jadi otomatis
-- di luar jam senyap 22.00-04.00 WIB tanpa logika tambahan). Tiga kejadian independen, masing-masing dihitung ULANG setiap hari dari data
-- sumbernya (BUKAN status tersimpan) sehingga otomatis "reset" begitu ada tindak lanjut -- tanpa perlu tabel status terpisah:
--   sku      : tidak ada sku_progress/riwayat baru (peserta ATAU penguji) selama >= 7 hari. TIDAK dihitung selama ada pra-uji yang menunggu penilai (Fase E):
--              penghambatnya penilai, bukan Penegak; yang macet muncul di Periksa Data (praUjiMacet) dan diingatkan sigarda.pra_uji_pengingat.
--   absensi  : 2 kali latihan Jumat TERAKHIR berturut-turut berstatus Alpa ('A'; izin/sakit tidak dihitung).
--   iuran    : 2 kali latihan Jumat TERAKHIR berturut-turut tanpa baris iuran (terpisah dari status absensi, sesuai catatan tabel iuran).
-- "mulai" = tanggal kejadian PERTAMA kali memenuhi syarat (tetap sejak itu selama belum ada tindak lanjut, tidak ikut mundur bila kejadian
-- berlanjut lebih lama). Tingkat: 1 ramah (hari ke 0-3 sejak mulai), 2 tegas (4-7), 3 mendesak (8+, JUGA memberi tahu semua pengurus dan
-- masuk sg_eskalasi_daftar). Isi notifikasi singkat, TANPA hasil lulus/ulang (aturan privasi lama).
create function sigarda.eskalasi_mulai_sku(p_peserta uuid) returns date language plpgsql stable security definer set search_path = public as
$$
declare v_terakhir date;
begin
  if exists (select 1 from public.sku_pra_uji where peserta_id = p_peserta and status = 'menunggu') then return null; end if;
  select greatest(
    coalesce((select max(diubah)::date from public.sku_progress where peserta_id = p_peserta), (select dibuat from public.profiles where id = p_peserta)),
    coalesce((select max(waktu)::date from public.sku_riwayat where peserta_id = p_peserta), (select dibuat from public.profiles where id = p_peserta))
  ) into v_terakhir;
  if sigarda.hari_ini() - v_terakhir >= 7 then return v_terakhir + 7; end if;
  return null;
end $$;

-- Beruntun Alpa dari sesi TERBARU mundur (dibatasi 15 sesi terakhir); "mulai" = tanggal ke-2 (dari yang tertua) dalam beruntun itu, hanya
-- bila beruntunnya sekurangnya 2. Sesi tanpa catatan (belum diabsen) MENGHENTIKAN beruntun (bukan Alpa, tapi juga bukan hadir).
create function sigarda.eskalasi_mulai_absensi(p_peserta uuid) returns date language plpgsql stable security definer set search_path = public as
$$
declare r record; v_beruntun date[] := '{}';
begin
  for r in select s.tanggal, ah.status from public.absensi_sesi s left join public.absensi_hadir ah on ah.tanggal = s.tanggal and ah.peserta_id = p_peserta
           order by s.tanggal desc limit 15
  loop
    if r.status = 'A' then v_beruntun := v_beruntun || r.tanggal; else exit; end if;
  end loop;
  if array_length(v_beruntun, 1) >= 2 then return v_beruntun[array_length(v_beruntun, 1) - 1]; end if;
  return null;
end $$;

-- Sama seperti eskalasi_mulai_absensi, tapi kejadian = tidak ada baris iuran pada sesi itu (terlepas dari status hadir/izin/sakit/alpa).
create function sigarda.eskalasi_mulai_iuran(p_peserta uuid) returns date language plpgsql stable security definer set search_path = public as
$$
declare r record; v_beruntun date[] := '{}';
begin
  for r in select s.tanggal, exists (select 1 from public.iuran i where i.tanggal = s.tanggal and i.peserta_id = p_peserta) as bayar
           from public.absensi_sesi s order by s.tanggal desc limit 15
  loop
    if not r.bayar then v_beruntun := v_beruntun || r.tanggal; else exit; end if;
  end loop;
  if array_length(v_beruntun, 1) >= 2 then return v_beruntun[array_length(v_beruntun, 1) - 1]; end if;
  return null;
end $$;

-- Tingkat (1 ramah, 2 tegas, 3 mendesak) dari jumlah hari sejak "mulai". Tanpa akses tabel: murni fungsi hari berjalan.
create function sigarda.eskalasi_tingkat(p_hari int) returns int language sql immutable as
$$ select case when p_hari < 4 then 1 when p_hari < 8 then 2 else 3 end $$;

create function sigarda.eskalasi_judul(p_jenis text, p_tingkat int) returns text language sql immutable as
$$
  select case p_jenis || p_tingkat
    when 'sku1' then 'Yuk lanjutkan SKU-mu' when 'sku2' then 'SKU belum bergerak' when 'sku3' then 'SKU sudah lama tidak bergerak'
    when 'absensi1' then 'Tidak hadir latihan' when 'absensi2' then 'Absensi perlu diperhatikan' when 'absensi3' then 'Absensi perlu tindak lanjut'
    when 'iuran1' then 'Iuran belum tercatat' when 'iuran2' then 'Iuran perlu diperhatikan' when 'iuran3' then 'Iuran perlu tindak lanjut'
  end
$$;
create function sigarda.eskalasi_isi(p_jenis text, p_tingkat int, p_mulai date) returns text language sql stable as
$$
  select case p_jenis || p_tingkat
    when 'sku1' then 'Belum ada pengajuan atau hasil baru sejak ' || to_char(p_mulai - 7, 'DD-MM-YYYY') || '.'
    when 'sku2' then 'Sudah beberapa hari tidak ada aktivitas SKU. Sempatkan mengajukan butir berikutnya.'
    when 'sku3' then 'Sudah lama tidak ada aktivitas SKU. Hubungi Pembina atau Dewan bila ada kendala.'
    when 'absensi1' then 'Tidak hadir latihan terakhir tanpa keterangan.'
    when 'absensi2' then 'Sudah 2 kali berturut-turut tidak hadir latihan tanpa keterangan.'
    when 'absensi3' then 'Sudah lama tidak hadir latihan tanpa keterangan. Hubungi Pembina atau Dewan bila ada kendala.'
    when 'iuran1' then 'Iuran latihan terakhir belum tercatat.'
    when 'iuran2' then 'Sudah 2 kali berturut-turut iuran belum tercatat.'
    when 'iuran3' then 'Sudah lama iuran belum tercatat. Hubungi Dewan atau asisten bendahara bila ada kendala.'
  end
$$;
-- Tab tujuan notifikasi milik Penegak sendiri per jenis kejadian (menu yang relevan di navigasinya).
create function sigarda.eskalasi_tab(p_jenis text) returns text language sql immutable as
$$ select case p_jenis when 'sku' then 'sku' when 'absensi' then 'absensi' when 'iuran' then 'iuran' end $$;

create function sigarda.eskalasi_proses() returns void language plpgsql security definer set search_path = public as
$$
declare v_hari date := sigarda.hari_ini(); r record; v_mulai date; v_elapsed int; v_tingkat int; v_x uuid;
begin
  -- Anak Siaga tanpa akun (tanpa_akun) tidak punya akun untuk diingatkan: hanya satu kejadian (absensi, 2 sesi terakhir Alpa) dan hanya pada tingkat
  -- mendesak (hari 8+) memberi tahu pengurus, tanpa notifikasi ke anak. SKU dan iuran tidak dipakai (SKU dinilai langsung Pembina; tabungan tidak = iuran).
  for r in select id, nama from public.profiles where role = 'peserta' and status = 'aktif' and tanpa_akun loop
    v_mulai := sigarda.eskalasi_mulai_absensi(r.id);
    continue when v_mulai is null;
    v_elapsed := v_hari - v_mulai;
    continue when sigarda.eskalasi_tingkat(v_elapsed) < 3;
    for v_x in select id from public.profiles where status = 'aktif' and (role in ('penguji','admin') or (role = 'peserta' and jabatan_dewan is not null)) loop
      perform sigarda.notif_buat(v_x, 'eskalasi', 'Perlu tindak lanjut: ' || r.nama, sigarda.eskalasi_isi('absensi', 3, v_mulai),
        '{"tab":"tindaklanjut"}', 'eskalasi-p:absensi:' || r.id || ':' || v_hari);
    end loop;
  end loop;
  for r in select id, nama from public.profiles where role = 'peserta' and status = 'aktif' and not tanpa_akun loop
    declare v_jenis text; v_fn text[] := array['sku','absensi','iuran'];
    begin
      foreach v_jenis in array v_fn loop
        v_mulai := case v_jenis
          when 'sku' then sigarda.eskalasi_mulai_sku(r.id)
          when 'absensi' then sigarda.eskalasi_mulai_absensi(r.id)
          else sigarda.eskalasi_mulai_iuran(r.id)
        end;
        continue when v_mulai is null;
        v_elapsed := v_hari - v_mulai;
        v_tingkat := sigarda.eskalasi_tingkat(v_elapsed);
        perform sigarda.notif_buat(r.id, 'eskalasi', sigarda.eskalasi_judul(v_jenis, v_tingkat), sigarda.eskalasi_isi(v_jenis, v_tingkat, v_mulai),
          jsonb_build_object('tab', sigarda.eskalasi_tab(v_jenis)), 'eskalasi:' || v_jenis || ':' || r.id || ':' || v_hari);
        if v_tingkat = 3 then
          for v_x in select id from public.profiles where status = 'aktif' and (role in ('penguji','admin') or (role = 'peserta' and jabatan_dewan is not null)) loop
            perform sigarda.notif_buat(v_x, 'eskalasi', 'Perlu tindak lanjut: ' || r.nama, sigarda.eskalasi_isi(v_jenis, v_tingkat, v_mulai),
              '{"tab":"tindaklanjut"}', 'eskalasi-p:' || v_jenis || ':' || r.id || ':' || v_hari);
          end loop;
        end if;
      end loop;
    end;
  end loop;
end $$;

-- Daftar Penegak yang perlu tindak lanjut (tingkat mendesak, hari ke 8+) untuk Pembina, Dewan Ambalan, dan Admin. Termasuk nomor WhatsApp
-- (bisa kosong bila pemiliknya belum mengisi) untuk tombol "Buka WhatsApp" di halaman.
create function public.sg_eskalasi_daftar() returns jsonb language plpgsql stable security definer set search_path = public as
$$
declare v_hari date := sigarda.hari_ini(); v_hasil jsonb := '[]'::jsonb; r record; v_mulai date; v_elapsed int; v_jenis text;
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pengurus() then raise exception 'Hanya Pembina, Dewan Ambalan, dan Admin Gudep yang dapat melihat daftar ini.'; end if;
  for r in select id, nama, kelas, sangga, whatsapp, tanpa_akun from public.profiles where role = 'peserta' and status = 'aktif' loop
    -- Anak Siaga tanpa akun: hanya kejadian absensi (lihat sigarda.eskalasi_proses).
    foreach v_jenis in array case when r.tanpa_akun then array['absensi'] else array['sku','absensi','iuran'] end loop
      v_mulai := case v_jenis
        when 'sku' then sigarda.eskalasi_mulai_sku(r.id)
        when 'absensi' then sigarda.eskalasi_mulai_absensi(r.id)
        else sigarda.eskalasi_mulai_iuran(r.id)
      end;
      continue when v_mulai is null;
      v_elapsed := v_hari - v_mulai;
      continue when sigarda.eskalasi_tingkat(v_elapsed) < 3;
      v_hasil := v_hasil || jsonb_build_object(
        'pesertaId', r.id, 'nama', r.nama, 'kelas', r.kelas, 'sangga', r.sangga, 'whatsapp', r.whatsapp, 'tanpaAkun', r.tanpa_akun,
        'jenis', v_jenis, 'mulai', v_mulai, 'hari', v_elapsed
      );
    end loop;
  end loop;
  return v_hasil;
end $$;
-- ===== akhir fungsi eskalasi =====

-- ===== Agenda tahunan (tahap L6): fungsi =====
-- Batas keras: Musyawarah Ambalan (pergantian kepengurusan) harus SEBELUM 1 Juli tahun kedua tahun ajaran (sebelum tahun ajaran
-- baru dan Naik Kelas dimulai). Dapat dilewati HANYA oleh Pembina (bukan Admin) lewat p_lewati_batas, atas usulan Dewan Ambalan
-- di luar aplikasi; cermin batasMusyawarah di src/lib/agendaLogic.js.
create function sigarda.agenda_batas_musyawarah(p_tahun_ajaran text) returns date language sql immutable as
$$ select (split_part(p_tahun_ajaran, '/', 2) || '-07-01')::date $$;

-- Menyimpan (tambah bila p_id null, ubah bila terisi) satu kegiatan agenda. Pembina dan Admin. peserta_terkait dibatasi ke
-- Penegak aktif (maks 500 baris, cukup untuk pelantikan satu angkatan penuh).
create function public.sg_agenda_simpan(
  p_id bigint, p_tahun_ajaran text, p_jenis text, p_judul text, p_tanggal date, p_keterangan text default '',
  p_peserta_terkait uuid[] default '{}', p_lewati_batas boolean default false
) returns bigint language plpgsql security definer set search_path = public as
$$
declare
  v_judul text := sigarda.rapikan(p_judul); v_ket text := btrim(coalesce(p_keterangan, ''));
  v_ids uuid[]; v_id uuid; v_lewati boolean := false; v_hasil_id bigint;
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pembina_atau_admin() then raise exception 'Hanya Pembina dan Admin Gudep yang dapat mengatur agenda.'; end if;
  if not sigarda.tahun_ajaran_sah(p_tahun_ajaran) then raise exception 'Tahun ajaran tidak sah. Contoh: 2026/2027.'; end if;
  if p_jenis not in (
    'musyawarah','naik_kelas','sidang','pelantikan_bantara','pelantikan_laksana','pelantikan_garuda','lainnya',
    'pengembaraan','perkemahan','gelora_saka_expo','gladi_tangguh_1','gladi_tangguh_2','penempuhan_sku_laksana','ptgd','pembekalan_dewan',
    'pesta_siaga','persari','pertemuan_siaga','pelantikan_siaga'
  ) then
    raise exception 'Jenis kegiatan tidak dikenal.';
  end if;
  if v_judul = '' then raise exception 'Judul wajib diisi.'; end if;
  if char_length(v_judul) > 120 then raise exception 'Judul maksimal 120 karakter.'; end if;
  if p_tanggal is null then raise exception 'Tanggal wajib diisi.'; end if;
  if char_length(v_ket) > 500 then raise exception 'Keterangan maksimal 500 karakter.'; end if;

  -- lewati_batas hanya berlaku bila pemanggil benar Pembina (bukan Admin, bukan Dewan/Penegak).
  if p_lewati_batas is true and sigarda.pembina_saja() then
    v_lewati := true;
  end if;
  if p_jenis = 'musyawarah' and not v_lewati and p_tanggal >= sigarda.agenda_batas_musyawarah(p_tahun_ajaran) then
    raise exception 'Musyawarah Ambalan harus dijadwalkan sebelum 1 Juli % (sebelum tahun ajaran baru dan Naik Kelas). Hanya Pembina yang dapat melewati batas ini, atas usulan Dewan Ambalan.', split_part(p_tahun_ajaran, '/', 2);
  end if;

  v_ids := coalesce((select array_agg(distinct x) from unnest(p_peserta_terkait) x), '{}');
  if cardinality(v_ids) > 500 then raise exception 'Maksimal 500 Penegak terkait.'; end if;
  foreach v_id in array v_ids loop
    if not exists (select 1 from public.profiles where id = v_id and role = 'peserta' and status = 'aktif') then
      raise exception 'Salah satu Penegak terkait tidak ditemukan atau tidak aktif.';
    end if;
  end loop;

  if p_id is null then
    insert into public.agenda (tahun_ajaran, jenis, judul, tanggal, keterangan, peserta_terkait, lewati_batas, dibuat_oleh)
      values (p_tahun_ajaran, p_jenis, v_judul, p_tanggal, v_ket, v_ids, v_lewati, auth.uid())
      returning id into v_hasil_id;
  else
    update public.agenda set tahun_ajaran = p_tahun_ajaran, jenis = p_jenis, judul = v_judul, tanggal = p_tanggal,
      keterangan = v_ket, peserta_terkait = v_ids, lewati_batas = v_lewati, diubah_pada = now()
      where id = p_id;
    if not found then raise exception 'Kegiatan agenda tidak ditemukan.'; end if;
    v_hasil_id := p_id;
  end if;
  return v_hasil_id;
end $$;

create function public.sg_agenda_hapus(p_id bigint) returns void language plpgsql security definer set search_path = public as
$$
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pembina_atau_admin() then raise exception 'Hanya Pembina dan Admin Gudep yang dapat menghapus agenda.'; end if;
  delete from public.agenda where id = p_id;
end $$;

-- Pengingat H-30, H-7, H-1: semua pengurus aktif, DITAMBAH Penegak pada peserta_terkait (bila ada dan masih aktif). Isi notifikasi
-- memakai judul dan keterangan agenda apa adanya (berlaku untuk jenis baku maupun 'lainnya', tanpa teks berbeda per jenis).
create function sigarda.agenda_proses() returns void language plpgsql security definer set search_path = public as
$$
declare v_hari date := sigarda.hari_ini(); r record; v_x uuid; v_judul text; v_isi text;
begin
  for r in select id, judul, tanggal, keterangan, peserta_terkait from public.agenda where tanggal - v_hari in (30, 7, 1) loop
    v_judul := 'H-' || (r.tanggal - v_hari)::text || ': ' || r.judul;
    v_isi := case when r.keterangan <> '' then r.keterangan else 'Dijadwalkan ' || to_char(r.tanggal, 'DD-MM-YYYY') || '.' end;
    for v_x in select id from public.profiles where status = 'aktif' and (role in ('penguji','admin') or (role = 'peserta' and jabatan_dewan is not null)) loop
      perform sigarda.notif_buat(v_x, 'agenda', v_judul, v_isi, '{"tab":"agenda"}', 'agenda:' || r.id || ':' || v_hari);
    end loop;
    foreach v_x in array coalesce(r.peserta_terkait, '{}') loop
      if exists (select 1 from public.profiles where id = v_x and status = 'aktif') then
        perform sigarda.notif_buat(v_x, 'agenda', v_judul, v_isi, '{"tab":"agenda"}', 'agenda:' || r.id || ':' || v_hari);
      end if;
    end loop;
  end loop;
end $$;
-- ===== akhir fungsi agenda =====

-- ===== Usulan kegiatan (tahap L6b): fungsi =====
-- Judul bawaan (dipakai isi notifikasi dan entri Agenda saat disetujui) untuk tiap jenis usulan kegiatan.
create function sigarda.kegiatan_judul_bawaan(p_jenis text) returns text language sql immutable as
$$
  select case p_jenis
    when 'musyawarah' then 'Musyawarah Ambalan'
    when 'pelantikan_bantara' then 'Pembayatan dan Pelantikan Bantara'
    when 'pelantikan_laksana' then 'Pelantikan Laksana'
    when 'pengembaraan' then 'Pengembaraan'
    when 'perkemahan' then 'Perkemahan'
    when 'gelora_saka_expo' then 'Gelora Saka Expo'
    when 'gladi_tangguh_1' then 'Gladi Tangguh 1'
    when 'gladi_tangguh_2' then 'Gladi Tangguh 2'
    when 'penempuhan_sku_laksana' then 'Penempuhan SKU Laksana'
    when 'ptgd' then 'PTGD (Penerimaan Tamu Gugus Depan)'
    when 'pembekalan_dewan' then 'Pembekalan Dewan Ambalan Angkatan Berikutnya'
    else initcap(replace(p_jenis, '_', ' '))
  end
$$;
-- Tanggal 1 pada bulan p_bulan di dalam tahun ajaran p_tahun_ajaran (Juli-Desember = tahun pertama, Januari-Juni = tahun kedua).
create function sigarda.kegiatan_bulan_tanggal(p_tahun_ajaran text, p_bulan int) returns date language sql immutable as
$$
  select case when p_bulan >= 7
    then (split_part(p_tahun_ajaran, '/', 1) || '-' || lpad(p_bulan::text, 2, '0') || '-01')::date
    else (split_part(p_tahun_ajaran, '/', 2) || '-' || lpad(p_bulan::text, 2, '0') || '-01')::date
  end
$$;

-- Hanya Pradana atau Pradani dapat mengajukan; hanya Pembina dapat meninjau (bukan Admin). Persetujuan otomatis membuat entri di
-- public.agenda lewat sg_agenda_simpan sendiri (lewati_batas hanya true untuk jenis 'musyawarah' bila tanggalnya memang di atas batas
-- 1 Juli -- persetujuan Pembina INILAH bentuk "usulan Dewan Ambalan" yang boleh melewatinya; jenis lain tidak mengenal batas ini).
create function public.sg_kegiatan_usul(p_jenis text, p_tahun_ajaran text, p_tanggal_usul date, p_dokumen_url text, p_catatan text default '')
returns bigint language plpgsql security definer set search_path = public as
$$
declare v_url text := btrim(coalesce(p_dokumen_url, '')); v_cat text := btrim(coalesce(p_catatan, '')); v_nama text; v_id bigint; v_x uuid; v_judul text;
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pradana_atau_pradani() then raise exception 'Hanya Pradana atau Pradani yang dapat mengajukan usulan kegiatan.'; end if;
  if p_jenis not in (
    'musyawarah', 'pelantikan_bantara', 'pelantikan_laksana', 'pengembaraan', 'perkemahan', 'gelora_saka_expo',
    'gladi_tangguh_1', 'gladi_tangguh_2', 'penempuhan_sku_laksana', 'ptgd', 'pembekalan_dewan'
  ) then raise exception 'Jenis kegiatan tidak dikenal.'; end if;
  if not sigarda.tahun_ajaran_sah(p_tahun_ajaran) then raise exception 'Tahun ajaran tidak sah. Contoh: 2026/2027.'; end if;
  if p_tanggal_usul is null then raise exception 'Tanggal usulan wajib diisi.'; end if;
  if v_url !~ '^https?://' or char_length(v_url) > 500 then raise exception 'Tautan dokumen proposal harus berupa alamat web (diawali http:// atau https://), maksimal 500 karakter.'; end if;
  if char_length(v_cat) > 500 then raise exception 'Catatan maksimal 500 karakter.'; end if;
  v_judul := sigarda.kegiatan_judul_bawaan(p_jenis);
  if exists (select 1 from public.kegiatan_usulan where tahun_ajaran = p_tahun_ajaran and jenis = p_jenis and status = 'menunggu') then
    raise exception 'Sudah ada usulan % yang menunggu ditinjau untuk tahun ajaran ini. Tunggu Pembina meninjaunya (atau ingatkan lewat tombol pada usulan itu) sebelum mengajukan lagi.', v_judul;
  end if;
  select nama into v_nama from public.profiles where id = auth.uid();

  insert into public.kegiatan_usulan (tahun_ajaran, jenis, tanggal_usul, dokumen_url, catatan, diajukan_oleh, diajukan_oleh_nama)
    values (p_tahun_ajaran, p_jenis, p_tanggal_usul, v_url, v_cat, auth.uid(), coalesce(v_nama, ''))
    returning id into v_id;

  for v_x in select id from public.profiles where role = 'penguji' and jabatan = 'Pembina' and status = 'aktif' loop
    perform sigarda.notif_buat(v_x, 'kegiatan', 'Usulan ' || v_judul,
      coalesce(v_nama, 'Pradana/Pradani') || ' mengusulkan ' || v_judul || ' ' || to_char(p_tanggal_usul, 'DD-MM-YYYY') || '. Perlu ditinjau.',
      '{"tab":"agenda"}', 'kegiatan:' || v_id || ':diajukan');
  end loop;
  return v_id;
end $$;

-- Setuju (catatan opsional) atau tolak (catatan WAJIB). p_keputusan: 'disetujui' atau 'ditolak'.
create function public.sg_kegiatan_tinjau(p_id bigint, p_keputusan text, p_catatan text default '') returns void
language plpgsql security definer set search_path = public as
$$
declare v_row public.kegiatan_usulan; v_cat text := btrim(coalesce(p_catatan, '')); v_nama text; v_agenda_id bigint; v_judul text; v_lewati boolean;
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pembina_saja() then raise exception 'Hanya Pembina yang dapat meninjau usulan kegiatan.'; end if;
  if p_keputusan not in ('disetujui', 'ditolak') then raise exception 'Keputusan harus disetujui atau ditolak.'; end if;
  select * into v_row from public.kegiatan_usulan where id = p_id;
  if not found then raise exception 'Usulan tidak ditemukan.'; end if;
  if v_row.status <> 'menunggu' then raise exception 'Usulan ini sudah ditinjau sebelumnya.'; end if;
  if p_keputusan = 'ditolak' and v_cat = '' then raise exception 'Catatan alasan penolakan wajib diisi.'; end if;
  if char_length(v_cat) > 500 then raise exception 'Catatan maksimal 500 karakter.'; end if;
  v_judul := sigarda.kegiatan_judul_bawaan(v_row.jenis);
  select nama into v_nama from public.profiles where id = auth.uid();

  if p_keputusan = 'disetujui' then
    -- lewati_batas hanya diset true bila jenisnya 'musyawarah' DAN tanggal usulan memang di atas/pada batas 1 Juli -- jenis lain tidak
    -- mengenal batas ini, dan kolom itu tetap berarti "tanggal ini melewati batas" (bukan sekadar "melalui persetujuan ini").
    v_lewati := v_row.jenis = 'musyawarah' and v_row.tanggal_usul >= sigarda.agenda_batas_musyawarah(v_row.tahun_ajaran);
    v_agenda_id := public.sg_agenda_simpan(null, v_row.tahun_ajaran, v_row.jenis, v_judul, v_row.tanggal_usul, v_row.catatan, '{}', v_lewati);
  end if;

  update public.kegiatan_usulan set status = p_keputusan, ditinjau_oleh = auth.uid(), ditinjau_oleh_nama = coalesce(v_nama, ''),
    ditinjau_pada = now(), catatan_tinjauan = v_cat, agenda_id = v_agenda_id
    where id = p_id;

  perform sigarda.notif_buat(v_row.diajukan_oleh, 'kegiatan',
    case when p_keputusan = 'disetujui' then 'Usulan ' || v_judul || ' disetujui' else 'Usulan ' || v_judul || ' ditolak' end,
    case when p_keputusan = 'disetujui' then 'Tanggal ' || to_char(v_row.tanggal_usul, 'DD-MM-YYYY') || ' oleh ' || coalesce(v_nama, 'Pembina') || '.'
         else 'Oleh ' || coalesce(v_nama, 'Pembina') || ': ' || v_cat end,
    '{"tab":"agenda"}', 'kegiatan:' || p_id || ':' || p_keputusan);
end $$;

-- Pradana/Pradani mengingatkan lagi semua Pembina tentang usulan yang masih menunggu (dibatasi sekali per 24 jam agar tidak dipakai spam).
create function public.sg_kegiatan_ping(p_id bigint) returns void language plpgsql security definer set search_path = public as
$$
declare v_row public.kegiatan_usulan; v_x uuid; v_judul text;
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pradana_atau_pradani() then raise exception 'Hanya Pradana atau Pradani yang dapat mengingatkan Pembina.'; end if;
  select * into v_row from public.kegiatan_usulan where id = p_id;
  if not found or v_row.status <> 'menunggu' then raise exception 'Usulan ini tidak lagi menunggu tinjauan.'; end if;
  if v_row.diping_pada is not null and v_row.diping_pada > now() - interval '24 hours' then
    raise exception 'Sudah mengingatkan dalam 24 jam terakhir. Coba lagi nanti.';
  end if;
  v_judul := sigarda.kegiatan_judul_bawaan(v_row.jenis);
  update public.kegiatan_usulan set diping_pada = now() where id = p_id;
  for v_x in select id from public.profiles where role = 'penguji' and jabatan = 'Pembina' and status = 'aktif' loop
    perform sigarda.notif_buat(v_x, 'kegiatan', 'Pengingat: usulan ' || v_judul || ' menunggu',
      'Usulan tanggal ' || to_char(v_row.tanggal_usul, 'DD-MM-YYYY') || ' masih menunggu ditinjau.', '{"tab":"agenda"}',
      'kegiatan:' || p_id || ':ping:' || to_char(now(), 'YYYY-MM-DD'));
  end loop;
end $$;

-- Pengingat H-60 (lalu tiap 14 hari) ke semua pengurus dan Dewan Ambalan bila tahun ajaran berjalan BELUM punya entri Agenda Musyawarah
-- Ambalan (artinya belum ada usulan yang disetujui), berlanjut sampai ada yang disetujui (tanpa batas atas, walau sudah lewat 1 Juli).
create function sigarda.musyawarah_pengingat() returns void language plpgsql security definer set search_path = public as
$$
declare v_ta text := sigarda.tahun_ajaran_kini(); v_hari date := sigarda.hari_ini(); v_batas date; v_x uuid; v_kunci text; v_isi text;
begin
  v_batas := sigarda.agenda_batas_musyawarah(v_ta);
  if v_hari < v_batas - 60 then return; end if;
  if exists (select 1 from public.agenda where tahun_ajaran = v_ta and jenis = 'musyawarah') then return; end if;
  v_kunci := 'musyawarah-pengingat:' || v_ta || ':' || ((v_hari - date '2000-01-01') / 14)::text;
  v_isi := case when exists (select 1 from public.kegiatan_usulan where tahun_ajaran = v_ta and jenis = 'musyawarah' and status = 'menunggu')
    then 'Ada usulan yang menunggu ditinjau Pembina. Batas 1 Juli ' || split_part(v_ta, '/', 2) || '.'
    else 'Belum ada usulan. Pradana atau Pradani dapat mengajukan lewat menu Agenda. Batas 1 Juli ' || split_part(v_ta, '/', 2) || '.' end;
  for v_x in select id from public.profiles where status = 'aktif' and (role in ('penguji','admin') or (role = 'peserta' and jabatan_dewan is not null)) loop
    perform sigarda.notif_buat(v_x, 'musyawarah', 'Musyawarah Ambalan belum terjadwal', v_isi, '{"tab":"agenda"}', v_kunci);
  end loop;
end $$;

-- Pengingat H-30/H-60 (lalu tiap 14 hari) ke semua pengurus dan Dewan Ambalan untuk 10 jenis kegiatan lain (di luar Musyawarah Ambalan,
-- yang punya pengingat sendiri di sigarda.musyawarah_pengingat di atas) bila tahun ajaran berjalan belum punya entri Agenda jenis itu,
-- berlanjut sampai ada yang disetujui. Tiap jenis punya 1-2 bulan sasaran per tahun; bila 2, H-N dihitung dari yang PALING AWAL (yang
-- kedua tidak menambah pengingat baru karena pengingat sudah berjalan tiap 14 hari sejak yang pertama sampai ada usulan disetujui).
create function sigarda.kegiatan_pengingat() returns void language plpgsql security definer set search_path = public as
$$
declare v_ta text := sigarda.tahun_ajaran_kini(); v_hari date := sigarda.hari_ini(); v_x uuid; v_kunci text; v_isi text; v_judul text;
  v_cfg record; v_mulai date;
begin
  for v_cfg in select * from (values
    ('pelantikan_bantara', 30, 12, 2::int),
    ('pelantikan_laksana', 30, 4, 6),
    ('pengembaraan', 30, 12, 2),
    ('perkemahan', 30, 12, 2),
    ('gelora_saka_expo', 30, 9, null),
    ('gladi_tangguh_1', 30, 12, 2),
    ('gladi_tangguh_2', 30, 4, 6),
    ('penempuhan_sku_laksana', 30, 12, 2),
    ('ptgd', 60, 7, null),
    ('pembekalan_dewan', 30, 8, null)
  ) as t(jenis, h_n, bulan1, bulan2) loop
    if exists (select 1 from public.agenda where tahun_ajaran = v_ta and jenis = v_cfg.jenis) then continue; end if;
    v_mulai := sigarda.kegiatan_bulan_tanggal(v_ta, v_cfg.bulan1) - v_cfg.h_n;
    if v_cfg.bulan2 is not null then
      v_mulai := least(v_mulai, sigarda.kegiatan_bulan_tanggal(v_ta, v_cfg.bulan2) - v_cfg.h_n);
    end if;
    if v_hari < v_mulai then continue; end if;
    v_judul := sigarda.kegiatan_judul_bawaan(v_cfg.jenis);
    v_kunci := 'kegiatan-pengingat:' || v_cfg.jenis || ':' || v_ta || ':' || ((v_hari - date '2000-01-01') / 14)::text;
    v_isi := case when exists (select 1 from public.kegiatan_usulan where tahun_ajaran = v_ta and jenis = v_cfg.jenis and status = 'menunggu')
      then 'Ada usulan yang menunggu ditinjau Pembina.'
      else 'Belum ada usulan. Pradana atau Pradani dapat mengajukan lewat menu Agenda.' end;
    for v_x in select id from public.profiles where status = 'aktif' and (role in ('penguji','admin') or (role = 'peserta' and jabatan_dewan is not null)) loop
      perform sigarda.notif_buat(v_x, 'kegiatan', v_judul || ' belum terjadwal', v_isi, '{"tab":"agenda"}', v_kunci);
    end loop;
  end loop;
end $$;
-- ===== akhir fungsi usulan kegiatan =====

-- Untuk Edge Function notif-push (service_role): bahan kirim untuk beberapa notifikasi yang belum berstatus, dan pencatatan hasilnya.
create function public.sg_push_ambil_internal(p_ids bigint[]) returns jsonb language sql stable security definer set search_path = public as
$$
  select coalesce(jsonb_agg(jsonb_build_object(
    'id', n.id, 'judul', n.judul, 'isi', n.isi, 'tautan', n.tautan,
    'langganan', (select coalesce(jsonb_agg(jsonb_build_object('id', l.id, 'endpoint', l.endpoint, 'p256dh', l.p256dh, 'auth', l.auth)), '[]'::jsonb)
                  from public.push_langganan l where l.penerima_id = n.penerima_id)
  )), '[]'::jsonb)
  from public.notifikasi n where n.id = any (p_ids) and n.push_status is null
$$;
-- p_hasil = { status: [{ id, status: 'dikirim' | 'gagal' }], hapus: [id langganan yang sudah tidak berlaku] }
create function public.sg_push_hasil_internal(p_hasil jsonb) returns void language plpgsql security definer set search_path = public as
$$
begin
  update public.notifikasi n set push_status = x.status
    from jsonb_to_recordset(coalesce(p_hasil -> 'status', '[]'::jsonb)) as x(id bigint, status text)
    where n.id = x.id and x.status in ('dikirim', 'gagal');
  delete from public.push_langganan where id in (select v::bigint from jsonb_array_elements_text(coalesce(p_hasil -> 'hapus', '[]'::jsonb)) v);
end $$;
-- ===== akhir fungsi notifikasi =====

-- ===== Sesi ujian (Dewan Ambalan, Pembina, Admin) =====
-- Menyimpan satu sesi beserta butir dan pesertanya (id kosong = sesi baru). Butir dan peserta diganti seluruhnya sesuai daftar.
create function public.sg_sesi_simpan(
  p_id int, p_nama text, p_tanggal date, p_tempat text, p_catatan text, p_status text, p_butir text[], p_peserta uuid[]
) returns int language plpgsql security definer set search_path = public as
$$
declare
  v_nama text := sigarda.rapikan(p_nama); v_tempat text := sigarda.rapikan(p_tempat); v_cat text := btrim(coalesce(p_catatan, ''));
  v_butir text[]; v_peserta uuid[]; v_id int;
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pengurus() then raise exception 'Hanya Dewan Ambalan, Pembina, atau Admin Gudep yang dapat mengelola sesi ujian.'; end if;
  if v_nama = '' or char_length(v_nama) > 120 then raise exception 'Nama sesi wajib diisi (maksimal 120 karakter).'; end if;
  if p_tanggal is null or p_tanggal < date '2000-01-01' or p_tanggal > date '2100-12-31' then raise exception 'Tanggal sesi tidak valid.'; end if;
  if char_length(v_tempat) > 120 then raise exception 'Tempat maksimal 120 karakter.'; end if;
  if char_length(v_cat) > 500 then raise exception 'Catatan maksimal 500 karakter.'; end if;
  if p_status is null or p_status not in ('terjadwal', 'berlangsung', 'selesai') then raise exception 'Status sesi tidak dikenal.'; end if;
  select coalesce(array_agg(distinct x), '{}') into v_butir from unnest(coalesce(p_butir, '{}')) x;
  select coalesce(array_agg(distinct x), '{}') into v_peserta from unnest(coalesce(p_peserta, '{}')) x;
  if cardinality(v_butir) = 0 then raise exception 'Pilih minimal satu butir.'; end if;
  if cardinality(v_butir) > 60 then raise exception 'Butir maksimal 60 per sesi.'; end if;
  if cardinality(v_peserta) = 0 then raise exception 'Pilih minimal satu peserta.'; end if;
  if cardinality(v_peserta) > 300 then raise exception 'Peserta maksimal 300 per sesi.'; end if;
  if (select count(*) from public.sku_butir where id = any (v_butir)) <> cardinality(v_butir) then raise exception 'Ada butir yang tidak dikenal.'; end if;
  if (select count(*) from public.profiles where id = any (v_peserta) and role = 'peserta') <> cardinality(v_peserta) then raise exception 'Ada peserta yang tidak dikenal.'; end if;

  if p_id is null then
    insert into public.sesi_ujian (nama, tanggal, tempat, catatan, status, dibuat_oleh) values (v_nama, p_tanggal, v_tempat, v_cat, p_status, auth.uid())
    returning id into v_id;
  else
    update public.sesi_ujian set nama = v_nama, tanggal = p_tanggal, tempat = v_tempat, catatan = v_cat, status = p_status where id = p_id returning id into v_id;
    if v_id is null then raise exception 'Sesi tidak ditemukan.'; end if;
    delete from public.sesi_ujian_butir where sesi_id = v_id;
    delete from public.sesi_ujian_peserta where sesi_id = v_id;
  end if;
  insert into public.sesi_ujian_butir (sesi_id, butir_id) select v_id, x from unnest(v_butir) x;
  insert into public.sesi_ujian_peserta (sesi_id, peserta_id) select v_id, x from unnest(v_peserta) x;
  return v_id;
end $$;

create function public.sg_sesi_status(p_id int, p_status text) returns void
language plpgsql security definer set search_path = public as
$$
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pengurus() then raise exception 'Hanya Dewan Ambalan, Pembina, atau Admin Gudep yang dapat mengelola sesi ujian.'; end if;
  if p_status is null or p_status not in ('terjadwal', 'berlangsung', 'selesai') then raise exception 'Status sesi tidak dikenal.'; end if;
  update public.sesi_ujian set status = p_status where id = p_id;
  if not found then raise exception 'Sesi tidak ditemukan.'; end if;
end $$;

-- Menghapus sesi tidak menghapus hasil penilaian yang sudah tercatat (hanya jadwal dan daftarnya).
create function public.sg_sesi_hapus(p_id int) returns void
language plpgsql security definer set search_path = public as
$$
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pembina_atau_admin() then raise exception 'Hanya Pembina dan Admin Gudep yang dapat menghapus sesi ujian.'; end if;
  delete from public.sesi_ujian where id = p_id;
end $$;

-- ===== Fungsi untuk Edge Function saja (service_role) =====

-- Membuat baris profil untuk akun yang baru dibuat di Supabase Auth. Kelas Penegak wajib rombel baku (X-01..XII-10); sangga disamakan penulisannya.
create function public.sg_profil_buat_internal(
  p_id uuid, p_username text, p_role text, p_nama text, p_nis text, p_kelas text, p_sangga text, p_agama text, p_jabatan text
) returns void language plpgsql security definer set search_path = public as
$$
declare v_kelas text := sigarda.rapikan(p_kelas); v_sangga text := sigarda.rapikan(p_sangga);
begin
  if p_role = 'peserta' then
    v_kelas := sigarda.rombel_baku(v_kelas);
    if not sigarda.rombel_sah(v_kelas) then raise exception 'Kelas harus berupa rombel: X-01 sampai X-10, XI-01 sampai XI-10, atau XII-01 sampai XII-10.'; end if;
    v_sangga := coalesce((select sangga from public.profiles where role = 'peserta' and lower(sangga) = lower(v_sangga) limit 1), v_sangga);
  end if;
  insert into public.profiles (id, username, role, nama, nis, kelas, sangga, agama, jabatan)
  values (p_id, p_username, p_role, sigarda.rapikan(p_nama),
          nullif(p_nis, ''), nullif(v_kelas, ''), nullif(v_sangga, ''), nullif(p_agama, ''), nullif(p_jabatan, ''));
end $$;

-- Pembatasan percobaan masuk: 5 kali salah berturut-turut mengunci nama pengguna itu selama 5 menit.
create function public.sg_kunci_cek_internal(p_username text) returns int
language plpgsql security definer set search_path = public as
$$
declare v_sampai timestamptz;
begin
  select terkunci_sampai into v_sampai from public.login_gagal where username = p_username;
  if v_sampai is not null and v_sampai > now() then return ceil(extract(epoch from (v_sampai - now())) / 60)::int; end if;
  return 0;
end $$;

create function public.sg_kunci_gagal_internal(p_username text) returns jsonb
language plpgsql security definer set search_path = public as
$$
declare v_j int; v_sampai timestamptz; v_dp timestamptz; v_n int;
begin
  select jumlah, terkunci_sampai, diperbarui into v_j, v_sampai, v_dp from public.login_gagal where username = p_username for update;
  if not found then v_j := 0; end if;
  -- hitungan dianggap baru bila kunci sebelumnya sudah habis atau percobaan terakhir sudah lama
  if (v_sampai is not null and v_sampai <= now()) or (v_dp is not null and v_dp < now() - interval '15 minutes') then v_j := 0; end if;
  v_n := v_j + 1;
  if v_n >= 5 then
    insert into public.login_gagal (username, jumlah, terkunci_sampai, diperbarui) values (p_username, 0, now() + interval '5 minutes', now())
      on conflict (username) do update set jumlah = 0, terkunci_sampai = now() + interval '5 minutes', diperbarui = now();
    return jsonb_build_object('sisa', 0, 'terkunci', true, 'menit', 5);
  end if;
  insert into public.login_gagal (username, jumlah, terkunci_sampai, diperbarui) values (p_username, v_n, null, now())
    on conflict (username) do update set jumlah = v_n, terkunci_sampai = null, diperbarui = now();
  return jsonb_build_object('sisa', 5 - v_n, 'terkunci', false, 'menit', 0);
end $$;

create function public.sg_kunci_lepas_internal(p_username text) returns void
language plpgsql security definer set search_path = public as
$$ begin delete from public.login_gagal where username = p_username; end $$;

-- ===== Pra-uji berjenjang (fase C): aksi =====
-- Pengajuan Penegak lewat sg_sku_ajukan (bila sakelar hidup, diteruskan ke pra-uji); pembatalan lewat sg_sku_batal. Di sini: keputusan penilai pra-uji,
-- antrian penilai, melewati tahap yang macet, dan sakelar. Pra-uji TIDAK memakai PIN (hanya rekomendasi; uji resmi Pembina tetap lewat Edge Function + PIN).

-- Antrian pra-uji milik penilai yang sedang masuk (Pinsa atau Bina Damping) beserta yang sudah ia putuskan. Nama Penegak dikirim lewat fungsi ini karena
-- Penegak biasa tidak dapat membaca profil Penegak lain. { aktif, menunggu: [...], selesai: [... 50 terbaru] }
create function public.sg_pra_uji_antrian() returns jsonb language plpgsql stable security definer set search_path = public as
$$
declare v_uid uuid := auth.uid();
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pra_uji_aktif() then return jsonb_build_object('aktif', false, 'menunggu', '[]'::jsonb, 'selesai', '[]'::jsonb); end if;
  return jsonb_build_object(
    'aktif', true,
    'menunggu', coalesce((
      select jsonb_agg(jsonb_build_object('id', r.id, 'peserta_id', r.peserta_id, 'peserta_nama', p.nama, 'kelas', p.kelas, 'sangga', p.sangga, 'sku_id', r.sku_id,
        'tahap', r.tahap, 'jadwal', r.jadwal, 'catatan_peserta', r.catatan_peserta, 'dibuat', r.dibuat) order by r.dibuat)
      from public.sku_pra_uji r join public.profiles p on p.id = r.peserta_id
      where r.status = 'menunggu' and sigarda.pra_uji_penilai_ok(r.peserta_id, r.sku_id, r.tahap, v_uid)
    ), '[]'::jsonb),
    'selesai', coalesce((
      select jsonb_agg(x.j order by x.waktu desc) from (
        select r.diputuskan_pada as waktu, jsonb_build_object('id', r.id, 'peserta_id', r.peserta_id, 'peserta_nama', p.nama, 'kelas', p.kelas, 'sangga', p.sangga,
          'sku_id', r.sku_id, 'tahap', r.tahap, 'status', r.status, 'catatan', r.catatan, 'diputuskan_pada', r.diputuskan_pada) as j
        from public.sku_pra_uji r join public.profiles p on p.id = r.peserta_id
        where r.penilai_id = v_uid and r.status in ('lulus', 'belum') order by r.diputuskan_pada desc limit 50
      ) x
    ), '[]'::jsonb));
end $$;

-- Penilai (Pinsa atau Bina Damping yang memenuhi syarat) memutuskan satu pra-uji. p_hasil: 'lulus' (diteruskan otomatis ke tahap berikut, atau ke uji resmi
-- Pembina bila tahap terakhir) atau 'belum' (kembali ke Penegak; catatan perbaikan wajib). Hasil: { hasil, tujuan } (tujuan: 'pinsa' | 'bina_damping' | 'pembina' | null).
create function public.sg_pra_uji_catat(p_id bigint, p_hasil text, p_catatan text default '') returns jsonb
language plpgsql security definer set search_path = public as
$$
declare v_uid uuid := auth.uid(); v_r public.sku_pra_uji; v_cat text := btrim(coalesce(p_catatan, '')); v_nama text; v_tujuan text; v_status text;
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pra_uji_aktif() then raise exception 'Pra-uji belum diaktifkan.'; end if;
  if p_hasil is null or p_hasil not in ('lulus', 'belum') then raise exception 'Hasil pra-uji harus lulus atau belum lulus.'; end if;
  if char_length(v_cat) > 1000 then raise exception 'Catatan maksimal 1000 karakter.'; end if;
  select * into v_r from public.sku_pra_uji where id = p_id for update;
  if not found or v_r.status <> 'menunggu' then raise exception 'Pengajuan pra-uji ini sudah tidak menunggu.'; end if;
  if not sigarda.pra_uji_penilai_ok(v_r.peserta_id, v_r.sku_id, v_r.tahap, v_uid) then
    raise exception 'Anda tidak dapat menilai pra-uji ini. Penilai adalah Pinsa sangga atau Bina Damping rombel Penegak yang sudah lulus butir yang sama.';
  end if;
  select status into v_status from public.sku_progress where peserta_id = v_r.peserta_id and sku_id = v_r.sku_id;
  if v_status in ('lulus', 'diajukan', 'proses') then raise exception 'Butir ini sudah lulus atau sedang dalam pengujian resmi.'; end if;
  if p_hasil = 'belum' and v_cat = '' then raise exception 'Isi catatan agar Penegak tahu bagian yang perlu diperbaiki.'; end if;
  select nama into v_nama from public.profiles where id = v_uid;

  update public.sku_pra_uji set status = p_hasil, penilai_id = v_uid, penilai_nama = v_nama, catatan = v_cat, diputuskan_pada = now() where id = p_id;
  if p_hasil = 'lulus' then
    insert into public.sku_riwayat (peserta_id, sku_id, teks, oleh)
    values (v_r.peserta_id, v_r.sku_id, 'Lulus pra-uji ' || sigarda.pra_uji_nama_tahap(v_r.tahap) || ' (' || v_nama || ')', v_uid);
    v_tujuan := sigarda.pra_uji_teruskan(v_r.peserta_id, v_r.sku_id, v_r.tahap, v_r.jadwal, v_r.catatan_peserta, v_uid);
    perform sigarda.pra_uji_beritahu_lulus(v_r.peserta_id, v_r.sku_id, v_tujuan);
  else
    insert into public.sku_riwayat (peserta_id, sku_id, teks, oleh)
    values (v_r.peserta_id, v_r.sku_id, 'Belum lulus pra-uji ' || sigarda.pra_uji_nama_tahap(v_r.tahap) || ' (' || v_nama || ')', v_uid);
    perform sigarda.notif_buat(v_r.peserta_id, 'pra_uji', 'Pra-uji belum lulus',
      sigarda.notif_label_butir(v_r.sku_id) || ' belum lulus pra-uji. Buka aplikasi untuk melihat catatan perbaikan.', '{"tab":"sku"}');
  end if;
  return jsonb_build_object('hasil', p_hasil, 'tujuan', v_tujuan);
end $$;

-- Pembina atau Admin Gudep melewati tahap pra-uji yang macet (mis. Pinsa berhalangan): pengajuan diteruskan ke tahap berikutnya atau uji resmi, dengan alasan.
create function public.sg_pra_uji_lewati(p_id bigint, p_alasan text) returns text language plpgsql security definer set search_path = public as
$$
declare v_uid uuid := auth.uid(); v_r public.sku_pra_uji; v_alasan text := btrim(coalesce(p_alasan, '')); v_nama text; v_tujuan text;
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pembina_atau_admin() then raise exception 'Hanya Pembina atau Admin Gudep yang dapat melewati tahap pra-uji.'; end if;
  if v_alasan = '' then raise exception 'Isi alasan melewati tahap pra-uji.'; end if;
  if char_length(v_alasan) > 200 then raise exception 'Alasan maksimal 200 karakter.'; end if;
  select * into v_r from public.sku_pra_uji where id = p_id for update;
  if not found or v_r.status <> 'menunggu' then raise exception 'Pengajuan pra-uji ini sudah tidak menunggu.'; end if;
  select nama into v_nama from public.profiles where id = v_uid;
  update public.sku_pra_uji set status = 'dilewati', penilai_id = v_uid, penilai_nama = v_nama, catatan = v_alasan, diputuskan_pada = now() where id = p_id;
  insert into public.sku_riwayat (peserta_id, sku_id, teks, oleh)
  values (v_r.peserta_id, v_r.sku_id, 'Tahap pra-uji ' || sigarda.pra_uji_nama_tahap(v_r.tahap) || ' dilewati oleh ' || v_nama || '. Alasan: ' || v_alasan, v_uid);
  v_tujuan := sigarda.pra_uji_teruskan(v_r.peserta_id, v_r.sku_id, v_r.tahap, v_r.jadwal, v_r.catatan_peserta, v_uid);
  perform sigarda.pra_uji_beritahu_lulus(v_r.peserta_id, v_r.sku_id, v_tujuan, true);
  return v_tujuan;
end $$;

-- Sakelar pra-uji (Pembina dan Admin Gudep). Hidup: uji resmi hanya Pembina; pengajuan yang menunggu dan ditujukan kepada penguji non-Pembina kembali ke
-- antrian rombel. Mati: pra-uji yang masih menunggu diteruskan langsung ke uji resmi (antrian rombel). Hasil: { aktif, dialihkan }.
create function public.sg_pra_uji_sakelar(p_aktif boolean) returns jsonb language plpgsql security definer set search_path = public as
$$
declare v_uid uuid := auth.uid(); v_lama boolean := sigarda.pra_uji_aktif(); v_r record; v_n int := 0; v_nama text;
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pembina_atau_admin() then raise exception 'Hanya Pembina atau Admin Gudep yang dapat mengubah pengaturan pra-uji.'; end if;
  if p_aktif is null then raise exception 'Pilih hidup atau mati.'; end if;
  if p_aktif = v_lama then return jsonb_build_object('aktif', v_lama, 'dialihkan', 0); end if;
  select nama into v_nama from public.profiles where id = v_uid;
  insert into public.pengaturan (kunci, nilai, diubah_oleh, diubah_pada) values ('pra_uji.aktif', jsonb_build_object('aktif', p_aktif), v_uid, now())
  on conflict (kunci) do update set nilai = excluded.nilai, diubah_oleh = excluded.diubah_oleh, diubah_pada = excluded.diubah_pada;
  if p_aktif then
    for v_r in select peserta_id, sku_id from public.sku_progress where status = 'diajukan' and penguji_id is not null and not sigarda.bisa_menguji(penguji_id) loop
      update public.sku_progress set penguji_id = null, diubah = now() where peserta_id = v_r.peserta_id and sku_id = v_r.sku_id;
      insert into public.sku_riwayat (peserta_id, sku_id, teks, oleh)
      values (v_r.peserta_id, v_r.sku_id, 'Dikembalikan ke antrian rombel karena pra-uji diaktifkan (uji resmi hanya Pembina)', v_uid);
      v_n := v_n + 1;
    end loop;
  else
    for v_r in select * from public.sku_pra_uji where status = 'menunggu' order by id loop
      if exists (select 1 from sigarda.penguji_sah(v_r.peserta_id, v_r.sku_id)) then
        update public.sku_pra_uji set status = 'dilewati', penilai_id = v_uid, penilai_nama = v_nama, catatan = 'Pra-uji dimatikan', diputuskan_pada = now() where id = v_r.id;
        perform sigarda.pra_uji_teruskan(v_r.peserta_id, v_r.sku_id, 'bina_damping', v_r.jadwal, v_r.catatan_peserta, v_uid);
      else
        update public.sku_pra_uji set status = 'dibatalkan', catatan = 'Pra-uji dimatikan', diputuskan_pada = now() where id = v_r.id;
        insert into public.sku_riwayat (peserta_id, sku_id, teks, oleh) values (v_r.peserta_id, v_r.sku_id, 'Pengajuan pra-uji dibatalkan karena pra-uji dimatikan', v_uid);
      end if;
      v_n := v_n + 1;
    end loop;
  end if;
  return jsonb_build_object('aktif', p_aktif, 'dialihkan', v_n);
end $$;
-- ===== akhir aksi pra-uji =====

-- ===== Cakupan pra-uji (Tahap 2, G4e): aksi =====
-- Seberapa banyak pengajuan baru yang benar-benar melewati pra-uji (punya penilai Pinsa atau Bina Damping) dibanding yang langsung ke antrian rombel Pembina karena tidak ada penilai
-- (hasil simulasi 2 Okt 2026: cakupan sangat bergantung pada banyaknya Bina Damping yang memenuhi syarat). Dihitung dari riwayat pengajuan (teks yang ditulis
-- sigarda.pra_uji_teruskan saat pengajuan awal), per rombel Penegak, untuk p_hari hari terakhir, beserta jumlah Bina Damping rombel itu pada tahun ajaran berjalan. Pembina dan Admin.
create function public.sg_pra_uji_cakupan(p_hari integer default 30) returns jsonb language plpgsql stable security definer set search_path = public as
$$
declare v_dari timestamptz; v_ta text := sigarda.tahun_ajaran_kini();
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pembina_atau_admin() then raise exception 'Hanya Pembina dan Admin Gudep yang dapat melihat cakupan pra-uji.'; end if;
  if p_hari is null or p_hari not between 1 and 365 then raise exception 'Jumlah hari harus 1 sampai 365.'; end if;
  v_dari := now() - make_interval(days => p_hari);
  return jsonb_build_object('aktif', sigarda.pra_uji_aktif(), 'hari', p_hari, 'perRombel', coalesce((
    select jsonb_agg(jsonb_build_object('rombel', x.kelas, 'lewat', x.lewat, 'langsung', x.langsung, 'binaDamping', coalesce(bd.n, 0)) order by x.langsung desc, x.kelas)
    from (
      select p.kelas, count(*) filter (where h.teks like '%; menunggu pra-uji %')::int as lewat, count(*) filter (where h.teks like '%(antrian rombel, tanpa pra-uji)')::int as langsung
      from public.sku_riwayat h join public.profiles p on p.id = h.peserta_id
      where h.waktu >= v_dari and h.teks like 'Mengajukan pengujian untuk %' and (h.teks like '%; menunggu pra-uji %' or h.teks like '%(antrian rombel, tanpa pra-uji)')
      group by p.kelas
    ) x left join (select rombel, count(*)::int as n from public.bina_damping where tahun_ajaran = v_ta group by rombel) bd on bd.rombel = x.kelas
  ), '[]'::jsonb));
end $$;
-- ===== akhir aksi cakupan pra-uji =====
-- ===== Pelantikan dan Saka (Tahap 2, G1): aksi =====
-- Hanya Pembina dan Admin Gudep yang mencatat (Pembina yang langsung membina menentukan kelayakan; Dewan hanya melihat). Pelantikan dicatat SESUDAH terjadi: tanggal tidak boleh
-- di masa depan (rencana kegiatan ada di Agenda). Penegak harus aktif dan sudah menyelesaikan SEMUA butir SKU tingkat itu (sigarda.tingkat_selesai; cermin klien
-- skuLogic.tingkatSelesai). Mencatat ulang Penegak yang sudah tercatat pada tingkat itu MENGGANTI catatannya (koreksi tanggal/tempat).

-- Mencatat pelantikan untuk banyak Penegak sekaligus (satu upacara): semua atau tidak sama sekali. Mengembalikan jumlah Penegak yang dicatat.
create function public.sg_pelantikan_catat(
  p_tingkat text, p_tanggal date, p_tempat text, p_peserta_ids uuid[], p_agenda_id bigint default null, p_catatan text default ''
) returns integer language plpgsql security definer set search_path = public as
$$
declare
  v_tempat text := sigarda.rapikan(p_tempat); v_cat text := sigarda.rapikan(p_catatan); v_ids uuid[]; v_id uuid; v_p public.profiles; v_tk text; v_pra text; v_pra_tgl date; v_siaga boolean; v_n int := 0;
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pembina_atau_admin() then raise exception 'Hanya Pembina dan Admin Gudep yang dapat mencatat pelantikan.'; end if;
  if p_tingkat is null or p_tingkat not in ('bantara','laksana','mula','bantu','tata') then raise exception 'Tingkat pelantikan harus Bantara, Laksana, Mula, Bantu, atau Tata.'; end if;
  if p_tanggal is null then raise exception 'Tanggal pelantikan wajib diisi.'; end if;
  if p_tanggal < date '2000-01-01' or p_tanggal > sigarda.hari_ini() then raise exception 'Tanggal pelantikan tidak boleh sebelum tahun 2000 atau di masa depan. Catat pelantikan sesudah terlaksana.'; end if;
  if char_length(v_tempat) not between 1 and 120 or v_tempat ~ '[[:cntrl:]<>]' then raise exception 'Tempat pelantikan wajib diisi (maksimal 120 karakter, tanpa tanda < atau >).'; end if;
  if char_length(v_cat) > 200 or v_cat ~ '[[:cntrl:]<>]' then raise exception 'Catatan maksimal 200 karakter, tanpa tanda < atau >.'; end if;
  select coalesce(array_agg(distinct x), '{}') into v_ids from unnest(coalesce(p_peserta_ids, '{}')) x;
  if coalesce(array_length(v_ids, 1), 0) = 0 then raise exception 'Pilih sedikitnya satu anggota.'; end if;
  if array_length(v_ids, 1) > 200 then raise exception 'Maksimal 200 anggota sekali catat.'; end if;
  v_siaga := p_tingkat in ('mula','bantu','tata');   -- Siaga: kegiatan Agenda jenis apa pun boleh ditautkan (belum ada jenis pelantikan Siaga)
  if p_agenda_id is not null and not exists (select 1 from public.agenda where id = p_agenda_id and (v_siaga or jenis = 'pelantikan_' || p_tingkat)) then
    raise exception 'Kegiatan Agenda yang dipilih bukan pelantikan %.', initcap(p_tingkat);
  end if;
  v_tk := initcap(p_tingkat);
  v_pra := lower(sigarda.prasyarat_tingkat(v_tk));   -- tingkat sebelumnya (null untuk Bantara dan Mula)
  foreach v_id in array v_ids loop
    select * into v_p from public.profiles where id = v_id and role = 'peserta';
    if not found then raise exception 'Ada anggota yang bukan Penegak atau anggota Siaga.'; end if;
    if v_p.status <> 'aktif' then raise exception '% tidak aktif; pelantikan hanya untuk anggota aktif.', v_p.nama; end if;
    if (v_p.tanpa_akun or sigarda.kelas_siaga(v_p.kelas)) <> v_siaga then raise exception '% bukan anggota %; pelantikan % hanya untuk %.', v_p.nama, case when v_siaga then 'Siaga' else 'Penegak' end, v_tk, case when v_siaga then 'anggota Siaga' else 'Penegak' end; end if;
    if not sigarda.tingkat_selesai(v_id, v_tk) then raise exception '% belum menyelesaikan seluruh butir SKU %.', v_p.nama, v_tk; end if;
    if v_pra is not null then
      select tanggal into v_pra_tgl from public.pelantikan where peserta_id = v_id and tingkat = v_pra;
      if v_pra_tgl is not null and p_tanggal <= v_pra_tgl then raise exception 'Pelantikan % % harus sesudah pelantikan % (%).', v_tk, v_p.nama, initcap(v_pra), to_char(v_pra_tgl, 'YYYY-MM-DD'); end if;
    end if;
    insert into public.pelantikan (peserta_id, tingkat, tanggal, tempat, agenda_id, catatan, dicatat_oleh, dicatat_pada)
    values (v_id, p_tingkat, p_tanggal, v_tempat, p_agenda_id, v_cat, auth.uid(), now())
    on conflict (peserta_id, tingkat) do update
      set tanggal = excluded.tanggal, tempat = excluded.tempat, agenda_id = excluded.agenda_id, catatan = excluded.catatan, dicatat_oleh = excluded.dicatat_oleh, dicatat_pada = excluded.dicatat_pada;
    v_n := v_n + 1;
  end loop;
  return v_n;
end $$;

-- Menghapus satu catatan pelantikan (salah Penegak atau salah tingkat).
create function public.sg_pelantikan_hapus(p_id bigint) returns void language plpgsql security definer set search_path = public as
$$
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pembina_atau_admin() then raise exception 'Hanya Pembina dan Admin Gudep yang dapat menghapus catatan pelantikan.'; end if;
  delete from public.pelantikan where id = p_id;
  if not found then raise exception 'Catatan pelantikan tidak ditemukan.'; end if;
end $$;

-- Keanggotaan Saka: tambah (p_id null) atau ubah. Satu Penegak boleh di beberapa Saka, tetapi satu catatan per nama Saka. Status 'aktif' (tanpa tanggal selesai) atau 'selesai'.
create function public.sg_saka_simpan(
  p_id bigint, p_peserta_id uuid, p_saka text, p_tanggal_masuk date, p_status text, p_tanggal_selesai date, p_surat_url text default '', p_catatan text default ''
) returns bigint language plpgsql security definer set search_path = public as
$$
declare
  v_saka text := sigarda.rapikan(p_saka); v_url text := btrim(coalesce(p_surat_url, '')); v_cat text := sigarda.rapikan(p_catatan); v_p public.profiles; v_hasil bigint;
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pembina_atau_admin() then raise exception 'Hanya Pembina dan Admin Gudep yang dapat mencatat keanggotaan Saka.'; end if;
  select * into v_p from public.profiles where id = p_peserta_id and role = 'peserta';
  if not found then raise exception 'Pilih Penegak.'; end if;
  if v_p.status <> 'aktif' then raise exception '% tidak aktif; keanggotaan Saka hanya dicatat untuk Penegak aktif.', v_p.nama; end if;
  if char_length(v_saka) not between 1 and 60 or v_saka ~ '[[:cntrl:]<>]' then raise exception 'Nama Saka wajib diisi (maksimal 60 karakter, tanpa tanda < atau >).'; end if;
  if p_tanggal_masuk is null then raise exception 'Tanggal masuk Saka wajib diisi.'; end if;
  if p_tanggal_masuk < date '2000-01-01' or p_tanggal_masuk > sigarda.hari_ini() then raise exception 'Tanggal masuk Saka tidak boleh sebelum tahun 2000 atau di masa depan.'; end if;
  if p_status is null or p_status not in ('aktif','selesai') then raise exception 'Status Saka harus aktif atau selesai.'; end if;
  if p_status = 'aktif' and p_tanggal_selesai is not null then raise exception 'Anggota Saka yang masih aktif tidak punya tanggal selesai.'; end if;
  if p_status = 'selesai' and (p_tanggal_selesai is null or p_tanggal_selesai < p_tanggal_masuk or p_tanggal_selesai > sigarda.hari_ini()) then
    raise exception 'Isi tanggal selesai (tidak sebelum tanggal masuk dan tidak di masa depan).';
  end if;
  if v_url <> '' and (v_url !~* '^https?://' or char_length(v_url) > 500 or v_url ~ '[[:cntrl:][:space:]<>]') then raise exception 'Tautan surat keterangan harus berawalan http:// atau https:// (maksimal 500 karakter, tanpa spasi).'; end if;
  if char_length(v_cat) > 200 or v_cat ~ '[[:cntrl:]<>]' then raise exception 'Catatan maksimal 200 karakter, tanpa tanda < atau >.'; end if;
  begin
    if p_id is null then
      insert into public.saka_anggota (peserta_id, saka, tanggal_masuk, status, tanggal_selesai, surat_url, catatan, dicatat_oleh)
      values (p_peserta_id, v_saka, p_tanggal_masuk, p_status, p_tanggal_selesai, v_url, v_cat, auth.uid()) returning id into v_hasil;
    else
      update public.saka_anggota set peserta_id = p_peserta_id, saka = v_saka, tanggal_masuk = p_tanggal_masuk, status = p_status, tanggal_selesai = p_tanggal_selesai,
        surat_url = v_url, catatan = v_cat, dicatat_oleh = auth.uid(), dicatat_pada = now()
      where id = p_id returning id into v_hasil;
      if v_hasil is null then raise exception 'Catatan Saka tidak ditemukan.'; end if;
    end if;
  exception when unique_violation then
    raise exception '% sudah tercatat di Saka %. Ubah catatan yang ada.', v_p.nama, v_saka;
  end;
  return v_hasil;
end $$;

create function public.sg_saka_hapus(p_id bigint) returns void language plpgsql security definer set search_path = public as
$$
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pembina_atau_admin() then raise exception 'Hanya Pembina dan Admin Gudep yang dapat menghapus catatan Saka.'; end if;
  delete from public.saka_anggota where id = p_id;
  if not found then raise exception 'Catatan Saka tidak ditemukan.'; end if;
end $$;
-- ===== akhir aksi pelantikan dan saka =====
-- ===== TKK (Tahap 2, G2): aksi =====
-- Hanya Pembina dan Admin Gudep yang mencatat (Pembina yang langsung membina yang memberi TKK; Dewan hanya membaca). TKK dicatat SESUDAH lulus uji (tanggal bukan
-- masa depan). Penegak harus aktif dan sudah menyelesaikan SKU Bantara (SK Kwarnas 134/1976: TKK dapat dikenakan sesudah Penegak Bantara). TKK harus dari golongan
-- Penegak dan, bila khusus satu agama (Sholat, Khotib, Qori, Muadzin), sesuai agama Penegak. Tingkat berurutan: Madya butuh Purwa jenis yang sama, Utama butuh Madya, dan
-- tanggalnya tidak boleh mendahului tingkat di bawahnya. Tim penguji 2 orang (nama; tanpa akun) dan bukti melatih wajib. Mencatat ulang tingkat yang sama = koreksi.

-- Mencatat (atau mengoreksi) satu capaian TKK. Mengembalikan id catatan.
create function public.sg_tkk_catat(
  p_peserta_id uuid, p_tkk_id text, p_tingkat text, p_tanggal date, p_penguji1 text, p_penguji2 text, p_melatih text, p_bukti_url text default '', p_catatan text default ''
) returns bigint language plpgsql security definer set search_path = public as
$$
declare v_id bigint;
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pembina_atau_admin() then raise exception 'Hanya Pembina dan Admin Gudep yang dapat mencatat TKK.'; end if;
  perform sigarda.tkk_periksa(p_peserta_id, p_tkk_id, p_tingkat, p_tanggal, p_penguji1, p_penguji2, p_melatih, p_bukti_url, p_catatan);
  insert into public.tkk_capaian (peserta_id, tkk_id, tingkat, tanggal, penguji1, penguji2, melatih, bukti_url, catatan, dicatat_oleh, dicatat_pada)
  values (p_peserta_id, p_tkk_id, p_tingkat, p_tanggal, sigarda.rapikan(p_penguji1), sigarda.rapikan(p_penguji2), sigarda.rapikan(p_melatih), btrim(coalesce(p_bukti_url, '')), sigarda.rapikan(p_catatan), auth.uid(), now())
  on conflict (peserta_id, tkk_id, tingkat) do update
    set tanggal = excluded.tanggal, penguji1 = excluded.penguji1, penguji2 = excluded.penguji2, melatih = excluded.melatih, bukti_url = excluded.bukti_url,
        catatan = excluded.catatan, dicatat_oleh = excluded.dicatat_oleh, dicatat_pada = excluded.dicatat_pada
  returning id into v_id;
  return v_id;
end $$;

-- Menghapus satu catatan capaian (salah Penegak atau salah jenis). Tingkat di bawah yang masih ditopang tingkat di atasnya tidak dapat dihapus lebih dulu.
create function public.sg_tkk_hapus(p_id bigint) returns void language plpgsql security definer set search_path = public as
$$
declare v public.tkk_capaian;
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pembina_atau_admin() then raise exception 'Hanya Pembina dan Admin Gudep yang dapat menghapus catatan TKK.'; end if;
  select * into v from public.tkk_capaian where id = p_id;
  if not found then raise exception 'Catatan TKK tidak ditemukan.'; end if;
  if v.tingkat <> 'utama' and exists (
    select 1 from public.tkk_capaian where peserta_id = v.peserta_id and tkk_id = v.tkk_id and tingkat = case v.tingkat when 'purwa' then 'madya' else 'utama' end
  ) then raise exception 'Hapus tingkat yang lebih tinggi dari TKK ini lebih dulu.'; end if;
  delete from public.tkk_capaian where id = p_id;
end $$;

-- TKK Krida: tambah (p_id null) atau ubah. Satu catatan per nama Krida per Penegak.
create function public.sg_tkk_krida_simpan(
  p_id bigint, p_peserta_id uuid, p_nama text, p_saka text, p_tanggal date, p_bukti_url text default '', p_catatan text default ''
) returns bigint language plpgsql security definer set search_path = public as
$$
declare v_nama text := sigarda.rapikan(p_nama); v_saka text := sigarda.rapikan(p_saka); v_url text := btrim(coalesce(p_bukti_url, '')); v_cat text := sigarda.rapikan(p_catatan); v_p public.profiles; v_id bigint;
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pembina_atau_admin() then raise exception 'Hanya Pembina dan Admin Gudep yang dapat mencatat TKK Krida.'; end if;
  select * into v_p from public.profiles where id = p_peserta_id and role = 'peserta';
  if not found then raise exception 'Pilih Penegak.'; end if;
  if v_p.status <> 'aktif' then raise exception '% tidak aktif; TKK Krida hanya dicatat untuk Penegak aktif.', v_p.nama; end if;
  if char_length(v_nama) not between 1 and 80 or v_nama ~ '[[:cntrl:]<>]' then raise exception 'Nama TKK Krida wajib diisi (maksimal 80 karakter, tanpa tanda < atau >).'; end if;
  if char_length(v_saka) > 60 or v_saka ~ '[[:cntrl:]<>]' then raise exception 'Nama Saka maksimal 60 karakter, tanpa tanda < atau >.'; end if;
  if p_tanggal is null then raise exception 'Tanggal lulus wajib diisi.'; end if;
  if p_tanggal < date '2000-01-01' or p_tanggal > sigarda.hari_ini() then raise exception 'Tanggal lulus tidak boleh sebelum tahun 2000 atau di masa depan.'; end if;
  if v_url <> '' and (v_url !~* '^https?://' or char_length(v_url) > 500 or v_url ~ '[[:cntrl:][:space:]<>]') then raise exception 'Tautan bukti harus berawalan http:// atau https:// (maksimal 500 karakter, tanpa spasi).'; end if;
  if char_length(v_cat) > 200 or v_cat ~ '[[:cntrl:]<>]' then raise exception 'Catatan maksimal 200 karakter, tanpa tanda < atau >.'; end if;
  begin
    if p_id is null then
      insert into public.tkk_krida (peserta_id, nama, saka, tanggal, bukti_url, catatan, dicatat_oleh) values (p_peserta_id, v_nama, v_saka, p_tanggal, v_url, v_cat, auth.uid()) returning id into v_id;
    else
      update public.tkk_krida set peserta_id = p_peserta_id, nama = v_nama, saka = v_saka, tanggal = p_tanggal, bukti_url = v_url, catatan = v_cat, dicatat_oleh = auth.uid(), dicatat_pada = now()
      where id = p_id returning id into v_id;
      if v_id is null then raise exception 'Catatan TKK Krida tidak ditemukan.'; end if;
    end if;
  exception when unique_violation then
    raise exception '% sudah tercatat memiliki TKK Krida %. Ubah catatan yang ada.', v_p.nama, v_nama;
  end;
  return v_id;
end $$;

create function public.sg_tkk_krida_hapus(p_id bigint) returns void language plpgsql security definer set search_path = public as
$$
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pembina_atau_admin() then raise exception 'Hanya Pembina dan Admin Gudep yang dapat menghapus catatan TKK Krida.'; end if;
  delete from public.tkk_krida where id = p_id;
  if not found then raise exception 'Catatan TKK Krida tidak ditemukan.'; end if;
end $$;

-- Ambang kesiapan Garuda (pengaturan 'tkk.ambang'): { total, madya, utamaWajib: [id TKK Penegak, unik] }. total 1-200; madya 0-100; total harus memuat semua yang wajib Utama dan Madya-nya.
create function public.sg_tkk_ambang_simpan(p_nilai jsonb) returns void language plpgsql security definer set search_path = public as
$$
declare v_total int; v_madya int; v_wajib text[]; v_n int;
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pembina_atau_admin() then raise exception 'Hanya Pembina dan Admin Gudep yang dapat mengubah ambang TKK.'; end if;
  if p_nilai is null or jsonb_typeof(p_nilai) <> 'object' or p_nilai - 'total' - 'madya' - 'utamaWajib' <> '{}'::jsonb then raise exception 'Bentuk ambang TKK tidak sah.'; end if;
  -- coalesce: kunci yang hilang menghasilkan NULL, dan perbandingan dengan NULL tidak akan memicu galat
  if coalesce(jsonb_typeof(p_nilai -> 'total'), '') <> 'number' or coalesce(jsonb_typeof(p_nilai -> 'madya'), '') <> 'number' or coalesce(jsonb_typeof(p_nilai -> 'utamaWajib'), '') <> 'array' then raise exception 'Bentuk ambang TKK tidak sah.'; end if;
  if (p_nilai ->> 'total') !~ '^[0-9]+$' or (p_nilai ->> 'madya') !~ '^[0-9]+$' then raise exception 'Jumlah TKK harus bilangan bulat tidak negatif.'; end if;
  v_total := (p_nilai ->> 'total')::int; v_madya := (p_nilai ->> 'madya')::int;
  if v_total not between 1 and 200 then raise exception 'Total TKK harus 1 sampai 200.'; end if;
  if v_madya not between 0 and 100 then raise exception 'Jumlah TKK Madya harus 0 sampai 100.'; end if;
  if exists (select 1 from jsonb_array_elements(p_nilai -> 'utamaWajib') e where jsonb_typeof(e) <> 'string') then raise exception 'Daftar TKK wajib Utama tidak sah.'; end if;
  select coalesce(array_agg(e #>> '{}'), '{}') into v_wajib from jsonb_array_elements(p_nilai -> 'utamaWajib') e;
  if (select count(distinct x) from unnest(v_wajib) x) <> coalesce(array_length(v_wajib, 1), 0) then raise exception 'Daftar TKK wajib Utama tidak boleh berulang.'; end if;
  select count(*) into v_n from public.tkk_katalog where id = any(v_wajib) and golongan = 'penegak';
  if v_n <> coalesce(array_length(v_wajib, 1), 0) then raise exception 'Ada TKK wajib Utama yang tidak dikenal atau khusus Siaga.'; end if;
  if v_total < coalesce(array_length(v_wajib, 1), 0) + v_madya then raise exception 'Total TKK harus memuat semua TKK wajib Utama ditambah TKK Madya.'; end if;
  insert into public.pengaturan (kunci, nilai, diubah_oleh, diubah_pada)
  values ('tkk.ambang', jsonb_build_object('total', v_total, 'madya', v_madya, 'utamaWajib', to_jsonb(v_wajib)), auth.uid(), now())
  on conflict (kunci) do update set nilai = excluded.nilai, diubah_oleh = excluded.diubah_oleh, diubah_pada = excluded.diubah_pada;
end $$;
-- ===== akhir aksi tkk =====

-- ===== TKK pengajuan (Tahap 2, G2b): aksi =====
-- Pemeriksa isian capaian TKK yang DIPAKAI BERSAMA sg_tkk_catat (Pembina/Admin), sg_tkk_ajukan (Penegak), dan persetujuan sg_tkk_tinjau, sehingga aturannya persis sama:
-- Penegak aktif, SKU Bantara selesai, TKK golongan Penegak dan seagama bila khusus agama, tingkat berurutan (Madya butuh Purwa, Utama butuh Madya, tanggal tidak
-- mendahului tingkat di bawahnya atau melewati tingkat di atasnya), tanggal bukan masa depan, dua penguji berbeda, bukti melatih, tautan, catatan. Melempar galat.
create function sigarda.tkk_periksa(
  p_peserta_id uuid, p_tkk_id text, p_tingkat text, p_tanggal date, p_penguji1 text, p_penguji2 text, p_melatih text, p_bukti_url text, p_catatan text
) returns void language plpgsql stable security definer set search_path = public as
$$
declare
  v_p public.profiles; v_t public.tkk_katalog; v_p1 text := sigarda.rapikan(p_penguji1); v_p2 text := sigarda.rapikan(p_penguji2); v_lat text := sigarda.rapikan(p_melatih);
  v_url text := btrim(coalesce(p_bukti_url, '')); v_cat text := sigarda.rapikan(p_catatan); v_bawah date; v_atas date;
begin
  select * into v_p from public.profiles where id = p_peserta_id and role = 'peserta';
  if not found then raise exception 'Pilih Penegak.'; end if;
  if v_p.status <> 'aktif' then raise exception '% tidak aktif; TKK hanya dicatat untuk Penegak aktif.', v_p.nama; end if;
  if not sigarda.tingkat_selesai(p_peserta_id, 'Bantara') then raise exception '% belum menyelesaikan SKU Bantara; TKK dapat dikenakan sesudah Penegak Bantara.', v_p.nama; end if;
  select * into v_t from public.tkk_katalog where id = p_tkk_id;
  if not found then raise exception 'TKK tidak dikenal.'; end if;
  if v_t.golongan <> 'penegak' then raise exception 'TKK % khusus golongan Siaga, tidak untuk Penegak.', v_t.nama; end if;
  if v_t.agama is not null and v_t.agama is distinct from v_p.agama then raise exception 'TKK % khusus penganut agama %.', v_t.nama, v_t.agama; end if;
  if p_tingkat is null or p_tingkat not in ('purwa','madya','utama') then raise exception 'Tingkat TKK harus Purwa, Madya, atau Utama.'; end if;
  if p_tanggal is null then raise exception 'Tanggal lulus wajib diisi.'; end if;
  if p_tanggal < date '2000-01-01' or p_tanggal > sigarda.hari_ini() then raise exception 'Tanggal lulus tidak boleh sebelum tahun 2000 atau di masa depan.'; end if;
  if char_length(v_p1) not between 1 and 80 or char_length(v_p2) not between 1 and 80 or v_p1 ~ '[[:cntrl:]<>]' or v_p2 ~ '[[:cntrl:]<>]' then
    raise exception 'Isi nama kedua penguji (tim 2 orang; maksimal 80 karakter, tanpa tanda < atau >).';
  end if;
  if lower(v_p1) = lower(v_p2) then raise exception 'Kedua penguji harus dua orang yang berbeda.'; end if;
  if char_length(v_lat) not between 1 and 200 or v_lat ~ '[[:cntrl:]<>]' then raise exception 'Isi bukti melatih: siapa yang telah dilatih sampai TKK tingkat di bawahnya (maksimal 200 karakter, tanpa tanda < atau >).'; end if;
  if v_url <> '' and (v_url !~* '^https?://' or char_length(v_url) > 500 or v_url ~ '[[:cntrl:][:space:]<>]') then raise exception 'Tautan bukti harus berawalan http:// atau https:// (maksimal 500 karakter, tanpa spasi).'; end if;
  if char_length(v_cat) > 200 or v_cat ~ '[[:cntrl:]<>]' then raise exception 'Catatan maksimal 200 karakter, tanpa tanda < atau >.'; end if;
  if p_tingkat <> 'purwa' then
    select tanggal into v_bawah from public.tkk_capaian where peserta_id = p_peserta_id and tkk_id = p_tkk_id and tingkat = case p_tingkat when 'madya' then 'purwa' else 'madya' end;
    if v_bawah is null then raise exception '% Utama butuh Madya, dan Madya butuh Purwa, dari jenis TKK yang sama. Catat tingkat di bawahnya lebih dulu.', v_t.nama; end if;
    if p_tanggal < v_bawah then raise exception 'Tanggal % tidak boleh sebelum tanggal tingkat di bawahnya (%).', initcap(p_tingkat), to_char(v_bawah, 'YYYY-MM-DD'); end if;
  end if;
  if p_tingkat <> 'utama' then
    select tanggal into v_atas from public.tkk_capaian where peserta_id = p_peserta_id and tkk_id = p_tkk_id and tingkat = case p_tingkat when 'purwa' then 'madya' else 'utama' end;
    if v_atas is not null and p_tanggal > v_atas then raise exception 'Tanggal % tidak boleh sesudah tanggal tingkat di atasnya (%).', initcap(p_tingkat), to_char(v_atas, 'YYYY-MM-DD'); end if;
  end if;
end $$;

-- Pembina yang boleh menjadi Penguji 1 pengajuan TKK seorang Penegak (G2c): Pembina aktif yang ditugaskan untuk Penegak itu pada tahun ajaran berjalan, dengan urutan yang sama seperti
-- penugasan penguji SKU: penugasan khusus Penegak (bila ada Pembina di dalamnya) mengalahkan penugasan rombel kelasnya; bila keduanya tidak memuat Pembina, semua Pembina aktif.
create function sigarda.tkk_pembina_penilai(p_peserta uuid) returns setof uuid language plpgsql stable security definer set search_path = public as
$$
declare v_ta text := sigarda.tahun_ajaran_kini(); v_kelas text; v_ada boolean;
begin
  select kelas into v_kelas from public.profiles where id = p_peserta;
  select exists (select 1 from public.penugasan_peserta pp join public.profiles u on u.id = pp.penguji_id
                 where pp.tahun_ajaran = v_ta and pp.peserta_id = p_peserta and u.role = 'penguji' and u.jabatan = 'Pembina' and u.status = 'aktif') into v_ada;
  if v_ada then
    return query select u.id from public.penugasan_peserta pp join public.profiles u on u.id = pp.penguji_id
                 where pp.tahun_ajaran = v_ta and pp.peserta_id = p_peserta and u.role = 'penguji' and u.jabatan = 'Pembina' and u.status = 'aktif';
    return;
  end if;
  select exists (select 1 from public.penugasan_rombel pr join public.profiles u on u.id = pr.penguji_id
                 where pr.tahun_ajaran = v_ta and pr.rombel = v_kelas and u.role = 'penguji' and u.jabatan = 'Pembina' and u.status = 'aktif') into v_ada;
  if v_ada then
    return query select u.id from public.penugasan_rombel pr join public.profiles u on u.id = pr.penguji_id
                 where pr.tahun_ajaran = v_ta and pr.rombel = v_kelas and u.role = 'penguji' and u.jabatan = 'Pembina' and u.status = 'aktif';
    return;
  end if;
  return query select u.id from public.profiles u where u.role = 'penguji' and u.jabatan = 'Pembina' and u.status = 'aktif';
end $$;

-- Pilihan Penguji 1 bagi Penegak yang sedang masuk: [{ id, nama }] menurut nama (pengajuan hanya diterima bila Penguji 1 ada di daftar ini).
create function public.sg_tkk_penguji_pilihan() returns jsonb language plpgsql stable security definer set search_path = public as
$$
begin
  perform sigarda.wajib_aktif();
  if not exists (select 1 from public.profiles where id = auth.uid() and role = 'peserta') then return '[]'::jsonb; end if;
  return coalesce((select jsonb_agg(jsonb_build_object('id', u.id, 'nama', u.nama) order by u.nama)
                   from public.profiles u where u.id in (select sigarda.tkk_pembina_penilai(auth.uid()))), '[]'::jsonb);
end $$;

-- Penegak mengajukan capaian TKK-nya sendiri (Pembina mencatat langsung lewat sg_tkk_catat). Penguji 1 = Pembina yang ditugaskan untuk kelasnya (dipilih dari sg_tkk_penguji_pilihan;
-- namanya disalin server), Penguji 2 diisi Penegak. Maksimal 20 pengajuan menunggu; tingkat yang sudah tercatat resmi tidak diajukan lagi.
create function public.sg_tkk_ajukan(
  p_tkk_id text, p_tingkat text, p_tanggal date, p_penguji1_id uuid, p_penguji2 text, p_melatih text, p_bukti_url text default '', p_catatan text default ''
) returns bigint language plpgsql security definer set search_path = public as
$$
declare v_uid uuid := auth.uid(); v_id bigint; v_nama1 text;
begin
  perform sigarda.wajib_aktif();
  if not exists (select 1 from public.profiles where id = v_uid and role = 'peserta') then raise exception 'Hanya Penegak yang dapat mengajukan TKK. Pembina mencatat langsung di menu TKK.'; end if;
  if (select count(*) from public.tkk_pengajuan where peserta_id = v_uid and status = 'menunggu') >= 20 then raise exception 'Terlalu banyak pengajuan yang menunggu (maksimal 20). Tunggu Pembina meninjau.'; end if;
  if p_penguji1_id is null or p_penguji1_id not in (select sigarda.tkk_pembina_penilai(v_uid)) then raise exception 'Penguji 1 harus Pembina yang ditugaskan untuk kelasmu. Pilih dari daftar.'; end if;
  select nama into v_nama1 from public.profiles where id = p_penguji1_id;
  perform sigarda.tkk_periksa(v_uid, p_tkk_id, p_tingkat, p_tanggal, v_nama1, p_penguji2, p_melatih, p_bukti_url, p_catatan);
  if exists (select 1 from public.tkk_capaian where peserta_id = v_uid and tkk_id = p_tkk_id and tingkat = p_tingkat) then
    raise exception 'TKK ini pada tingkat itu sudah tercatat resmi. Koreksi dilakukan Pembina.';
  end if;
  begin
    insert into public.tkk_pengajuan (peserta_id, tkk_id, tingkat, tanggal, penguji1, penguji1_id, penguji2, melatih, bukti_url, catatan)
    values (v_uid, p_tkk_id, p_tingkat, p_tanggal, sigarda.rapikan(v_nama1), p_penguji1_id, sigarda.rapikan(p_penguji2), sigarda.rapikan(p_melatih), btrim(coalesce(p_bukti_url, '')), sigarda.rapikan(p_catatan))
    returning id into v_id;
  exception when unique_violation then
    raise exception 'Pengajuan yang sama masih menunggu ditinjau Pembina.';
  end;
  return v_id;
end $$;

-- Penegak membatalkan pengajuannya yang masih menunggu.
create function public.sg_tkk_ajukan_batal(p_id bigint) returns void language plpgsql security definer set search_path = public as
$$
begin
  perform sigarda.wajib_aktif();
  update public.tkk_pengajuan set status = 'dibatalkan' where id = p_id and peserta_id = auth.uid() and status = 'menunggu';
  if not found then raise exception 'Pengajuan tidak ditemukan atau sudah ditinjau.'; end if;
end $$;

-- Pembina atau Admin meninjau satu pengajuan. p_keputusan 'disetujui' (menjadi capaian resmi lewat pemeriksa yang sama; keadaan dicek ulang saat ini) atau 'ditolak' (catatan wajib).
-- Saat menyetujui, peninjau boleh MENGGANTI nama penguji (p_penguji1/p_penguji2; kosong = tetap), mis. bila Pembina 1 dan 2 berhalangan hadir: alasan wajib di catatan, dan nama
-- sebelumnya tersimpan di penguji_awal. Penggantian diabaikan saat menolak.
create function public.sg_tkk_tinjau(p_id bigint, p_keputusan text, p_catatan text default '', p_penguji1 text default null, p_penguji2 text default null) returns void language plpgsql security definer set search_path = public as
$$
declare
  v public.tkk_pengajuan; v_cat text := sigarda.rapikan(p_catatan); v_nama text; v_cid bigint;
  v_p1 text; v_p2 text; v_awal text := ''; v_ganti boolean;
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pembina_atau_admin() then raise exception 'Hanya Pembina dan Admin Gudep yang dapat meninjau pengajuan TKK.'; end if;
  if p_keputusan is null or p_keputusan not in ('disetujui','ditolak') then raise exception 'Keputusan harus disetujui atau ditolak.'; end if;
  if char_length(v_cat) > 200 or v_cat ~ '[[:cntrl:]<>]' then raise exception 'Catatan maksimal 200 karakter, tanpa tanda < atau >.'; end if;
  if p_keputusan = 'ditolak' and v_cat = '' then raise exception 'Isi catatan agar Penegak tahu alasan penolakan.'; end if;
  select * into v from public.tkk_pengajuan where id = p_id for update;
  if not found or v.status <> 'menunggu' then raise exception 'Pengajuan ini sudah tidak menunggu.'; end if;
  select nama into v_nama from public.profiles where id = auth.uid();
  v_p1 := v.penguji1; v_p2 := v.penguji2;
  if p_keputusan = 'disetujui' then
    if sigarda.rapikan(p_penguji1) <> '' then v_p1 := sigarda.rapikan(p_penguji1); end if;
    if sigarda.rapikan(p_penguji2) <> '' then v_p2 := sigarda.rapikan(p_penguji2); end if;
    v_ganti := v_p1 <> v.penguji1 or v_p2 <> v.penguji2;
    if v_ganti then
      if v_cat = '' then raise exception 'Nama penguji diganti: isi alasannya di catatan (mis. Pembina 1 dan 2 berhalangan hadir).'; end if;
      v_awal := left(v.penguji1 || ' dan ' || v.penguji2, 200);
    end if;
    perform sigarda.tkk_periksa(v.peserta_id, v.tkk_id, v.tingkat, v.tanggal, v_p1, v_p2, v.melatih, v.bukti_url, v.catatan);
    insert into public.tkk_capaian (peserta_id, tkk_id, tingkat, tanggal, penguji1, penguji2, melatih, bukti_url, catatan, dicatat_oleh, dicatat_pada)
    values (v.peserta_id, v.tkk_id, v.tingkat, v.tanggal, v_p1, v_p2, v.melatih, v.bukti_url, v.catatan, auth.uid(), now())
    on conflict (peserta_id, tkk_id, tingkat) do update
      set tanggal = excluded.tanggal, penguji1 = excluded.penguji1, penguji2 = excluded.penguji2, melatih = excluded.melatih, bukti_url = excluded.bukti_url,
          catatan = excluded.catatan, dicatat_oleh = excluded.dicatat_oleh, dicatat_pada = excluded.dicatat_pada
    returning id into v_cid;
  end if;
  update public.tkk_pengajuan set status = p_keputusan, penguji1 = v_p1, penguji2 = v_p2, penguji_awal = v_awal, ditinjau_oleh = auth.uid(), ditinjau_nama = v_nama, ditinjau_pada = now(),
    catatan_tinjauan = v_cat, capaian_id = v_cid where id = p_id;
end $$;

-- Notifikasi: Pembina Penguji 1 diberi tahu pengajuan baru (semua Pembina bila Penguji 1 tidak tercatat); Penegak diberi tahu pengajuannya ditinjau (isi singkat, hasil dilihat di aplikasi).
create function sigarda.notif_tkk_pengajuan() returns trigger language plpgsql security definer set search_path = public as
$$
declare v_x uuid; v_nama text; v_tkk text;
begin
  select nama into v_tkk from public.tkk_katalog where id = NEW.tkk_id;
  if TG_OP = 'INSERT' then
    select nama into v_nama from public.profiles where id = NEW.peserta_id;
    for v_x in select id from public.profiles where role = 'penguji' and jabatan = 'Pembina' and status = 'aktif' and (NEW.penguji1_id is null or id = NEW.penguji1_id) loop
      perform sigarda.notif_buat(v_x, 'tkk', 'Pengajuan TKK baru', v_nama || ' mengajukan TKK ' || v_tkk || ' ' || initcap(NEW.tingkat), '{"tab":"tkk"}', 'tkk-baru:' || NEW.id);
    end loop;
  elsif OLD.status = 'menunggu' and NEW.status in ('disetujui','ditolak') then
    perform sigarda.notif_buat(NEW.peserta_id, 'tkk', 'Pengajuan TKK ditinjau', 'Pengajuan TKK ' || v_tkk || ' ' || initcap(NEW.tingkat) || ' sudah ditinjau Pembina. Buka aplikasi untuk melihat hasilnya.', '{"tab":"tkk"}', 'tkk-tinjau:' || NEW.id);
  end if;
  return null;
end $$;
create trigger notif_tkk_pengajuan_baru after insert on public.tkk_pengajuan for each row execute function sigarda.notif_tkk_pengajuan();
create trigger notif_tkk_pengajuan_tinjau after update of status on public.tkk_pengajuan for each row execute function sigarda.notif_tkk_pengajuan();
-- ===== akhir aksi tkk pengajuan =====

-- ===== TKK Siaga (Pramuka Siaga, Fase 5): aksi =====
-- Pembina atau Admin mencatat bahwa seorang anak Siaga aktif lulus satu TKK (satu tingkat saja). Syarat: anggota Siaga (kelas SD atau tanpa akun), SKU Siaga Bantu sudah selesai
-- (SK 134/1976: TKK dapat dikenakan sesudah Siaga Bantu), TKK dari 84 SKK SK 132/1979 (semuanya punya syarat golongan Siaga; SKK tambahan sesudahnya tidak dipakai) dan seagama
-- bila khusus satu agama, tanggal bukan masa depan. Mencatat ulang TKK yang sama = koreksi. Aturan isian dicerminkan src/lib/tkkSiagaLogic.js (periksaTkkSiaga) dan dibandingkan
-- langsung dengan fungsi ini oleh uji/tkk-siaga-klien.mjs.
create function public.sg_tkk_siaga_catat(
  p_peserta_id uuid, p_tkk_id text, p_tanggal date, p_penguji text, p_bukti_url text default '', p_catatan text default ''
) returns bigint language plpgsql security definer set search_path = public as
$$
declare
  v_p public.profiles; v_t public.tkk_katalog; v_peng text := sigarda.rapikan(p_penguji); v_url text := btrim(coalesce(p_bukti_url, '')); v_cat text := sigarda.rapikan(p_catatan); v_id bigint;
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pembina_atau_admin() then raise exception 'Hanya Pembina dan Admin Gudep yang dapat mencatat TKK.'; end if;
  select * into v_p from public.profiles where id = p_peserta_id and role = 'peserta';
  if not found then raise exception 'Pilih anggota Siaga.'; end if;
  if not (v_p.tanpa_akun or sigarda.kelas_siaga(v_p.kelas)) then raise exception 'TKK Siaga hanya dicatat untuk anggota Siaga.'; end if;
  if v_p.status <> 'aktif' then raise exception '% tidak aktif; TKK hanya dicatat untuk anggota aktif.', v_p.nama; end if;
  if not sigarda.tingkat_selesai(p_peserta_id, 'Bantu') then raise exception '% belum menyelesaikan SKU Bantu; TKK dapat dikenakan sesudah Siaga Bantu.', v_p.nama; end if;
  select * into v_t from public.tkk_katalog where id = p_tkk_id;
  if not found then raise exception 'TKK tidak dikenal.'; end if;
  if v_t.sumber <> 'skk-132-1979' then raise exception 'TKK % belum dipakai untuk golongan Siaga.', v_t.nama; end if;
  if v_t.agama is not null and v_t.agama is distinct from v_p.agama then raise exception 'TKK % khusus penganut agama %.', v_t.nama, v_t.agama; end if;
  if p_tanggal is null then raise exception 'Tanggal lulus wajib diisi.'; end if;
  if p_tanggal < date '2015-01-01' or p_tanggal > sigarda.hari_ini() then raise exception 'Tanggal lulus harus antara 1 Januari 2015 dan hari ini.'; end if;
  if char_length(v_peng) not between 1 and 80 or v_peng ~ '[[:cntrl:]<>]' then raise exception 'Isi nama penguji (maksimal 80 karakter, tanpa tanda < atau >).'; end if;
  if v_url <> '' and (v_url !~* '^https?://' or char_length(v_url) > 500 or v_url ~ '[[:cntrl:][:space:]<>]') then raise exception 'Tautan bukti harus berawalan http:// atau https:// (maksimal 500 karakter, tanpa spasi).'; end if;
  if char_length(v_cat) > 200 or v_cat ~ '[[:cntrl:]<>]' then raise exception 'Catatan maksimal 200 karakter, tanpa tanda < atau >.'; end if;
  insert into public.tkk_siaga (peserta_id, tkk_id, tanggal, penguji, bukti_url, catatan, dicatat_oleh, dicatat_pada)
  values (p_peserta_id, p_tkk_id, p_tanggal, v_peng, v_url, v_cat, auth.uid(), now())
  on conflict (peserta_id, tkk_id) do update
    set tanggal = excluded.tanggal, penguji = excluded.penguji, bukti_url = excluded.bukti_url, catatan = excluded.catatan, dicatat_oleh = excluded.dicatat_oleh, dicatat_pada = excluded.dicatat_pada
  returning id into v_id;
  return v_id;
end $$;

create function public.sg_tkk_siaga_hapus(p_id bigint) returns void language plpgsql security definer set search_path = public as
$$
declare v public.tkk_siaga;
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pembina_atau_admin() then raise exception 'Hanya Pembina dan Admin Gudep yang dapat menghapus catatan TKK.'; end if;
  select * into v from public.tkk_siaga where id = p_id;
  if not found then raise exception 'Catatan TKK tidak ditemukan.'; end if;
  if exists (select 1 from public.profiles where id = v.peserta_id and status <> 'aktif') then raise exception 'Anggota nonaktif atau alumni tidak dapat diubah.'; end if;
  delete from public.tkk_siaga where id = p_id;
end $$;
-- ===== akhir aksi tkk siaga =====
-- ===== SPG (Tahap 2, G3): aksi =====
-- Hanya Pembina dan Admin Gudep yang menetapkan (Pembina menguji SPG; Dewan hanya membaca). Penegak harus aktif dan sudah menyelesaikan seluruh SKU Bantara dan Laksana
-- (sigarda.layak_garuda). Menetapkan ulang butir yang sama = koreksi. Penetapan yang berbeda dari hasil hitung aplikasi (p_timpa) wajib beralasan di catatan; server tidak
-- menghitung ulang hasil aplikasi (dihitung di klien), jadi p_timpa dipercaya sebatas tanda dan alasan.

create function public.sg_spg_catat(
  p_peserta_id uuid, p_butir integer, p_nilai integer, p_tanggal date, p_catatan text default '', p_timpa boolean default false
) returns void language plpgsql security definer set search_path = public as
$$
declare v_p public.profiles; v_cat text := sigarda.rapikan(p_catatan);
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pembina_atau_admin() then raise exception 'Hanya Pembina dan Admin Gudep yang dapat menetapkan Syarat Pramuka Garuda.'; end if;
  select * into v_p from public.profiles where id = p_peserta_id and role = 'peserta';
  if not found then raise exception 'Pilih Penegak.'; end if;
  if v_p.status <> 'aktif' then raise exception '% tidak aktif; Syarat Pramuka Garuda hanya untuk Penegak aktif.', v_p.nama; end if;
  if not sigarda.layak_garuda(p_peserta_id) then raise exception '% belum menyelesaikan seluruh SKU Bantara dan Laksana.', v_p.nama; end if;
  if p_butir is null or p_butir not between 1 and 13 then raise exception 'Butir SPG harus 1 sampai 13.'; end if;
  if p_nilai is null or p_nilai not in (0, 100) then raise exception 'Nilai harus 100 (lengkap dan memenuhi) atau 0 (belum).'; end if;
  if p_tanggal is null then raise exception 'Tanggal pengujian wajib diisi.'; end if;
  if p_tanggal < date '2000-01-01' or p_tanggal > sigarda.hari_ini() then raise exception 'Tanggal pengujian tidak boleh sebelum tahun 2000 atau di masa depan.'; end if;
  if char_length(v_cat) > 200 or v_cat ~ '[[:cntrl:]<>]' then raise exception 'Catatan maksimal 200 karakter, tanpa tanda < atau >.'; end if;
  if coalesce(p_timpa, false) and char_length(v_cat) < 5 then raise exception 'Penetapan berbeda dari hasil aplikasi: tulis alasannya di catatan (sedikitnya 5 karakter).'; end if;
  insert into public.spg_penetapan (peserta_id, butir, nilai, tanggal, catatan, timpa, dicatat_oleh, dicatat_pada)
  values (p_peserta_id, p_butir, p_nilai, p_tanggal, v_cat, coalesce(p_timpa, false), auth.uid(), now())
  on conflict (peserta_id, butir) do update
    set nilai = excluded.nilai, tanggal = excluded.tanggal, catatan = excluded.catatan, timpa = excluded.timpa, dicatat_oleh = excluded.dicatat_oleh, dicatat_pada = excluded.dicatat_pada;
end $$;

-- Menghapus penetapan satu butir (kembali ke hasil hitung aplikasi atau "menunggu ditetapkan").
create function public.sg_spg_hapus(p_peserta_id uuid, p_butir integer) returns void language plpgsql security definer set search_path = public as
$$
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pembina_atau_admin() then raise exception 'Hanya Pembina dan Admin Gudep yang dapat menghapus penetapan SPG.'; end if;
  delete from public.spg_penetapan where peserta_id = p_peserta_id and butir = p_butir;
  if not found then raise exception 'Penetapan SPG tidak ditemukan.'; end if;
end $$;
-- ===== akhir aksi spg =====

-- ===== Siaga Garuda (Pramuka Siaga, Fase 6): aksi =====
-- Hanya Pembina dan Admin Gudep yang menetapkan. Anak harus anggota Siaga aktif dan sudah menyelesaikan seluruh SKU Tata (syarat Siaga Garuda: SKU Tata lebih dulu). Menetapkan
-- ulang butir yang sama = koreksi. Aturan isian dicerminkan src/lib/siagaGarudaLogic.js (periksaSiagaGaruda) dan dibandingkan langsung dengan fungsi ini oleh uji/siaga-garuda.mjs.
create function public.sg_siaga_garuda_catat(
  p_peserta_id uuid, p_butir integer, p_nilai integer, p_tanggal date, p_catatan text default ''
) returns void language plpgsql security definer set search_path = public as
$$
declare v_p public.profiles; v_cat text := sigarda.rapikan(p_catatan);
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pembina_atau_admin() then raise exception 'Hanya Pembina dan Admin Gudep yang dapat menetapkan Syarat Siaga Garuda.'; end if;
  select * into v_p from public.profiles where id = p_peserta_id and role = 'peserta';
  if not found then raise exception 'Pilih anggota Siaga.'; end if;
  if not (v_p.tanpa_akun or sigarda.kelas_siaga(v_p.kelas)) then raise exception 'Syarat Siaga Garuda hanya untuk anggota Siaga.'; end if;
  if v_p.status <> 'aktif' then raise exception '% tidak aktif; Syarat Siaga Garuda hanya untuk anggota aktif.', v_p.nama; end if;
  if not sigarda.tingkat_selesai(p_peserta_id, 'Tata') then raise exception '% belum menyelesaikan SKU Tata.', v_p.nama; end if;
  if p_butir is null or p_butir not between 1 and 6 then raise exception 'Butir Siaga Garuda harus 1 sampai 6.'; end if;
  if p_nilai is null or p_nilai not in (0, 100) then raise exception 'Nilai harus 100 (memenuhi) atau 0 (belum).'; end if;
  if p_tanggal is null then raise exception 'Tanggal pengujian wajib diisi.'; end if;
  if p_tanggal < date '2015-01-01' or p_tanggal > sigarda.hari_ini() then raise exception 'Tanggal pengujian harus antara 1 Januari 2015 dan hari ini.'; end if;
  if char_length(v_cat) > 200 or v_cat ~ '[[:cntrl:]<>]' then raise exception 'Catatan maksimal 200 karakter, tanpa tanda < atau >.'; end if;
  insert into public.siaga_garuda (peserta_id, butir, nilai, tanggal, catatan, dicatat_oleh, dicatat_pada)
  values (p_peserta_id, p_butir, p_nilai, p_tanggal, v_cat, auth.uid(), now())
  on conflict (peserta_id, butir) do update
    set nilai = excluded.nilai, tanggal = excluded.tanggal, catatan = excluded.catatan, dicatat_oleh = excluded.dicatat_oleh, dicatat_pada = excluded.dicatat_pada;
end $$;

-- Menghapus penetapan satu butir (kembali ke saran aplikasi atau "belum ditetapkan").
create function public.sg_siaga_garuda_hapus(p_peserta_id uuid, p_butir integer) returns void language plpgsql security definer set search_path = public as
$$
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pembina_atau_admin() then raise exception 'Hanya Pembina dan Admin Gudep yang dapat menghapus penetapan Siaga Garuda.'; end if;
  if exists (select 1 from public.profiles where id = p_peserta_id and status <> 'aktif') then raise exception 'Anggota nonaktif atau alumni tidak dapat diubah.'; end if;
  delete from public.siaga_garuda where peserta_id = p_peserta_id and butir = p_butir;
  if not found then raise exception 'Penetapan Siaga Garuda tidak ditemukan.'; end if;
end $$;
-- ===== akhir aksi siaga garuda =====
-- ===== Gerbang calon Garuda (Tahap 2, G4): aksi =====
-- Gerbang calon hanya PERINGATAN (keputusan pemilik 25 Sep 2026): kelas, usia, dan kuota dihitung dan ditampilkan di klien; server tidak memblokir pendaftaran Calon Garuda.
-- Server hanya menyimpan tanggal lahir dan aturan gerbang. Keduanya oleh Pembina atau Admin Gudep.

-- Mengisi (atau mengoreksi) tanggal lahir satu Penegak aktif; tanggal kosong = menghapus catatan.
create function public.sg_tanggal_lahir_atur(p_peserta_id uuid, p_tanggal date) returns void language plpgsql security definer set search_path = public as
$$
declare v_p public.profiles;
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pembina_atau_admin() then raise exception 'Hanya Pembina dan Admin Gudep yang dapat mengisi tanggal lahir.'; end if;
  select * into v_p from public.profiles where id = p_peserta_id and role = 'peserta';
  if not found then raise exception 'Pilih Penegak.'; end if;
  if v_p.status <> 'aktif' then raise exception '% tidak aktif; tanggal lahir hanya diisi untuk Penegak aktif.', v_p.nama; end if;
  if p_tanggal is null then
    delete from public.tanggal_lahir where peserta_id = p_peserta_id;
    return;
  end if;
  if p_tanggal < date '1990-01-01' or p_tanggal > sigarda.hari_ini() then raise exception 'Tanggal lahir tidak boleh sebelum tahun 1990 atau di masa depan.'; end if;
  insert into public.tanggal_lahir (peserta_id, tanggal, dicatat_oleh, dicatat_pada) values (p_peserta_id, p_tanggal, auth.uid(), now())
  on conflict (peserta_id) do update set tanggal = excluded.tanggal, dicatat_oleh = excluded.dicatat_oleh, dicatat_pada = excluded.dicatat_pada;
end $$;

-- Aturan gerbang calon (pengaturan 'garuda.gerbang'): { kelasMin: 'X'|'XI'|'XII', lahirDari, lahirSampai ('YYYY-MM-DD', dari <= sampai), kuotaPersen: bilangan bulat 0-100 }.
create function public.sg_gerbang_simpan(p_nilai jsonb) returns void language plpgsql security definer set search_path = public as
$$
declare v_dari date; v_sampai date; v_kuota int;
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pembina_atau_admin() then raise exception 'Hanya Pembina dan Admin Gudep yang dapat mengubah aturan gerbang calon.'; end if;
  if p_nilai is null or jsonb_typeof(p_nilai) <> 'object' or p_nilai - 'kelasMin' - 'lahirDari' - 'lahirSampai' - 'kuotaPersen' <> '{}'::jsonb then raise exception 'Bentuk aturan gerbang tidak sah.'; end if;
  -- coalesce: kunci yang hilang menghasilkan NULL, dan perbandingan dengan NULL tidak akan memicu galat
  if coalesce(jsonb_typeof(p_nilai -> 'kelasMin'), '') <> 'string' or coalesce(jsonb_typeof(p_nilai -> 'lahirDari'), '') <> 'string'
     or coalesce(jsonb_typeof(p_nilai -> 'lahirSampai'), '') <> 'string' or coalesce(jsonb_typeof(p_nilai -> 'kuotaPersen'), '') <> 'number' then raise exception 'Bentuk aturan gerbang tidak sah.'; end if;
  if (p_nilai ->> 'kelasMin') not in ('X', 'XI', 'XII') then raise exception 'Kelas minimal harus X, XI, atau XII.'; end if;
  if (p_nilai ->> 'lahirDari') !~ '^\d{4}-\d{2}-\d{2}$' or (p_nilai ->> 'lahirSampai') !~ '^\d{4}-\d{2}-\d{2}$' then raise exception 'Tanggal lahir harus berbentuk TTTT-BB-HH.'; end if;
  begin
    v_dari := (p_nilai ->> 'lahirDari')::date; v_sampai := (p_nilai ->> 'lahirSampai')::date;
  exception when others then raise exception 'Tanggal lahir tidak sah.';
  end;
  if v_dari < date '1990-01-01' or v_sampai > date '2030-12-31' then raise exception 'Rentang tanggal lahir harus antara tahun 1990 dan 2030.'; end if;
  if v_dari > v_sampai then raise exception 'Tanggal lahir awal tidak boleh sesudah tanggal akhir.'; end if;
  if (p_nilai ->> 'kuotaPersen') !~ '^[0-9]+$' then raise exception 'Kuota harus bilangan bulat 0 sampai 100 persen.'; end if;
  v_kuota := (p_nilai ->> 'kuotaPersen')::int;
  if v_kuota > 100 then raise exception 'Kuota harus bilangan bulat 0 sampai 100 persen.'; end if;
  insert into public.pengaturan (kunci, nilai, diubah_oleh, diubah_pada)
  values ('garuda.gerbang', jsonb_build_object('kelasMin', p_nilai ->> 'kelasMin', 'lahirDari', to_char(v_dari, 'YYYY-MM-DD'), 'lahirSampai', to_char(v_sampai, 'YYYY-MM-DD'), 'kuotaPersen', v_kuota), auth.uid(), now())
  on conflict (kunci) do update set nilai = excluded.nilai, diubah_oleh = excluded.diubah_oleh, diubah_pada = excluded.diubah_pada;
end $$;
-- ===== akhir aksi gerbang =====

-- ===== Tanggal lahir impor (Tahap 2, G4b): aksi =====
-- Mengisi tanggal lahir banyak Penegak sekaligus sesudah impor akun dari Excel (kolom "Tanggal Lahir" pada template). `p_data` = [{ username, tanggal 'YYYY-MM-DD' }]. Semua atau
-- tidak sama sekali: satu baris keliru membatalkan seluruhnya. Hanya Penegak aktif yang diperbarui (nama pengguna yang tidak dikenal dilewati, seperti sg_anggota_jk_atur).
-- Mengembalikan jumlah Penegak yang diperbarui.
create function public.sg_tanggal_lahir_impor(p_data jsonb) returns integer language plpgsql security definer set search_path = public as
$$
declare v_e jsonb; v_user text; v_tgl date; v_n int := 0; v_k int;
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pembina_atau_admin() then raise exception 'Hanya Pembina dan Admin Gudep yang dapat mengisi tanggal lahir.'; end if;
  if p_data is null or jsonb_typeof(p_data) <> 'array' then raise exception 'Data tanggal lahir tidak valid.'; end if;
  if jsonb_array_length(p_data) > 500 then raise exception 'Maksimal 500 baris tanggal lahir per permintaan.'; end if;
  for v_e in select * from jsonb_array_elements(p_data) loop
    v_user := lower(btrim(coalesce(v_e ->> 'username', '')));
    if v_user = '' then raise exception 'Nama pengguna anggota wajib diisi.'; end if;
    if coalesce(v_e ->> 'tanggal', '') !~ '^\d{4}-\d{2}-\d{2}$' then raise exception 'Tanggal lahir % harus berbentuk TTTT-BB-HH.', v_user; end if;
    begin
      v_tgl := (v_e ->> 'tanggal')::date;
    exception when others then raise exception 'Tanggal lahir % tidak sah.', v_user;
    end;
    if v_tgl < date '1990-01-01' or v_tgl > sigarda.hari_ini() then raise exception 'Tanggal lahir % tidak boleh sebelum tahun 1990 atau di masa depan.', v_user; end if;
    insert into public.tanggal_lahir (peserta_id, tanggal, dicatat_oleh, dicatat_pada)
      select id, v_tgl, auth.uid(), now() from public.profiles where username = v_user and role = 'peserta' and status = 'aktif'
    on conflict (peserta_id) do update set tanggal = excluded.tanggal, dicatat_oleh = excluded.dicatat_oleh, dicatat_pada = excluded.dicatat_pada;
    get diagnostics v_k = row_count;
    v_n := v_n + v_k;
  end loop;
  return v_n;
end $$;
-- ===== akhir aksi tanggal lahir impor =====
-- ===== Tim penilai dan kalender Garuda (Tahap 2, G4b dan G4c): aksi =====
-- Hanya Pembina dan Admin Gudep yang mengubah (Ketua Gudep mengajukan tim penilai lewat Kwarran; di aplikasi Pembina atau Admin yang mencatat hasilnya). Dewan hanya membaca.
-- Komposisi tim tidak diblokir (peringatan di klien); yang ditegakkan hanya bentuk isian.

-- Menyimpan satu tim penilai beserta seluruh anggotanya (atomik; anggota lama diganti). p_id kosong = tim baru. Satu tim per (tahun ajaran, untuk).
-- p_anggota = [{ nama, unsur, jabatan ('ketua' | 'anggota'), keterangan }] 1-15 orang (urutan larik = urutan tampil); paling banyak satu ketua.
create function public.sg_tim_penilai_simpan(
  p_id bigint, p_tahun_ajaran text, p_untuk text, p_nomor_sk text, p_tanggal_sk date, p_sk_url text, p_catatan text, p_anggota jsonb
) returns bigint language plpgsql security definer set search_path = public as
$$
declare
  v_nomor text := sigarda.rapikan(p_nomor_sk); v_url text := btrim(coalesce(p_sk_url, '')); v_cat text := sigarda.rapikan(p_catatan);
  v_id bigint; v_e jsonb; v_i int := 0; v_nama text; v_unsur text; v_jab text; v_ket text; v_ketua int := 0;
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pembina_atau_admin() then raise exception 'Hanya Pembina dan Admin Gudep yang dapat mencatat tim penilai.'; end if;
  if p_tahun_ajaran is null or p_tahun_ajaran !~ '^[0-9]{4}/[0-9]{4}$' then raise exception 'Tahun ajaran tidak sah.'; end if;
  if p_untuk is null or p_untuk not in ('putra', 'putri') then raise exception 'Tim penilai harus untuk putra atau putri.'; end if;
  if char_length(v_nomor) > 80 or v_nomor ~ '[[:cntrl:]<>]' then raise exception 'Nomor SK maksimal 80 karakter, tanpa tanda < atau >.'; end if;
  if (v_nomor = '') <> (p_tanggal_sk is null) then raise exception 'Nomor SK dan tanggal SK diisi berpasangan (keduanya atau tidak sama sekali).'; end if;
  if p_tanggal_sk is not null and (p_tanggal_sk < date '2000-01-01' or p_tanggal_sk > sigarda.hari_ini()) then raise exception 'Tanggal SK tidak boleh sebelum tahun 2000 atau di masa depan.'; end if;
  if v_url <> '' and (v_url !~* '^https?://' or char_length(v_url) > 500 or v_url ~ '[[:cntrl:][:space:]<>]') then raise exception 'Tautan SK harus berawalan http:// atau https:// (maksimal 500 karakter, tanpa spasi).'; end if;
  if char_length(v_cat) > 300 or v_cat ~ '[[:cntrl:]<>]' then raise exception 'Catatan maksimal 300 karakter, tanpa tanda < atau >.'; end if;
  if p_anggota is null or jsonb_typeof(p_anggota) <> 'array' or jsonb_array_length(p_anggota) not between 1 and 15 then raise exception 'Isi 1 sampai 15 anggota tim penilai.'; end if;
  for v_e in select * from jsonb_array_elements(p_anggota) loop
    v_i := v_i + 1;
    if jsonb_typeof(v_e) <> 'object' then raise exception 'Anggota tim nomor % tidak sah.', v_i; end if;
    v_nama := sigarda.rapikan(v_e ->> 'nama'); v_unsur := coalesce(v_e ->> 'unsur', ''); v_jab := coalesce(v_e ->> 'jabatan', 'anggota'); v_ket := sigarda.rapikan(v_e ->> 'keterangan');
    if char_length(v_nama) not between 1 and 80 or v_nama ~ '[[:cntrl:]<>]' then raise exception 'Nama anggota tim nomor % wajib diisi (maksimal 80 karakter, tanpa tanda < atau >).', v_i; end if;
    if v_unsur not in ('ketua_gudep', 'pembina', 'andalan_ranting', 'tokoh_masyarakat', 'orang_tua', 'lainnya') then raise exception 'Unsur anggota tim nomor % tidak dikenal.', v_i; end if;
    if v_jab not in ('ketua', 'anggota') then raise exception 'Jabatan anggota tim nomor % harus ketua atau anggota.', v_i; end if;
    if char_length(v_ket) > 120 or v_ket ~ '[[:cntrl:]<>]' then raise exception 'Keterangan anggota tim nomor % maksimal 120 karakter, tanpa tanda < atau >.', v_i; end if;
    if v_jab = 'ketua' then v_ketua := v_ketua + 1; end if;
  end loop;
  if v_ketua > 1 then raise exception 'Tim penilai hanya boleh punya satu ketua.'; end if;
  if p_id is null then
    if exists (select 1 from public.tim_penilai where tahun_ajaran = p_tahun_ajaran and untuk = p_untuk) then raise exception 'Tim penilai % untuk tahun ajaran % sudah ada; ubah yang sudah ada.', p_untuk, p_tahun_ajaran; end if;
    insert into public.tim_penilai (tahun_ajaran, untuk, nomor_sk, tanggal_sk, sk_url, catatan, dicatat_oleh, dicatat_pada)
    values (p_tahun_ajaran, p_untuk, v_nomor, p_tanggal_sk, v_url, v_cat, auth.uid(), now()) returning id into v_id;
  else
    if not exists (select 1 from public.tim_penilai where id = p_id) then raise exception 'Tim penilai tidak ditemukan.'; end if;
    if exists (select 1 from public.tim_penilai where tahun_ajaran = p_tahun_ajaran and untuk = p_untuk and id <> p_id) then raise exception 'Tim penilai % untuk tahun ajaran % sudah ada.', p_untuk, p_tahun_ajaran; end if;
    update public.tim_penilai set tahun_ajaran = p_tahun_ajaran, untuk = p_untuk, nomor_sk = v_nomor, tanggal_sk = p_tanggal_sk, sk_url = v_url, catatan = v_cat, dicatat_oleh = auth.uid(), dicatat_pada = now()
      where id = p_id returning id into v_id;
    delete from public.tim_penilai_anggota where tim_id = v_id;
  end if;
  v_i := 0;
  for v_e in select * from jsonb_array_elements(p_anggota) loop
    v_i := v_i + 1;
    insert into public.tim_penilai_anggota (tim_id, urut, nama, unsur, jabatan, keterangan)
    values (v_id, v_i, sigarda.rapikan(v_e ->> 'nama'), v_e ->> 'unsur', coalesce(v_e ->> 'jabatan', 'anggota'), sigarda.rapikan(v_e ->> 'keterangan'));
  end loop;
  return v_id;
end $$;

create function public.sg_tim_penilai_hapus(p_id bigint) returns void language plpgsql security definer set search_path = public as
$$
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pembina_atau_admin() then raise exception 'Hanya Pembina dan Admin Gudep yang dapat menghapus tim penilai.'; end if;
  delete from public.tim_penilai where id = p_id;
  if not found then raise exception 'Tim penilai tidak ditemukan.'; end if;
end $$;

-- Mengisi (atau mengoreksi) satu tahap kalender Garuda dari Kwarcab. Mengembalikan id.
create function public.sg_garuda_tahap_simpan(p_tahun_ajaran text, p_tahap text, p_mulai date, p_akhir date, p_catatan text default '') returns bigint
language plpgsql security definer set search_path = public as
$$
declare v_cat text := sigarda.rapikan(p_catatan); v_id bigint;
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pembina_atau_admin() then raise exception 'Hanya Pembina dan Admin Gudep yang dapat mengisi kalender Garuda.'; end if;
  if p_tahun_ajaran is null or p_tahun_ajaran !~ '^[0-9]{4}/[0-9]{4}$' then raise exception 'Tahun ajaran tidak sah.'; end if;
  if p_tahap is null or p_tahap not in ('uji_spg', 'ajukan_tim', 'ambil_sk', 'penilaian_gudep', 'serah_kwarran', 'nilai_kwarran', 'kirim_kwarcab', 'verifikasi_visitasi', 'iuran', 'pelantikan') then raise exception 'Tahap tidak dikenal.'; end if;
  if p_mulai is null then raise exception 'Tanggal mulai wajib diisi.'; end if;
  if p_mulai < date '2000-01-01' or p_mulai > date '2100-12-31' then raise exception 'Tanggal mulai tidak sah.'; end if;
  if p_akhir is not null and (p_akhir < p_mulai or p_akhir > date '2100-12-31') then raise exception 'Tanggal akhir tidak boleh sebelum tanggal mulai.'; end if;
  if char_length(v_cat) > 200 or v_cat ~ '[[:cntrl:]<>]' then raise exception 'Catatan maksimal 200 karakter, tanpa tanda < atau >.'; end if;
  insert into public.garuda_tahap (tahun_ajaran, tahap, mulai, akhir, catatan, dicatat_oleh, dicatat_pada)
  values (p_tahun_ajaran, p_tahap, p_mulai, p_akhir, v_cat, auth.uid(), now())
  on conflict (tahun_ajaran, tahap) do update set mulai = excluded.mulai, akhir = excluded.akhir, catatan = excluded.catatan, dicatat_oleh = excluded.dicatat_oleh, dicatat_pada = excluded.dicatat_pada
  returning id into v_id;
  return v_id;
end $$;

create function public.sg_garuda_tahap_hapus(p_id bigint) returns void language plpgsql security definer set search_path = public as
$$
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pembina_atau_admin() then raise exception 'Hanya Pembina dan Admin Gudep yang dapat menghapus tahap kalender Garuda.'; end if;
  delete from public.garuda_tahap where id = p_id;
  if not found then raise exception 'Tahap kalender tidak ditemukan.'; end if;
end $$;
-- ===== akhir aksi tim kalender =====

-- ===== Pengingat kalender Garuda (Tahap 2, G4d): fungsi =====
-- Nama tahap kalender Garuda untuk isi notifikasi; sama dengan TAHAP_GARUDA di src/lib/kalenderGarudaLogic.js (dijaga uji/tim-kalender-klien.mjs).
create function sigarda.garuda_tahap_label(p_tahap text) returns text language sql immutable as
$$
  select case p_tahap
    when 'uji_spg' then 'Pengujian SPG oleh Pembina'
    when 'ajukan_tim' then 'Pengajuan SK tim penilai'
    when 'ambil_sk' then 'Pengambilan SK tim penilai'
    when 'penilaian_gudep' then 'Penilaian tim penilai gugus depan'
    when 'serah_kwarran' then 'Penyerahan portofolio ke Kwarran'
    when 'nilai_kwarran' then 'Penilaian portofolio oleh Kwarran'
    when 'kirim_kwarcab' then 'Pengiriman berkas ke Kwarcab'
    when 'verifikasi_visitasi' then 'Verifikasi dan visitasi Kwarcab'
    when 'iuran' then 'Iuran gotong royong'
    when 'pelantikan' then 'Pelantikan Pramuka Garuda'
    else p_tahap
  end
$$;

-- Pengingat pukul 07.00 WIB (dari notif_pengingat) untuk tahap kalender Garuda yang sudah diisi: H-7, H-3, H-1, dan hari-H mulainya, serta "berakhir besok" untuk tahap
-- berentang yang sedang berjalan. Penerima: semua pengurus aktif (Pembina, Admin, akun Dewan lama, Penegak berjabatan Dewan), jenis 'agenda'. Sekali per tahap per hari (kunci).
create function sigarda.garuda_kalender_pengingat() returns void language plpgsql security definer set search_path = public as
$$
declare v_hari date := sigarda.hari_ini(); r record; v_x uuid; v_n int; v_judul text; v_isi text; v_rentang text;
begin
  for r in select id, tahap, mulai, akhir, catatan from public.garuda_tahap where mulai - v_hari in (7, 3, 1, 0) loop
    v_n := r.mulai - v_hari;
    v_rentang := case when r.akhir is not null and r.akhir <> r.mulai then to_char(r.mulai, 'DD-MM-YYYY') || ' s.d. ' || to_char(r.akhir, 'DD-MM-YYYY') else to_char(r.mulai, 'DD-MM-YYYY') end;
    v_judul := case when v_n = 0 then 'Hari ini: ' else 'H-' || v_n::text || ': ' end || sigarda.garuda_tahap_label(r.tahap);
    v_isi := 'Tahap seleksi Garuda dari Kwarcab, ' || v_rentang || '.' || case when r.catatan <> '' then ' ' || r.catatan else '' end;
    for v_x in select id from public.profiles where status = 'aktif' and (role in ('penguji', 'admin') or (role = 'peserta' and jabatan_dewan is not null)) loop
      perform sigarda.notif_buat(v_x, 'agenda', v_judul, v_isi, '{"tab":"kelayakan"}', 'garuda:' || r.id || ':' || v_hari);
    end loop;
  end loop;
  for r in select id, tahap, mulai, akhir from public.garuda_tahap where akhir is not null and akhir > mulai and mulai <= v_hari and akhir - v_hari = 1 loop
    v_judul := 'Berakhir besok: ' || sigarda.garuda_tahap_label(r.tahap);
    v_isi := 'Tahap seleksi Garuda dari Kwarcab berakhir ' || to_char(r.akhir, 'DD-MM-YYYY') || '.';
    for v_x in select id from public.profiles where status = 'aktif' and (role in ('penguji', 'admin') or (role = 'peserta' and jabatan_dewan is not null)) loop
      perform sigarda.notif_buat(v_x, 'agenda', v_judul, v_isi, '{"tab":"kelayakan"}', 'garuda-akhir:' || r.id || ':' || v_hari);
    end loop;
  end loop;
end $$;
-- ===== akhir fungsi pengingat kalender garuda =====
-- ===== Isian Penegak dan templat dokumen (Tahap 3, H1): aksi =====
-- Isian data diri milik SENDIRI oleh Penegak aktif (admin gudep hanya membuat akun dengan nama, NIS, dan rombel). p_data = objek datar { kunci: teks }: kunci profil (jk, agama,
-- lahir, nta) hanya boleh diisi bila belum ada (koreksi sesudahnya lewat Pembina atau Admin) dan kunci isian lain (lihat sigarda.isian_periksa) boleh diubah kapan saja; nilai
-- kosong menghapus isian (kunci profil kosong = tidak diubah). Semua atau tidak sama sekali. Mengembalikan jumlah isian yang berubah.
create function public.sg_isian_saya_simpan(p_data jsonb) returns integer language plpgsql security definer set search_path = public as
$$
declare v_p public.profiles; v_k text; v_e jsonb; v_v text; v_err text; v_n int := 0; v_k2 int; v_tgl date;
begin
  perform sigarda.wajib_aktif();
  select * into v_p from public.profiles where id = auth.uid();
  if not found or v_p.role <> 'peserta' then raise exception 'Isian data diri hanya untuk Penegak.'; end if;
  if v_p.status <> 'aktif' then raise exception 'Akun Anda berstatus % dan hanya dapat dilihat.', v_p.status; end if;
  if p_data is null or jsonb_typeof(p_data) <> 'object' then raise exception 'Data isian tidak sah.'; end if;
  if (select count(*) from jsonb_object_keys(p_data)) > 120 then raise exception 'Terlalu banyak isian dalam satu permintaan.'; end if;

  -- Tahap 1: periksa semuanya lebih dulu
  for v_k, v_e in select key, value from jsonb_each(p_data) loop
    if jsonb_typeof(v_e) <> 'string' then raise exception 'Isian % harus berupa teks.', left(v_k, 40); end if;
    v_v := sigarda.rapikan(v_e #>> '{}');
    if v_k in ('jk', 'agama', 'lahir', 'nta') then v_err := sigarda.isian_periksa_profil(v_k, v_v);
    else v_err := sigarda.isian_periksa(v_k, v_v);
    end if;
    if v_err is not null then raise exception '%', v_err; end if;
  end loop;

  -- Tahap 2: tulis
  for v_k, v_e in select key, value from jsonb_each(p_data) loop
    v_v := sigarda.rapikan(v_e #>> '{}');
    if v_k = 'jk' then
      if v_v <> '' and v_p.jenis_kelamin is distinct from v_v then
        if v_p.jenis_kelamin is not null then raise exception 'Jenis kelamin sudah tercatat. Untuk mengoreksi, hubungi Pembina atau Admin Gudep.'; end if;
        update public.profiles set jenis_kelamin = v_v where id = v_p.id; v_n := v_n + 1;
      end if;
    elsif v_k = 'agama' then
      if v_v <> '' and v_p.agama is distinct from v_v then
        if v_p.agama is not null then raise exception 'Agama sudah tercatat. Untuk mengoreksi, hubungi Admin Gudep.'; end if;
        update public.profiles set agama = v_v where id = v_p.id; v_n := v_n + 1;
      end if;
    elsif v_k = 'nta' then
      if v_v <> '' and v_p.nta is distinct from v_v then
        if v_p.nta is not null then raise exception 'NTA sudah tercatat. Untuk mengoreksi, hubungi Admin Gudep.'; end if;
        update public.profiles set nta = v_v where id = v_p.id; v_n := v_n + 1;
      end if;
    elsif v_k = 'lahir' then
      if v_v <> '' then
        v_tgl := v_v::date;
        if exists (select 1 from public.tanggal_lahir where peserta_id = v_p.id and tanggal <> v_tgl) then
          raise exception 'Tanggal lahir sudah tercatat. Untuk mengoreksi, hubungi Pembina atau Admin Gudep.';
        end if;
        insert into public.tanggal_lahir (peserta_id, tanggal, dicatat_oleh, dicatat_pada) values (v_p.id, v_tgl, v_p.id, now()) on conflict (peserta_id) do nothing;
        get diagnostics v_k2 = row_count; v_n := v_n + v_k2;
      end if;
    elsif v_v = '' then
      delete from public.penegak_isian where peserta_id = v_p.id and kunci = v_k;
      get diagnostics v_k2 = row_count; v_n := v_n + v_k2;
    else
      insert into public.penegak_isian (peserta_id, kunci, nilai, diubah_pada) values (v_p.id, v_k, v_v, now())
      on conflict (peserta_id, kunci) do update set nilai = excluded.nilai, diubah_pada = excluded.diubah_pada where public.penegak_isian.nilai is distinct from excluded.nilai;
      get diagnostics v_k2 = row_count; v_n := v_n + v_k2;
    end if;
  end loop;
  return v_n;
end $$;

-- Templat isi dokumen per tahun ajaran (rubrik surat keterangan guru): Pembina atau Admin. isi = { uji?: teks (<= 200), baris: [teks 1-300 karakter, paling banyak 40; berawalan "# " =
-- judul kelompok], pita?: [tiga teks <= 20] }. Menyimpan ulang tahun ajaran dan jenis yang sama mengganti isinya. Mengembalikan id.
create function public.sg_dokumen_templat_simpan(p_tahun_ajaran text, p_jenis text, p_isi jsonb) returns bigint language plpgsql security definer set search_path = public as
$$
declare v_ta text := sigarda.rapikan(p_tahun_ajaran); v_e jsonb; v_t text; v_uji text; v_baris jsonb := '[]'::jsonb; v_pita jsonb; v_id bigint;
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pembina_atau_admin() then raise exception 'Hanya Pembina dan Admin Gudep yang dapat mengubah templat dokumen.'; end if;
  if v_ta !~ '^\d{4}/\d{4}$' then raise exception 'Tahun ajaran harus berbentuk 2026/2027.'; end if;
  if split_part(v_ta, '/', 2)::int <> split_part(v_ta, '/', 1)::int + 1 then raise exception 'Tahun ajaran harus berbentuk 2026/2027.'; end if;
  if coalesce(p_jenis, '') not in ('surat_uud', 'surat_uu_pramuka', 'surat_tik', 'surat_internet', 'surat_bahasa', 'surat_seni', 'surat_iptek', 'surat_olahraga') then raise exception 'Jenis templat tidak dikenal.'; end if;
  if p_isi is null or jsonb_typeof(p_isi) <> 'object' or p_isi - 'uji' - 'baris' - 'pita' <> '{}'::jsonb then raise exception 'Bentuk isi templat tidak sah.'; end if;

  if p_isi ? 'uji' then
    if jsonb_typeof(p_isi -> 'uji') <> 'string' then raise exception 'Topik uji harus berupa teks.'; end if;
    v_uji := sigarda.rapikan(p_isi ->> 'uji');
    if char_length(v_uji) > 200 or v_uji ~ '[[:cntrl:]<>]' then raise exception 'Topik uji maksimal 200 karakter dan tanpa karakter khusus.'; end if;
  end if;
  if coalesce(jsonb_typeof(p_isi -> 'baris'), '') <> 'array' then raise exception 'Baris rubrik harus berupa daftar.'; end if;
  if jsonb_array_length(p_isi -> 'baris') > 40 then raise exception 'Baris rubrik maksimal 40.'; end if;
  for v_e in select * from jsonb_array_elements(p_isi -> 'baris') loop
    if jsonb_typeof(v_e) <> 'string' then raise exception 'Setiap baris rubrik harus berupa teks.'; end if;
    v_t := sigarda.rapikan(v_e #>> '{}');
    if v_t = '' or char_length(v_t) > 300 or v_t ~ '[[:cntrl:]<>]' then raise exception 'Setiap baris rubrik 1 sampai 300 karakter dan tanpa karakter khusus.'; end if;
    v_baris := v_baris || to_jsonb(v_t);
  end loop;
  if p_isi ? 'pita' and jsonb_typeof(p_isi -> 'pita') <> 'null' then
    if jsonb_typeof(p_isi -> 'pita') <> 'array' or jsonb_array_length(p_isi -> 'pita') <> 3 then raise exception 'Pita nilai harus tiga teks.'; end if;
    v_pita := '[]'::jsonb;
    for v_e in select * from jsonb_array_elements(p_isi -> 'pita') loop
      if jsonb_typeof(v_e) <> 'string' then raise exception 'Pita nilai harus berupa teks.'; end if;
      v_t := sigarda.rapikan(v_e #>> '{}');
      if char_length(v_t) > 20 or v_t ~ '[[:cntrl:]<>]' then raise exception 'Setiap pita nilai maksimal 20 karakter dan tanpa karakter khusus.'; end if;
      v_pita := v_pita || to_jsonb(v_t);
    end loop;
  end if;

  insert into public.dokumen_templat (tahun_ajaran, jenis, isi, diubah_oleh, diubah_pada)
  values (v_ta, p_jenis, jsonb_strip_nulls(jsonb_build_object('uji', nullif(v_uji, ''), 'baris', v_baris, 'pita', v_pita)), auth.uid(), now())
  on conflict (tahun_ajaran, jenis) do update set isi = excluded.isi, diubah_oleh = excluded.diubah_oleh, diubah_pada = excluded.diubah_pada
  returning id into v_id;
  return v_id;
end $$;

create function public.sg_dokumen_templat_hapus(p_id bigint) returns void language plpgsql security definer set search_path = public as
$$
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pembina_atau_admin() then raise exception 'Hanya Pembina dan Admin Gudep yang dapat menghapus templat dokumen.'; end if;
  delete from public.dokumen_templat where id = p_id;
end $$;
-- ===== akhir aksi isian penegak =====

-- ===== Salinan beku portofolio (Tahap 3, H3): aksi =====
-- Menyimpan salinan beku Portofolio format Kwarcab satu Penegak (Pembina dan Admin). p_isi = objek yang memuat `peserta` (id harus sama dengan p_peserta_id) dan `hari`; paling
-- banyak 600 kB dan 20 salinan per Penegak. Mengembalikan id salinan.
create function public.sg_portofolio_snapshot_simpan(p_peserta_id uuid, p_catatan text, p_isi jsonb) returns bigint language plpgsql security definer set search_path = public as
$$
declare v_p public.profiles; v_cat text := sigarda.rapikan(p_catatan); v_id bigint; v_oleh text;
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pembina_atau_admin() then raise exception 'Hanya Pembina dan Admin Gudep yang dapat membuat salinan beku portofolio.'; end if;
  select * into v_p from public.profiles where id = p_peserta_id and role = 'peserta';
  if not found then raise exception 'Pilih Penegak.'; end if;
  if char_length(v_cat) > 200 or v_cat ~ '[[:cntrl:]<>]' then raise exception 'Catatan maksimal 200 karakter dan tanpa karakter khusus.'; end if;
  if p_isi is null or jsonb_typeof(p_isi) <> 'object' then raise exception 'Isi salinan tidak sah.'; end if;
  if coalesce(jsonb_typeof(p_isi -> 'peserta'), '') <> 'object' or coalesce(p_isi #>> '{peserta,id}', '') <> p_peserta_id::text or coalesce(jsonb_typeof(p_isi -> 'hari'), '') <> 'string' then
    raise exception 'Isi salinan tidak sesuai dengan Penegak yang dipilih.';
  end if;
  if octet_length(p_isi::text) > 600000 then raise exception 'Isi salinan terlalu besar (maksimal 600 kB).'; end if;
  if (select count(*) from public.portofolio_snapshot where peserta_id = p_peserta_id) >= 20 then
    raise exception 'Sudah ada 20 salinan beku untuk Penegak ini. Hapus yang tidak diperlukan lebih dulu.';
  end if;
  select nama into v_oleh from public.profiles where id = auth.uid();
  insert into public.portofolio_snapshot (peserta_id, tahun_ajaran, catatan, isi, dibuat_oleh, dibuat_oleh_nama)
  values (p_peserta_id, sigarda.tahun_ajaran_kini(), v_cat, p_isi, auth.uid(), coalesce(v_oleh, '')) returning id into v_id;
  return v_id;
end $$;

create function public.sg_portofolio_snapshot_hapus(p_id bigint) returns void language plpgsql security definer set search_path = public as
$$
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pembina_atau_admin() then raise exception 'Hanya Pembina dan Admin Gudep yang dapat menghapus salinan beku portofolio.'; end if;
  delete from public.portofolio_snapshot where id = p_id;
end $$;
-- ===== akhir aksi salinan beku portofolio =====

-- ===== Perlindungan anggota / Safe From Harm (Tahap 4): aksi =====
-- Mencatat (atau mengoreksi) satu catatan Safe From Harm bagi anggota dewasa gugus depan: Pembina aktif (pelatihan, pakta_integritas, rekam_jejak) atau Admin Gudep aktif (pelatihan saja).
-- Pembina dan Admin yang mencatat. tanggal tidak boleh di masa depan; bukti_url (opsional) tautan http(s); catatan <= 200 karakter. Mencatat ulang = koreksi.
create function public.sg_sfh_catat(p_anggota_id uuid, p_jenis text, p_tanggal date, p_bukti_url text default '', p_catatan text default '') returns void language plpgsql security definer set search_path = public as
$$
declare v_p public.profiles; v_url text := btrim(coalesce(p_bukti_url, '')); v_cat text := sigarda.rapikan(p_catatan);
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pembina_atau_admin() then raise exception 'Hanya Pembina dan Admin Gudep yang dapat mencatat Safe From Harm.'; end if;
  if coalesce(p_jenis, '') not in ('pelatihan', 'pakta_integritas', 'rekam_jejak') then raise exception 'Jenis catatan harus pelatihan, pakta_integritas, atau rekam_jejak.'; end if;
  select * into v_p from public.profiles where id = p_anggota_id;
  if not found then raise exception 'Pilih anggota.'; end if;
  if v_p.status <> 'aktif' or not ((v_p.role = 'penguji' and v_p.jabatan = 'Pembina') or v_p.role = 'admin') then
    raise exception 'Catatan Safe From Harm hanya untuk anggota dewasa aktif (Pembina dan Admin Gudep).';
  end if;
  if v_p.role = 'admin' and p_jenis <> 'pelatihan' then raise exception 'Admin Gudep hanya dicatat untuk pelatihan; pakta integritas dan rekam jejak untuk Pembina.'; end if;
  if p_tanggal is null or p_tanggal < date '2015-01-01' or p_tanggal > sigarda.hari_ini() then raise exception 'Tanggal tidak boleh sebelum tahun 2015 atau di masa depan.'; end if;
  if char_length(v_url) > 500 then raise exception 'Tautan bukti maksimal 500 karakter.'; end if;
  if v_url <> '' and v_url !~* '^https?://[^[:space:]<>]+$' then raise exception 'Tautan bukti harus berawalan http:// atau https:// tanpa spasi.'; end if;
  if char_length(v_cat) > 200 or v_cat ~ '[[:cntrl:]<>]' then raise exception 'Catatan maksimal 200 karakter dan tanpa karakter khusus.'; end if;
  insert into public.sfh_catatan (anggota_id, jenis, tanggal, bukti_url, catatan, dicatat_oleh, dicatat_pada)
  values (p_anggota_id, p_jenis, p_tanggal, v_url, v_cat, auth.uid(), now())
  on conflict (anggota_id, jenis) do update set tanggal = excluded.tanggal, bukti_url = excluded.bukti_url, catatan = excluded.catatan, dicatat_oleh = excluded.dicatat_oleh, dicatat_pada = excluded.dicatat_pada;
end $$;

create function public.sg_sfh_hapus(p_id bigint) returns void language plpgsql security definer set search_path = public as
$$
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pembina_atau_admin() then raise exception 'Hanya Pembina dan Admin Gudep yang dapat menghapus catatan Safe From Harm.'; end if;
  delete from public.sfh_catatan where id = p_id;
end $$;

-- Penerima laporan gugus depan (Pasal 10 ayat 3: setiap gugus depan wajib memiliki prosedur penerimaan laporan). Pengaturan 'perlindungan.gudep' = { penerima, kontak, prosedurUrl, catatan }
-- (dibaca semua pengguna agar Penegak tahu kepada siapa melapor; diubah Pembina dan Admin). Laporan sendiri TIDAK disimpan di aplikasi.
create function public.sg_sfh_gudep_simpan(p_nilai jsonb) returns void language plpgsql security definer set search_path = public as
$$
declare v_k text; v_v text; v_maks int; v_h jsonb := '{}'::jsonb;
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pembina_atau_admin() then raise exception 'Hanya Pembina dan Admin Gudep yang dapat mengubah penerima laporan Safe From Harm.'; end if;
  if p_nilai is null or jsonb_typeof(p_nilai) <> 'object' or p_nilai - 'penerima' - 'kontak' - 'prosedurUrl' - 'catatan' <> '{}'::jsonb then raise exception 'Bentuk isian tidak sah.'; end if;
  foreach v_k in array array['penerima', 'kontak', 'prosedurUrl', 'catatan'] loop
    if coalesce(jsonb_typeof(p_nilai -> v_k), '') <> 'string' then raise exception 'Isian % harus berupa teks.', v_k; end if;
    if v_k = 'prosedurUrl' then
      v_v := btrim(p_nilai ->> v_k);
      if char_length(v_v) > 500 or (v_v <> '' and v_v !~* '^https?://[^[:space:]<>]+$') then raise exception 'Tautan prosedur harus berawalan http:// atau https:// tanpa spasi (maksimal 500 karakter).'; end if;
    else
      v_v := sigarda.rapikan(p_nilai ->> v_k);
      v_maks := case v_k when 'penerima' then 120 when 'kontak' then 80 else 300 end; -- (case di dalam kondisi if terpotong pada then pertama)
      if char_length(v_v) > v_maks or v_v ~ '[[:cntrl:]<>]' then
        raise exception 'Isian % terlalu panjang atau memuat karakter khusus.', v_k;
      end if;
    end if;
    v_h := v_h || jsonb_build_object(v_k, v_v);
  end loop;
  insert into public.pengaturan (kunci, nilai, diubah_oleh, diubah_pada) values ('perlindungan.gudep', v_h, auth.uid(), now())
  on conflict (kunci) do update set nilai = excluded.nilai, diubah_oleh = excluded.diubah_oleh, diubah_pada = excluded.diubah_pada;
end $$;
-- ===== akhir aksi perlindungan anggota =====
-- ===== Anggota Siaga tanpa akun (Pramuka Siaga, Fase 1): fungsi =====
-- Anggota Siaga = anak berkelas SD (angka 1-6 + paralel opsional): TANPA akun (tanpa_akun) ATAU dengan akun masuk (dibuat Pembina/Admin lewat Edge Function
-- buat-akun, sama seperti Penegak; Siaga Fase 2b). Pengenal "Siaga" yang dipakai fungsi di bawah dan klien (siagaLogic.kelasSiagaSah) adalah KELAS-nya.
create function sigarda.kelas_siaga(p_kelas text) returns boolean language sql immutable as
$$ select coalesce(p_kelas, '') ~ '^[1-6][A-Z]?$' $$;
-- Anak Siaga TIDAK punya akun masuk: profilnya (role 'peserta', tanpa_akun = true) dibuat dan dirawat Pembina/Admin lewat fungsi di bawah,
-- tanpa auth.users, PIN, WhatsApp, atau isian mandiri. Kelas berupa angka 1-6 dengan paralel opsional (1, 4A, 5B): sigarda.rombel_sah.
-- Kelompok: perindukan (3-4 barung) dan barung (6-8 anak); penulisan nama disamakan dengan yang sudah ada (tanpa membedakan huruf besar/kecil).

-- Profil ikut terhapus bila akun loginnya dihapus (dulu oleh FK ON DELETE CASCADE ke auth.users, kini FK itu tidak ada agar anggota tanpa akun dapat disimpan).
create function sigarda.profil_hapus_bersama_akun() returns trigger language plpgsql security definer set search_path = public as
$$ begin delete from public.profiles where id = old.id and not tanpa_akun; return old; end $$;
drop trigger if exists profil_hapus_bersama_akun on auth.users;
create trigger profil_hapus_bersama_akun after delete on auth.users for each row execute function sigarda.profil_hapus_bersama_akun();

-- Memeriksa dan merapikan satu anggota Siaga; mengembalikan kolom yang sudah bersih (jsonb) atau melempar galat berbahasa Indonesia.
-- Dicerminkan src/lib/siagaLogic.js (periksaSiaga) dan DIBANDINGKAN LANGSUNG dengan fungsi ini oleh uji/siaga-klien.mjs.
create function sigarda.siaga_periksa(p_d jsonb, p_id uuid default null) returns jsonb language plpgsql stable security definer set search_path = public as
$$
declare v_nama text; v_kelas text; v_jk text; v_agama text; v_nis text; v_per text; v_bar text;
begin
  if p_d is null or jsonb_typeof(p_d) <> 'object' then raise exception 'Data anggota tidak valid.'; end if;
  v_nama := sigarda.rapikan(p_d ->> 'nama');
  if v_nama = '' then raise exception 'Nama wajib diisi.'; end if;
  if char_length(v_nama) > 120 then raise exception 'Nama maksimal 120 karakter.'; end if;
  v_kelas := sigarda.rombel_baku(p_d ->> 'kelas');
  if v_kelas !~ '^[1-6][A-Z]?$' then raise exception 'Kelas harus angka 1 sampai 6, boleh diikuti satu huruf paralel (contoh: 4, 5A).'; end if;
  v_jk := upper(btrim(coalesce(p_d ->> 'jk', '')));
  if v_jk not in ('', 'L', 'P') then raise exception 'Jenis kelamin harus L atau P.'; end if;
  v_agama := btrim(coalesce(p_d ->> 'agama', ''));
  if v_agama <> '' and v_agama not in ('Islam','Katolik','Protestan','Hindu','Buddha','Khonghucu') then raise exception 'Agama tidak dikenal.'; end if;
  v_nis := btrim(coalesce(p_d ->> 'nis', ''));
  if v_nis <> '' and v_nis !~ '^[0-9A-Za-z./-]{3,20}$' then raise exception 'NIS hanya boleh berisi huruf, angka, titik, garis miring, atau tanda hubung (3 sampai 20 karakter).'; end if;
  if v_nis <> '' and exists (select 1 from public.profiles where nis = v_nis and id is distinct from p_id) then raise exception 'NIS % sudah dipakai anggota lain.', v_nis; end if;
  v_per := sigarda.rapikan(p_d ->> 'perindukan');
  v_bar := sigarda.rapikan(p_d ->> 'barung');
  if char_length(v_per) > 40 or char_length(v_bar) > 40 then raise exception 'Nama perindukan dan barung maksimal 40 karakter.'; end if;
  if v_per ~ '[[:cntrl:]<>]' or v_bar ~ '[[:cntrl:]<>]' then raise exception 'Nama perindukan dan barung tidak boleh memuat karakter < atau >.'; end if;
  if v_bar <> '' and v_per = '' then raise exception 'Barung harus berada di sebuah perindukan: isi perindukannya.'; end if;
  if v_per <> '' then v_per := coalesce((select perindukan from public.profiles where lower(perindukan) = lower(v_per) limit 1), v_per); end if;
  if v_bar <> '' then v_bar := coalesce((select barung from public.profiles where lower(barung) = lower(v_bar) and lower(perindukan) = lower(v_per) limit 1), v_bar); end if;
  return jsonb_build_object('nama', v_nama, 'kelas', v_kelas, 'jk', nullif(v_jk, ''), 'agama', nullif(v_agama, ''), 'nis', nullif(v_nis, ''),
    'perindukan', nullif(v_per, ''), 'barung', nullif(v_bar, ''));
end $$;

-- Menambah anggota Siaga (banyak sekaligus; semua atau tidak sama sekali). p_data = larik { nama, kelas, jk?, agama?, nis?, perindukan?, barung? }.
create function public.sg_siaga_tambah(p_data jsonb) returns int language plpgsql security definer set search_path = public as
$$
declare v_e jsonb; v_n int := 0; v_h jsonb; v_id uuid;
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pembina_atau_admin() then raise exception 'Hanya Pembina dan Admin Gudep yang dapat menambah anggota Siaga.'; end if;
  if p_data is null or jsonb_typeof(p_data) <> 'array' or jsonb_array_length(p_data) = 0 then raise exception 'Tidak ada data anggota.'; end if;
  if jsonb_array_length(p_data) > 300 then raise exception 'Paling banyak 300 anggota sekali tambah.'; end if;
  for v_e in select * from jsonb_array_elements(p_data) loop
    v_n := v_n + 1;
    begin
      v_h := sigarda.siaga_periksa(v_e);
    exception when others then
      raise exception 'Baris %: %', v_n, sqlerrm;
    end;
    v_id := gen_random_uuid();
    insert into public.profiles (id, username, role, nama, nis, kelas, agama, jenis_kelamin, perindukan, barung, tanpa_akun, wajib_ganti_pin)
    values (v_id, 'siaga' || substr(md5(v_id::text), 1, 12), 'peserta', v_h ->> 'nama', v_h ->> 'nis', v_h ->> 'kelas', v_h ->> 'agama', v_h ->> 'jk',
            v_h ->> 'perindukan', v_h ->> 'barung', true, false);
  end loop;
  return v_n;
end $$;

-- Mengubah data satu anggota Siaga (semua kolom diganti sesuai isian; kosong = dikosongkan).
create function public.sg_siaga_ubah(p_id uuid, p_data jsonb) returns void language plpgsql security definer set search_path = public as
$$
declare v_h jsonb;
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pembina_atau_admin() then raise exception 'Hanya Pembina dan Admin Gudep yang dapat mengubah data anggota Siaga.'; end if;
  if not exists (select 1 from public.profiles where id = p_id and (tanpa_akun or sigarda.kelas_siaga(kelas))) then raise exception 'Anggota Siaga tidak ditemukan.'; end if;
  v_h := sigarda.siaga_periksa(p_data, p_id);
  -- NIS anak berakun = nama penggunanya: tidak diubah dari sini (Admin Gudep mengubah nama pengguna di menu Anggota).
  update public.profiles set nama = v_h ->> 'nama', kelas = v_h ->> 'kelas', jenis_kelamin = v_h ->> 'jk', agama = v_h ->> 'agama',
    nis = case when tanpa_akun then v_h ->> 'nis' else nis end, perindukan = v_h ->> 'perindukan', barung = v_h ->> 'barung'
  where id = p_id;
end $$;

-- Menghapus anggota Siaga yang salah dimasukkan. Hanya bila belum punya catatan apa pun (SKU, kehadiran, iuran); selebihnya gunakan status nonaktif/alumni.
create function public.sg_siaga_hapus(p_id uuid) returns void language plpgsql security definer set search_path = public as
$$
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pembina_atau_admin() then raise exception 'Hanya Pembina dan Admin Gudep yang dapat menghapus anggota Siaga.'; end if;
  if not exists (select 1 from public.profiles where id = p_id and (tanpa_akun or sigarda.kelas_siaga(kelas))) then raise exception 'Anggota Siaga tidak ditemukan.'; end if;
  if not exists (select 1 from public.profiles where id = p_id and tanpa_akun) then raise exception 'Anggota ini punya akun masuk. Hapus akunnya lewat menu Anggota (Admin Gudep), atau ubah statusnya menjadi nonaktif.'; end if;
  if exists (select 1 from public.sku_progress where peserta_id = p_id) or exists (select 1 from public.sku_riwayat where peserta_id = p_id)
     or exists (select 1 from public.absensi_hadir where peserta_id = p_id) or exists (select 1 from public.iuran where peserta_id = p_id) then
    raise exception 'Anggota ini sudah punya catatan (SKU, kehadiran, atau iuran). Ubah statusnya menjadi nonaktif, jangan dihapus.';
  end if;
  delete from public.profiles where id = p_id;
end $$;

-- Menempatkan banyak anggota Siaga ke perindukan dan barung sekaligus (semua atau tidak sama sekali). Perindukan kosong = dikeluarkan dari kelompok.
create function public.sg_barung_atur(p_ids uuid[], p_perindukan text, p_barung text) returns int language plpgsql security definer set search_path = public as
$$
declare v_h jsonb; v_n int;
begin
  perform sigarda.wajib_aktif();
  if not sigarda.pembina_atau_admin() then raise exception 'Hanya Pembina dan Admin Gudep yang dapat mengatur barung.'; end if;
  if p_ids is null or cardinality(p_ids) = 0 then raise exception 'Pilih anggota lebih dulu.'; end if;
  if cardinality(p_ids) > 300 then raise exception 'Paling banyak 300 anggota sekali atur.'; end if;
  if (select count(*) from public.profiles where id = any (p_ids) and (tanpa_akun or sigarda.kelas_siaga(kelas))) <> (select count(distinct x) from unnest(p_ids) x) then
    raise exception 'Ada anggota yang bukan anggota Siaga atau tidak ditemukan.';
  end if;
  v_h := sigarda.siaga_periksa(jsonb_build_object('nama', 'x', 'kelas', '1', 'perindukan', p_perindukan, 'barung', p_barung));
  update public.profiles set perindukan = v_h ->> 'perindukan', barung = v_h ->> 'barung' where id = any (p_ids);
  get diagnostics v_n = row_count;
  return v_n;
end $$;
-- ===== akhir anggota Siaga tanpa akun =====
-- ---------------------------------------------------------------------------
-- 5. Hak akses: baca saja untuk pengguna; fungsi aksi hanya untuk pengguna masuk
-- ---------------------------------------------------------------------------
revoke all on all tables in schema public from anon, authenticated;
grant select on public.profiles, public.sku_butir, public.sku_unit, public.pf_item, public.sku_progress,
  public.sku_riwayat, public.absensi_sesi, public.absensi_hadir, public.portofolio, public.portofolio_jurnal,
  public.materi, public.pengaturan, public.sidang_dk, public.sidang_urut, public.raport,
  public.instrumen, public.instrumen_kriteria, public.instrumen_penguji, public.instrumen_panduan, public.sku_penilaian,
  public.sesi_ujian, public.sesi_ujian_butir, public.sesi_ujian_peserta,
  public.iuran, public.iuran_log, public.iuran_kas, public.asisten_iuran, public.tabungan_cek,
  public.penugasan_rombel, public.penugasan_log, public.guru_agama, public.dokumen_terbit, public.dokumen_urut, public.notifikasi,
  public.naik_kelas_batch, public.naik_kelas_log, public.penugasan_peserta, public.kepengurusan_log, public.agenda, public.kegiatan_usulan, public.pengukuhan_dewan, public.sku_pra_uji, public.pelantikan, public.saka_anggota, public.tkk_katalog, public.tkk_capaian, public.tkk_krida, public.siaga_garuda, public.tkk_siaga, public.tkk_pengajuan, public.spg_penetapan, public.tanggal_lahir, public.tim_penilai, public.tim_penilai_anggota, public.garuda_tahap, public.penegak_isian, public.dokumen_templat, public.portofolio_snapshot, public.sfh_catatan,
  public.beranda_berita, public.beranda_prestasi, public.beranda_galeri, public.beranda_sosial, public.beranda_faq to authenticated;

revoke all on all functions in schema public from public, anon, authenticated;
grant execute on function
  public.sg_sku_ajukan(text, date, uuid, text), public.sg_sku_batal(text), public.sg_calon_garuda_daftar(),
  public.sg_pf_ubah(text, text, text, text), public.sg_pf_catat_penguji(uuid, text, text),
  public.sg_absen_buat_sesi(date), public.sg_absen_set(date, uuid, text),
  public.sg_absen_set_banyak(date, uuid[], text, boolean), public.sg_absen_hapus_sesi(date),
  public.sg_anggota_ubah(uuid, text, text, text, text, boolean),
  public.sg_anggota_nta_atur(jsonb), public.sg_anggota_agama_atur(jsonb), public.sg_anggota_jabatan_dewan_atur(jsonb), public.sg_anggota_jk_atur(jsonb),
  public.sg_materi_simpan(uuid, text, text, text, text, text, text[], jsonb),
  public.sg_materi_hapus(uuid), public.sg_materi_geser(uuid, int),
  public.sg_pengaturan_simpan(text, jsonb),
  public.sg_sidang_simpan(uuid, text, date, text, text, text, text, text, text, text), public.sg_sidang_hapus(int), public.sg_sidang_token(int),
  public.sg_sidang_urut_atur(int, int),
  public.sg_raport_pengaturan_simpan(jsonb),
  public.sg_raport_simpan(uuid, text, text, text, int, text[], int, text, text, text, boolean),
  public.sg_raport_hapus(uuid, text, text),
  public.sg_instrumen_simpan(text, text, text, jsonb, text),
  public.sg_instrumen_status(text[], text),
  public.sg_instrumen_pengaturan_simpan(jsonb),
  public.sg_sertifikat_tingkat(uuid, text),
  public.sg_sesi_simpan(int, text, date, text, text, text, text[], uuid[]),
  public.sg_sesi_status(int, text),
  public.sg_sesi_hapus(int),
  public.sg_iuran_set(date, uuid, int), public.sg_iuran_set_banyak(date, uuid[], int, boolean), public.sg_iuran_lembar(date),
  public.sg_iuran_agregat(date, date), public.sg_iuran_kas_simpan(date, int, text), public.sg_asisten_iuran_atur(uuid, boolean),
  public.sg_iuran_pengaturan(), public.sg_iuran_pengaturan_simpan(jsonb), public.sg_iuran_ringkas(uuid, date), public.sg_iuran_susulan(uuid, date, int, int),
  public.sg_tabungan_catat(uuid, date, int, text), public.sg_tabungan_hapus(uuid, date),
  public.sg_penugasan_atur(text, uuid, text[], boolean), public.sg_penugasan_salin(text, text), public.sg_rombel_perbarui(jsonb),
  public.sg_guru_agama_simpan(bigint, text, text, text), public.sg_guru_agama_hapus(bigint),
  public.sg_penguji_pilihan(text, uuid), public.sg_sku_alihkan(uuid, text, uuid, text),
  public.sg_dokumen_surat_agama_terbit(uuid, text[], bigint, text, date, text, text, text, text, text), public.sg_dokumen_cabut(bigint, text),
  public.sg_gudep_simpan(jsonb), public.sg_beranda_kontak_simpan(jsonb),
  public.sg_naik_kelas(text, jsonb, boolean), public.sg_naik_kelas_batalkan(bigint), public.sg_anggota_status_atur(uuid, text, text, text),
  public.sg_notifikasi_tandai(bigint[]), public.sg_push_kunci(), public.sg_push_simpan(text, text, text, text), public.sg_push_hapus(text), public.sg_push_ringkasan(), public.sg_notifikasi_tes(),
  public.sg_penugasan_peserta_atur(text, uuid, uuid[], text), public.sg_kepengurusan_terapkan(jsonb, boolean, boolean), public.sg_pengukuhan_dewan_simpan(text, text, date, text, date, text), public.sg_pengukuhan_dewan_hapus(text), public.sg_dewan_lama_arsipkan(uuid[], boolean),
  public.sg_pemeriksaan_data(), public.sg_cadangan_admin(), public.sg_cadangan_status(),
  public.sg_profil_whatsapp_atur(text), public.sg_eskalasi_daftar(),
  public.sg_agenda_simpan(bigint, text, text, text, date, text, uuid[], boolean), public.sg_agenda_hapus(bigint),
  public.sg_kegiatan_usul(text, text, date, text, text), public.sg_kegiatan_tinjau(bigint, text, text), public.sg_kegiatan_ping(bigint),
  public.sg_garuda_berkas_baca(uuid), public.sg_garuda_token_buat(uuid), public.sg_garuda_token_cabut(uuid),
  public.sg_bina_damping_atur(text, text, uuid[]), public.sg_bina_damping_daftar(text), public.sg_sangga_rombel(text), public.sg_sangga_atur(text, jsonb), public.sg_pendampingan_saya(),
  public.sg_pinsa_calon(text), public.sg_pinsa_tugaskan(text, text, uuid), public.sg_pinsa_cabut(text, uuid),
  public.sg_pra_uji_antrian(), public.sg_pra_uji_catat(bigint, text, text), public.sg_pra_uji_lewati(bigint, text), public.sg_pra_uji_sakelar(boolean), public.sg_pra_uji_cakupan(integer),
  public.sg_pelantikan_catat(text, date, text, uuid[], bigint, text), public.sg_pelantikan_hapus(bigint),
  public.sg_saka_simpan(bigint, uuid, text, date, text, date, text, text), public.sg_saka_hapus(bigint),
  public.sg_tkk_catat(uuid, text, text, date, text, text, text, text, text), public.sg_tkk_hapus(bigint),
  public.sg_tkk_krida_simpan(bigint, uuid, text, text, date, text, text), public.sg_tkk_krida_hapus(bigint), public.sg_siaga_garuda_catat(uuid, integer, integer, date, text), public.sg_siaga_garuda_hapus(uuid, integer), public.sg_tkk_siaga_catat(uuid, text, date, text, text, text), public.sg_tkk_siaga_hapus(bigint), public.sg_tkk_ambang_simpan(jsonb),
  public.sg_tkk_ajukan(text, text, date, uuid, text, text, text, text), public.sg_tkk_ajukan_batal(bigint), public.sg_tkk_tinjau(bigint, text, text, text, text),
  public.sg_tkk_penguji_pilihan(),
  public.sg_spg_catat(uuid, integer, integer, date, text, boolean), public.sg_spg_hapus(uuid, integer),
  public.sg_tanggal_lahir_atur(uuid, date), public.sg_gerbang_simpan(jsonb), public.sg_tanggal_lahir_impor(jsonb),
  public.sg_tim_penilai_simpan(bigint, text, text, text, date, text, text, jsonb), public.sg_tim_penilai_hapus(bigint),
  public.sg_garuda_tahap_simpan(text, text, date, date, text), public.sg_garuda_tahap_hapus(bigint),
  public.sg_isian_saya_simpan(jsonb), public.sg_dokumen_templat_simpan(text, text, jsonb), public.sg_dokumen_templat_hapus(bigint),
  public.sg_portofolio_snapshot_simpan(uuid, text, jsonb), public.sg_portofolio_snapshot_hapus(bigint),
  public.sg_sfh_catat(uuid, text, date, text, text), public.sg_sfh_hapus(bigint), public.sg_sfh_gudep_simpan(jsonb),
  public.sg_berita_simpan(bigint, text, text, text, text, text, text, timestamptz), public.sg_berita_hapus(bigint), public.sg_berita_tinjau(bigint, text, text),
  public.sg_prestasi_simpan(bigint, text, text, text, integer, text, text, text), public.sg_prestasi_hapus(bigint), public.sg_prestasi_tinjau(bigint, text, text),
  public.sg_galeri_simpan(bigint, text, text, text, text, text), public.sg_galeri_hapus(bigint), public.sg_galeri_tinjau(bigint, text, text),
  public.sg_sosial_simpan(bigint, text, text, text, text, boolean), public.sg_sosial_hapus(bigint),
  public.sg_faq_simpan(bigint, text, text), public.sg_faq_hapus(bigint), public.sg_faq_geser(bigint, integer),
  public.sg_terbit_ulang_status(), public.sg_terbit_ulang_minta(),
  public.sg_siaga_tambah(jsonb), public.sg_siaga_ubah(uuid, jsonb), public.sg_siaga_hapus(uuid), public.sg_barung_atur(uuid[], text, text)
  to authenticated;
-- Fungsi yang boleh dipanggil tanpa login (hanya membaca): verifikasi keaslian dokumen, identitas gudep di halaman masuk, dan
-- tautan berbagi baca-saja Berkas Calon Garuda (tahap L7), dan isi beranda publik (Fase 1 landing page: hanya membaca)
grant execute on function public.sg_verifikasi_token(text), public.sg_verifikasi_kode(text), public.sg_gudep_publik(), public.sg_garuda_token_baca(text), public.sg_beranda_publik(), public.sg_berita_publik(), public.sg_berita_lagi(int), public.sg_prestasi_lagi(int), public.sg_galeri_lagi(int), public.sg_sosial_lagi(int) to anon, authenticated;
grant execute on function
  public.sg_sku_catat_internal(uuid, uuid, text, text, date, text, text),
  public.sg_sku_catat_rubrik_internal(uuid, uuid, text, date, jsonb, text, text),
  public.sg_push_ambil_internal(bigint[]), public.sg_push_hasil_internal(jsonb),
  public.sg_profil_buat_internal(uuid, text, text, text, text, text, text, text, text),
  public.sg_kunci_cek_internal(text), public.sg_kunci_gagal_internal(text), public.sg_kunci_lepas_internal(text)
  to service_role;

revoke all on all functions in schema sigarda from public, anon;
grant execute on all functions in schema sigarda to authenticated, service_role;

-- ---------------------------------------------------------------------------
-- 6. Katalog butir SKU dan dokumen portofolio (dibuat otomatis dari data aplikasi)
-- ---------------------------------------------------------------------------
-- (dibuat otomatis oleh scripts/buat-skema.mjs; jangan diubah manual)
insert into public.sku_butir (id, tingkat, no, teks) values
  ('BAN-01', 'Bantara', 1, 'Sesuai agama yang dianut (ketakwaan)'),
  ('BAN-02', 'Bantara', 2, 'Berani menyampaikan kritik dan saran dengan sopan dan santun kepada sesama teman.'),
  ('BAN-03', 'Bantara', 3, 'Dapat mengikuti jalannya diskusi dengan baik.'),
  ('BAN-04', 'Bantara', 4, 'Dapat saling menghormati dan toleransi dalam bakti antar umat beragama.'),
  ('BAN-05', 'Bantara', 5, 'Mengikuti pertemuan Ambalan sekurang-kurangnya 2 kali setiap bulan.'),
  ('BAN-06', 'Bantara', 6, 'Setia membayar iuran kepada gugus depan, dengan uang yang diperoleh dari usaha sendiri.'),
  ('BAN-07', 'Bantara', 7, 'Dapat berbahasa Indonesia dengan baik dan benar dalam pergaulan sehari-hari.'),
  ('BAN-08', 'Bantara', 8, 'Telah membantu mengelola kegiatan di Ambalan.'),
  ('BAN-09', 'Bantara', 9, 'Telah ikut aktif kerja bakti di masyarakat minimal 2 kali.'),
  ('BAN-10', 'Bantara', 10, 'Dapat menampilkan kesenian daerah di depan umum minimal satu kali.'),
  ('BAN-11', 'Bantara', 11, 'Mengenal, mengerti dan memahami isi AD & ART Gerakan Pramuka.'),
  ('BAN-12', 'Bantara', 12, 'Dapat menjelaskan sejarah Kepramukaan Indonesia dan dunia.'),
  ('BAN-13', 'Bantara', 13, 'Dapat menggunakan jam, kompas, tanda jejak dan tanda-tanda alam lainnya dalam pengembaraan.'),
  ('BAN-14', 'Bantara', 14, 'Dapat menjelaskan bentuk pengamalan Pancasila dalam kehidupan sehari-hari.'),
  ('BAN-15', 'Bantara', 15, 'Dapat menjelaskan tentang organisasi ASEAN dan PBB.'),
  ('BAN-16', 'Bantara', 16, 'Dapat menjelaskan tentang kewirausahaan.'),
  ('BAN-17', 'Bantara', 17, 'Dapat mendaur ulang barang bekas menjadi barang yang bermanfaat.'),
  ('BAN-18', 'Bantara', 18, 'Dapat menerapkan pengetahuannya tentang tali temali dan pionering dalam kehidupan sehari-hari.'),
  ('BAN-19', 'Bantara', 19, 'Selalu berolahraga, mampu melakukan olahraga renang gaya bebas dan menguasai 1 (satu) cabang olahraga tim.'),
  ('BAN-20', 'Bantara', 20, 'Dapat menjelaskan perkembangan fisik laki-laki dan perempuan.'),
  ('BAN-21', 'Bantara', 21, 'Dapat memimpin baris-berbaris dan menjelaskan peraturannya kepada anggota sangganya.'),
  ('BAN-22', 'Bantara', 22, 'Dapat menyebutkan beberapa penyakit infeksi, degeneratif dan penyakit yang disebabkan perilaku tidak sehat.'),
  ('BAN-23', 'Bantara', 23, 'Ikut serta dalam perkemahan selama 3 hari berturut-turut.'),
  ('LAK-01', 'Laksana', 1, 'Sesuai agama yang dianut (ketakwaan)'),
  ('LAK-02', 'Laksana', 2, 'Dapat menerima kritik orang lain, serta berani mengeluarkan pendapatnya dengan tertib, sopan dan santun kepada orang-orang di sekitarnya.'),
  ('LAK-03', 'Laksana', 3, 'Dapat mengikuti atau memimpin diskusi Ambalan dan mampu mengambil keputusan.'),
  ('LAK-04', 'Laksana', 4, 'Dapat menjadi penengah (memberi solusi), jika terjadi ketidaksepahaman dalam kelompoknya.'),
  ('LAK-05', 'Laksana', 5, 'Mengikuti pertemuan Ambalan sekurang-kurangnya 3 kali setiap bulan.'),
  ('LAK-06', 'Laksana', 6, 'Setia membayar iuran kepada gugus depannya, dengan uang yang diperoleh dari usaha sendiri, serta membantu Ambalan dalam mengelola administrasi keuangan.'),
  ('LAK-07', 'Laksana', 7, 'Dapat memimpin rapat dan membuat risalah dengan baik.'),
  ('LAK-08', 'Laksana', 8, 'Pernah memimpin kegiatan di tingkat Ambalan.'),
  ('LAK-09', 'Laksana', 9, 'Pernah memimpin kerja bakti di masyarakat minimal 2 kali.'),
  ('LAK-10', 'Laksana', 10, 'Dapat memimpin kelompok dalam menampilkan salah satu jenis kesenian daerah.'),
  ('LAK-11', 'Laksana', 11, 'Dapat menjelaskan isi AD & ART Gerakan Pramuka kepada Ambalan.'),
  ('LAK-12', 'Laksana', 12, 'Dapat menjelaskan di muka umum tentang sejarah kepramukaan Indonesia dan dunia.'),
  ('LAK-13', 'Laksana', 13, 'Dapat melakukan pengembaraan selama 3 hari dan atau mengatur kehidupan perkemahan selama minimal 3 hari.'),
  ('LAK-14', 'Laksana', 14, 'Dapat menjelaskan sejarah, arti, tatacara penggunaan dan kiasan Sang Merah Putih.'),
  ('LAK-15', 'Laksana', 15, 'Dapat menjelaskan peran Indonesia dalam organisasi ASEAN dan PBB.'),
  ('LAK-16', 'Laksana', 16, 'Telah memiliki keterampilan kewirausahaan yang dapat menghasilkan uang.'),
  ('LAK-17', 'Laksana', 17, 'Dapat membuat salah satu jenis peralatan teknologi tepat guna.'),
  ('LAK-18', 'Laksana', 18, 'Secara berkelompok dapat membuat struktur dari keterampilan tali temali dan pionering, yang dapat digunakan masyarakat.'),
  ('LAK-19', 'Laksana', 19, 'Selalu berolahraga. Dapat melakukan olahraga renang selain gaya bebas dan menguasai 1 (satu) cabang olahraga lainnya.'),
  ('LAK-20', 'Laksana', 20, 'Dapat memahami dan menjelaskan tentang kesehatan reproduksi.'),
  ('LAK-21', 'Laksana', 21, 'Dapat mempersiapkan dan melaksanakan upacara umum minimal 3 kali.'),
  ('LAK-22', 'Laksana', 22, 'Dapat menyebutkan penyebab dan cara pencegahan penyakit infeksi, degeneratif dan penyakit yang disebabkan perilaku tidak sehat.'),
  ('MUL-01', 'Mula', 1, 'Sesuai agama yang dianut (ketakwaan)'),
  ('MUL-02', 'Mula', 2, 'Dapat menghafal Dwisatya dan Dwidarma.'),
  ('MUL-03', 'Mula', 3, 'Dapat menyebutkan jenis-jenis Salam Pramuka.'),
  ('MUL-04', 'Mula', 4, 'Telah memiliki buku tabungan, sekurang-kurangnya dalam waktu 6 minggu terakhir.'),
  ('MUL-05', 'Mula', 5, 'Setia membayar uang iuran kepada gugus depannya, sedapat-dapatnya dengan uang yang diperoleh dari usahanya sendiri.'),
  ('MUL-06', 'Mula', 6, 'Dapat menyebutkan lambang Gerakan Pramuka dan penciptanya.'),
  ('MUL-07', 'Mula', 7, 'Dapat menyebutkan salah satu seni budaya di daerah tempat tinggalnya.'),
  ('MUL-08', 'Mula', 8, 'Selalu bersikap hemat dan cermat dengan segala miliknya.'),
  ('MUL-09', 'Mula', 9, 'Dapat menyebutkan identitas diri dan keluarganya.'),
  ('MUL-10', 'Mula', 10, 'Dapat membedakan perbuatan baik dan perbuatan buruk.'),
  ('MUL-11', 'Mula', 11, 'Rajin dan giat mengikuti latihan perindukan Siaga, sekurang-kurangnya 6 kali latihan berturut-turut.'),
  ('MUL-12', 'Mula', 12, 'Dapat dengan hafal menyanyikan lagu kebangsaan Indonesia Raya bait pertama di depan perindukannya.'),
  ('MUL-13', 'Mula', 13, 'Dapat menyebutkan arti kiasan warna Sang Merah Putih.'),
  ('MUL-14', 'Mula', 14, 'Dapat menyebutkan sedikitnya 3 hari besar nasional dan 3 hari besar keagamaan.'),
  ('MUL-15', 'Mula', 15, 'Dapat menyebutkan 5 peraturan keluarga.'),
  ('MUL-16', 'Mula', 16, 'Dapat menyebutkan 3 peraturan di lingkungannya.'),
  ('MUL-17', 'Mula', 17, 'Dapat menyebutkan 2 macam adat/budaya di lingkungannya.'),
  ('MUL-18', 'Mula', 18, 'Dapat menyampaikan ucapan dengan baik dan sopan serta hormat kepada orang tua, sesama teman, dan orang lain.'),
  ('MUL-19', 'Mula', 19, 'Dapat menyebutkan nama dan alamat Ketua RT, Ketua RW, Lurah, dan Camat di sekitar tempat tinggalnya.'),
  ('MUL-20', 'Mula', 20, 'Dapat menyebutkan sila-sila Pancasila.'),
  ('MUL-21', 'Mula', 21, 'Dapat mengumpulkan keterangan untuk memperoleh pertolongan pertama pada kecelakaan dan dapat menginformasikan kepada orang dewasa di sekitarnya.'),
  ('MUL-22', 'Mula', 22, 'Dapat membaca jam digital dan analog.'),
  ('MUL-23', 'Mula', 23, 'Dapat menunjukkan 4 arah mata angin.'),
  ('MUL-24', 'Mula', 24, 'Dapat berbahasa Indonesia dalam mengikuti pertemuan-pertemuan Siaga.'),
  ('MUL-25', 'Mula', 25, 'Dapat menyebutkan sedikitnya 2 macam alat komunikasi tradisional dan modern.'),
  ('MUL-26', 'Mula', 26, 'Dapat menyebutkan organ tubuh.'),
  ('MUL-27', 'Mula', 27, 'Dapat menyebutkan gerakan dasar olahraga.'),
  ('MUL-28', 'Mula', 28, 'Dapat melipat selimut dan merapikan tempat tidurnya.'),
  ('MUL-29', 'Mula', 29, 'Selalu berpakaian rapi dan memelihara kebersihan pribadi.'),
  ('MUL-30', 'Mula', 30, 'Dapat menjalankan latihan-latihan keseimbangan, dapat melempar dan menerima bola dengan tangan kanan dan kiri sedikitnya 5 kali tangkapan.'),
  ('MUL-31', 'Mula', 31, 'Dapat menyebutkan makanan dan minuman yang bergizi (4 sehat 5 sempurna).'),
  ('MUL-32', 'Mula', 32, 'Dapat memelihara sedikitnya satu macam tanaman berguna, atau satu jenis binatang ternak, selama kira-kira 1 bulan.'),
  ('MUL-33', 'Mula', 33, 'Dapat melipat kertas yang dibentuk menyerupai pesawat, kapal, flora, dan fauna.'),
  ('MUL-34', 'Mula', 34, 'Dapat membuat simpul mati, simpul hidup, simpul anyam, simpul pangkal, dan simpul jangkar.'),
  ('BNU-01', 'Bantu', 1, 'Sesuai agama yang dianut (ketakwaan)'),
  ('BNU-02', 'Bantu', 2, 'Dapat melaksanakan Dwisatya dan Dwidarma.'),
  ('BNU-03', 'Bantu', 3, 'Dapat melakukan Salam Pramuka dengan benar.'),
  ('BNU-04', 'Bantu', 4, 'Telah memiliki buku tabungan dan sudah menabung uang secara teratur dalam buku tabungannya selama sekurang-kurangnya 8 minggu sejak menjadi Siaga Mula, yang diperoleh dari usahanya sendiri.'),
  ('BNU-05', 'Bantu', 5, 'Setia membayar uang iuran kepada gugus depan dengan uang yang sebagian diperoleh dari usahanya sendiri.'),
  ('BNU-06', 'Bantu', 6, 'Dapat menyebutkan arti lambang Gerakan Pramuka.'),
  ('BNU-07', 'Bantu', 7, 'Dapat menyebutkan sedikitnya 5 macam seni budaya yang ada di Indonesia.'),
  ('BNU-08', 'Bantu', 8, 'Untuk putri: dapat memasang buah baju dan menyalakan kompor/alat sejenis lainnya. Untuk putra: dapat membuat hasta karya dengan dua macam bahan yang berbeda.'),
  ('BNU-09', 'Bantu', 9, 'Dapat menyampaikan pendapat tentang lingkungan sekitarnya.'),
  ('BNU-10', 'Bantu', 10, 'Dapat memperhatikan dan melaksanakan nasihat orang tua, yanda dan bunda, serta gurunya.'),
  ('BNU-11', 'Bantu', 11, 'Rajin dan giat mengikuti latihan perindukan sebagai Siaga Mula sekurang-kurangnya 8 kali latihan.'),
  ('BNU-12', 'Bantu', 12, 'Dapat memperlihatkan sikap yang harus dilakukan jika lagu kebangsaan diperdengarkan atau dinyanyikan pada suatu upacara.'),
  ('BNU-13', 'Bantu', 13, 'Dapat memperlihatkan cara mengibarkan dan menyimpan bendera merah putih pada upacara pembukaan dan penutupan latihan.'),
  ('BNU-14', 'Bantu', 14, 'Dapat menyebutkan sedikitnya 6 hari besar nasional dan 5 orang nama pahlawan nasional.'),
  ('BNU-15', 'Bantu', 15, 'Dapat mengikuti acara-acara adat/budaya di lingkungan tempat tinggalnya.'),
  ('BNU-16', 'Bantu', 16, 'Dapat menyebutkan 3 peraturan di lingkungan tempat tinggalnya.'),
  ('BNU-17', 'Bantu', 17, 'Dapat menjadi contoh yang baik bagi temannya.'),
  ('BNU-18', 'Bantu', 18, 'Dapat menyebutkan nama kota/kabupaten, ibukota provinsi, dan kepala daerahnya, negara, ibukota negara, kepala negara dan wakilnya.'),
  ('BNU-19', 'Bantu', 19, 'Dapat menyebutkan sila-sila Pancasila sesuai dengan lambangnya.'),
  ('BNU-20', 'Bantu', 20, 'Dapat mengumpulkan keterangan untuk memperoleh pertolongan pertama pada kecelakaan dan dapat menginformasikan kepada petugas Puskesmas/rumah sakit/polisi.'),
  ('BNU-21', 'Bantu', 21, 'Dapat menyebutkan perbedaan jam digital dan jam analog serta dapat memperkirakan waktu tanpa bantuan alat.'),
  ('BNU-22', 'Bantu', 22, 'Dapat menunjukkan 8 arah mata angin.'),
  ('BNU-23', 'Bantu', 23, 'Dapat menyampaikan berita secara lisan dengan menggunakan bahasa Indonesia.'),
  ('BNU-24', 'Bantu', 24, 'Dapat menggunakan alat komunikasi tradisional dan modern.'),
  ('BNU-25', 'Bantu', 25, 'Dapat menyebutkan fungsi organ tubuh.'),
  ('BNU-26', 'Bantu', 26, 'Dapat melakukan gerakan dasar olahraga.'),
  ('BNU-27', 'Bantu', 27, 'Dapat mencuci, menjemur, melipat, dan menyimpan pakaiannya dengan rapi.'),
  ('BNU-28', 'Bantu', 28, 'Dapat memelihara kebersihan salah satu ruangan di rumah, sekolah, tempat ibadah, dan tempat lainnya.'),
  ('BNU-29', 'Bantu', 29, 'Dapat melakukan senam Pramuka.'),
  ('BNU-30', 'Bantu', 30, 'Dapat menunjukkan bahan-bahan makanan yang bergizi.'),
  ('BNU-31', 'Bantu', 31, 'Dapat memelihara sedikitnya satu macam tanaman yang berguna, atau satu jenis binatang ternak, selama kira-kira 2 bulan.'),
  ('BNU-32', 'Bantu', 32, 'Dapat membuat satu macam hasta karya dari barang bekas.'),
  ('BNU-33', 'Bantu', 33, 'Dapat menggunakan simpul mati, simpul hidup, simpul anyam, simpul pangkal, dan simpul jangkar.'),
  ('TAT-01', 'Tata', 1, 'Sesuai agama yang dianut (ketakwaan)'),
  ('TAT-02', 'Tata', 2, 'Dapat mengajak temannya untuk mengamalkan Dwisatya dan Dwidarma.'),
  ('TAT-03', 'Tata', 3, 'Dapat menjelaskan tentang Salam Pramuka kepada teman sebarungnya.'),
  ('TAT-04', 'Tata', 4, 'Telah memiliki buku tabungan dan sudah menabung uang secara teratur dalam buku tabungannya selama sekurang-kurangnya 12 minggu sejak menjadi Siaga Bantu. Seluruh atau sebagian dari uang itu diperoleh dari usahanya sendiri.'),
  ('TAT-05', 'Tata', 5, 'Setia membayar uang iuran kepada gugus depan dengan uang yang diperoleh dari usahanya sendiri.'),
  ('TAT-06', 'Tata', 6, 'Dapat membuat lambang Gerakan Pramuka dari bahan yang ada.'),
  ('TAT-07', 'Tata', 7, 'Dapat memperagakan satu macam kegiatan seni budaya asal daerahnya.'),
  ('TAT-08', 'Tata', 8, 'Telah memiliki sedikitnya 5 tanda kecakapan khusus.'),
  ('TAT-09', 'Tata', 9, 'Dapat mengkritisi sesuatu masalah dengan baik.'),
  ('TAT-10', 'Tata', 10, 'Dapat menolong seseorang dan peduli terhadap lingkungan sekitarnya.'),
  ('TAT-11', 'Tata', 11, 'Rajin dan giat mengikuti latihan perindukan sebagai Siaga Bantu sekurang-kurangnya 12 kali latihan.'),
  ('TAT-12', 'Tata', 12, 'Dapat menceritakan sejarah Lagu Kebangsaan Indonesia Raya.'),
  ('TAT-13', 'Tata', 13, 'Dapat menceritakan sejarah bendera kebangsaan Indonesia dan tahu sikap yang harus dilakukan pada waktu bendera kebangsaan dikibarkan atau diturunkan serta dapat memelihara bendera kebangsaan.'),
  ('TAT-14', 'Tata', 14, 'Dapat menyebutkan sedikitnya 7 hari besar nasional, 4 hari besar dunia, dan 10 nama pahlawan nasional.'),
  ('TAT-15', 'Tata', 15, 'Dapat menyebutkan akibat melanggar peraturan di keluarga, barung, perindukan, dan sekolah.'),
  ('TAT-16', 'Tata', 16, 'Dapat menyebutkan akibat melanggar adat/budaya di lingkungannya.'),
  ('TAT-17', 'Tata', 17, 'Dapat mengajak temannya berbuat baik dan berkata benar.'),
  ('TAT-18', 'Tata', 18, 'Dapat menyebutkan negara-negara ASEAN dan menunjukkan bendera kebangsaannya.'),
  ('TAT-19', 'Tata', 19, 'Dapat menyebutkan perbuatan yang baik sesuai dengan sila-sila Pancasila.'),
  ('TAT-20', 'Tata', 20, 'Dapat mengumpulkan keterangan untuk memperoleh pertolongan pertama pada kecelakaan dan menyampaikan kepada dokter, rumah sakit, polisi, dan keluarga korban.'),
  ('TAT-21', 'Tata', 21, 'Dapat menceritakan dasar terjadinya perbedaan waktu yang ada di wilayah Indonesia.'),
  ('TAT-22', 'Tata', 22, 'Dapat menunjuk 8 macam arah mata angin dengan menggunakan kompas.'),
  ('TAT-23', 'Tata', 23, 'Dapat menulis surat kepada teman atau saudaranya dengan menggunakan bahasa Indonesia.'),
  ('TAT-24', 'Tata', 24, 'Dapat merawat peralatan elektronik, peralatan listrik, dan alat komunikasi yang ada di rumahnya.'),
  ('TAT-25', 'Tata', 25, 'Dapat memelihara organ tubuh.'),
  ('TAT-26', 'Tata', 26, 'Dapat melakukan olahraga secara tim.'),
  ('TAT-27', 'Tata', 27, 'Dapat mencuci peralatan dapur.'),
  ('TAT-28', 'Tata', 28, 'Dapat memelihara kebersihan halaman di rumah, sekolah, tempat ibadah, atau di tempat lainnya.'),
  ('TAT-29', 'Tata', 29, 'Dapat melakukan salah satu cabang olahraga atletik atau salah satu gaya cabang olahraga renang.'),
  ('TAT-30', 'Tata', 30, 'Dapat menyebutkan 5 macam penyakit menular.'),
  ('TAT-31', 'Tata', 31, 'Dapat memelihara sedikitnya dua macam tanaman berguna, atau satu jenis binatang ternak, selama kira-kira 4 bulan.'),
  ('TAT-32', 'Tata', 32, 'Dapat membuat 2 (dua) macam hasta karya dengan bahan yang berbeda.'),
  ('TAT-33', 'Tata', 33, 'Dapat membuat sedikitnya 2 (dua) macam ikatan.');

insert into public.sku_unit (id, butir_id, tingkat, butir_no, agama, sub) values
  ('BAN-01-BUD-1', 'BAN-01', 'Bantara', 1, 'Buddha', 1),
  ('BAN-01-BUD-2', 'BAN-01', 'Bantara', 1, 'Buddha', 2),
  ('BAN-01-BUD-3', 'BAN-01', 'Bantara', 1, 'Buddha', 3),
  ('BAN-01-BUD-4', 'BAN-01', 'Bantara', 1, 'Buddha', 4),
  ('BAN-01-BUD-5', 'BAN-01', 'Bantara', 1, 'Buddha', 5),
  ('BAN-01-HIN-1', 'BAN-01', 'Bantara', 1, 'Hindu', 1),
  ('BAN-01-HIN-2', 'BAN-01', 'Bantara', 1, 'Hindu', 2),
  ('BAN-01-HIN-3', 'BAN-01', 'Bantara', 1, 'Hindu', 3),
  ('BAN-01-HIN-4', 'BAN-01', 'Bantara', 1, 'Hindu', 4),
  ('BAN-01-HIN-5', 'BAN-01', 'Bantara', 1, 'Hindu', 5),
  ('BAN-01-HIN-6', 'BAN-01', 'Bantara', 1, 'Hindu', 6),
  ('BAN-01-HIN-7', 'BAN-01', 'Bantara', 1, 'Hindu', 7),
  ('BAN-01-ISL-1', 'BAN-01', 'Bantara', 1, 'Islam', 1),
  ('BAN-01-ISL-2', 'BAN-01', 'Bantara', 1, 'Islam', 2),
  ('BAN-01-ISL-3', 'BAN-01', 'Bantara', 1, 'Islam', 3),
  ('BAN-01-ISL-4', 'BAN-01', 'Bantara', 1, 'Islam', 4),
  ('BAN-01-ISL-5', 'BAN-01', 'Bantara', 1, 'Islam', 5),
  ('BAN-01-ISL-6', 'BAN-01', 'Bantara', 1, 'Islam', 6),
  ('BAN-01-KAT-1', 'BAN-01', 'Bantara', 1, 'Katolik', 1),
  ('BAN-01-KAT-2', 'BAN-01', 'Bantara', 1, 'Katolik', 2),
  ('BAN-01-KHO-1', 'BAN-01', 'Bantara', 1, 'Khonghucu', 1),
  ('BAN-01-PRO-1', 'BAN-01', 'Bantara', 1, 'Protestan', 1),
  ('BAN-02', 'BAN-02', 'Bantara', 2, null, null),
  ('BAN-03', 'BAN-03', 'Bantara', 3, null, null),
  ('BAN-04', 'BAN-04', 'Bantara', 4, null, null),
  ('BAN-05', 'BAN-05', 'Bantara', 5, null, null),
  ('BAN-06', 'BAN-06', 'Bantara', 6, null, null),
  ('BAN-07', 'BAN-07', 'Bantara', 7, null, null),
  ('BAN-08', 'BAN-08', 'Bantara', 8, null, null),
  ('BAN-09', 'BAN-09', 'Bantara', 9, null, null),
  ('BAN-10', 'BAN-10', 'Bantara', 10, null, null),
  ('BAN-11', 'BAN-11', 'Bantara', 11, null, null),
  ('BAN-12', 'BAN-12', 'Bantara', 12, null, null),
  ('BAN-13', 'BAN-13', 'Bantara', 13, null, null),
  ('BAN-14', 'BAN-14', 'Bantara', 14, null, null),
  ('BAN-15', 'BAN-15', 'Bantara', 15, null, null),
  ('BAN-16', 'BAN-16', 'Bantara', 16, null, null),
  ('BAN-17', 'BAN-17', 'Bantara', 17, null, null),
  ('BAN-18', 'BAN-18', 'Bantara', 18, null, null),
  ('BAN-19', 'BAN-19', 'Bantara', 19, null, null),
  ('BAN-20', 'BAN-20', 'Bantara', 20, null, null),
  ('BAN-21', 'BAN-21', 'Bantara', 21, null, null),
  ('BAN-22', 'BAN-22', 'Bantara', 22, null, null),
  ('BAN-23', 'BAN-23', 'Bantara', 23, null, null),
  ('BNU-01-BUD-1', 'BNU-01', 'Bantu', 1, 'Buddha', 1),
  ('BNU-01-BUD-2', 'BNU-01', 'Bantu', 1, 'Buddha', 2),
  ('BNU-01-BUD-3', 'BNU-01', 'Bantu', 1, 'Buddha', 3),
  ('BNU-01-HIN-1', 'BNU-01', 'Bantu', 1, 'Hindu', 1),
  ('BNU-01-HIN-2', 'BNU-01', 'Bantu', 1, 'Hindu', 2),
  ('BNU-01-HIN-3', 'BNU-01', 'Bantu', 1, 'Hindu', 3),
  ('BNU-01-HIN-4', 'BNU-01', 'Bantu', 1, 'Hindu', 4),
  ('BNU-01-HIN-5', 'BNU-01', 'Bantu', 1, 'Hindu', 5),
  ('BNU-01-HIN-6', 'BNU-01', 'Bantu', 1, 'Hindu', 6),
  ('BNU-01-HIN-7', 'BNU-01', 'Bantu', 1, 'Hindu', 7),
  ('BNU-01-ISL-1', 'BNU-01', 'Bantu', 1, 'Islam', 1),
  ('BNU-01-ISL-2', 'BNU-01', 'Bantu', 1, 'Islam', 2),
  ('BNU-01-ISL-3', 'BNU-01', 'Bantu', 1, 'Islam', 3),
  ('BNU-01-ISL-4', 'BNU-01', 'Bantu', 1, 'Islam', 4),
  ('BNU-01-ISL-5', 'BNU-01', 'Bantu', 1, 'Islam', 5),
  ('BNU-01-ISL-6', 'BNU-01', 'Bantu', 1, 'Islam', 6),
  ('BNU-01-KAT-1', 'BNU-01', 'Bantu', 1, 'Katolik', 1),
  ('BNU-01-KAT-2', 'BNU-01', 'Bantu', 1, 'Katolik', 2),
  ('BNU-01-KAT-3', 'BNU-01', 'Bantu', 1, 'Katolik', 3),
  ('BNU-01-KAT-4', 'BNU-01', 'Bantu', 1, 'Katolik', 4),
  ('BNU-01-KHO-1', 'BNU-01', 'Bantu', 1, 'Khonghucu', 1),
  ('BNU-01-PRO-1', 'BNU-01', 'Bantu', 1, 'Protestan', 1),
  ('BNU-01-PRO-2', 'BNU-01', 'Bantu', 1, 'Protestan', 2),
  ('BNU-01-PRO-3', 'BNU-01', 'Bantu', 1, 'Protestan', 3),
  ('BNU-01-PRO-4', 'BNU-01', 'Bantu', 1, 'Protestan', 4),
  ('BNU-01-PRO-5', 'BNU-01', 'Bantu', 1, 'Protestan', 5),
  ('BNU-01-PRO-6', 'BNU-01', 'Bantu', 1, 'Protestan', 6),
  ('BNU-02', 'BNU-02', 'Bantu', 2, null, null),
  ('BNU-03', 'BNU-03', 'Bantu', 3, null, null),
  ('BNU-04', 'BNU-04', 'Bantu', 4, null, null),
  ('BNU-05', 'BNU-05', 'Bantu', 5, null, null),
  ('BNU-06', 'BNU-06', 'Bantu', 6, null, null),
  ('BNU-07', 'BNU-07', 'Bantu', 7, null, null),
  ('BNU-08', 'BNU-08', 'Bantu', 8, null, null),
  ('BNU-09', 'BNU-09', 'Bantu', 9, null, null),
  ('BNU-10', 'BNU-10', 'Bantu', 10, null, null),
  ('BNU-11', 'BNU-11', 'Bantu', 11, null, null),
  ('BNU-12', 'BNU-12', 'Bantu', 12, null, null),
  ('BNU-13', 'BNU-13', 'Bantu', 13, null, null),
  ('BNU-14', 'BNU-14', 'Bantu', 14, null, null),
  ('BNU-15', 'BNU-15', 'Bantu', 15, null, null),
  ('BNU-16', 'BNU-16', 'Bantu', 16, null, null),
  ('BNU-17', 'BNU-17', 'Bantu', 17, null, null),
  ('BNU-18', 'BNU-18', 'Bantu', 18, null, null),
  ('BNU-19', 'BNU-19', 'Bantu', 19, null, null),
  ('BNU-20', 'BNU-20', 'Bantu', 20, null, null),
  ('BNU-21', 'BNU-21', 'Bantu', 21, null, null),
  ('BNU-22', 'BNU-22', 'Bantu', 22, null, null),
  ('BNU-23', 'BNU-23', 'Bantu', 23, null, null),
  ('BNU-24', 'BNU-24', 'Bantu', 24, null, null),
  ('BNU-25', 'BNU-25', 'Bantu', 25, null, null),
  ('BNU-26', 'BNU-26', 'Bantu', 26, null, null),
  ('BNU-27', 'BNU-27', 'Bantu', 27, null, null),
  ('BNU-28', 'BNU-28', 'Bantu', 28, null, null),
  ('BNU-29', 'BNU-29', 'Bantu', 29, null, null),
  ('BNU-30', 'BNU-30', 'Bantu', 30, null, null),
  ('BNU-31', 'BNU-31', 'Bantu', 31, null, null),
  ('BNU-32', 'BNU-32', 'Bantu', 32, null, null),
  ('BNU-33', 'BNU-33', 'Bantu', 33, null, null),
  ('LAK-01-BUD-1', 'LAK-01', 'Laksana', 1, 'Buddha', 1),
  ('LAK-01-BUD-2', 'LAK-01', 'Laksana', 1, 'Buddha', 2),
  ('LAK-01-BUD-3', 'LAK-01', 'Laksana', 1, 'Buddha', 3),
  ('LAK-01-BUD-4', 'LAK-01', 'Laksana', 1, 'Buddha', 4),
  ('LAK-01-BUD-5', 'LAK-01', 'Laksana', 1, 'Buddha', 5),
  ('LAK-01-HIN-1', 'LAK-01', 'Laksana', 1, 'Hindu', 1),
  ('LAK-01-HIN-2', 'LAK-01', 'Laksana', 1, 'Hindu', 2),
  ('LAK-01-HIN-3', 'LAK-01', 'Laksana', 1, 'Hindu', 3),
  ('LAK-01-HIN-4', 'LAK-01', 'Laksana', 1, 'Hindu', 4),
  ('LAK-01-HIN-5', 'LAK-01', 'Laksana', 1, 'Hindu', 5),
  ('LAK-01-HIN-6', 'LAK-01', 'Laksana', 1, 'Hindu', 6),
  ('LAK-01-HIN-7', 'LAK-01', 'Laksana', 1, 'Hindu', 7),
  ('LAK-01-ISL-1', 'LAK-01', 'Laksana', 1, 'Islam', 1),
  ('LAK-01-ISL-2', 'LAK-01', 'Laksana', 1, 'Islam', 2),
  ('LAK-01-ISL-3', 'LAK-01', 'Laksana', 1, 'Islam', 3),
  ('LAK-01-ISL-4', 'LAK-01', 'Laksana', 1, 'Islam', 4),
  ('LAK-01-ISL-5', 'LAK-01', 'Laksana', 1, 'Islam', 5),
  ('LAK-01-ISL-6', 'LAK-01', 'Laksana', 1, 'Islam', 6),
  ('LAK-01-KAT-1', 'LAK-01', 'Laksana', 1, 'Katolik', 1),
  ('LAK-01-KAT-2', 'LAK-01', 'Laksana', 1, 'Katolik', 2),
  ('LAK-01-KAT-3', 'LAK-01', 'Laksana', 1, 'Katolik', 3),
  ('LAK-01-KHO-1', 'LAK-01', 'Laksana', 1, 'Khonghucu', 1),
  ('LAK-01-PRO-1', 'LAK-01', 'Laksana', 1, 'Protestan', 1),
  ('LAK-01-PRO-2', 'LAK-01', 'Laksana', 1, 'Protestan', 2),
  ('LAK-01-PRO-3', 'LAK-01', 'Laksana', 1, 'Protestan', 3),
  ('LAK-02', 'LAK-02', 'Laksana', 2, null, null),
  ('LAK-03', 'LAK-03', 'Laksana', 3, null, null),
  ('LAK-04', 'LAK-04', 'Laksana', 4, null, null),
  ('LAK-05', 'LAK-05', 'Laksana', 5, null, null),
  ('LAK-06', 'LAK-06', 'Laksana', 6, null, null),
  ('LAK-07', 'LAK-07', 'Laksana', 7, null, null),
  ('LAK-08', 'LAK-08', 'Laksana', 8, null, null),
  ('LAK-09', 'LAK-09', 'Laksana', 9, null, null),
  ('LAK-10', 'LAK-10', 'Laksana', 10, null, null),
  ('LAK-11', 'LAK-11', 'Laksana', 11, null, null),
  ('LAK-12', 'LAK-12', 'Laksana', 12, null, null),
  ('LAK-13', 'LAK-13', 'Laksana', 13, null, null),
  ('LAK-14', 'LAK-14', 'Laksana', 14, null, null),
  ('LAK-15', 'LAK-15', 'Laksana', 15, null, null),
  ('LAK-16', 'LAK-16', 'Laksana', 16, null, null),
  ('LAK-17', 'LAK-17', 'Laksana', 17, null, null),
  ('LAK-18', 'LAK-18', 'Laksana', 18, null, null),
  ('LAK-19', 'LAK-19', 'Laksana', 19, null, null),
  ('LAK-20', 'LAK-20', 'Laksana', 20, null, null),
  ('LAK-21', 'LAK-21', 'Laksana', 21, null, null),
  ('LAK-22', 'LAK-22', 'Laksana', 22, null, null),
  ('MUL-01-BUD-1', 'MUL-01', 'Mula', 1, 'Buddha', 1),
  ('MUL-01-BUD-2', 'MUL-01', 'Mula', 1, 'Buddha', 2),
  ('MUL-01-BUD-3', 'MUL-01', 'Mula', 1, 'Buddha', 3),
  ('MUL-01-HIN-1', 'MUL-01', 'Mula', 1, 'Hindu', 1),
  ('MUL-01-HIN-2', 'MUL-01', 'Mula', 1, 'Hindu', 2),
  ('MUL-01-HIN-3', 'MUL-01', 'Mula', 1, 'Hindu', 3),
  ('MUL-01-HIN-4', 'MUL-01', 'Mula', 1, 'Hindu', 4),
  ('MUL-01-HIN-5', 'MUL-01', 'Mula', 1, 'Hindu', 5),
  ('MUL-01-ISL-1', 'MUL-01', 'Mula', 1, 'Islam', 1),
  ('MUL-01-ISL-2', 'MUL-01', 'Mula', 1, 'Islam', 2),
  ('MUL-01-ISL-3', 'MUL-01', 'Mula', 1, 'Islam', 3),
  ('MUL-01-ISL-4', 'MUL-01', 'Mula', 1, 'Islam', 4),
  ('MUL-01-ISL-5', 'MUL-01', 'Mula', 1, 'Islam', 5),
  ('MUL-01-ISL-6', 'MUL-01', 'Mula', 1, 'Islam', 6),
  ('MUL-01-ISL-7', 'MUL-01', 'Mula', 1, 'Islam', 7),
  ('MUL-01-KAT-1', 'MUL-01', 'Mula', 1, 'Katolik', 1),
  ('MUL-01-KAT-2', 'MUL-01', 'Mula', 1, 'Katolik', 2),
  ('MUL-01-KAT-3', 'MUL-01', 'Mula', 1, 'Katolik', 3),
  ('MUL-01-KAT-4', 'MUL-01', 'Mula', 1, 'Katolik', 4),
  ('MUL-01-KAT-5', 'MUL-01', 'Mula', 1, 'Katolik', 5),
  ('MUL-01-KHO-1', 'MUL-01', 'Mula', 1, 'Khonghucu', 1),
  ('MUL-01-PRO-1', 'MUL-01', 'Mula', 1, 'Protestan', 1),
  ('MUL-01-PRO-2', 'MUL-01', 'Mula', 1, 'Protestan', 2),
  ('MUL-01-PRO-3', 'MUL-01', 'Mula', 1, 'Protestan', 3),
  ('MUL-01-PRO-4', 'MUL-01', 'Mula', 1, 'Protestan', 4),
  ('MUL-01-PRO-5', 'MUL-01', 'Mula', 1, 'Protestan', 5),
  ('MUL-02', 'MUL-02', 'Mula', 2, null, null),
  ('MUL-03', 'MUL-03', 'Mula', 3, null, null),
  ('MUL-04', 'MUL-04', 'Mula', 4, null, null),
  ('MUL-05', 'MUL-05', 'Mula', 5, null, null),
  ('MUL-06', 'MUL-06', 'Mula', 6, null, null),
  ('MUL-07', 'MUL-07', 'Mula', 7, null, null),
  ('MUL-08', 'MUL-08', 'Mula', 8, null, null),
  ('MUL-09', 'MUL-09', 'Mula', 9, null, null),
  ('MUL-10', 'MUL-10', 'Mula', 10, null, null),
  ('MUL-11', 'MUL-11', 'Mula', 11, null, null),
  ('MUL-12', 'MUL-12', 'Mula', 12, null, null),
  ('MUL-13', 'MUL-13', 'Mula', 13, null, null),
  ('MUL-14', 'MUL-14', 'Mula', 14, null, null),
  ('MUL-15', 'MUL-15', 'Mula', 15, null, null),
  ('MUL-16', 'MUL-16', 'Mula', 16, null, null),
  ('MUL-17', 'MUL-17', 'Mula', 17, null, null),
  ('MUL-18', 'MUL-18', 'Mula', 18, null, null),
  ('MUL-19', 'MUL-19', 'Mula', 19, null, null),
  ('MUL-20', 'MUL-20', 'Mula', 20, null, null),
  ('MUL-21', 'MUL-21', 'Mula', 21, null, null),
  ('MUL-22', 'MUL-22', 'Mula', 22, null, null),
  ('MUL-23', 'MUL-23', 'Mula', 23, null, null),
  ('MUL-24', 'MUL-24', 'Mula', 24, null, null),
  ('MUL-25', 'MUL-25', 'Mula', 25, null, null),
  ('MUL-26', 'MUL-26', 'Mula', 26, null, null),
  ('MUL-27', 'MUL-27', 'Mula', 27, null, null),
  ('MUL-28', 'MUL-28', 'Mula', 28, null, null),
  ('MUL-29', 'MUL-29', 'Mula', 29, null, null),
  ('MUL-30', 'MUL-30', 'Mula', 30, null, null),
  ('MUL-31', 'MUL-31', 'Mula', 31, null, null),
  ('MUL-32', 'MUL-32', 'Mula', 32, null, null),
  ('MUL-33', 'MUL-33', 'Mula', 33, null, null),
  ('MUL-34', 'MUL-34', 'Mula', 34, null, null),
  ('TAT-01-BUD-1', 'TAT-01', 'Tata', 1, 'Buddha', 1),
  ('TAT-01-BUD-2', 'TAT-01', 'Tata', 1, 'Buddha', 2),
  ('TAT-01-BUD-3', 'TAT-01', 'Tata', 1, 'Buddha', 3),
  ('TAT-01-HIN-1', 'TAT-01', 'Tata', 1, 'Hindu', 1),
  ('TAT-01-HIN-2', 'TAT-01', 'Tata', 1, 'Hindu', 2),
  ('TAT-01-HIN-3', 'TAT-01', 'Tata', 1, 'Hindu', 3),
  ('TAT-01-HIN-4', 'TAT-01', 'Tata', 1, 'Hindu', 4),
  ('TAT-01-HIN-5', 'TAT-01', 'Tata', 1, 'Hindu', 5),
  ('TAT-01-HIN-6', 'TAT-01', 'Tata', 1, 'Hindu', 6),
  ('TAT-01-HIN-7', 'TAT-01', 'Tata', 1, 'Hindu', 7),
  ('TAT-01-ISL-1', 'TAT-01', 'Tata', 1, 'Islam', 1),
  ('TAT-01-ISL-2', 'TAT-01', 'Tata', 1, 'Islam', 2),
  ('TAT-01-ISL-3', 'TAT-01', 'Tata', 1, 'Islam', 3),
  ('TAT-01-ISL-4', 'TAT-01', 'Tata', 1, 'Islam', 4),
  ('TAT-01-KAT-1', 'TAT-01', 'Tata', 1, 'Katolik', 1),
  ('TAT-01-KAT-2', 'TAT-01', 'Tata', 1, 'Katolik', 2),
  ('TAT-01-KAT-3', 'TAT-01', 'Tata', 1, 'Katolik', 3),
  ('TAT-01-KAT-4', 'TAT-01', 'Tata', 1, 'Katolik', 4),
  ('TAT-01-KAT-5', 'TAT-01', 'Tata', 1, 'Katolik', 5),
  ('TAT-01-KHO-1', 'TAT-01', 'Tata', 1, 'Khonghucu', 1),
  ('TAT-01-PRO-1', 'TAT-01', 'Tata', 1, 'Protestan', 1),
  ('TAT-01-PRO-2', 'TAT-01', 'Tata', 1, 'Protestan', 2),
  ('TAT-01-PRO-3', 'TAT-01', 'Tata', 1, 'Protestan', 3),
  ('TAT-01-PRO-4', 'TAT-01', 'Tata', 1, 'Protestan', 4),
  ('TAT-01-PRO-5', 'TAT-01', 'Tata', 1, 'Protestan', 5),
  ('TAT-02', 'TAT-02', 'Tata', 2, null, null),
  ('TAT-03', 'TAT-03', 'Tata', 3, null, null),
  ('TAT-04', 'TAT-04', 'Tata', 4, null, null),
  ('TAT-05', 'TAT-05', 'Tata', 5, null, null),
  ('TAT-06', 'TAT-06', 'Tata', 6, null, null),
  ('TAT-07', 'TAT-07', 'Tata', 7, null, null),
  ('TAT-08', 'TAT-08', 'Tata', 8, null, null),
  ('TAT-09', 'TAT-09', 'Tata', 9, null, null),
  ('TAT-10', 'TAT-10', 'Tata', 10, null, null),
  ('TAT-11', 'TAT-11', 'Tata', 11, null, null),
  ('TAT-12', 'TAT-12', 'Tata', 12, null, null),
  ('TAT-13', 'TAT-13', 'Tata', 13, null, null),
  ('TAT-14', 'TAT-14', 'Tata', 14, null, null),
  ('TAT-15', 'TAT-15', 'Tata', 15, null, null),
  ('TAT-16', 'TAT-16', 'Tata', 16, null, null),
  ('TAT-17', 'TAT-17', 'Tata', 17, null, null),
  ('TAT-18', 'TAT-18', 'Tata', 18, null, null),
  ('TAT-19', 'TAT-19', 'Tata', 19, null, null),
  ('TAT-20', 'TAT-20', 'Tata', 20, null, null),
  ('TAT-21', 'TAT-21', 'Tata', 21, null, null),
  ('TAT-22', 'TAT-22', 'Tata', 22, null, null),
  ('TAT-23', 'TAT-23', 'Tata', 23, null, null),
  ('TAT-24', 'TAT-24', 'Tata', 24, null, null),
  ('TAT-25', 'TAT-25', 'Tata', 25, null, null),
  ('TAT-26', 'TAT-26', 'Tata', 26, null, null),
  ('TAT-27', 'TAT-27', 'Tata', 27, null, null),
  ('TAT-28', 'TAT-28', 'Tata', 28, null, null),
  ('TAT-29', 'TAT-29', 'Tata', 29, null, null),
  ('TAT-30', 'TAT-30', 'Tata', 30, null, null),
  ('TAT-31', 'TAT-31', 'Tata', 31, null, null),
  ('TAT-32', 'TAT-32', 'Tata', 32, null, null),
  ('TAT-33', 'TAT-33', 'Tata', 33, null, null);

insert into public.pf_item (id) values
  ('PF-01'),
  ('PF-02'),
  ('PF-03'),
  ('PF-04'),
  ('PF-05'),
  ('PF-06'),
  ('PF-07'),
  ('PF-08'),
  ('PF-09'),
  ('PF-10'),
  ('PF-11'),
  ('PF-12'),
  ('PF-13'),
  ('PF-14'),
  ('PF-15'),
  ('PF-16'),
  ('PF-17'),
  ('PF-18'),
  ('PF-19'),
  ('PF-20'),
  ('PF-21'),
  ('PF-22'),
  ('PF-23'),
  ('PF-24'),
  ('PF-25'),
  ('PF-26');

insert into public.tkk_katalog (id, nama, bidang, golongan, agama, sumber, urut) values
  ('sholat', 'Sholat', 1, 'penegak', 'Islam', 'skk-132-1979', 1),
  ('khotib', 'Khotib', 1, 'penegak', 'Islam', 'skk-132-1979', 2),
  ('qori', 'Qori', 1, 'penegak', 'Islam', 'skk-132-1979', 3),
  ('muadzin', 'Muadzin', 1, 'penegak', 'Islam', 'skk-132-1979', 4),
  ('penabung', 'Penabung', 1, 'penegak', null, 'skk-132-1979', 5),
  ('cakap-keuangan', 'Cakap Keuangan', 1, 'penegak', null, 'penabung-01-2024', 6),
  ('pengatur-ruangan', 'Pengatur Ruangan', 2, 'siaga', null, 'skk-132-1979', 7),
  ('pengatur-rumah', 'Pengatur Rumah', 2, 'penegak', null, 'skk-132-1979', 8),
  ('pengatur-meja-makan', 'Pengatur Meja Makan', 2, 'penegak', null, 'skk-132-1979', 9),
  ('pemimpin-menyanyi', 'Pemimpin Menyanyi', 2, 'penegak', null, 'skk-132-1979', 10),
  ('menyanyi', 'Menyanyi', 2, 'penegak', null, 'skk-132-1979', 11),
  ('pelukis', 'Pelukis', 2, 'penegak', null, 'skk-132-1979', 12),
  ('juru-gambar', 'Juru Gambar', 2, 'penegak', null, 'skk-132-1979', 13),
  ('pengarang', 'Pengarang', 2, 'penegak', null, 'skk-132-1979', 14),
  ('pembaca', 'Pembaca', 2, 'penegak', null, 'tambahan', 15),
  ('gerak-jalan', 'Gerak Jalan', 3, 'penegak', null, 'skk-132-1979', 16),
  ('pengamat', 'Pengamat', 3, 'penegak', null, 'skk-132-1979', 17),
  ('penyelidik', 'Penyelidik', 3, 'penegak', null, 'skk-132-1979', 18),
  ('perenang', 'Perenang', 3, 'penegak', null, 'skk-132-1979', 19),
  ('juru-layar', 'Juru Layar', 3, 'penegak', null, 'skk-132-1979', 20),
  ('juru-selam', 'Juru Selam', 3, 'penegak', null, 'skk-132-1979', 21),
  ('pendayung', 'Pendayung', 3, 'penegak', null, 'skk-132-1979', 22),
  ('ski-air', 'Ski Air', 3, 'penegak', null, 'skk-132-1979', 23),
  ('pencak-silat', 'Pencak Silat', 3, 'penegak', null, 'tambahan', 24),
  ('peternak-ulat-sutera', 'Peternak Ulat Sutera', 4, 'penegak', null, 'skk-132-1979', 25),
  ('peternak-kelinci', 'Peternak Kelinci', 4, 'penegak', null, 'skk-132-1979', 26),
  ('peternak-lebah', 'Peternak Lebah', 4, 'penegak', null, 'skk-132-1979', 27),
  ('juru-kebun', 'Juru Kebun', 4, 'penegak', null, 'skk-132-1979', 28),
  ('penenun', 'Penenun', 4, 'penegak', null, 'skk-132-1979', 29),
  ('juru-bambu', 'Juru Bambu', 4, 'penegak', null, 'skk-132-1979', 30),
  ('juru-anyam', 'Juru Anyam', 4, 'penegak', null, 'skk-132-1979', 31),
  ('juru-kayu', 'Juru Kayu', 4, 'penegak', null, 'skk-132-1979', 32),
  ('juru-batu', 'Juru Batu', 4, 'penegak', null, 'skk-132-1979', 33),
  ('juru-logam', 'Juru Logam', 4, 'penegak', null, 'skk-132-1979', 34),
  ('juru-kulit', 'Juru Kulit', 4, 'penegak', null, 'skk-132-1979', 35),
  ('penjilid-buku', 'Penjilid Buku', 4, 'penegak', null, 'skk-132-1979', 36),
  ('juru-potret', 'Juru Potret', 4, 'penegak', null, 'skk-132-1979', 37),
  ('penangkap-ikan', 'Penangkap Ikan', 4, 'penegak', null, 'skk-132-1979', 38),
  ('peternak-itik', 'Peternak Itik', 4, 'penegak', null, 'skk-132-1979', 39),
  ('peternak-ayam', 'Peternak Ayam', 4, 'penegak', null, 'skk-132-1979', 40),
  ('pemelihara-ternak', 'Pemelihara Ternak', 4, 'penegak', null, 'skk-132-1979', 41),
  ('pemelihara-merpati', 'Pemelihara Merpati', 4, 'penegak', null, 'skk-132-1979', 42),
  ('pengumpul', 'Pengumpul (khusus Siaga)', 4, 'siaga', null, 'skk-132-1979', 43),
  ('pengumpul-perangko', 'Pengumpul Perangko', 4, 'penegak', null, 'skk-132-1979', 44),
  ('pengumpul-lencana', 'Pengumpul Lencana', 4, 'penegak', null, 'skk-132-1979', 45),
  ('pengumpul-mata-uang', 'Pengumpul Mata Uang', 4, 'penegak', null, 'skk-132-1979', 46),
  ('pengumpul-tanaman-kering', 'Pengumpul Tanaman Kering', 4, 'penegak', null, 'skk-132-1979', 47),
  ('pengumpul-tanaman-hidup', 'Pengumpul Tanaman Hidup', 4, 'penegak', null, 'skk-132-1979', 48),
  ('pengumpul-benda', 'Pengumpul Benda', 4, 'penegak', null, 'skk-132-1979', 49),
  ('pengumpul-hewan', 'Pengumpul Hewan (Kering/Basah)', 4, 'penegak', null, 'skk-132-1979', 50),
  ('juru-semboyan', 'Juru Semboyan', 4, 'penegak', null, 'skk-132-1979', 51),
  ('menjahit', 'Menjahit', 4, 'penegak', null, 'skk-132-1979', 52),
  ('pengendara-sepeda', 'Pengendara Sepeda', 4, 'penegak', null, 'skk-132-1979', 53),
  ('juru-masak', 'Juru Masak', 4, 'penegak', null, 'skk-132-1979', 54),
  ('pencinta-dirgantara', 'Pencinta Dirgantara', 4, 'penegak', null, 'skk-132-1979', 55),
  ('pembuat-pesawat-model', 'Pembuat Pesawat Model', 4, 'penegak', null, 'skk-132-1979', 56),
  ('pengenal-cuaca', 'Pengenal Cuaca', 4, 'penegak', null, 'skk-132-1979', 57),
  ('komunikasi', 'Komunikasi', 4, 'penegak', null, 'skk-132-1979', 58),
  ('konstruksi-pesawat-udara', 'Konstruksi Pesawat Udara', 4, 'penegak', null, 'skk-132-1979', 59),
  ('juru-motor-pesawat-terbang', 'Juru Motor Pesawat Terbang', 4, 'penegak', null, 'skk-132-1979', 60),
  ('navigasi-udara', 'Navigasi Udara', 4, 'penegak', null, 'skk-132-1979', 61),
  ('evakuasi-medis-dirgantara', 'Evakuasi Medis Dirgantara', 4, 'penegak', null, 'skk-132-1979', 62),
  ('pengenal-pesawat-terbang', 'Pengenal Pesawat Terbang', 4, 'penegak', null, 'skk-132-1979', 63),
  ('petani-padi', 'Petani Padi', 4, 'penegak', null, 'skk-132-1979', 64),
  ('juru-peta', 'Juru Peta', 4, 'penegak', null, 'skk-132-1979', 65),
  ('navigasi-laut', 'Navigasi Laut', 4, 'penegak', null, 'skk-132-1979', 66),
  ('juru-isyarat-bendera', 'Juru Isyarat Bendera', 4, 'penegak', null, 'skk-132-1979', 67),
  ('pelaut', 'Pelaut', 4, 'penegak', null, 'skk-132-1979', 68),
  ('juru-isyarat-listrik', 'Juru Isyarat Listrik', 4, 'penegak', null, 'skk-132-1979', 69),
  ('juru-isyarat-optik', 'Juru Isyarat Optik', 4, 'penegak', null, 'skk-132-1979', 70),
  ('perencana-kapal', 'Perencana Kapal', 4, 'penegak', null, 'skk-132-1979', 71),
  ('perahu-motor', 'Perahu Motor', 4, 'penegak', null, 'skk-132-1979', 72),
  ('berkemah', 'Berkemah', 4, 'penegak', null, 'tambahan', 73),
  ('pengembara', 'Pengembara', 4, 'penegak', null, 'tambahan', 74),
  ('penjelajah', 'Penjelajah', 4, 'penegak', null, 'tambahan', 75),
  ('pemadam-kebakaran', 'Pemadam Kebakaran', 5, 'penegak', null, 'skk-132-1979', 76),
  ('pengaman-lalu-lintas', 'Pengaman Lalu Lintas', 5, 'penegak', null, 'skk-132-1979', 77),
  ('pengamanan-kampung', 'Pengamanan Kampung/Desa', 5, 'penegak', null, 'skk-132-1979', 78),
  ('penunjuk-jalan', 'Penunjuk Jalan', 5, 'penegak', null, 'skk-132-1979', 79),
  ('juru-bahasa', 'Juru Bahasa', 5, 'penegak', null, 'skk-132-1979', 80),
  ('pembantu-ibu', 'Pembantu Ibu', 5, 'siaga', null, 'skk-132-1979', 81),
  ('perawatan-anak', 'Perawatan Anak', 5, 'penegak', null, 'skk-132-1979', 82),
  ('perawatan-keluarga', 'Perawatan Keluarga', 5, 'penegak', null, 'skk-132-1979', 83),
  ('penerima-tamu', 'Penerima Tamu', 5, 'penegak', null, 'skk-132-1979', 84),
  ('juru-penerang', 'Juru Penerang', 5, 'penegak', null, 'skk-132-1979', 85),
  ('korespondensi', 'Korespondensi', 5, 'penegak', null, 'skk-132-1979', 86),
  ('pppk', 'PPPK (Pertolongan Pertama Pada Kecelakaan)', 5, 'penegak', null, 'skk-132-1979', 87),
  ('pembantu-penyuluh-padi', 'Pembantu Penyuluh Padi', 5, 'penegak', null, 'skk-132-1979', 88),
  ('keadaan-darurat-penerbangan', 'Keadaan Darurat Penerbangan', 5, 'penegak', null, 'skk-132-1979', 89),
  ('keadaan-darurat-laut', 'Keadaan Darurat Laut', 5, 'penegak', null, 'skk-132-1979', 90),
  ('penghijauan', 'Penghijauan', 5, 'penegak', null, 'tambahan', 91);

notify pgrst, 'reload schema';
